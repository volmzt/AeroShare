# `:transfer` — final API notes for the app layer

The `:transfer` module is pure Kotlin/JVM (Android API 26 compatible). It is verified by 142 JUnit tests that run the real TLS
engine over loopback (`./gradlew :transfer:test`). This file lists what was added to the original skeleton and the behaviour the
app layer (service, coordinator, UI) has to know. Source of truth is always the code in `transfer/src/main/kotlin`.

## Additions to the skeleton (nothing was removed or renamed)

| Where | Addition |
|---|---|
| `proto/Messages.kt` | `HelloAck.showsCode` (extra trailing byte of HELLO_ACK: the receiver displays a verification code), `ReplyCode.STORAGE_ERROR = 6` (receiver could not open its storage) |
| `queue/Queue.kt` | `TransferQueue(scope, runner, clock = System::currentTimeMillis)` — injectable clock |
| `engine/` | `ProgressMeter`, `CompressionPolicy`, `ChunkDeflater/ChunkInflater` (internal), `ConnectionSession` base class (internal), `TransferSender`, `ReceiverServer` |
| `storage/` | `StagedIncomingStorage` (abstract: staging + resume ledger, subclasses only implement the destination), `FileIncomingStorage` (java.io.File destination), `StagedIncomingStorage.purgeOlderThan(partsDir, cutoffMillis)` |
| `proto/Wire.kt` | frame reader/writer and message primitives (internal use; the app never speaks the protocol itself) |

## How the app uses the engine

```kotlin
// Receiving (one server for the whole process, owned by the foreground service / coordinator)
val server = ReceiverServer(identity, local = { localPeer }, config = { engineConfig }, policy = peerPolicy,
    tokens = pairTokenRegistry, storageProvider = { destinationResolver.storage() }, listener = incomingListener, logger = ...)
val port: Int = server.start(preferredPort = 47474)      // suspend; falls back to an ephemeral port, returns the bound port
server.stop()

// Sending (one TransferSender per identity; the queue runs jobs strictly one at a time)
val sender = TransferSender(identity, localPeer, engineConfig, logger)
val result: TransferResult = sender.send(SendTarget(host, port, expectedFingerprint, pairToken, TransportKind.LAN, connector),
    SendRequest(transferId, files /* List<SendableFile> */, title, CompressionMode.SMART), control, tracker)
```

* `TransferQueue<P>` wraps the sender: `enqueue(QueuedJob(id, payload, tracker, control))`, `cancel/pause/resume/retry/remove`, `snapshots: StateFlow<List<TransferSnapshot>>`.
* The UI only observes `TransferTracker.state` (a `StateFlow<TransferSnapshot>`) and calls `TransferControl.pause()/resume()/cancel()`.
* `IncomingListener.onOffer` is called on an engine thread and may suspend until the user decided (the engine applies
  `EngineConfig.acceptTimeoutMs`; on expiry the sender gets TIMEOUT). `onSession` hands over the tracker/control of an accepted
  transfer; `onRejected` is diagnostics only (blocked device, bad QR token, version mismatch).
* Failures are enums (`TransferFailure`); `TransferSnapshot.failureDetail` is short and never contains file names, keys or tokens.

## Behaviour the app layer must respect

1. **Resume is automatic and keyed per peer.** Partial files are stored in the staging directory under
   `partsDir/<first 16 hex of sha256(peerFingerprint)>/` and matched by *relative path + size + last-modified*. A **new** transfer
   (new `transferId`, even after an app restart) of the same files from the same device continues where the last attempt stopped:
   the receiver reports `(offset, sha256 of the stored prefix)` per file, the sender re-hashes its own prefix and only continues when
   both are identical (otherwise that file restarts at 0). Completed files of the earlier attempt are skipped via a ledger.
   `IncomingOffer.isResume` / `resumeBytes` tell the UI that data is already there.
2. **Auto-accepting resumes.** Partial data can only exist for a peer the user already accepted once. The coordinator should record
   every accepted peer (`devices.upsertSeen`) and may accept an `isResume` offer without another dialog **only** when
   `offer.trust` is `TRUSTED` or `KNOWN` (same fingerprint). Anything else (first contact, changed key) always asks the user.
   Trusted devices are auto-accepted only when the setting is on (default off).
3. **A new connection from the same peer replaces a stale one.** After a silent network drop the receiver may still hold the old
   connection; a new connection from the same fingerprint supersedes it. The old receive session then ends `INTERRUPTED`
   (`resumable = true`, partial data kept). Connections from other devices get `BUSY` while a transfer is active.
4. **Final states.** Sender: `COMPLETED` only after every file was verified by the receiver; `FAILED(INTEGRITY)` on any hash mismatch;
   `INTERRUPTED(resumable)` when the link dies mid-transfer; `CANCELLED` when the local user cancelled. Receiver: sender cancel is
   `FAILED(PEER_CANCELLED)` and the partial data is deleted; receiver cancel is `CANCELLED` and the sender sees `FAILED(PEER_CANCELLED)`.
5. **Pause** holds the connection (the TCP window closes, PING frames keep it alive). After `EngineConfig.pauseTimeoutMs` the
   connection is closed and the transfer becomes `INTERRUPTED` (resumable); `retry`/a new send continues.
6. **First contact** (no pin, device unknown): both sides show the same 6-digit code (`TransferSnapshot.verificationCode` on the sender,
   `IncomingOffer.verificationCode` on the receiver). With a QR token or a pinned fingerprint no code is needed (`authenticatedByQr`).
7. **Storage backends** extend `StagedIncomingStorage` (incoming bytes always go to private staging files first, so resume works for
   every destination) and implement only `destinationFreeBytes()`, `destinationLabel()` and `publish(entry, stagedFile, sha256)`.
   `publish` must apply the conflict policy itself, never write outside its destination and return a `SavedFile` with a usable URI.
   Decorating an `IncomingTransferStore` is allowed, but `commit` must receive the **same `PartWriter` instance** that `createPart` /
   `reopenPart` returned (unwrap your wrapper first).
8. **Sources** implement `SendableFile`: `open(offset)` must not read the whole file into memory; `currentVersion()` (size + mtime) lets the
   engine detect that a file changed while sending (`SOURCE_CHANGED`); return `null` when the file vanished (`SOURCE_UNREADABLE`).
9. **Paths from peers** are sanitized by `PathSafety`; two different names that become identical after sanitizing (`a:b.txt`, `a_b.txt`)
   are both kept (`a_b.txt`, `a_b (1).txt`).
10. **Large files**: sizes/offsets are `Long` everywhere, buffers are bounded by `EngineConfig.chunkSize`; a 2.3 GiB file and a resume from an
    offset beyond 2 GiB are covered by tests (`EngineHugeFileTest`).
11. **Cancel is announced before the connection goes away.** When the user cancels, the cancelling side writes a CANCEL frame and then keeps
    the connection open (reading and discarding) until the peer has closed its end, which the peer does as soon as it has read the frame,
    or until `CANCEL_LINGER_MS` (1 s) has passed. Closing at once let a peer that was still writing hit a broken pipe, or never see the frame,
    and then report a lost connection (`INTERRUPTED`, partial data kept) instead of the cancel. Consequence for the app layer: after
    `TransferControl.cancel()` the tracker shows `CANCELLED` immediately, but `send()` / the receive session's `completion` can take up to
    about a second longer to finish when the other device does not answer.

## Test inventory (`./gradlew :transfer:test`, 142 tests)

Security/TLS/X.509 (identity restore, pin match/mismatch, SAS), `PathSafety`, QR payload + pair tokens, state machine, queue (10),
staged storage, wire format (frame limits, truncation, codecs), compression (round trip, bomb cap, policy), progress/ETA,
engine loopback (multi-file + folder tree with SHA-256 equality), failures (decline, busy, blocked, wrong pin, QR token once/expired,
unreachable, silent peer, unanswered offer, no space, changed source, cancel on either side, and 25 repeated rounds of a cancel by
each side to prove the other side always sees the cancel), resume (interrupted, changed source,
ledger skip, supersede, pause/resume on either side, long pause), protocol abuse (traversal, inconsistent manifests, corrupted
content, more data than declared, unknown/oversized frames, wrong device id, unauthenticated TLS client), a fake receiver for the
sender side, 1500-file manifest, Unicode names, empty files, 2.3 GiB streaming transfer and resume beyond 2 GiB.
