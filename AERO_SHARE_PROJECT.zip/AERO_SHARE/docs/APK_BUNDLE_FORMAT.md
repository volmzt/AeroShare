# AERO split-APK bundle (`.aeroapks`)

Modern Android apps are often installed from several APK files: `base.apk` plus split APKs for the processor type, the
screen density and the language. To share such an app between two phones, AERO SHARE packs these files into one file with
the extension `.aeroapks` and unpacks it on the receiving side while installing. Apps that have only a base APK are sent
as an ordinary `.apk` file.

## Container

A standard ZIP file. The entries are written **without compression** (deflate level 0; APKs are already compressed), in
this order:

| # | Entry name | Content |
|---|------------|---------|
| 1 | `aero-app.json` | Informational manifest (UTF-8 JSON, at most 64 KiB) |
| 2 | `base.apk` | The base APK of the app. Required. |
| 3… | `split_<name>.apk` | The split APKs, with the file names they have on the sending device |

Names must match `base.apk` or `split_[A-Za-z0-9._-]{1,100}.apk`. Entries with any other name (directories, paths with
`/` or `..`, other files) are ignored and never written anywhere. A bundle has at most 128 splits and no duplicate names.

## Manifest (`aero-app.json`)

```json
{
  "format": 1,
  "package": "com.example.app",
  "versionName": "1.2.3",
  "versionCode": 123,
  "label": "Example",
  "splits": ["split_config.arm64_v8a.apk", "split_config.xxhdpi.apk"]
}
```

* `format` must be `1`; other values make the manifest unreadable (the bundle is then shown with a warning).
* The manifest is **informational only**. The installer trusts nothing but the APK files: the package name, version and
  signing certificates shown to the user come from `base.apk` itself. If the manifest names another package than
  `base.apk`, the bundle is flagged as invalid.

## What the receiver does

1. **Inspect** (before the user decides): streams the bundle once, computes SHA-256 of the whole file, reads the manifest,
   copies `base.apk` to the cache (packages above 1 GiB, or a full cache, get only the hash), reads package name,
   version, icon, signing certificates, minimum Android version and compares them with an installed copy of the same
   package. A warning is raised when the signer differs (`SIGNER_MISMATCH`), the version is older (`DOWNGRADE`), the
   package needs a newer Android (`MIN_SDK_TOO_HIGH`), the bundle is damaged (`INVALID`), or it has ABI splits but none
   for a processor type of this device (`INCOMPLETE_SPLITS`).
2. **Install** (only after the user taps *Install*): opens a `PackageInstaller` session (`MODE_FULL_INSTALL`) and streams
   each valid APK entry into it; Android then shows its own confirmation window. Nothing is installed silently.

Density and language splits that are missing are not an error: Android falls back to the base resources.

## Limits and notes

* The format is specific to AERO SHARE. Bundles from other tools (`.apks`, `.xapk`, `.apkm`) are not supported.
* Only the splits installed on the *sending* device are included. A bundle made on an arm64 phone cannot be installed
  on a 32-bit-only phone; the inspection warns about this.
* Android 11+ lets an app see only some other installed apps, so the comparison with an installed copy works for apps
  that have a launcher icon. If the package is not visible, the check is skipped and the system installer still refuses
  a conflicting update.
* Installation needs the user to allow *Install unknown apps* for AERO SHARE in the system settings.
* The inspection is **not** malware scanning.
