package com.aero.share.transfer

import com.aero.share.domain.FileItem
import com.aero.share.domain.HistoryFile
import com.aero.share.domain.HistoryItem
import com.aero.share.domain.HistoryStatus
import com.aero.share.domain.PendingIncoming
import com.aero.share.domain.SelectionItem
import com.aero.share.transfer.model.TransferDirection
import com.aero.share.transfer.model.TransferFailure
import com.aero.share.transfer.model.TransferSnapshot
import com.aero.share.transfer.model.TransferState

/** Turns finished transfers into history rows. Pure functions, so they are covered by unit tests. */
internal object HistoryMapper {
    /**
     * Sent transfers use their own random id. Received ones use an id that came from the other device, so it is reduced to
     * safe characters (it ends up in navigation routes) and prefixed so it can never collide with a sent transfer.
     */
    fun idFor(direction: TransferDirection, transferId: String): String = when (direction) {
        TransferDirection.SEND -> transferId
        TransferDirection.RECEIVE -> "in-" + safeId(transferId)
    }

    private fun safeId(raw: String): String {
        val kept = raw.filter { it.isLetterOrDigit() || it == '-' }.take(64)
        return kept.ifEmpty { "x" }
    }

    /** Null for transfers that are still running or that never started (cancelled while waiting in the queue). */
    fun fromSnapshot(s: TransferSnapshot, sentItems: List<SelectionItem>?, now: Long): HistoryItem? {
        val status: HistoryStatus
        val failure: TransferFailure?
        when (s.state) {
            TransferState.COMPLETED -> {
                status = HistoryStatus.COMPLETED
                failure = null
            }
            TransferState.CANCELLED -> {
                if (s.startedAt <= 0L) return null
                status = HistoryStatus.CANCELLED
                failure = null
            }
            TransferState.FAILED -> {
                status = HistoryStatus.FAILED
                failure = s.failure ?: TransferFailure.INTERNAL
            }
            TransferState.INTERRUPTED -> {
                status = HistoryStatus.FAILED
                failure = s.failure ?: TransferFailure.INTERRUPTED
            }
            else -> return null
        }
        val finished = s.finishedAt
        val duration = if (finished != null && s.startedAt > 0L) finished - s.startedAt else s.elapsedMillis
        val files: List<HistoryFile> = when (s.direction) {
            TransferDirection.SEND -> sentItems.orEmpty().map { item ->
                HistoryFile(
                    name = item.displayName,
                    size = item.size.coerceAtLeast(0L),
                    uri = null,
                    mimeType = (item as? FileItem)?.mimeType,
                    category = item.category,
                )
            }
            TransferDirection.RECEIVE -> s.savedFiles.map { saved ->
                HistoryFile(
                    name = saved.displayName,
                    size = saved.size,
                    uri = saved.uri,
                    mimeType = saved.mimeType,
                    category = saved.category,
                )
            }
        }
        val peer = s.peer
        val peerName = DisplayText.clean(s.peerName).ifEmpty { peer?.name?.let { DisplayText.clean(it) } ?: "" }
        return HistoryItem(
            id = idFor(s.direction, s.id),
            direction = s.direction,
            timestamp = finished ?: now,
            peerName = peerName,
            peerId = peer?.deviceId,
            fileCount = s.totalFiles,
            completedFiles = s.completedFiles,
            totalBytes = s.totalBytes,
            transferredBytes = s.transferredBytes,
            durationMillis = duration.coerceAtLeast(0L),
            status = status,
            failure = failure,
            transport = s.transport,
            files = files,
        )
    }

    /** An incoming request that the user declined or that timed out. */
    fun declined(pending: PendingIncoming, failure: TransferFailure, peerId: String?, now: Long): HistoryItem = HistoryItem(
        id = idFor(TransferDirection.RECEIVE, pending.transferId),
        direction = TransferDirection.RECEIVE,
        timestamp = now,
        peerName = pending.peerName,
        peerId = peerId,
        fileCount = pending.fileCount,
        completedFiles = 0,
        totalBytes = pending.totalBytes,
        transferredBytes = 0L,
        durationMillis = 0L,
        status = HistoryStatus.CANCELLED,
        failure = failure,
        transport = pending.transport,
        files = emptyList(),
    )
}
