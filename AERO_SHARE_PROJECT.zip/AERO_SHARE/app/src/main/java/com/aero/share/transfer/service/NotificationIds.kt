package com.aero.share.transfer.service

/**
 * Notification ids. Incoming-request and result notifications are told apart by their tag (the transfer id), so each
 * transfer has at most one notification of each kind.
 */
internal object NotificationIds {
    const val FOREGROUND = 4101
    const val INCOMING = 4102
    const val RESULT = 4103
}
