package com.aero.share.core.database

import com.aero.share.domain.DeviceRecord
import com.aero.share.domain.DeviceRepository
import com.aero.share.transfer.model.PeerInfo
import com.aero.share.transfer.model.PeerTrust
import com.aero.share.transfer.model.TransportKind
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/**
 * Known devices in Room plus an in-memory snapshot used by [trustOf], which the transfer engine calls from its own
 * threads. Writes update the snapshot immediately, so a block or un-trust takes effect before the next connection.
 */
class RoomDeviceRepository(
    db: AeroDatabase,
    scope: CoroutineScope,
) : DeviceRepository {
    private val dao = db.devices()
    private val lock = Any()
    private val loaded = CountDownLatch(1)

    @Volatile
    private var snapshot: Map<String, DeviceRecord> = emptyMap()

    override val devices: Flow<List<DeviceRecord>> = dao.observeAll().map { list -> list.map { it.toRecord() } }

    init {
        scope.launch(Dispatchers.IO) {
            dao.observeAll().collect { list ->
                synchronized(lock) { snapshot = list.associate { it.deviceId to it.toRecord() } }
                loaded.countDown()
            }
        }
    }

    override suspend fun find(deviceId: String): DeviceRecord? = dao.find(deviceId)?.toRecord()

    override suspend fun upsertSeen(peer: PeerInfo, address: String?, transport: TransportKind?) {
        val now = System.currentTimeMillis()
        val existing = dao.find(peer.deviceId)?.toRecord()
        val record = if (existing == null) {
            DeviceRecord(
                deviceId = peer.deviceId,
                name = peer.name,
                alias = null,
                kind = peer.kind,
                model = null,
                fingerprint = peer.fingerprint,
                firstSeen = now,
                lastSeen = now,
                trusted = false,
                blocked = false,
                capabilities = peer.capabilities,
                lastAddress = address,
                lastTransport = transport,
            )
        } else {
            // A different key under the same id is never merged into an existing (possibly trusted) record.
            if (existing.fingerprint != peer.fingerprint) return
            existing.copy(
                name = peer.name,
                kind = peer.kind,
                lastSeen = now,
                capabilities = peer.capabilities,
                lastAddress = address ?: existing.lastAddress,
                lastTransport = transport ?: existing.lastTransport,
            )
        }
        dao.upsert(DeviceEntity.from(record))
        remember(record)
    }

    override suspend fun rename(deviceId: String, alias: String?) {
        val clean = alias?.trim()?.take(MAX_ALIAS)?.takeIf { it.isNotEmpty() }
        dao.setAlias(deviceId, clean)
        update(deviceId) { it.copy(alias = clean) }
    }

    override suspend fun setTrusted(deviceId: String, trusted: Boolean) {
        dao.setTrusted(deviceId, trusted)
        update(deviceId) { it.copy(trusted = trusted) }
    }

    override suspend fun setBlocked(deviceId: String, blocked: Boolean) {
        dao.setBlocked(deviceId, blocked)
        update(deviceId) { it.copy(blocked = blocked) }
    }

    override suspend fun forget(deviceId: String) {
        dao.delete(deviceId)
        synchronized(lock) { snapshot = snapshot - deviceId }
    }

    override fun trustOf(deviceId: String, fingerprint: String): PeerTrust {
        // The first database emission normally arrives within milliseconds of start-up; never answer from an empty snapshot before.
        if (loaded.count > 0L) loaded.await(LOAD_WAIT_SECONDS, TimeUnit.SECONDS)
        return TrustRules.trustOf(snapshot, deviceId, fingerprint)
    }

    private fun remember(record: DeviceRecord) {
        synchronized(lock) { snapshot = snapshot + (record.deviceId to record) }
    }

    private fun update(deviceId: String, change: (DeviceRecord) -> DeviceRecord) {
        synchronized(lock) {
            val current = snapshot[deviceId] ?: return
            snapshot = snapshot + (deviceId to change(current))
        }
    }

    private companion object {
        const val MAX_ALIAS = 40
        const val LOAD_WAIT_SECONDS = 3L
    }
}
