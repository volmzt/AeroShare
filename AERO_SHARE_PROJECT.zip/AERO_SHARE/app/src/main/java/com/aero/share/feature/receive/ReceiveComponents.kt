package com.aero.share.feature.receive

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.QrCodeScanner
import androidx.compose.material.icons.rounded.WifiTethering
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.aero.share.R
import com.aero.share.core.designsystem.AeroBadge
import com.aero.share.core.designsystem.AeroButton
import com.aero.share.core.designsystem.AeroButtonStyle
import com.aero.share.core.designsystem.AeroCard
import com.aero.share.core.designsystem.AeroIcon
import com.aero.share.core.designsystem.AeroText
import com.aero.share.core.designsystem.AeroTheme
import com.aero.share.domain.ReceiverStatus

/** This device as others see it: its name, whether receiving is working, and whether it announces itself. */
@Composable
internal fun ReceiveStatusCard(ui: ReceiveUi, onRetry: () -> Unit) {
    val colors = AeroTheme.colors
    val statusText = when (ui.status) {
        ReceiverStatus.OFF -> stringResource(R.string.recv_status_off)
        ReceiverStatus.STARTING -> stringResource(R.string.recv_status_starting)
        ReceiverStatus.LISTENING -> stringResource(R.string.recv_status_listening)
        ReceiverStatus.ERROR -> stringResource(R.string.recv_status_error)
    }
    val statusColor = when (ui.status) {
        ReceiverStatus.LISTENING -> colors.success
        ReceiverStatus.ERROR -> colors.danger
        ReceiverStatus.OFF,
        ReceiverStatus.STARTING,
        -> colors.textSecondary
    }
    AeroCard(elevated = true) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconTile(icon = Icons.Rounded.WifiTethering, size = 56)
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                AeroText(text = ui.deviceName, style = AeroTheme.typography.titleSmall, maxLines = 2)
                AeroText(text = statusText, color = statusColor)
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            if (ui.visible) {
                AeroBadge(text = stringResource(R.string.recv_visibility_visible))
            } else {
                AeroBadge(text = stringResource(R.string.recv_visibility_hidden), color = colors.textSecondary)
            }
        }
        if (ui.status == ReceiverStatus.ERROR) {
            Spacer(Modifier.height(12.dp))
            AeroText(text = stringResource(R.string.recv_error_text), color = colors.textSecondary)
            Spacer(Modifier.height(12.dp))
            AeroButton(text = stringResource(R.string.common_retry), onClick = onRetry, style = AeroButtonStyle.Secondary)
        }
    }
}

/** Hidden mode only stops the announcements; the text says so and does not oversell it. */
@Composable
internal fun HiddenNote(onOpenSettings: () -> Unit) {
    AeroCard {
        Row(verticalAlignment = Alignment.Top) {
            AeroIcon(icon = Icons.Rounded.Info, contentDescription = null, tint = AeroTheme.colors.accentText, modifier = Modifier.padding(top = 2.dp))
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                AeroText(text = stringResource(R.string.recv_hidden_note))
                Spacer(Modifier.height(10.dp))
                AeroButton(
                    text = stringResource(R.string.recv_hidden_action),
                    onClick = onOpenSettings,
                    style = AeroButtonStyle.Secondary,
                )
            }
        }
    }
}

/** The big action: show a pairing code another device can scan. */
@Composable
internal fun QrActionCard(enabled: Boolean, onClick: () -> Unit) {
    AeroCard(
        modifier = Modifier.alpha(if (enabled) 1f else 0.5f),
        onClick = if (enabled) onClick else null,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconTile(icon = Icons.Rounded.QrCodeScanner, size = 48)
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                AeroText(text = stringResource(R.string.recv_qr_action), style = AeroTheme.typography.bodyStrong)
                AeroText(
                    text = stringResource(R.string.recv_qr_text),
                    style = AeroTheme.typography.caption,
                    color = AeroTheme.colors.textSecondary,
                )
            }
        }
    }
}

/** A title and a paragraph. */
@Composable
internal fun InfoCard(title: String, text: String) {
    AeroCard {
        AeroText(text = title, style = AeroTheme.typography.bodyStrong)
        Spacer(Modifier.height(4.dp))
        AeroText(text = text, color = AeroTheme.colors.textSecondary)
    }
}

/** For connecting by address: every local address with the port, in a fixed-width font so digits are easy to read out. */
@Composable
internal fun EndpointsCard(endpoints: List<String>) {
    AeroCard {
        AeroText(text = stringResource(R.string.recv_advanced_title), style = AeroTheme.typography.bodyStrong)
        Spacer(Modifier.height(4.dp))
        AeroText(text = stringResource(R.string.recv_advanced_text), color = AeroTheme.colors.textSecondary)
        Spacer(Modifier.height(8.dp))
        for (endpoint in endpoints) {
            AeroText(text = endpoint, style = AeroTheme.typography.mono, modifier = Modifier.padding(vertical = 2.dp))
        }
    }
}

@Composable
internal fun IconTile(icon: ImageVector, size: Int) {
    Box(
        modifier = Modifier
            .size(size.dp)
            .clip(RoundedCornerShape(AeroTheme.dimens.radiusSmall))
            .background(AeroTheme.colors.accentContainer),
        contentAlignment = Alignment.Center,
    ) {
        AeroIcon(icon = icon, contentDescription = null, tint = AeroTheme.colors.accentText, size = (size / 2).dp)
    }
}

@Composable
internal fun StopBar(busy: Boolean, onStop: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(AeroTheme.colors.surfaceElevated)
            .padding(horizontal = AeroTheme.dimens.screenPadding, vertical = 12.dp),
    ) {
        if (busy) {
            AeroText(
                text = stringResource(R.string.recv_stop_later),
                style = AeroTheme.typography.caption,
                color = AeroTheme.colors.textSecondary,
            )
            Spacer(Modifier.height(10.dp))
        }
        AeroButton(
            text = stringResource(R.string.recv_stop),
            onClick = onStop,
            modifier = Modifier.fillMaxWidth(),
            style = AeroButtonStyle.Secondary,
        )
    }
}
