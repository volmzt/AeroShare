package com.aero.share.feature.devices

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Devices
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.aero.share.R
import com.aero.share.core.common.SystemIntents
import com.aero.share.core.designsystem.AeroEmptyState
import com.aero.share.core.designsystem.AeroIconButton
import com.aero.share.core.designsystem.AeroScreen
import com.aero.share.core.designsystem.AeroSectionHeader
import com.aero.share.core.designsystem.AeroTheme
import com.aero.share.core.designsystem.AeroTopBar
import com.aero.share.core.permissions.Permissions
import com.aero.share.di.LocalAppContainer
import com.aero.share.domain.DiscoveryStatus
import com.aero.share.feature.home.DeviceCard
import com.aero.share.feature.home.HomeLogic
import com.aero.share.feature.home.NearbyEmpty
import com.aero.share.feature.home.NearbyHeader
import com.aero.share.navigation.AeroNavigator

/**
 * The Devices tab: what is nearby right now, and every device this one has talked to, with the person's decisions about
 * each (name, trusted, blocked). A tap opens the actions for that device.
 */
@Composable
fun DevicesScreen(navigator: AeroNavigator) {
    val container = LocalAppContainer.current
    val context = LocalContext.current
    val viewModel: DevicesViewModel = viewModel(factory = viewModelFactory { initializer { DevicesViewModel(container) } })
    val ui by viewModel.state.collectAsStateWithLifecycle()
    val settings by container.settings.settings.collectAsStateWithLifecycle()
    var selected by rememberSaveable { mutableStateOf<String?>(null) }
    var permissionDenied by rememberSaveable { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        permissionDenied = grants.values.any { granted -> !granted }
        viewModel.onPermissionResult()
    }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { viewModel.onResume() }
    LifecycleEventEffect(Lifecycle.Event.ON_PAUSE) { viewModel.onPause() }

    // "Last seen" is worked out when the list changes; it does not tick while nothing changes.
    val now = remember(ui) { System.currentTimeMillis() }
    val chosen = selected
    val target = if (chosen != null) ui.target(chosen) else null

    // The device disappeared (forgotten, or it left the network and was never stored): close its sheet.
    LaunchedEffect(chosen, target == null, ui.loaded) {
        if (chosen != null && target == null && ui.loaded) selected = null
    }

    AeroScreen {
        AeroTopBar(
            title = stringResource(R.string.nav_devices),
            actions = {
                AeroIconButton(
                    icon = Icons.Rounded.Refresh,
                    contentDescription = stringResource(R.string.dev_refresh),
                    onClick = { viewModel.searchNow() },
                )
            },
        )
        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = AeroTheme.dimens.screenPadding, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(AeroTheme.dimens.gap),
        ) {
            item(key = "visibility") {
                VisibilityCard(hidden = ui.hidden, onVisibleChange = { visible -> viewModel.setVisible(visible) })
            }
            item(key = "nearby-header") {
                NearbyHeader(
                    count = ui.nearby.size,
                    searching = ui.discovery.status == DiscoveryStatus.SEARCHING,
                    onRefresh = { viewModel.searchNow() },
                )
            }
            if (ui.nearby.isEmpty()) {
                val empty = HomeLogic.emptyState(
                    deviceCount = 0,
                    discovery = ui.discovery,
                    searchedLongEnough = ui.longSearch,
                    searchWanted = true,
                )
                if (empty != null) {
                    item(key = "nearby-empty") {
                        NearbyEmpty(
                            kind = empty,
                            permissionDenied = permissionDenied,
                            onSearch = { viewModel.searchNow() },
                            onWifiSettings = { SystemIntents.openWifiSettings(context) },
                            onAllow = { permissionLauncher.launch(Permissions.nearby()) },
                            onAppSettings = { SystemIntents.openAppSettings(context) },
                        )
                    }
                }
            } else {
                items(ui.nearby, key = { row -> "n:" + row.device.deviceId }) { row ->
                    DeviceCard(row) { selected = row.device.deviceId }
                }
            }
            item(key = "known-header") {
                AeroSectionHeader(text = stringResource(R.string.dev_known_title))
            }
            if (ui.loaded && ui.known.isEmpty()) {
                item(key = "known-empty") {
                    AeroEmptyState(
                        icon = Icons.Rounded.Devices,
                        title = stringResource(R.string.dev_known_empty_title),
                        message = stringResource(R.string.dev_known_empty_text),
                    )
                }
            } else {
                items(ui.known, key = { row -> "k:" + row.record.deviceId }) { row ->
                    KnownDeviceRow(row = row, now = now, onClick = { selected = row.record.deviceId })
                }
            }
        }
    }

    if (target != null) {
        DeviceActionsSheet(
            target = target,
            autoAcceptTrusted = settings.autoAcceptTrusted,
            onDismiss = { selected = null },
            onSend = { device ->
                selected = null
                viewModel.prepareSend(device)
                navigator.openSendPicker()
            },
            onRename = { text -> viewModel.rename(target.deviceId, text) },
            onSetTrusted = { trusted -> viewModel.setTrusted(target.deviceId, trusted) },
            onSetBlocked = { blocked -> viewModel.setBlocked(target.deviceId, blocked) },
            onForget = { viewModel.forget(target.deviceId) },
        )
    }
}
