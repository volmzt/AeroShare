package com.aero.share.feature.home

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.aero.share.R
import com.aero.share.core.common.Formatters
import com.aero.share.core.common.labelRes
import com.aero.share.core.designsystem.AeroBadge
import com.aero.share.core.designsystem.AeroCard
import com.aero.share.core.designsystem.AeroDeviceIcon
import com.aero.share.core.designsystem.AeroIcon
import com.aero.share.core.designsystem.AeroIconButton
import com.aero.share.core.designsystem.AeroLogo
import com.aero.share.core.designsystem.AeroProgressBar
import com.aero.share.core.designsystem.AeroText
import com.aero.share.core.designsystem.AeroTheme
import com.aero.share.core.designsystem.aeroClickable
import com.aero.share.core.designsystem.aeroGlass

/** Logo, name, a small chip with this device's name and visibility, and the history action. */
@Composable
internal fun HomeHeader(deviceName: String, visible: Boolean, onHistory: () -> Unit) {
    val colors = AeroTheme.colors
    val chipDescription = stringResource(R.string.home_this_device, deviceName)
    Row(
        modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp).padding(start = 20.dp, end = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AeroLogo(size = 32.dp)
        Spacer(Modifier.width(10.dp))
        AeroText(
            text = stringResource(R.string.app_name),
            style = AeroTheme.typography.titleSmall,
            maxLines = 1,
        )
        Spacer(Modifier.weight(1f))
        if (deviceName.isNotBlank()) {
            val shape = RoundedCornerShape(50)
            Row(
                modifier = Modifier
                    .widthIn(max = 150.dp)
                    .clip(shape)
                    .background(colors.surfaceAlt, shape)
                    .border(1.dp, colors.divider, shape)
                    .padding(horizontal = 10.dp, vertical = 6.dp)
                    .semantics { contentDescription = chipDescription },
                verticalAlignment = Alignment.CenterVertically,
            ) {
                // Green: other devices can see this one. Grey: hidden mode.
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(if (visible) colors.success else colors.textSecondary),
                )
                Spacer(Modifier.width(6.dp))
                AeroText(text = deviceName, style = AeroTheme.typography.caption, maxLines = 1)
            }
        }
        AeroIconButton(
            icon = Icons.Rounded.History,
            contentDescription = stringResource(R.string.home_history),
            onClick = onHistory,
        )
    }
}

/** The two big actions. The primary one is filled with the accent colour. */
@Composable
internal fun ActionCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    primary: Boolean,
    onClick: () -> Unit,
) {
    val colors = AeroTheme.colors
    val shape = RoundedCornerShape(AeroTheme.dimens.radius)
    val titleColor = if (primary) colors.onAccent else colors.textPrimary
    val bodyColor = if (primary) colors.onAccent else colors.textSecondary
    val iconBox = if (primary) colors.onAccent.copy(alpha = 0.14f) else colors.accentContainer
    val iconTint = if (primary) colors.onAccent else colors.accentText
    val surface = if (primary) Modifier.clip(shape).background(colors.accent, shape) else Modifier.aeroGlass()
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 104.dp)
            .aeroClickable(role = Role.Button, onClick = onClick)
            .then(surface)
            .padding(20.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(modifier = Modifier.weight(1f)) {
            AeroText(text = title, style = AeroTheme.typography.title, color = titleColor)
            Spacer(Modifier.height(4.dp))
            AeroText(text = subtitle, color = bodyColor)
        }
        Spacer(Modifier.width(16.dp))
        Box(
            modifier = Modifier.size(56.dp).clip(RoundedCornerShape(18.dp)).background(iconBox),
            contentAlignment = Alignment.Center,
        ) {
            AeroIcon(icon = icon, contentDescription = null, tint = iconTint, size = 30.dp)
        }
    }
}

/** Shown while something is being sent or received (or waits to continue); tapping opens its progress screen. */
@Composable
internal fun TransferBanner(banner: HomeBanner, onClick: () -> Unit) {
    val colors = AeroTheme.colors
    val transfer = banner.transfer
    val name = transfer.peerName.ifBlank { stringResource(R.string.common_unknown_device) }
    val kind = HomeLogic.bannerKind(transfer)
    val title = when (kind) {
        BannerKind.SENDING -> stringResource(R.string.home_banner_sending, name)
        BannerKind.RECEIVING -> stringResource(R.string.home_banner_receiving, name)
        BannerKind.INTERRUPTED -> stringResource(R.string.home_banner_interrupted)
    }
    val detail = when {
        kind == BannerKind.INTERRUPTED -> stringResource(R.string.home_banner_tap)
        HomeLogic.bannerShowsSizes(transfer) -> stringResource(
            R.string.home_banner_progress,
            Formatters.bytes(transfer.transferredBytes),
            Formatters.bytes(transfer.totalBytes),
        )
        else -> stringResource(transfer.state.labelRes())
    }
    AeroCard(onClick = onClick, elevated = true) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                AeroText(text = title, style = AeroTheme.typography.bodyStrong, maxLines = 1)
                AeroText(text = detail, style = AeroTheme.typography.caption, color = colors.textSecondary, maxLines = 1)
            }
            if (banner.additional > 0) {
                AeroBadge(text = stringResource(R.string.home_banner_extra, banner.additional))
            }
        }
        when (HomeLogic.bannerProgress(transfer)) {
            BannerProgress.NONE -> Unit
            BannerProgress.INDETERMINATE -> {
                Spacer(Modifier.height(12.dp))
                AeroProgressBar(progress = 0f, modifier = Modifier.fillMaxWidth(), indeterminate = true)
            }
            BannerProgress.DETERMINATE -> {
                Spacer(Modifier.height(12.dp))
                AeroProgressBar(progress = transfer.fraction, modifier = Modifier.fillMaxWidth())
            }
        }
    }
}

/** "Nearby devices", the number found, the discovery status and the refresh action. */
@Composable
internal fun NearbyHeader(count: Int, searching: Boolean, onRefresh: () -> Unit) {
    val colors = AeroTheme.colors
    val countText = if (count > 0) pluralStringResource(R.plurals.home_devices_count, count, count) else null
    val statusText = if (searching) stringResource(R.string.home_searching) else null
    val subtitle = when {
        countText != null && statusText != null -> stringResource(R.string.common_pair, countText, statusText)
        countText != null -> countText
        else -> statusText
    }
    Row(
        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(modifier = Modifier.weight(1f)) {
            AeroText(text = stringResource(R.string.home_nearby_title), style = AeroTheme.typography.titleSmall)
            if (subtitle != null) {
                AeroText(text = subtitle, style = AeroTheme.typography.caption, color = colors.textSecondary)
            }
        }
        AeroIconButton(
            icon = Icons.Rounded.Refresh,
            contentDescription = stringResource(R.string.home_refresh),
            onClick = onRefresh,
        )
    }
}

/** One discovered device: icon, name, "Phone · Strong connection", the transports it can be reached over and its badges. */
@Composable
internal fun DeviceCard(item: HomeDevice, onClick: () -> Unit) {
    val colors = AeroTheme.colors
    val device = item.device
    val name = item.displayName.ifBlank { stringResource(R.string.common_unknown_device) }
    val subtitle = stringResource(
        R.string.common_pair,
        stringResource(device.kind.labelRes()),
        stringResource(device.quality.labelRes()),
    )
    val transports = device.transports.sortedBy { it.ordinal }.map { stringResource(it.labelRes()) }.joinToString(", ")
    AeroCard(onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(AeroTheme.dimens.radiusSmall))
                    .background(colors.accentContainer),
                contentAlignment = Alignment.Center,
            ) {
                AeroDeviceIcon(kind = device.kind)
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                AeroText(text = name, style = AeroTheme.typography.bodyStrong, maxLines = 1)
                AeroText(text = subtitle, style = AeroTheme.typography.caption, color = colors.textSecondary, maxLines = 1)
                if (transports.isNotEmpty()) {
                    AeroText(text = transports, style = AeroTheme.typography.caption, color = colors.textSecondary, maxLines = 1)
                }
            }
            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                if (item.trusted) AeroBadge(text = stringResource(R.string.common_trust_trusted), color = colors.success)
                if (item.blocked) AeroBadge(text = stringResource(R.string.common_trust_blocked), color = colors.danger)
            }
        }
    }
}
