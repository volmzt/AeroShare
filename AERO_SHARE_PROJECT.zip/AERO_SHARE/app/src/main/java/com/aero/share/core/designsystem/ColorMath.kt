package com.aero.share.core.designsystem

import kotlin.math.pow
import kotlin.math.roundToInt

/**
 * Colour arithmetic on packed 0xAARRGGBB values (plain [Long]s, no UI types) so the palette rules can be unit-tested on
 * the JVM. Contrast uses the WCAG relative-luminance formula.
 */
internal object ColorMath {
    const val WHITE = 0xFFFFFFFFL
    const val NEAR_BLACK = 0xFF0B0B0BL
    const val BLACK = 0xFF000000L

    fun red(argb: Long): Int = ((argb shr 16) and 0xFFL).toInt()

    fun green(argb: Long): Int = ((argb shr 8) and 0xFFL).toInt()

    fun blue(argb: Long): Int = (argb and 0xFFL).toInt()

    fun rgb(red: Int, green: Int, blue: Int): Long =
        0xFF000000L or (red.coerceIn(0, 255).toLong() shl 16) or (green.coerceIn(0, 255).toLong() shl 8) or blue.coerceIn(0, 255).toLong()

    /** Same colour with the given opacity (0..1) in the alpha byte. */
    fun withAlpha(argb: Long, opacity: Double): Long {
        val alpha = (opacity.coerceIn(0.0, 1.0) * 255.0).roundToInt().toLong()
        return (alpha shl 24) or (argb and 0x00FFFFFFL)
    }

    private fun channel(value: Int): Double {
        val s = value / 255.0
        return if (s <= 0.03928) s / 12.92 else ((s + 0.055) / 1.055).pow(2.4)
    }

    /** Relative luminance 0..1 of the RGB part (alpha is ignored). */
    fun luminance(argb: Long): Double =
        0.2126 * channel(red(argb)) + 0.7152 * channel(green(argb)) + 0.0722 * channel(blue(argb))

    /** WCAG contrast ratio 1..21 between two opaque colours. */
    fun contrast(first: Long, second: Long): Double {
        val a = luminance(first)
        val b = luminance(second)
        return (maxOf(a, b) + 0.05) / (minOf(a, b) + 0.05)
    }

    /** Opaque mix: 0 gives [from], 1 gives [to]. */
    fun mix(from: Long, to: Long, fraction: Double): Long {
        val t = fraction.coerceIn(0.0, 1.0)
        fun lerp(a: Int, b: Int): Int = (a + (b - a) * t).roundToInt()
        return rgb(lerp(red(from), red(to)), lerp(green(from), green(to)), lerp(blue(from), blue(to)))
    }

    /** White or near-black, whichever is easier to read on [background]. */
    fun readableOn(background: Long): Long =
        if (contrast(WHITE, background) >= contrast(NEAR_BLACK, background)) WHITE else NEAR_BLACK

    /**
     * Moves [foreground] towards [towards] in small steps until it reaches [minRatio] against [background]. The colour is
     * returned unchanged when it already reads well enough.
     */
    fun ensureContrast(foreground: Long, background: Long, minRatio: Double, towards: Long): Long {
        var current = rgb(red(foreground), green(foreground), blue(foreground))
        var step = 0
        while (contrast(current, background) < minRatio && step < STEPS) {
            step++
            current = mix(foreground, towards, step.toDouble() / STEPS)
        }
        return current
    }

    private const val STEPS = 50
}
