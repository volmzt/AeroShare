package com.aero.share.feature.settings

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent

/** Hands the written report to another app or to the clipboard. Both calls say whether it worked. */
internal object DiagnosticsActions {
    private const val LABEL = "AERO SHARE diagnostics"

    fun share(context: Context, report: String, chooserTitle: String): Boolean {
        val send = Intent(Intent.ACTION_SEND)
            .setType("text/plain")
            .putExtra(Intent.EXTRA_SUBJECT, LABEL)
            .putExtra(Intent.EXTRA_TEXT, report)
        val chooser = Intent.createChooser(send, chooserTitle).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(chooser)
            true
        } catch (e: ActivityNotFoundException) {
            false
        } catch (e: SecurityException) {
            false
        }
    }

    fun copy(context: Context, report: String): Boolean {
        val manager = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager ?: return false
        return try {
            manager.setPrimaryClip(ClipData.newPlainText(LABEL, report))
            true
        } catch (e: RuntimeException) {
            false
        }
    }
}
