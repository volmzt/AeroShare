package com.aero.share.network.pairing

import android.graphics.Bitmap
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.WriterException
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel

/**
 * Draws QR codes. Always black modules on a white background with a one-module margin, so scanners work no matter which
 * theme the app is in (the screen shows the code on a white card, which provides the rest of the quiet zone).
 */
object QrCodes {
    private const val MIN_SIZE_PX = 64
    private const val MAX_SIZE_PX = 2048
    private const val BLACK = 0xFF000000.toInt()
    private const val WHITE = 0xFFFFFFFF.toInt()

    /** Throws IllegalArgumentException when [text] cannot be encoded (it is far longer than any pairing code). */
    fun encode(text: String, sizePx: Int): ImageBitmap =
        encodeOrNull(text, sizePx) ?: throw IllegalArgumentException("the text cannot be encoded as a QR code")

    fun encodeOrNull(text: String, sizePx: Int): ImageBitmap? {
        if (text.isEmpty()) return null
        val size = sizePx.coerceIn(MIN_SIZE_PX, MAX_SIZE_PX)
        val hints = mapOf<EncodeHintType, Any>(
            EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.M,
            EncodeHintType.MARGIN to 1,
            EncodeHintType.CHARACTER_SET to "UTF-8",
        )
        val matrix = try {
            QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size, hints)
        } catch (e: WriterException) {
            return null
        }
        val width = matrix.width
        val height = matrix.height
        val pixels = IntArray(width * height)
        for (y in 0 until height) {
            val row = y * width
            for (x in 0 until width) {
                pixels[row + x] = if (matrix.get(x, y)) BLACK else WHITE
            }
        }
        val bitmap = Bitmap.createBitmap(pixels, width, height, Bitmap.Config.ARGB_8888)
        return bitmap.asImageBitmap()
    }
}
