package com.aero.share.core.designsystem

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.progressSemantics
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.InsertDriveFile
import androidx.compose.material.icons.rounded.Android
import androidx.compose.material.icons.rounded.Archive
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Devices
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Laptop
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.PhoneAndroid
import androidx.compose.material.icons.rounded.TabletAndroid
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.aero.share.R
import com.aero.share.transfer.model.DeviceKind
import com.aero.share.transfer.model.FileCategory

/** Full-screen background with safe-area padding (status bar, navigation bar, cutout and keyboard). */
@Composable
fun AeroScreen(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AeroTheme.colors.background)
            .glassBackdrop()
            .safeDrawingPadding(),
        content = content,
    )
}

/** Title row. With [onBack] a back arrow is shown; [actions] sit on the right. */
@Composable
fun AeroTopBar(title: String, onBack: (() -> Unit)? = null, actions: @Composable RowScope.() -> Unit = {}) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 56.dp)
            .padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (onBack != null) {
            AeroIconButton(
                icon = Icons.AutoMirrored.Rounded.ArrowBack,
                contentDescription = stringResource(R.string.common_back),
                onClick = onBack,
            )
        } else {
            Spacer(Modifier.width(12.dp))
        }
        AeroText(
            text = title,
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 4.dp)
                .semantics { heading() },
            style = AeroTheme.typography.title,
            maxLines = 1,
        )
        actions()
    }
}

/** Rounded surface with padding. Pass [onClick] to make it pressable. */
@Composable
fun AeroCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    elevated: Boolean = false,
    content: @Composable ColumnScope.() -> Unit,
) {
    val colors = AeroTheme.colors
    val dimens = AeroTheme.dimens
    val shape = RoundedCornerShape(dimens.radius)
    val pressable = if (onClick != null) modifier.aeroClickable(role = Role.Button, onClick = onClick) else modifier
    val surface = if (elevated) {
        Modifier
            .clip(shape)
            .background(colors.surfaceElevated, shape)
            .border(1.dp, colors.divider, shape)
    } else {
        Modifier.aeroGlass()
    }
    Column(
        modifier = pressable.then(surface).padding(dimens.cardPadding),
        content = content,
    )
}

/** Like [AeroCard] without inner padding, for groups of rows that bring their own padding. */
@Composable
fun AeroGroup(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier = modifier.fillMaxWidth().aeroGlass(), content = content)
}

@Composable
fun AeroDivider(modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth().height(1.dp).background(AeroTheme.colors.divider))
}

/** Small status label such as "Trusted". */
@Composable
fun AeroBadge(text: String, modifier: Modifier = Modifier, color: Color = AeroTheme.colors.accentText) {
    AeroText(
        text = text,
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(color.copy(alpha = 0.16f))
            .padding(horizontal = 8.dp, vertical = 3.dp),
        style = AeroTheme.typography.caption.copy(fontWeight = FontWeight.Medium),
        color = color,
        maxLines = 1,
    )
}

@Composable
fun AeroLogo(size: Dp = 32.dp, modifier: Modifier = Modifier) {
    Image(
        painter = painterResource(R.drawable.ic_aero_logo),
        contentDescription = null,
        modifier = modifier.size(size),
    )
}

@Composable
private fun IconTile(icon: ImageVector, modifier: Modifier, tint: Color) {
    Box(
        modifier = modifier
            .size(44.dp)
            .clip(RoundedCornerShape(AeroTheme.dimens.radiusSmall))
            .background(tint.copy(alpha = 0.14f)),
        contentAlignment = Alignment.Center,
    ) {
        AeroIcon(icon = icon, contentDescription = null, tint = tint, size = 24.dp)
    }
}

/** Device type icon on a soft tile (44 dp by default; pass a size modifier to change it). */
@Composable
fun AeroDeviceIcon(kind: DeviceKind, modifier: Modifier = Modifier, tint: Color = AeroTheme.colors.accentText) {
    val icon = when (kind) {
        DeviceKind.PHONE -> Icons.Rounded.PhoneAndroid
        DeviceKind.TABLET -> Icons.Rounded.TabletAndroid
        DeviceKind.COMPUTER -> Icons.Rounded.Laptop
        DeviceKind.OTHER -> Icons.Rounded.Devices
    }
    IconTile(icon, modifier, tint)
}

/** File category icon on a soft tile. */
@Composable
fun AeroCategoryIcon(category: FileCategory, modifier: Modifier = Modifier, tint: Color = AeroTheme.colors.accentText) {
    val icon = when (category) {
        FileCategory.IMAGE -> Icons.Rounded.Image
        FileCategory.VIDEO -> Icons.Rounded.Videocam
        FileCategory.AUDIO -> Icons.Rounded.MusicNote
        FileCategory.DOCUMENT -> Icons.Rounded.Description
        FileCategory.ARCHIVE -> Icons.Rounded.Archive
        FileCategory.APK -> Icons.Rounded.Android
        FileCategory.OTHER -> Icons.AutoMirrored.Rounded.InsertDriveFile
    }
    IconTile(icon, modifier, tint)
}

@Composable
fun AeroSectionHeader(text: String, modifier: Modifier = Modifier) {
    AeroText(
        text = text,
        modifier = modifier
            .fillMaxWidth()
            .padding(top = 20.dp, bottom = 8.dp)
            .semantics { heading() },
        style = AeroTheme.typography.label,
        color = AeroTheme.colors.textSecondary,
        maxLines = 2,
    )
}

/** Explains why a list is empty and offers the matching action. */
@Composable
fun AeroEmptyState(
    icon: ImageVector,
    title: String,
    message: String,
    modifier: Modifier = Modifier,
    actionText: String? = null,
    onAction: (() -> Unit)? = null,
) {
    val colors = AeroTheme.colors
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            modifier = Modifier
                .size(72.dp)
                .clip(RoundedCornerShape(AeroTheme.dimens.radius))
                .background(colors.surfaceAlt),
            contentAlignment = Alignment.Center,
        ) {
            AeroIcon(icon = icon, contentDescription = null, tint = colors.textSecondary, size = 32.dp)
        }
        Spacer(Modifier.height(16.dp))
        AeroText(text = title, style = AeroTheme.typography.titleSmall, textAlign = TextAlign.Center)
        Spacer(Modifier.height(8.dp))
        AeroText(text = message, color = colors.textSecondary, textAlign = TextAlign.Center)
        if (actionText != null && onAction != null) {
            Spacer(Modifier.height(16.dp))
            AeroButton(text = actionText, onClick = onAction, style = AeroButtonStyle.Secondary)
        }
    }
}

/** Selectable filter chip. The touch target is 48 dp high even though the chip itself is slimmer. */
@Composable
fun AeroChip(
    text: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
) {
    val colors = AeroTheme.colors
    val shape = RoundedCornerShape(AeroTheme.dimens.radiusSmall)
    val fill = if (selected) colors.accentContainer else colors.surfaceAlt
    val stroke = if (selected) colors.accent else colors.divider
    val content = if (selected) colors.accentText else colors.textPrimary
    Box(
        modifier = modifier
            .heightIn(min = 48.dp)
            .aeroClickable(role = Role.Button, onClick = onClick)
            .semantics { this.selected = selected },
        contentAlignment = Alignment.Center,
    ) {
        Row(
            modifier = Modifier
                .clip(shape)
                .background(fill, shape)
                .border(1.dp, stroke, shape)
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            if (icon != null) AeroIcon(icon = icon, contentDescription = null, tint = content, size = 18.dp)
            AeroText(text = text, style = AeroTheme.typography.label, color = content, maxLines = 1)
        }
    }
}

/** Horizontal progress bar. [progress] is 0..1; [indeterminate] shows a moving segment (a still one when motion is off). */
@Composable
fun AeroProgressBar(progress: Float, modifier: Modifier = Modifier, indeterminate: Boolean = false) {
    val colors = AeroTheme.colors
    val motion = AeroTheme.motion
    val shape = RoundedCornerShape(4.dp)
    val fillBrush = Brush.horizontalGradient(listOf(colors.accent, colors.accentSecondary))
    val clamped = if (progress.isNaN()) 0f else progress.coerceIn(0f, 1f)
    val track = modifier
        .fillMaxWidth()
        .height(8.dp)
        .clip(shape)
        .background(colors.surfaceElevated)
    if (indeterminate) {
        if (motion.enabled) {
            val transition = rememberInfiniteTransition()
            val offset by transition.animateFloat(
                initialValue = -0.4f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    animation = tween(durationMillis = 1100, easing = LinearEasing),
                    repeatMode = RepeatMode.Restart,
                ),
            )
            Box(
                modifier = track
                    .progressSemantics()
                    .drawBehind {
                        drawRoundRect(
                            brush = fillBrush,
                            topLeft = Offset(size.width * offset, 0f),
                            size = Size(size.width * 0.4f, size.height),
                            cornerRadius = CornerRadius(size.height / 2f),
                        )
                    },
            )
        } else {
            Box(modifier = track.progressSemantics()) {
                Box(Modifier.fillMaxHeight().fillMaxWidth(0.3f).background(fillBrush))
            }
        }
    } else {
        val animated by animateFloatAsState(
            targetValue = clamped,
            animationSpec = tween(durationMillis = if (motion.enabled) motion.short else 0),
            label = "progress",
        )
        Box(modifier = track.progressSemantics(clamped)) {
            Box(Modifier.fillMaxHeight().fillMaxWidth(animated).background(fillBrush))
        }
    }
}

/** One destination of the bottom bar. */
@Immutable
data class AeroNavItem(val label: String, val icon: ImageVector)

@Composable
fun AeroBottomBar(items: List<AeroNavItem>, selectedIndex: Int, onSelect: (Int) -> Unit) {
    val colors = AeroTheme.colors
    Column(modifier = Modifier.fillMaxWidth().background(colors.surface)) {
        AeroDivider()
        Row(modifier = Modifier.fillMaxWidth().navigationBarsPadding()) {
            items.forEachIndexed { index, item ->
                val isSelected = index == selectedIndex
                val tint = if (isSelected) colors.accentText else colors.textSecondary
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 60.dp)
                        .aeroClickable(role = Role.Tab) { onSelect(index) }
                        .semantics { this.selected = isSelected }
                        .padding(vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    Box(
                        modifier = Modifier
                            .size(width = 56.dp, height = 30.dp)
                            .clip(RoundedCornerShape(AeroTheme.dimens.radiusSmall))
                            .background(if (isSelected) colors.accentContainer else Color.Transparent),
                        contentAlignment = Alignment.Center,
                    ) {
                        AeroIcon(icon = item.icon, contentDescription = null, tint = tint, size = 24.dp)
                    }
                    Spacer(Modifier.height(2.dp))
                    AeroText(
                        text = item.label,
                        style = AeroTheme.typography.caption.copy(fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal),
                        color = tint,
                        maxLines = 1,
                    )
                }
            }
        }
    }
}
