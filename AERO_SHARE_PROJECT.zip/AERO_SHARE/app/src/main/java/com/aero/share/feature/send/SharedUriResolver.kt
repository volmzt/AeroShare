package com.aero.share.feature.send

import android.content.Context
import android.net.Uri
import com.aero.share.core.storage.MimeTypes
import com.aero.share.core.storage.UriMetadata
import com.aero.share.domain.FileItem
import com.aero.share.transfer.model.FileCategory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Turns URIs handed to the app (the share sheet, the system file picker) into selection items. Each one is asked for its
 * name, size and type; anything that cannot be read, or that is not a `content://` URI, is left out, so the caller can tell
 * the person that nothing (or only part) of what they shared was usable.
 */
object SharedUriResolver {
    suspend fun resolve(context: Context, uris: List<String>): List<FileItem> = withContext(Dispatchers.IO) {
        val result = ArrayList<FileItem>()
        for (text in SharedUriRules.distinct(uris)) {
            val uri = Uri.parse(text)
            if (!SharedUriRules.isAcceptable(uri.scheme)) continue
            val meta = UriMetadata.query(context, uri) ?: continue
            val name = SharedUriRules.displayName(meta.name, uri.lastPathSegment)
            val mime = meta.mimeType ?: MimeTypes.fromName(name)
            result.add(
                FileItem(
                    id = text,
                    uri = text,
                    displayName = name,
                    size = meta.size,
                    category = FileCategory.classify(name, mime),
                    mimeType = mime,
                    lastModified = meta.lastModified,
                ),
            )
        }
        result
    }
}
