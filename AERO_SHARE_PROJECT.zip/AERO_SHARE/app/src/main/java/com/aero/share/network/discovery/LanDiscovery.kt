package com.aero.share.network.discovery

import android.content.Context
import android.content.pm.PackageManager
import android.os.SystemClock
import com.aero.share.BuildConfig
import com.aero.share.core.common.DiagnosticsLog
import com.aero.share.domain.DiscoveryProblem
import com.aero.share.domain.LinkQuality
import com.aero.share.domain.LocalDeviceProvider
import com.aero.share.domain.NearbyDevice
import com.aero.share.domain.PowerPolicy
import com.aero.share.domain.SettingsRepository
import com.aero.share.domain.Visibility
import com.aero.share.transfer.model.Capabilities
import java.util.concurrent.atomic.AtomicBoolean
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit

/**
 * Finds and announces devices on the local network (Wi-Fi or Ethernet).
 *
 * Two independent mechanisms run together: DNS-SD through NsdManager and a multicast beacon (see [BeaconCodec]); the
 * list merges both. Nothing runs while nobody asked for it: the network and Wi-Fi watchers, the sockets and the timers
 * exist only between [start] / [startAdvertising] and the matching stop. All real work happens on one serial loop, so
 * start, stop, network changes and settings changes can never interleave.
 *
 * Link quality is measured once per device by a short TCP connect and stays UNKNOWN when that fails. Nothing is invented.
 */
class LanDiscovery(
    context: Context,
    private val scope: CoroutineScope,
    private val local: LocalDeviceProvider,
    private val settings: SettingsRepository,
    private val power: PowerPolicy,
    private val diagnostics: DiagnosticsLog,
) {
    private val app = context.applicationContext
    private val lock = Any()
    private val table = DeviceTable { local.info.value.deviceId }
    private val probed = HashSet<String>()
    private val probeSlots = Semaphore(MAX_PARALLEL_PROBES)
    private val kick = Channel<Unit>(Channel.CONFLATED)
    private val refreshRequested = AtomicBoolean(false)
    private val capabilityBits: Int =
        if (app.packageManager.hasSystemFeature(PackageManager.FEATURE_WIFI_DIRECT)) {
            Capabilities.ALL
        } else {
            Capabilities.ALL and Capabilities.WIFI_DIRECT.inv()
        }

    private val watcher = NetworkWatcher(app) { message -> log(message) }
    private val wifi = WifiState(app)
    private val beacon = MulticastBeacon(
        context = app,
        scope = scope,
        localAddresses = { localAddressSet() },
        presence = { currentPresence() },
        onPresence = { presence, source -> onBeacon(presence, source) },
        log = { message -> log(message) },
    )
    private val browser = NsdBrowser(
        context = app,
        scope = scope,
        onResolved = { name, presence, addresses -> onNsdResolved(name, presence, addresses) },
        onLost = { name -> onNsdLost(name) },
        onChanged = { kick.trySend(Unit) },
        log = { message -> log(message) },
    )
    private val advertiser = NsdAdvertiser(
        context = app,
        onChanged = { kick.trySend(Unit) },
        log = { message -> log(message) },
    )

    private val deviceState = MutableStateFlow<List<NearbyDevice>>(emptyList())
    private val problemState = MutableStateFlow<DiscoveryProblem?>(null)
    private val methodState = MutableStateFlow<Set<String>>(emptySet())

    /** LAN devices only (transport LAN), this device excluded. */
    val devices: StateFlow<List<NearbyDevice>> = deviceState.asStateFlow()

    /** Why nothing can be found right now: Wi-Fi off, no network, or no mechanism working. Null when fine or idle. */
    val problem: StateFlow<DiscoveryProblem?> = problemState.asStateFlow()

    /** Mechanisms that currently work: "mdns" and/or "multicast". */
    val methods: StateFlow<Set<String>> = methodState.asStateFlow()

    /** The network used right now (null when there is none or nothing is running). */
    val network: StateFlow<LanNetwork?> get() = watcher.current

    // Requested state: written by the public functions, read by the loop.
    @Volatile private var wanted = false
    @Volatile private var advertisePort: Int? = null
    @Volatile private var activeNetwork: LanNetwork? = null

    // Applied state: touched by the loop only.
    private var watching = false
    private var browsing = false
    private var activeAdvert: Beacon.Presence? = null
    private var activeIntervalMs = 0L
    private var ticker: Job? = null

    /** Starts looking for devices. Idempotent. Also reacts to network changes until [stop]. */
    fun start() {
        wanted = true
        kick.trySend(Unit)
    }

    fun stop() {
        wanted = false
        kick.trySend(Unit)
    }

    /** Sends a fresh query, restarts DNS-SD browsing, drops expired entries and measures the link again. */
    fun refresh() {
        refreshRequested.set(true)
        kick.trySend(Unit)
    }

    /** Makes this device visible (unless the setting says hidden) with the receiver's TLS [port]. */
    fun startAdvertising(port: Int) {
        advertisePort = port
        kick.trySend(Unit)
    }

    fun stopAdvertising() {
        advertisePort = null
        kick.trySend(Unit)
    }

    /** One announcement straight to [host]; used where multicast does not reach (Wi-Fi Direct client to group owner). */
    fun announceTo(host: String) {
        beacon.announceTo(host)
    }

    // ---- the serial loop

    private fun reconcile() {
        val lanOn = settings.settings.value.lanDiscoveryEnabled
        val wantBrowse = wanted && lanOn
        val advert = currentPresence()
        if (!wantBrowse && advert == null) {
            shutdown()
            return
        }
        if (!watching) {
            watching = true
            wifi.start()
            watcher.start()
        }
        val lan = watcher.current.value
        if (lan == null) {
            stopMechanisms()
            activeNetwork = null
            clearDevices()
            methodState.value = emptySet()
            problemState.value = if (wifi.enabled.value) DiscoveryProblem.NO_NETWORK else DiscoveryProblem.WIFI_OFF
            return
        }
        if (lan != activeNetwork) {
            stopMechanisms()
            clearDevices()
            synchronized(lock) { table.setSubnets(lan.subnets) }
            activeNetwork = lan
        }
        val interval = power.beaconIntervalMs().coerceIn(MIN_INTERVAL_MS, MAX_INTERVAL_MS)

        if (!beacon.isActive) beacon.start(lan)

        if (wantBrowse) {
            if (!browsing) {
                browsing = true
                browser.start()
                beacon.query()
            } else if (!browser.isActive) {
                browser.start()
            }
            ensureTicker()
        } else if (browsing) {
            browsing = false
            browser.stop()
            cancelTicker()
            clearDevices()
        }

        if (advert != null) {
            if (advert != activeAdvert || interval != activeIntervalMs) {
                advertiser.register(advert)
                beacon.setAdvertising(true, interval)
                activeAdvert = advert
                activeIntervalMs = interval
            }
        } else if (activeAdvert != null) {
            advertiser.unregister()
            beacon.setAdvertising(false, interval)
            activeAdvert = null
            activeIntervalMs = 0L
        }

        if (refreshRequested.getAndSet(false) && wantBrowse) {
            synchronized(lock) {
                table.expire(SystemClock.elapsedRealtime(), ttlMs())
                probed.clear()
                publishLocked()
            }
            beacon.query()
            browser.restart()
            probePending()
        }

        val working = HashSet<String>()
        if (browser.isActive || advertiser.isActive) working.add(METHOD_MDNS)
        if (beacon.isActive) working.add(METHOD_MULTICAST)
        methodState.value = working
        problemState.value = if (working.isEmpty()) DiscoveryProblem.UNAVAILABLE else null
    }

    private fun stopMechanisms() {
        cancelTicker()
        browsing = false
        browser.stop()
        advertiser.unregister()
        beacon.setAdvertising(false, 0L)
        beacon.stop()
        activeAdvert = null
        activeIntervalMs = 0L
    }

    private fun shutdown() {
        stopMechanisms()
        if (watching) {
            watching = false
            watcher.stop()
            wifi.stop()
        }
        activeNetwork = null
        clearDevices()
        methodState.value = emptySet()
        problemState.value = null
    }

    private fun ensureTicker() {
        if (ticker?.isActive == true) return
        ticker = scope.launch(Dispatchers.IO) {
            while (isActive) {
                delay(TICK_MS)
                synchronized(lock) {
                    table.expire(SystemClock.elapsedRealtime(), ttlMs())
                    publishLocked()
                }
                probePending()
            }
        }
    }

    private fun cancelTicker() {
        ticker?.cancel()
        ticker = null
    }

    // ---- what mDNS and the beacon report (called from their threads)

    private fun onBeacon(presence: Beacon.Presence, source: String) {
        synchronized(lock) {
            table.onBeacon(presence, source, SystemClock.elapsedRealtime())
            publishLocked()
        }
        if (!presence.goodbye) probePending()
    }

    private fun onNsdResolved(serviceName: String, presence: Beacon.Presence, addresses: List<String>) {
        synchronized(lock) {
            table.onNsd(serviceName, presence, addresses, SystemClock.elapsedRealtime())
            publishLocked()
        }
        probePending()
    }

    private fun onNsdLost(serviceName: String) {
        synchronized(lock) {
            table.onNsdLost(serviceName)
            publishLocked()
        }
    }

    // ---- helpers

    /** Callers hold [lock]. */
    private fun publishLocked() {
        val list = table.snapshot()
        probed.retainAll(list.map { it.deviceId }.toSet())
        deviceState.value = list
    }

    private fun clearDevices() {
        synchronized(lock) {
            table.clear()
            probed.clear()
            publishLocked()
        }
    }

    private fun probePending() {
        val targets = synchronized(lock) { table.probeTargets().filter { probed.add(it.deviceId) } }
        for (target in targets) {
            scope.launch(Dispatchers.IO) { probeSlots.withPermit { probe(target) } }
        }
    }

    private fun probe(target: ProbeTarget) {
        val network = activeNetwork?.network
        var quality = LinkQuality.UNKNOWN
        for (address in target.addresses.take(MAX_PROBE_ADDRESSES)) {
            val millis = LinkProbe.measure(address, target.port, LinkProbe.TIMEOUT_MS) { socket -> network?.bindSocket(socket) }
            if (millis != null) {
                quality = LinkProbe.classify(millis)
                break
            }
        }
        synchronized(lock) {
            table.setQuality(target.deviceId, quality)
            publishLocked()
        }
    }

    /** What this device announces, or null when it must not be visible (not advertising, discovery off, or hidden). */
    private fun currentPresence(): Beacon.Presence? {
        val port = advertisePort ?: return null
        val config = settings.settings.value
        if (!config.lanDiscoveryEnabled || config.visibility == Visibility.HIDDEN) return null
        val info = local.info.value
        return Beacon.Presence(
            goodbye = false,
            fingerprint = info.fingerprint,
            name = info.name,
            kind = info.kind,
            port = port,
            appVersion = BuildConfig.VERSION_NAME,
            capabilities = capabilityBits,
        )
    }

    private fun localAddressSet(): Set<String> = activeNetwork?.subnets?.mapTo(HashSet()) { it.address } ?: emptySet()

    /** Beacons live three announcement intervals, but never less than [MIN_TTL_MS], so slow power modes do not flap. */
    private fun ttlMs(): Long = maxOf(3 * power.beaconIntervalMs(), MIN_TTL_MS)

    private fun log(message: String) {
        diagnostics.add(TAG, message)
    }

    init {
        scope.launch(Dispatchers.IO) {
            for (ignored in kick) {
                try {
                    reconcile()
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    log("discovery: unexpected ${e.javaClass.simpleName}")
                }
            }
        }
        scope.launch {
            settings.settings
                .map { Triple(it.lanDiscoveryEnabled, it.visibility, it.powerMode) }
                .distinctUntilChanged()
                .collect { kick.trySend(Unit) }
        }
        scope.launch {
            local.info
                .map { Triple(it.name, it.kind, it.fingerprint) }
                .distinctUntilChanged()
                .collect { kick.trySend(Unit) }
        }
        scope.launch { watcher.current.collect { kick.trySend(Unit) } }
        scope.launch { wifi.enabled.collect { kick.trySend(Unit) } }
    }

    private companion object {
        const val TAG = "discovery"
        const val METHOD_MDNS = "mdns"
        const val METHOD_MULTICAST = "multicast"
        const val MIN_INTERVAL_MS = 1_000L
        const val MAX_INTERVAL_MS = 30_000L
        const val MIN_TTL_MS = 30_000L
        const val TICK_MS = 3_000L
        const val MAX_PARALLEL_PROBES = 3
        const val MAX_PROBE_ADDRESSES = 2
    }
}
