package com.aero.share.feature.history

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Share
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import com.aero.share.R
import com.aero.share.core.common.Formatters
import com.aero.share.core.common.hintRes
import com.aero.share.core.common.labelRes
import com.aero.share.core.common.messageRes
import com.aero.share.core.designsystem.AeroBadge
import com.aero.share.core.designsystem.AeroBottomSheet
import com.aero.share.core.designsystem.AeroButton
import com.aero.share.core.designsystem.AeroButtonStyle
import com.aero.share.core.designsystem.AeroCard
import com.aero.share.core.designsystem.AeroCategoryIcon
import com.aero.share.core.designsystem.AeroDialog
import com.aero.share.core.designsystem.AeroDivider
import com.aero.share.core.designsystem.AeroSectionHeader
import com.aero.share.core.designsystem.AeroText
import com.aero.share.core.designsystem.AeroTheme
import com.aero.share.core.designsystem.aeroRowClickable
import com.aero.share.di.LocalAppContainer
import com.aero.share.domain.HistoryFile
import com.aero.share.domain.HistoryItem
import com.aero.share.transfer.model.TransferDirection

/**
 * One record in full: who, when, how much, how it ended, and the files. Received files can be opened from here; sent files
 * are only listed, because AERO SHARE keeps no copy of what it sent. Problems are written inside the sheet, because a toast
 * would sit behind it.
 */
@Composable
internal fun HistoryDetailSheet(item: HistoryItem, onDismiss: () -> Unit, onDelete: () -> Unit) {
    val container = LocalAppContainer.current
    val colors = AeroTheme.colors
    var notice by remember { mutableStateOf<String?>(null) }
    var confirmDelete by rememberSaveable { mutableStateOf(false) }
    val openFailed = stringResource(R.string.hist_open_failed)
    val shareFailed = stringResource(R.string.xfer_share_failed)
    val folderFailed = stringResource(R.string.xfer_folder_failed)
    val openable = HistoryLogic.openableFiles(item)
    val name = item.peerName.ifBlank { stringResource(R.string.common_unknown_device) }
    val received = item.direction == TransferDirection.RECEIVE

    fun openFile(file: HistoryFile) {
        val uri = file.uri
        notice = if (uri.isNullOrEmpty() || !container.fileOpener.open(uri, file.mimeType)) openFailed else null
    }

    AeroBottomSheet(onDismiss = onDismiss) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            DirectionTile(item.direction)
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                AeroText(text = name, style = AeroTheme.typography.titleSmall, maxLines = 2)
                AeroText(text = dateTimeText(item.timestamp), style = AeroTheme.typography.caption, color = colors.textSecondary)
            }
            Spacer(Modifier.width(8.dp))
            AeroBadge(text = stringResource(item.status.labelRes()), color = statusColor(item.status))
        }
        Spacer(Modifier.height(16.dp))
        AeroCard {
            val transport = item.transport
            DetailLine(stringResource(R.string.xfer_detail_files), filesText(item))
            DetailLine(stringResource(R.string.xfer_detail_size), sizeText(item))
            if (item.durationMillis > 0L) {
                DetailLine(stringResource(R.string.xfer_detail_duration), Formatters.duration(item.durationMillis))
            }
            if (transport != null) {
                DetailLine(stringResource(R.string.xfer_detail_connection), stringResource(transport.labelRes()))
            }
        }
        val failure = item.failure
        if (failure != null && HistoryLogic.showsFailure(item)) {
            Spacer(Modifier.height(12.dp))
            AeroCard {
                AeroText(text = stringResource(failure.messageRes()), style = AeroTheme.typography.bodyStrong, color = colors.danger)
                Spacer(Modifier.height(4.dp))
                AeroText(text = stringResource(failure.hintRes()), style = AeroTheme.typography.caption, color = colors.textSecondary)
            }
        }
        if (item.files.isNotEmpty()) {
            AeroSectionHeader(text = pluralStringResource(R.plurals.send_files_total, item.files.size, item.files.size))
            AeroCard {
                val listed = HistoryLogic.listedFiles(item)
                listed.forEachIndexed { index, file ->
                    if (index > 0) AeroDivider()
                    HistoryFileRow(file = file, onOpen = if (file.uri.isNullOrEmpty()) null else ({ openFile(file) }))
                }
                val hidden = HistoryLogic.hiddenFileCount(item)
                if (hidden > 0) {
                    AeroText(
                        text = pluralStringResource(R.plurals.xfer_saved_more, hidden, hidden),
                        style = AeroTheme.typography.caption,
                        color = colors.textSecondary,
                        modifier = Modifier.padding(top = 8.dp),
                    )
                }
            }
        }
        val message = notice
        if (message != null) {
            Spacer(Modifier.height(12.dp))
            AeroText(text = message, color = colors.warning)
        }
        if (received && openable.isNotEmpty()) {
            Spacer(Modifier.height(16.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                AeroButton(
                    text = stringResource(R.string.xfer_open_folder),
                    onClick = { notice = if (container.fileOpener.openReceiveFolder()) null else folderFailed },
                    modifier = Modifier.weight(1f),
                    style = AeroButtonStyle.Secondary,
                    icon = Icons.Rounded.Folder,
                )
                if (HistoryLogic.canShare(item)) {
                    AeroButton(
                        text = stringResource(R.string.xfer_share),
                        onClick = {
                            val shared = container.fileOpener.share(openable.mapNotNull { file -> file.uri }, openable.map { file -> file.mimeType })
                            notice = if (shared) null else shareFailed
                        },
                        modifier = Modifier.weight(1f),
                        style = AeroButtonStyle.Secondary,
                        icon = Icons.Rounded.Share,
                    )
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        AeroButton(
            text = stringResource(R.string.hist_delete_record),
            onClick = { confirmDelete = true },
            modifier = Modifier.fillMaxWidth(),
            style = AeroButtonStyle.Danger,
            icon = Icons.Rounded.Delete,
        )
    }

    if (confirmDelete) {
        AeroDialog(
            title = stringResource(R.string.hist_delete_title),
            message = stringResource(R.string.hist_delete_message),
            confirmText = stringResource(R.string.hist_delete_confirm),
            dismissText = stringResource(R.string.common_cancel),
            danger = true,
            onConfirm = {
                confirmDelete = false
                onDelete()
            },
            onDismiss = { confirmDelete = false },
        )
    }
}

@Composable
private fun filesText(item: HistoryItem): String =
    if (HistoryLogic.filesPartial(item)) {
        pluralStringResource(R.plurals.xfer_files_progress, item.fileCount, item.completedFiles, item.fileCount)
    } else {
        pluralStringResource(R.plurals.send_files_total, item.fileCount, item.fileCount)
    }

@Composable
private fun sizeText(item: HistoryItem): String = when {
    HistoryLogic.bytesPartial(item) ->
        stringResource(R.string.xfer_progress_bytes, Formatters.bytes(item.transferredBytes), Formatters.bytes(item.totalBytes))
    else -> Formatters.bytes(item.totalBytes)
}

@Composable
private fun DetailLine(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().heightIn(min = 36.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        AeroText(text = label, style = AeroTheme.typography.caption, color = AeroTheme.colors.textSecondary, modifier = Modifier.weight(1f))
        AeroText(text = value, modifier = Modifier.weight(2f), maxLines = 2)
    }
}

@Composable
private fun HistoryFileRow(file: HistoryFile, onOpen: (() -> Unit)?) {
    val base = Modifier.fillMaxWidth().heightIn(min = 48.dp)
    Row(
        modifier = if (onOpen != null) base.aeroRowClickable(role = Role.Button, onClick = onOpen) else base,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AeroCategoryIcon(category = file.category)
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f).padding(vertical = 6.dp)) {
            AeroText(text = file.name, maxLines = 2)
            AeroText(text = Formatters.bytes(file.size), style = AeroTheme.typography.caption, color = AeroTheme.colors.textSecondary)
        }
    }
}
