package com.aero.share.feature.home

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.StringRes
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material.icons.rounded.WifiOff
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.aero.share.R
import com.aero.share.core.common.SystemIntents
import com.aero.share.core.designsystem.AeroCard
import com.aero.share.core.designsystem.AeroEmptyState
import com.aero.share.core.designsystem.AeroProgressBar
import com.aero.share.core.designsystem.AeroScreen
import com.aero.share.core.designsystem.AeroText
import com.aero.share.core.designsystem.AeroTheme
import com.aero.share.core.permissions.Permissions
import com.aero.share.di.LocalAppContainer
import com.aero.share.domain.NearbyDevice
import com.aero.share.domain.Recipient
import com.aero.share.navigation.AeroNavigator

/**
 * The first screen: this device, the two big actions (Send on top, Receive below) and the devices found nearby.
 * Nothing here is invented: the list is exactly what discovery reports, and every empty state names its real cause.
 */
@Composable
fun HomeScreen(navigator: AeroNavigator) {
    val container = LocalAppContainer.current
    val context = LocalContext.current
    val viewModel: HomeViewModel = viewModel(factory = viewModelFactory { initializer { HomeViewModel(container) } })
    val ui by viewModel.state.collectAsStateWithLifecycle()
    var permissionDenied by rememberSaveable { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        permissionDenied = grants.values.any { granted -> !granted }
        viewModel.onPermissionResult()
    }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { viewModel.onResume() }
    LifecycleEventEffect(Lifecycle.Event.ON_PAUSE) { viewModel.onPause() }

    val onDevice: (NearbyDevice) -> Unit = { device ->
        container.sendSession.clearAll()
        container.sendSession.setRecipients(listOf(Recipient.Nearby(device)))
        navigator.openSendPicker()
    }

    AeroScreen {
        HomeHeader(deviceName = ui.deviceName, visible = !ui.hidden, onHistory = { navigator.openHistory() })
        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = AeroTheme.dimens.screenPadding, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(AeroTheme.dimens.gap),
        ) {
            val banner = ui.banner
            if (banner != null) {
                item(key = "banner") { TransferBanner(banner) { navigator.openTransfer(banner.transfer.id) } }
            }
            if (ui.hidden) {
                item(key = "hidden") {
                    AeroCard {
                        AeroText(
                            text = stringResource(R.string.home_hidden_note),
                            style = AeroTheme.typography.caption,
                            color = AeroTheme.colors.textSecondary,
                        )
                    }
                }
            }
            item(key = "send") {
                ActionCard(
                    title = stringResource(R.string.home_send_title),
                    subtitle = stringResource(R.string.home_send_subtitle),
                    icon = Icons.AutoMirrored.Rounded.Send,
                    primary = true,
                    onClick = {
                        // Starting from Home always starts a fresh selection.
                        container.sendSession.clearAll()
                        navigator.openSendPicker()
                    },
                )
            }
            item(key = "receive") {
                ActionCard(
                    title = stringResource(R.string.home_receive_title),
                    subtitle = stringResource(R.string.home_receive_subtitle),
                    icon = Icons.Rounded.Download,
                    primary = false,
                    onClick = { navigator.openReceive() },
                )
            }
            item(key = "nearby") {
                NearbyHeader(count = ui.devices.size, searching = ui.searching, onRefresh = { viewModel.searchNow() })
            }
            val empty = ui.empty
            if (ui.devices.isEmpty() && empty != null) {
                item(key = "empty") {
                    NearbyEmpty(
                        kind = empty,
                        permissionDenied = permissionDenied,
                        onSearch = { viewModel.searchNow() },
                        onWifiSettings = { SystemIntents.openWifiSettings(context) },
                        onAllow = { permissionLauncher.launch(Permissions.nearby()) },
                        onAppSettings = { SystemIntents.openAppSettings(context) },
                    )
                }
            } else {
                items(ui.devices, key = { row -> row.device.deviceId }) { row ->
                    DeviceCard(row) { onDevice(row.device) }
                }
            }
        }
    }
}

private class EmptySpec(
    val icon: ImageVector,
    @StringRes val title: Int,
    @StringRes val text: Int,
    @StringRes val action: Int?,
    val onAction: () -> Unit,
)

@Composable
internal fun NearbyEmpty(
    kind: HomeEmpty,
    permissionDenied: Boolean,
    onSearch: () -> Unit,
    onWifiSettings: () -> Unit,
    onAllow: () -> Unit,
    onAppSettings: () -> Unit,
) {
    val spec = when (kind) {
        HomeEmpty.SEARCHING -> EmptySpec(
            Icons.Rounded.Search, R.string.home_empty_searching_title, R.string.home_empty_searching_text, null, {},
        )
        HomeEmpty.NONE_FOUND -> EmptySpec(
            Icons.Rounded.Search, R.string.home_empty_none_title, R.string.home_empty_none_text,
            R.string.home_action_search_again, onSearch,
        )
        HomeEmpty.IDLE -> EmptySpec(
            Icons.Rounded.Search, R.string.home_empty_idle_title, R.string.home_empty_idle_text,
            R.string.home_action_search, onSearch,
        )
        HomeEmpty.WIFI_OFF -> EmptySpec(
            Icons.Rounded.WifiOff, R.string.home_empty_wifi_title, R.string.home_empty_wifi_text,
            R.string.home_action_wifi_settings, onWifiSettings,
        )
        HomeEmpty.NO_NETWORK -> EmptySpec(
            Icons.Rounded.WifiOff, R.string.home_empty_network_title, R.string.home_empty_network_text,
            R.string.home_action_wifi_settings, onWifiSettings,
        )
        HomeEmpty.PERMISSION -> EmptySpec(
            Icons.Rounded.Lock, R.string.home_empty_permission_title, R.string.home_empty_permission_text,
            // After a refusal Android may not show its dialog again, so the app settings are the only way back.
            if (permissionDenied) R.string.common_open_settings else R.string.common_allow,
            if (permissionDenied) onAppSettings else onAllow,
        )
        HomeEmpty.UNAVAILABLE -> EmptySpec(
            Icons.Rounded.Warning, R.string.home_empty_unavailable_title, R.string.home_empty_unavailable_text,
            R.string.common_retry, onSearch,
        )
    }
    val message = if (kind == HomeEmpty.PERMISSION && permissionDenied) {
        stringResource(spec.text) + "\n\n" + stringResource(R.string.perm_denied_hint)
    } else {
        stringResource(spec.text)
    }
    val actionText = spec.action?.let { id -> stringResource(id) }
    Box(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.TopCenter) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            AeroEmptyState(
                icon = spec.icon,
                title = stringResource(spec.title),
                message = message,
                actionText = actionText,
                onAction = if (actionText != null) spec.onAction else null,
            )
            if (kind == HomeEmpty.SEARCHING) {
                AeroProgressBar(progress = 0f, modifier = Modifier.width(160.dp), indeterminate = true)
            }
        }
    }
}
