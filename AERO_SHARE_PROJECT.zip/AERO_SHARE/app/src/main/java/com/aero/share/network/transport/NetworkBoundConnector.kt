package com.aero.share.network.transport

import android.net.Network
import com.aero.share.transfer.engine.SocketConnector
import java.io.IOException
import java.net.InetSocketAddress
import java.net.Socket

/**
 * Opens TCP connections through one specific [Network]: the Wi-Fi LAN when the phone's default network is mobile data
 * (a Wi-Fi without internet is not the default network on many phones), or a hotspot joined for pairing.
 */
class NetworkBoundConnector(private val network: Network) : SocketConnector {
    override fun connect(host: String, port: Int, timeoutMs: Int): Socket {
        val socket = Socket()
        try {
            network.bindSocket(socket)
            val address = network.getByName(host)
            socket.connect(InetSocketAddress(address, port), timeoutMs)
            return socket
        } catch (t: Throwable) {
            try {
                socket.close()
            } catch (e: IOException) {
                // nothing more to do
            }
            throw t
        }
    }
}
