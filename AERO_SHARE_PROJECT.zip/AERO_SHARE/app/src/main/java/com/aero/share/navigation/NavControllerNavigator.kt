package com.aero.share.navigation

import androidx.navigation.NavHostController

/**
 * [AeroNavigator] on top of a [NavHostController]. [onExit] is called when "back" is requested on the very first screen,
 * so the screen never ends up with an empty back stack.
 */
internal class NavControllerNavigator(
    private val navController: NavHostController,
    private val onExit: () -> Unit,
) : AeroNavigator {

    override fun back() {
        if (navController.previousBackStackEntry != null) {
            navController.popBackStack()
        } else {
            onExit()
        }
    }

    override fun openHome() = switchTab(Routes.HOME)

    override fun openDevices() = switchTab(Routes.DEVICES)

    override fun openSettings() = switchTab(Routes.SETTINGS)

    override fun openHistory() = push(Routes.HISTORY)

    override fun openSettingsSection(section: SettingsSection) = push(Routes.settingsSection(section))

    override fun openDiagnostics() = push(Routes.DIAGNOSTICS)

    override fun openAbout() = push(Routes.ABOUT)

    override fun openSendPicker() = push(Routes.SEND_PICK)

    override fun openRecipients() = push(Routes.SEND_RECIPIENTS)

    override fun openConfirm() = push(Routes.SEND_CONFIRM)

    override fun openReceive() = push(Routes.RECEIVE)

    override fun openTransfer(id: String, replaceCurrent: Boolean) {
        if (id.isBlank()) return
        navController.navigate(Routes.transfer(id)) {
            launchSingleTop = true
            // The send flow (picker, recipients, confirmation) is finished once a transfer exists: Back goes to Home.
            if (replaceCurrent) popUpTo(Routes.HOME) { inclusive = false }
        }
    }

    override fun backToHome() {
        if (!navController.popBackStack(Routes.HOME, false)) switchTab(Routes.HOME)
    }

    /** Tabs keep their own state: leaving one saves it, coming back restores it. Back from any tab lands on Home. */
    private fun switchTab(route: String) {
        navController.navigate(route) {
            popUpTo(Routes.HOME) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    private fun push(route: String) {
        navController.navigate(route) { launchSingleTop = true }
    }
}
