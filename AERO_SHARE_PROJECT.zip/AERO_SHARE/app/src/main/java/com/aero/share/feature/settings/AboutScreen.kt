package com.aero.share.feature.settings

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Info
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.aero.share.BuildConfig
import com.aero.share.R
import com.aero.share.core.designsystem.AeroCard
import com.aero.share.core.designsystem.AeroDivider
import com.aero.share.core.designsystem.AeroGroup
import com.aero.share.core.designsystem.AeroLogo
import com.aero.share.core.designsystem.AeroSectionHeader
import com.aero.share.core.designsystem.AeroSettingsRow
import com.aero.share.core.designsystem.AeroText
import com.aero.share.core.designsystem.AeroTheme
import com.aero.share.core.designsystem.LocalAeroToast
import com.aero.share.di.LocalAppContainer
import com.aero.share.feature.send.metaLine
import com.aero.share.navigation.AeroNavigator

/**
 * The name, version and build, who makes the app, what it does, how privacy is protected and which open-source components
 * it contains. The support row only exists in builds that were given a support address.
 */
@Composable
fun AboutScreen(navigator: AeroNavigator) {
    val container = LocalAppContainer.current
    val viewModel: SettingsViewModel = viewModel(factory = viewModelFactory { initializer { SettingsViewModel(container) } })
    val context = LocalContext.current
    val toast = LocalAeroToast.current
    val openFailed = stringResource(R.string.set_open_failed)
    val supportUrl = BuildConfig.SUPPORT_URL
    val privacy = listOf(
        R.string.about_privacy_1,
        R.string.about_privacy_2,
        R.string.about_privacy_3,
        R.string.about_privacy_4,
    )

    SettingsPage(title = stringResource(R.string.about_title), onBack = { navigator.back() }) {
        AboutHeader()
        AeroCard { AeroText(text = stringResource(R.string.about_description)) }

        AeroSectionHeader(text = stringResource(R.string.about_details_header))
        AeroGroup {
            AboutLine(stringResource(R.string.about_developer), stringResource(R.string.app_developer))
            AeroDivider()
            AboutLine(stringResource(R.string.about_version), BuildConfig.VERSION_NAME)
            AeroDivider()
            AboutLine(stringResource(R.string.about_build), BuildConfig.BUILD_NUMBER.toString())
        }

        AeroSectionHeader(text = stringResource(R.string.about_privacy_header))
        AeroCard {
            privacy.forEachIndexed { index, text ->
                if (index > 0) Spacer(Modifier.height(10.dp))
                AeroText(text = stringResource(text))
            }
        }

        AeroSectionHeader(text = stringResource(R.string.about_licenses_header))
        AeroGroup {
            Licenses.NOTICES.forEachIndexed { index, notice ->
                if (index > 0) AeroDivider()
                AeroSettingsRow(title = notice.name, subtitle = metaLine(listOf(notice.author, notice.license)))
            }
        }
        SettingsNote(text = stringResource(R.string.about_licenses_note))

        AeroSectionHeader(text = stringResource(R.string.about_more_header))
        AeroGroup {
            if (supportUrl.isNotBlank()) {
                AeroSettingsRow(
                    title = stringResource(R.string.about_support_title),
                    subtitle = stringResource(R.string.about_support_text),
                    icon = Icons.Rounded.Favorite,
                    onClick = { if (!openWebPage(context, supportUrl)) toast.show(openFailed) },
                )
                AeroDivider()
            }
            AeroSettingsRow(
                title = stringResource(R.string.about_intro_title),
                subtitle = stringResource(R.string.about_intro_text),
                icon = Icons.Rounded.Info,
                // The root watches this flag and shows the first-launch guide again at once.
                onClick = { viewModel.update { current -> current.copy(onboardingCompleted = false) } },
            )
        }
    }
}

@Composable
private fun AboutHeader() {
    Column(
        modifier = Modifier.fillMaxWidth().padding(vertical = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        AeroLogo(size = 72.dp)
        Spacer(Modifier.height(12.dp))
        AeroText(text = stringResource(R.string.app_name), style = AeroTheme.typography.title)
        AeroText(
            text = stringResource(R.string.about_version_build, BuildConfig.VERSION_NAME, BuildConfig.BUILD_NUMBER),
            style = AeroTheme.typography.caption,
            color = AeroTheme.colors.textSecondary,
        )
        Spacer(Modifier.height(6.dp))
        AeroText(
            text = stringResource(R.string.app_tagline),
            color = AeroTheme.colors.textSecondary,
            textAlign = TextAlign.Center,
        )
    }
}

@Composable
private fun AboutLine(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 48.dp)
            .padding(horizontal = AeroTheme.dimens.cardPadding, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        AeroText(text = label, modifier = Modifier.weight(1f))
        AeroText(text = value, color = AeroTheme.colors.textSecondary, textAlign = TextAlign.End)
    }
}

/** Opens an http(s) address in the browser; false when the address is not a web page or nothing can open it. */
private fun openWebPage(context: Context, address: String): Boolean {
    val clean = address.trim()
    if (!clean.startsWith("https://") && !clean.startsWith("http://")) return false
    val view = Intent(Intent.ACTION_VIEW, Uri.parse(clean)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    return try {
        context.startActivity(view)
        true
    } catch (e: ActivityNotFoundException) {
        false
    } catch (e: SecurityException) {
        false
    }
}
