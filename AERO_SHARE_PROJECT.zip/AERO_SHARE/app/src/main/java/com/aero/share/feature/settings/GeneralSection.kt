package com.aero.share.feature.settings

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aero.share.R
import com.aero.share.core.common.LocalDeviceModel
import com.aero.share.core.designsystem.AeroChoiceRow
import com.aero.share.core.designsystem.AeroDivider
import com.aero.share.core.designsystem.AeroGroup
import com.aero.share.core.designsystem.AeroInputDialog
import com.aero.share.core.designsystem.AeroSectionHeader
import com.aero.share.core.designsystem.AeroSettingsRow
import com.aero.share.core.designsystem.AeroSwitchRow
import com.aero.share.core.designsystem.findActivity
import com.aero.share.domain.AppSettings
import com.aero.share.domain.LanguagePref

/** Language, theme, the device name, searching at start-up, where received files go, and notifications. */
@Composable
internal fun GeneralSection(settings: AppSettings, viewModel: SettingsViewModel) {
    val context = LocalContext.current
    val device by viewModel.device.collectAsStateWithLifecycle()
    var renaming by rememberSaveable { mutableStateOf(false) }

    AeroGroup {
        AeroChoiceRow(
            title = stringResource(R.string.set_language_title),
            options = listOf(
                LanguagePref.SYSTEM to stringResource(R.string.common_language_system),
                LanguagePref.ENGLISH to stringResource(R.string.common_language_english),
                LanguagePref.UKRAINIAN to stringResource(R.string.common_language_ukrainian),
                LanguagePref.RUSSIAN to stringResource(R.string.common_language_russian),
            ),
            selected = settings.language,
            onSelected = { language ->
                if (language != settings.language) {
                    // The language is applied when the activity is created, so it is recreated once the choice is stored.
                    viewModel.setLanguage(language) { context.findActivity()?.recreate() }
                }
            },
        )
        AeroDivider()
        ThemeRow(settings = settings, viewModel = viewModel)
        AeroDivider()
        AeroSettingsRow(
            title = stringResource(R.string.set_device_name_title),
            subtitle = device.name,
            icon = Icons.Rounded.Edit,
            onClick = { renaming = true },
        )
        AeroDivider()
        AeroSwitchRow(
            title = stringResource(R.string.set_discover_title),
            subtitle = stringResource(R.string.set_discover_text),
            checked = settings.discoverOnLaunch,
            onCheckedChange = { on -> viewModel.update { current -> current.copy(discoverOnLaunch = on) } },
        )
    }
    SettingsNote(text = stringResource(R.string.set_device_name_hint))

    AeroSectionHeader(text = stringResource(R.string.set_receiving_header))
    AeroGroup {
        ReceiveFolderRows(
            settings = settings,
            onChosen = { uri -> viewModel.update { current -> current.copy(saveDirectoryUri = uri) } },
        )
    }

    AeroSectionHeader(text = stringResource(R.string.set_notifications_header))
    AeroGroup { NotificationRows(settings = settings, viewModel = viewModel) }

    if (renaming) {
        AeroInputDialog(
            title = stringResource(R.string.set_device_name_title),
            initialValue = settings.customDeviceName.orEmpty(),
            confirmText = stringResource(R.string.common_save),
            dismissText = stringResource(R.string.common_cancel),
            onConfirm = { text ->
                renaming = false
                viewModel.setDeviceName(text)
            },
            onDismiss = { renaming = false },
            label = stringResource(R.string.set_device_name_title),
            placeholder = device.defaultName,
            message = stringResource(R.string.set_device_name_dialog, device.defaultName),
            maxLength = LocalDeviceModel.MAX_NAME_LENGTH,
        )
    }
}
