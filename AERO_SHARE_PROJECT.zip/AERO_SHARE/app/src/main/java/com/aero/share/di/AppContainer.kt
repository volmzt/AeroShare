package com.aero.share.di

import android.app.Application
import com.aero.share.core.common.DiagnosticsLog
import com.aero.share.core.designsystem.FeedbackManager
import com.aero.share.core.storage.FileOpener
import com.aero.share.core.storage.apk.ApkInstaller
import com.aero.share.domain.CapabilityProvider
import com.aero.share.domain.DeviceRepository
import com.aero.share.domain.DiscoveryController
import com.aero.share.domain.HistoryRepository
import com.aero.share.domain.LocalDeviceProvider
import com.aero.share.domain.PowerPolicy
import com.aero.share.domain.SettingsRepository
import com.aero.share.domain.TransferCoordinator
import com.aero.share.domain.TransportPlanner
import com.aero.share.feature.send.SendSession

/** Manual dependency container; built once in [com.aero.share.AeroApp]. Features read what they need from it. */
class AppContainer(
    val application: Application,
    val settings: SettingsRepository,
    val localDevice: LocalDeviceProvider,
    val devices: DeviceRepository,
    val history: HistoryRepository,
    val discovery: DiscoveryController,
    val capabilities: CapabilityProvider,
    val planner: TransportPlanner,
    val coordinator: TransferCoordinator,
    val apkInstaller: ApkInstaller,
    val fileOpener: FileOpener,
    val power: PowerPolicy,
    val diagnostics: DiagnosticsLog,
    val feedback: FeedbackManager,
    val sendSession: SendSession,
    val launch: LaunchRequests,
)
