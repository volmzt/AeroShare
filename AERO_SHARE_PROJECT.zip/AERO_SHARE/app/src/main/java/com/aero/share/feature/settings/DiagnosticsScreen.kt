package com.aero.share.feature.settings

import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.aero.share.R
import com.aero.share.core.common.DiagnosticEntry
import com.aero.share.core.common.SystemIntents
import com.aero.share.core.common.labelRes
import com.aero.share.core.designsystem.AeroButton
import com.aero.share.core.designsystem.AeroButtonStyle
import com.aero.share.core.designsystem.AeroDivider
import com.aero.share.core.designsystem.AeroGroup
import com.aero.share.core.designsystem.AeroSectionHeader
import com.aero.share.core.designsystem.AeroSettingsRow
import com.aero.share.core.designsystem.AeroText
import com.aero.share.core.designsystem.AeroTheme
import com.aero.share.core.designsystem.LocalAeroToast
import com.aero.share.di.LocalAppContainer
import com.aero.share.domain.DiscoveryProblem
import com.aero.share.domain.DiscoveryStatus
import com.aero.share.domain.ReceiverStatus
import com.aero.share.navigation.AeroNavigator
import java.text.DateFormat
import java.util.Date

/**
 * What this device can do right now and what the app has been doing. All values come from the components that own them,
 * and the same data can be copied or shared as a plain-text report.
 */
@Composable
fun DiagnosticsScreen(navigator: AeroNavigator) {
    val container = LocalAppContainer.current
    val viewModel: DiagnosticsViewModel = viewModel(factory = viewModelFactory { initializer { DiagnosticsViewModel(container) } })
    val input by viewModel.state.collectAsStateWithLifecycle()

    // Radios and permissions are changed in the system settings, so they are read again whenever the page comes back.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { viewModel.refresh() }

    SettingsPage(title = stringResource(R.string.diag_title), onBack = { navigator.back() }) {
        val current = input
        if (current != null) DiagnosticsContent(current, viewModel)
    }
}

@Composable
private fun DiagnosticsContent(input: DiagnosticsInput, viewModel: DiagnosticsViewModel) {
    val context = LocalContext.current
    val toast = LocalAeroToast.current
    val on = stringResource(R.string.common_on)
    val off = stringResource(R.string.common_off)
    val yes = stringResource(R.string.diag_yes)
    val no = stringResource(R.string.diag_no)
    val copied = stringResource(R.string.common_copied)
    val copyFailed = stringResource(R.string.diag_copy_failed)
    val shareFailed = stringResource(R.string.diag_share_failed)
    val shareTitle = stringResource(R.string.diag_share_title)
    val radio = input.radio

    SettingsNote(text = stringResource(R.string.diag_intro))

    AeroSectionHeader(text = stringResource(R.string.diag_device_header))
    AeroGroup {
        DiagLine(stringResource(R.string.diag_app), stringResource(R.string.diag_version_build, input.appVersion, input.buildNumber))
        AeroDivider()
        DiagLine(stringResource(R.string.diag_android), stringResource(R.string.diag_android_value, input.androidRelease, input.sdkInt))
        AeroDivider()
        DiagLine(stringResource(R.string.diag_model), input.deviceModel)
    }

    if (input.capabilities.isNotEmpty()) {
        AeroSectionHeader(text = stringResource(R.string.set_capabilities_title))
        AeroGroup {
            SettingsLogic.orderedTransports(input.capabilities).forEachIndexed { index, capability ->
                if (index > 0) AeroDivider()
                DiagLine(stringResource(capability.kind.labelRes()), stringResource(capability.state.labelRes()))
            }
        }
    }

    AeroSectionHeader(text = stringResource(R.string.diag_state_header))
    AeroGroup {
        val wifiLink = stringResource(if (radio.wifiConnected) R.string.diag_connected else R.string.diag_not_connected)
        DiagLine(stringResource(R.string.diag_wifi), stringResource(R.string.common_pair, if (radio.wifiEnabled) on else off, wifiLink))
        AeroDivider()
        val bluetooth = if (!radio.bluetoothSupported) stringResource(R.string.diag_not_supported) else if (radio.bluetoothEnabled) on else off
        DiagLine(stringResource(R.string.diag_bluetooth), bluetooth)
        AeroDivider()
        DiagLine(stringResource(R.string.diag_location), if (radio.locationEnabled) on else off)
        AeroDivider()
        DiagLine(stringResource(R.string.diag_receiver), stringResource(input.receiver.labelRes()))
        AeroDivider()
        val problem = input.discovery.problem
        val searching = stringResource(input.discovery.status.labelRes())
        val discovery = if (input.discovery.status == DiscoveryStatus.PROBLEM && problem != null) {
            stringResource(R.string.common_pair, searching, stringResource(problem.labelRes()))
        } else {
            searching
        }
        DiagLine(stringResource(R.string.diag_discovery), discovery)
        AeroDivider()
        DiagLine(stringResource(R.string.diag_announcing), if (input.discovery.advertising) yes else no)
        AeroDivider()
        DiagLine(stringResource(R.string.diag_nearby), input.nearbyCount.toString())
        AeroDivider()
        DiagLine(stringResource(R.string.diag_active), input.activeTransfers.toString())
    }
    SettingsNote(text = stringResource(R.string.set_bluetooth_note))

    AeroSectionHeader(text = stringResource(R.string.diag_perm_header))
    AeroGroup {
        input.permissions.forEachIndexed { index, line ->
            if (index > 0) AeroDivider()
            val open: (() -> Unit)? = if (line.granted) null else ({ openSettingsFor(line.kind, context) })
            AeroSettingsRow(
                title = stringResource(line.kind.labelRes()),
                subtitle = stringResource(if (line.granted) R.string.diag_granted else R.string.diag_not_granted),
                icon = if (line.granted) Icons.Rounded.Check else Icons.Rounded.Warning,
                onClick = open,
            )
        }
        AeroDivider()
        AeroSettingsRow(
            title = stringResource(R.string.diag_perm_install),
            subtitle = stringResource(if (input.canInstallPackages) R.string.diag_allowed else R.string.diag_not_allowed),
            icon = if (input.canInstallPackages) Icons.Rounded.Check else Icons.Rounded.Warning,
        )
    }

    val events = DiagnosticsReport.recentEvents(input.log)
    AeroSectionHeader(text = stringResource(R.string.diag_events_header))
    if (events.isEmpty()) {
        SettingsNote(text = stringResource(R.string.diag_events_empty))
    } else {
        AeroGroup {
            events.asReversed().forEachIndexed { index, entry ->
                if (index > 0) AeroDivider()
                EventRow(entry)
            }
        }
    }
    SettingsNote(text = stringResource(R.string.diag_report_note))

    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        AeroButton(
            text = stringResource(R.string.diag_share),
            onClick = {
                if (!DiagnosticsActions.share(context, viewModel.reportText(input), shareTitle)) toast.show(shareFailed)
            },
            modifier = Modifier.weight(1f),
            icon = Icons.Rounded.Share,
        )
        AeroButton(
            text = stringResource(R.string.diag_copy),
            onClick = {
                toast.show(if (DiagnosticsActions.copy(context, viewModel.reportText(input))) copied else copyFailed)
            },
            modifier = Modifier.weight(1f),
            style = AeroButtonStyle.Secondary,
            icon = Icons.Rounded.ContentCopy,
        )
    }
    Spacer(Modifier.height(10.dp))
    AeroButton(
        text = stringResource(R.string.diag_clear),
        onClick = { viewModel.clearLog() },
        modifier = Modifier.fillMaxWidth(),
        style = AeroButtonStyle.Secondary,
        enabled = input.log.isNotEmpty(),
    )
}

/** A label on the left and its value on the right; long values wrap instead of being cut. */
@Composable
private fun DiagLine(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 48.dp)
            .padding(horizontal = AeroTheme.dimens.cardPadding, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        AeroText(text = label, modifier = Modifier.weight(1f))
        AeroText(text = value, modifier = Modifier.weight(1f), color = AeroTheme.colors.textSecondary, textAlign = TextAlign.End)
    }
}

@Composable
private fun EventRow(entry: DiagnosticEntry) {
    val time = DateFormat.getTimeInstance(DateFormat.MEDIUM).format(Date(entry.timestamp))
    Column(modifier = Modifier.fillMaxWidth().padding(horizontal = AeroTheme.dimens.cardPadding, vertical = 8.dp)) {
        AeroText(
            text = stringResource(R.string.common_pair, time, entry.category),
            style = AeroTheme.typography.caption,
            color = AeroTheme.colors.textSecondary,
        )
        AeroText(text = entry.message)
    }
}

private fun openSettingsFor(kind: PermissionKind, context: Context) {
    if (kind == PermissionKind.NOTIFICATIONS) SystemIntents.openNotificationSettings(context) else SystemIntents.openAppSettings(context)
}

private fun PermissionKind.labelRes(): Int = when (this) {
    PermissionKind.NEARBY -> R.string.perm_nearby_title
    PermissionKind.CAMERA -> R.string.perm_camera_title
    PermissionKind.NOTIFICATIONS -> R.string.perm_notifications_title
}

private fun ReceiverStatus.labelRes(): Int = when (this) {
    ReceiverStatus.OFF -> R.string.diag_receiver_off
    ReceiverStatus.STARTING -> R.string.diag_receiver_starting
    ReceiverStatus.LISTENING -> R.string.diag_receiver_listening
    ReceiverStatus.ERROR -> R.string.diag_receiver_error
}

private fun DiscoveryStatus.labelRes(): Int = when (this) {
    DiscoveryStatus.IDLE -> R.string.diag_discovery_idle
    DiscoveryStatus.SEARCHING -> R.string.diag_discovery_searching
    DiscoveryStatus.PROBLEM -> R.string.diag_discovery_problem
}

private fun DiscoveryProblem.labelRes(): Int = when (this) {
    DiscoveryProblem.WIFI_OFF -> R.string.set_cap_radio_off
    DiscoveryProblem.NO_NETWORK -> R.string.set_cap_no_network
    DiscoveryProblem.PERMISSION_MISSING -> R.string.set_cap_permission
    DiscoveryProblem.UNAVAILABLE -> R.string.diag_problem_unavailable
}
