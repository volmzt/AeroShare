package com.aero.share.core.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import com.aero.share.transfer.security.DeviceIdentity
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.security.GeneralSecurityException
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Loads or creates this device's long-term TLS identity (EC P-256 key + self-signed certificate).
 *
 * The identity is stored in `noBackupFilesDir/identity/` (never backed up, never leaves the device). Key and certificate
 * are encrypted with an AES-256-GCM key that lives in the AndroidKeyStore (alias [KEY_ALIAS]). Layout of the file:
 * `version(1) | iv(12) | AES-GCM(payload)` with `payload = [u32 len][pkcs8][u32 len][certificate DER]`.
 * Any problem (missing keystore key, tag mismatch, invalid or expired certificate) creates a NEW identity: the device
 * then simply appears as a new, unknown device to its peers. Key material is never logged.
 */
class IdentityStore(private val context: Context) {

    fun loadOrCreate(): DeviceIdentity {
        val dir = File(context.noBackupFilesDir, "identity")
        val file = File(dir, FILE_NAME)
        val existing = try {
            read(file)
        } catch (e: Exception) {
            null
        }
        if (existing != null) return existing

        val fresh = DeviceIdentity.generate("AERO SHARE")
        try {
            write(dir, file, fresh)
        } catch (e: Exception) {
            // Could not persist (disk full, storage error): keep running with the in-memory identity.
        }
        return fresh
    }

    private fun read(file: File): DeviceIdentity? {
        if (!file.isFile || file.length() < 2 || file.length() > MAX_FILE_BYTES) return null
        val bytes = file.readBytes()
        val payload: ByteArray = when (bytes[0].toInt()) {
            VERSION_WRAPPED -> {
                val key = wrapKey(create = false) ?: return null
                if (bytes.size < 1 + IV_SIZE + TAG_BYTES) return null
                val iv = bytes.copyOfRange(1, 1 + IV_SIZE)
                val cipher = Cipher.getInstance(TRANSFORMATION)
                cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(TAG_BYTES * 8, iv))
                cipher.doFinal(bytes, 1 + IV_SIZE, bytes.size - 1 - IV_SIZE)
            }
            VERSION_PLAIN -> bytes.copyOfRange(1, bytes.size)
            else -> return null
        }
        val input = DataInputStream(ByteArrayInputStream(payload))
        val keyLength = input.readInt()
        if (keyLength !in 1..MAX_PART_BYTES) return null
        val privateKey = ByteArray(keyLength)
        input.readFully(privateKey)
        val certLength = input.readInt()
        if (certLength !in 1..MAX_PART_BYTES) return null
        val certificate = ByteArray(certLength)
        input.readFully(certificate)
        return try {
            DeviceIdentity.restore(privateKey, certificate)
        } catch (e: IllegalArgumentException) {
            null
        }
    }

    private fun write(dir: File, file: File, identity: DeviceIdentity) {
        if (!dir.isDirectory && !dir.mkdirs() && !dir.isDirectory) throw IOException("cannot create identity directory")
        val payload = ByteArrayOutputStream().also { buffer ->
            DataOutputStream(buffer).use { out ->
                val key = identity.privateKeyPkcs8()
                val cert = identity.certificateDer()
                out.writeInt(key.size)
                out.write(key)
                out.writeInt(cert.size)
                out.write(cert)
            }
        }.toByteArray()

        val key = wrapKey(create = true)
        val content = if (key != null) {
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.ENCRYPT_MODE, key)
            val iv = cipher.iv
            require(iv.size == IV_SIZE) { "unexpected IV size" }
            byteArrayOf(VERSION_WRAPPED.toByte()) + iv + cipher.doFinal(payload)
        } else {
            // The AndroidKeyStore is unavailable (rare emulator / OEM defect). The file is still private to this app
            // (noBackupFilesDir, MODE_PRIVATE semantics), so we keep working instead of crashing. The key is
            // not hardware-wrapped in this case.
            byteArrayOf(VERSION_PLAIN.toByte()) + payload
        }

        val temp = File(dir, "$FILE_NAME.tmp")
        FileOutputStream(temp).use { out ->
            out.write(content)
            out.fd.sync()
        }
        if (!temp.renameTo(file)) {
            file.delete()
            if (!temp.renameTo(file)) throw IOException("cannot replace identity file")
        }
    }

    /** The AES key from the AndroidKeyStore; null when the keystore cannot be used. */
    private fun wrapKey(create: Boolean): SecretKey? {
        return try {
            val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE)
            keyStore.load(null)
            val existing = keyStore.getKey(KEY_ALIAS, null) as? SecretKey
            if (existing != null || !create) return existing
            val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
            generator.init(
                KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .build(),
            )
            generator.generateKey()
        } catch (e: GeneralSecurityException) {
            null
        } catch (e: IOException) {
            null
        } catch (e: RuntimeException) {
            // ProviderException and friends thrown by broken keystore implementations.
            null
        }
    }

    private companion object {
        const val FILE_NAME = "identity.bin"
        const val KEY_ALIAS = "aero_identity_wrap_v1"
        const val ANDROID_KEYSTORE = "AndroidKeyStore"
        const val TRANSFORMATION = "AES/GCM/NoPadding"
        const val VERSION_PLAIN = 0
        const val VERSION_WRAPPED = 1
        const val IV_SIZE = 12
        const val TAG_BYTES = 16
        const val MAX_PART_BYTES = 8192
        const val MAX_FILE_BYTES = 32L * 1024
    }
}
