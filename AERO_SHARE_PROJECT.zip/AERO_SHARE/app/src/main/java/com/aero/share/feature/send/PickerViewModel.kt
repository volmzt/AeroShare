package com.aero.share.feature.send

import android.content.Intent
import android.net.Uri
import androidx.compose.ui.graphics.ImageBitmap
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aero.share.di.AppContainer
import com.aero.share.domain.AppItem
import com.aero.share.domain.FolderItem
import com.aero.share.domain.SelectionItem
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/** What one media list (Recent, Images, Videos, Audio) is showing right now. */
internal data class MediaListState(
    val access: MediaAccess = MediaAccess.NONE,
    val entries: List<MediaEntry> = emptyList(),
    val loading: Boolean = false,
    val loaded: Boolean = false,
    val endReached: Boolean = false,
    val failed: Boolean = false,
    val nextOffset: Int = 0,
)

internal data class AppsState(
    val apps: List<AppItem> = emptyList(),
    val loading: Boolean = false,
    val loaded: Boolean = false,
    val failed: Boolean = false,
)

/** One-off notices after something was picked; the screen turns them into a toast. */
internal enum class PickerMessage { NOTHING_READABLE, SOME_UNREADABLE, EMPTY_FOLDER, FOLDER_PARTIAL }

/**
 * Loads what the picker shows and records what the person chooses in the [SendSession]. Lists are loaded lazily, the first
 * time their tab is shown and only while the permission for them is held, and never on the main thread.
 */
internal class PickerViewModel(private val container: AppContainer) : ViewModel() {
    val selection: StateFlow<List<SelectionItem>> = container.sendSession.selection
    val thumbnails = ThumbnailLoader(container.application)

    private val media = MediaRepository(container.application)
    private val appsRepository = AppsRepository(container.application)
    private val mediaStates: Map<PickerTab, MutableStateFlow<MediaListState>> = mapOf(
        PickerTab.RECENT to MutableStateFlow(MediaListState()),
        PickerTab.IMAGES to MutableStateFlow(MediaListState()),
        PickerTab.VIDEOS to MutableStateFlow(MediaListState()),
        PickerTab.AUDIO to MutableStateFlow(MediaListState()),
    )
    private val jobs = HashMap<PickerTab, Job>()
    private var currentTab = PickerTab.RECENT

    private val appsMutable = MutableStateFlow(AppsState())
    val apps: StateFlow<AppsState> = appsMutable.asStateFlow()

    private val busyMutable = MutableStateFlow(false)

    /** True while a chosen folder is being counted. */
    val busy: StateFlow<Boolean> = busyMutable.asStateFlow()

    private val messageMutable = MutableStateFlow<PickerMessage?>(null)
    val message: StateFlow<PickerMessage?> = messageMutable.asStateFlow()

    /** Only the four media tabs have a list; the screen never asks for another one. */
    fun media(tab: PickerTab): StateFlow<MediaListState> = mediaStates.getValue(tab)

    fun toggle(item: SelectionItem) = container.sendSession.toggle(item)

    fun remove(id: String) = container.sendSession.remove(id)

    fun clearSelection() = container.sendSession.clearSelection()

    fun onTabShown(tab: PickerTab) {
        currentTab = tab
        refresh()
    }

    /** The screen came to the front: the person may have changed the permissions in the system settings meanwhile. */
    fun onResume() = refresh()

    fun onPermissionResult() = refresh()

    fun retry(tab: PickerTab) {
        val flow = mediaStates[tab] ?: return
        jobs.remove(tab)?.cancel()
        flow.value = MediaListState(access = flow.value.access)
        refresh()
    }

    fun retryApps() {
        appsMutable.value = AppsState()
        loadApps()
    }

    fun loadMore(tab: PickerTab) {
        val state = mediaStates[tab]?.value ?: return
        if (state.access != MediaAccess.NONE && state.loaded && !state.loading && !state.endReached && !state.failed) load(tab)
    }

    private fun refresh() {
        val context = container.application
        for ((tab, flow) in mediaStates) {
            val access = MediaPermissions.tabAccess(context, tab)
            if (flow.value.access != access) {
                jobs.remove(tab)?.cancel()
                flow.value = MediaListState(access = access)
            }
        }
        if (PickerLogic.isMediaTab(currentTab)) {
            val state = mediaStates.getValue(currentTab).value
            if (state.access != MediaAccess.NONE && !state.loaded && !state.loading && !state.failed) load(currentTab)
        }
        if (currentTab == PickerTab.APPS) loadApps()
    }

    private fun load(tab: PickerTab) {
        val flow = mediaStates.getValue(tab)
        val offset = flow.value.nextOffset
        flow.value = flow.value.copy(loading = true, failed = false)
        jobs[tab] = viewModelScope.launch {
            val context = container.application
            val kinds = PickerLogic.kindsOf(tab).filter { kind -> MediaPermissions.access(context, kind) != MediaAccess.NONE }
            val page = when {
                kinds.isEmpty() -> MediaPage(emptyList(), false)
                tab == PickerTab.RECENT -> media.recent(kinds, PickerLogic.RECENT_LIMIT)
                else -> media.page(kinds.first(), offset, PickerLogic.PAGE_SIZE)
            }
            val before = flow.value
            flow.value = if (page.failed) {
                before.copy(loading = false, failed = true)
            } else {
                before.copy(
                    entries = PickerLogic.append(before.entries, page.entries),
                    loading = false,
                    loaded = true,
                    nextOffset = before.nextOffset + page.entries.size,
                    endReached = tab == PickerTab.RECENT || page.entries.size < PickerLogic.PAGE_SIZE,
                )
            }
        }
    }

    fun loadApps() {
        val current = appsMutable.value
        if (current.loaded || current.loading) return
        appsMutable.value = current.copy(loading = true, failed = false)
        viewModelScope.launch {
            appsMutable.value = try {
                AppsState(apps = appsRepository.load(), loaded = true)
            } catch (e: CancellationException) {
                throw e
            } catch (e: RuntimeException) {
                AppsState(failed = true)
            }
        }
    }

    fun appIconCached(packageName: String): ImageBitmap? = appsRepository.cachedIcon(packageName)

    suspend fun appIcon(packageName: String, sizePx: Int): ImageBitmap? = appsRepository.icon(packageName, sizePx)

    /** Files chosen in the system picker: kept readable if the provider allows it, then added to the selection. */
    fun onFilesPicked(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            for (uri in uris) keepAccess(uri)
            val items = SharedUriResolver.resolve(container.application, uris.map { it.toString() })
            if (items.isEmpty()) {
                messageMutable.value = PickerMessage.NOTHING_READABLE
            } else {
                container.sendSession.add(items)
                if (items.size < uris.size) messageMutable.value = PickerMessage.SOME_UNREADABLE
            }
        }
    }

    /** A folder chosen in the system picker: its files are counted first, so the selection shows what will really be sent. */
    fun onFolderPicked(uri: Uri?) {
        if (uri == null) return
        viewModelScope.launch {
            keepAccess(uri)
            busyMutable.value = true
            try {
                val context = container.application
                val name = FolderScanner.nameOf(context, uri)
                val totals = FolderScanner.measure(context, uri, name)
                if (totals.files == 0) {
                    messageMutable.value = PickerMessage.EMPTY_FOLDER
                } else {
                    val text = uri.toString()
                    container.sendSession.add(
                        listOf(FolderItem(id = text, treeUri = text, displayName = name, size = totals.bytes, fileCount = totals.files)),
                    )
                    if (totals.skipped > 0) messageMutable.value = PickerMessage.FOLDER_PARTIAL
                }
            } finally {
                busyMutable.value = false
            }
        }
    }

    fun consumeMessage() {
        messageMutable.value = null
    }

    /** Best effort: not every provider offers a lasting grant, and the transfer still works with the temporary one. */
    private fun keepAccess(uri: Uri) {
        try {
            container.application.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: SecurityException) {
            return
        } catch (e: IllegalArgumentException) {
            return
        }
    }
}
