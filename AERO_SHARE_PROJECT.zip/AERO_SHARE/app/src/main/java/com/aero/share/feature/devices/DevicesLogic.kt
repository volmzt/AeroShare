package com.aero.share.feature.devices

import com.aero.share.core.common.LocalDeviceModel
import com.aero.share.domain.DeviceRecord
import com.aero.share.domain.NearbyDevice
import com.aero.share.transfer.model.Capabilities
import com.aero.share.transfer.model.DeviceKind

/** A feature a device announced when it connected (a bit in [DeviceRecord.capabilities]). */
internal enum class DeviceFeature { COMPRESSION, RESUME, FOLDERS, WIFI_DIRECT, APK_BUNDLE }

/** One entry of "Known devices": the stored record and, while the device is visible, its live discovery entry. */
internal data class KnownRow(val record: DeviceRecord, val nearby: NearbyDevice?)

/** Whether "Send files" can be offered for a device, and if not, why. */
internal enum class SendAvailability { AVAILABLE, NOT_NEARBY, BLOCKED }

internal enum class SeenUnit { NOW, MINUTES, HOURS, DAYS, DATE, NEVER }

/** "Last seen" as a number of units; the screen turns it into words. DATE means "too long ago for a relative time". */
internal data class SeenAgo(val unit: SeenUnit, val amount: Int = 0)

/**
 * A device the person tapped: its stored record (null for a device that was only seen on the network, never connected
 * to) and its live entry (null when it is not nearby right now). At least one of them exists.
 */
internal data class DeviceTarget(val deviceId: String, val record: DeviceRecord?, val nearby: NearbyDevice?) {
    val name: String get() = record?.displayName ?: nearby?.name.orEmpty()
    val kind: DeviceKind get() = record?.kind ?: nearby?.kind ?: DeviceKind.OTHER
    val trusted: Boolean get() = record?.trusted == true
    val blocked: Boolean get() = record?.blocked == true

    /** Trust, block and rename need a stored record, which is created by the first real connection. */
    val manageable: Boolean get() = record != null
}

/** Decisions of the Devices tab that do not need Android, kept apart so they can be unit-tested. */
internal object DevicesLogic {
    const val ID_SHORT_LENGTH = 8
    const val FINGERPRINT_BLOCK = 4
    const val FINGERPRINT_BLOCKS_PER_LINE = 4
    const val RELATIVE_DAYS_LIMIT = 30

    private const val MINUTE_MS = 60_000L
    private const val HOUR_MS = 60L * MINUTE_MS
    private const val DAY_MS = 24L * HOUR_MS

    /** The stored devices in the order the repository gives them (trusted first, then newest), with their live entry. */
    fun known(records: List<DeviceRecord>, nearby: List<NearbyDevice>): List<KnownRow> {
        val live = HashMap<String, NearbyDevice>(nearby.size * 2)
        for (device in nearby) live[device.deviceId] = device
        return records.map { record -> KnownRow(record, live[record.deviceId]) }
    }

    /** "3F9A-12BC": enough to tell two devices apart in a list, never the whole identifier. */
    fun shortId(id: String): String {
        val head = id.trim().take(ID_SHORT_LENGTH).uppercase()
        return if (head.length > FINGERPRINT_BLOCK) head.substring(0, FINGERPRINT_BLOCK) + "-" + head.substring(FINGERPRINT_BLOCK) else head
    }

    /** Upper-case blocks of four characters, four blocks per line, so two fingerprints can be compared by eye. */
    fun groupFingerprint(fingerprint: String): String {
        val clean = fingerprint.filter { it.isLetterOrDigit() }.uppercase()
        if (clean.isEmpty()) return ""
        val blocks = clean.chunked(FINGERPRINT_BLOCK)
        return blocks.chunked(FINGERPRINT_BLOCKS_PER_LINE).joinToString("\n") { line -> line.joinToString(" ") }
    }

    /** The features set in a capability mask, in a fixed order. */
    fun features(mask: Int): List<DeviceFeature> {
        val result = ArrayList<DeviceFeature>(5)
        if ((mask and Capabilities.COMPRESSION) != 0) result.add(DeviceFeature.COMPRESSION)
        if ((mask and Capabilities.RESUME) != 0) result.add(DeviceFeature.RESUME)
        if ((mask and Capabilities.FOLDERS) != 0) result.add(DeviceFeature.FOLDERS)
        if ((mask and Capabilities.WIFI_DIRECT) != 0) result.add(DeviceFeature.WIFI_DIRECT)
        if ((mask and Capabilities.APK_BUNDLE) != 0) result.add(DeviceFeature.APK_BUNDLE)
        return result
    }

    /** A blocked device is never offered; otherwise the device has to be visible on the network right now. */
    fun availability(blocked: Boolean, nearby: NearbyDevice?): SendAvailability = when {
        blocked -> SendAvailability.BLOCKED
        nearby == null -> SendAvailability.NOT_NEARBY
        else -> SendAvailability.AVAILABLE
    }

    /** How long ago [then] was. A time in the future (a clock that was set back) counts as "now". */
    fun seenAgo(now: Long, then: Long): SeenAgo {
        if (then <= 0L) return SeenAgo(SeenUnit.NEVER)
        val diff = now - then
        return when {
            diff < MINUTE_MS -> SeenAgo(SeenUnit.NOW)
            diff < HOUR_MS -> SeenAgo(SeenUnit.MINUTES, (diff / MINUTE_MS).toInt())
            diff < DAY_MS -> SeenAgo(SeenUnit.HOURS, (diff / HOUR_MS).toInt())
            diff < RELATIVE_DAYS_LIMIT * DAY_MS -> SeenAgo(SeenUnit.DAYS, (diff / DAY_MS).toInt())
            else -> SeenAgo(SeenUnit.DATE)
        }
    }

    /** The alias to store for what was typed: trimmed, at most 40 characters; null (reset to the real name) when empty. */
    fun aliasOf(input: String): String? {
        val clean = input.trim().take(LocalDeviceModel.MAX_NAME_LENGTH).trimEnd()
        return if (clean.isEmpty()) null else clean
    }
}
