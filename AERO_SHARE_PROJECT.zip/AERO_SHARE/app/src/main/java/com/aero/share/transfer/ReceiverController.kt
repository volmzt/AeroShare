package com.aero.share.transfer

import com.aero.share.core.common.DiagnosticsLog
import com.aero.share.core.storage.DestinationResolver
import com.aero.share.domain.DiscoveryController
import com.aero.share.domain.LocalDeviceProvider
import com.aero.share.domain.PowerPolicy
import com.aero.share.domain.ReceiverState
import com.aero.share.domain.ReceiverStatus
import com.aero.share.transfer.engine.EngineLogger
import com.aero.share.transfer.engine.IncomingListener
import com.aero.share.transfer.engine.PeerPolicy
import com.aero.share.transfer.engine.ReceiverServer
import com.aero.share.transfer.model.LocalPeer
import com.aero.share.transfer.pairing.PairTokenRegistry
import com.aero.share.transfer.security.DeviceIdentity
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * Owns the TLS server that accepts incoming transfers and the advertisement that makes this device visible.
 * Start and stop requests are queued and executed one after the other, so a quick start/stop/start from the UI always ends
 * in the state of the last request.
 */
internal class ReceiverController(
    private val scope: CoroutineScope,
    private val identity: DeviceIdentity,
    private val localPeer: () -> LocalPeer,
    private val localDevice: LocalDeviceProvider,
    private val peerPolicy: PeerPolicy,
    private val power: PowerPolicy,
    private val destination: DestinationResolver,
    private val discovery: DiscoveryController,
    private val listener: IncomingListener,
    private val diagnostics: DiagnosticsLog,
) {
    /** Tokens of pairing QR codes; the same registry validates them when a scanning device connects. */
    val tokens = PairTokenRegistry()

    private val mutableState = MutableStateFlow(
        ReceiverState(
            status = ReceiverStatus.OFF,
            deviceName = localDevice.info.value.name,
            fingerprint = localDevice.info.value.fingerprint,
        ),
    )
    val state: StateFlow<ReceiverState> get() = mutableState

    private class Op(val start: Boolean, val done: CompletableDeferred<ReceiverState>)

    private val ops = Channel<Op>(Channel.UNLIMITED)
    private var server: ReceiverServer? = null

    init {
        scope.launch {
            for (op in ops) {
                try {
                    if (op.start) doStart() else doStop()
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    diagnostics.add("receiver", "failed: " + e.javaClass.simpleName)
                    mutableState.value = failed(e.javaClass.simpleName)
                }
                op.done.complete(mutableState.value)
            }
        }
        scope.launch {
            localDevice.info.collect { info ->
                mutableState.update { current ->
                    if (current.deviceName == info.name && current.fingerprint == info.fingerprint) {
                        current
                    } else {
                        current.copy(deviceName = info.name, fingerprint = info.fingerprint)
                    }
                }
            }
        }
    }

    /** Queues a start or stop. The returned deferred completes with the resulting state. */
    fun request(start: Boolean): CompletableDeferred<ReceiverState> {
        val op = Op(start, CompletableDeferred())
        ops.trySend(op)
        return op.done
    }

    private suspend fun doStart() {
        val info = localDevice.info.value
        val existing = server
        if (existing != null && existing.isRunning) {
            val runningPort = existing.port
            if (runningPort != null) {
                // Already listening: only refresh what may have changed (network addresses, device name).
                mutableState.value = listening(runningPort)
                return
            }
        }
        mutableState.value = ReceiverState(
            status = ReceiverStatus.STARTING,
            deviceName = info.name,
            fingerprint = info.fingerprint,
        )
        val created = ReceiverServer(
            identity = identity,
            local = { localPeer() },
            config = { power.engineConfig() },
            policy = peerPolicy,
            tokens = tokens,
            storageProvider = { destination.storage() },
            listener = listener,
            logger = EngineLogger { line -> diagnostics.add("engine", line) },
        )
        val port: Int = try {
            created.start(PREFERRED_PORT)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            diagnostics.add("receiver", "could not listen: " + e.javaClass.simpleName)
            mutableState.value = failed(e.javaClass.simpleName)
            return
        }
        server = created
        discovery.startAdvertising(OWNER, port)
        mutableState.value = listening(port)
        diagnostics.add("receiver", "listening")
    }

    private suspend fun doStop() {
        val running = server
        server = null
        running?.stop()
        discovery.stopAdvertising(OWNER)
        tokens.invalidateAll()
        val info = localDevice.info.value
        mutableState.value = ReceiverState(
            status = ReceiverStatus.OFF,
            deviceName = info.name,
            fingerprint = info.fingerprint,
        )
        if (running != null) diagnostics.add("receiver", "stopped")
    }

    private fun listening(port: Int): ReceiverState {
        val info = localDevice.info.value
        return ReceiverState(
            status = ReceiverStatus.LISTENING,
            port = port,
            addresses = LocalAddresses.receiverAddresses(LocalAddresses.enumerate()),
            deviceName = info.name,
            fingerprint = info.fingerprint,
        )
    }

    private fun failed(detail: String): ReceiverState {
        val info = localDevice.info.value
        return ReceiverState(
            status = ReceiverStatus.ERROR,
            deviceName = info.name,
            fingerprint = info.fingerprint,
            errorDetail = detail,
        )
    }

    private companion object {
        const val PREFERRED_PORT = 47474
        const val OWNER = "receiver"
    }
}
