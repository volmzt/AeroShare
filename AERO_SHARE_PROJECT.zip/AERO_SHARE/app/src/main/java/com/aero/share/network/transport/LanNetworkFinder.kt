package com.aero.share.network.transport

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import com.aero.share.network.discovery.LanNetwork
import com.aero.share.network.discovery.LocalSubnet
import java.net.Inet4Address

/**
 * Finds the Wi-Fi or Ethernet network that has an IPv4 address right now, without registering any callback. Wi-Fi wins
 * over Ethernet; VPN networks are never a LAN. A network without internet access counts (that is the usual home LAN).
 */
internal object LanNetworkFinder {
    @Suppress("DEPRECATION")
    fun find(context: Context): LanNetwork? {
        val manager = context.applicationContext.getSystemService(ConnectivityManager::class.java) ?: return null
        val networks = try {
            manager.allNetworks
        } catch (e: RuntimeException) {
            return null
        }
        var wifi: LanNetwork? = null
        var wired: LanNetwork? = null
        for (network in networks) {
            val lan = describe(manager, network) ?: continue
            if (lan.isWifi) {
                if (wifi == null) wifi = lan
            } else if (wired == null) {
                wired = lan
            }
        }
        return wifi ?: wired
    }

    private fun describe(manager: ConnectivityManager, network: Network): LanNetwork? {
        val capabilities = manager.getNetworkCapabilities(network) ?: return null
        if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) return null
        val isWifi = capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
        val isWired = capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
        if (!isWifi && !isWired) return null
        val link = manager.getLinkProperties(network) ?: return null
        val subnets = ArrayList<LocalSubnet>()
        for (linkAddress in link.linkAddresses) {
            val address = linkAddress.address
            if (address is Inet4Address) {
                val text = address.hostAddress ?: continue
                subnets.add(LocalSubnet(text, linkAddress.prefixLength))
            }
        }
        if (subnets.isEmpty()) return null
        return LanNetwork(network, link.interfaceName, isWifi, subnets)
    }
}
