package com.aero.share.core.storage

import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.provider.OpenableColumns
import java.io.File
import java.io.IOException

internal data class UriMeta(val name: String?, val size: Long, val lastModified: Long, val mimeType: String?)

/** Reads name / size / modification time / type of a content or file URI. Returns null when the source is gone or unreadable. */
internal object UriMetadata {
    fun query(context: Context, uri: Uri): UriMeta? {
        if (uri.scheme == "file") {
            val file = File(uri.path ?: return null)
            if (!file.isFile) return null
            return UriMeta(file.name, file.length(), file.lastModified(), null)
        }
        val resolver = context.contentResolver
        var name: String? = null
        var size = -1L
        var modified = 0L
        try {
            val cursor = resolver.query(uri, null, null, null, null) ?: return null
            cursor.use { c ->
                if (!c.moveToFirst()) return null
                name = c.stringOf(OpenableColumns.DISPLAY_NAME)
                size = c.longOf(OpenableColumns.SIZE) ?: -1L
                modified = c.longOf(DocumentsContract.Document.COLUMN_LAST_MODIFIED)
                    ?: c.longOf(MediaStore.MediaColumns.DATE_MODIFIED)?.times(1000L)
                    ?: 0L
            }
            if (size < 0L) size = descriptorSize(context, uri)
            if (size < 0L) return null
            return UriMeta(name, size, modified, resolver.getType(uri))
        } catch (e: SecurityException) {
            return null
        } catch (e: IOException) {
            return null
        } catch (e: RuntimeException) {
            return null
        }
    }

    private fun descriptorSize(context: Context, uri: Uri): Long =
        try {
            context.contentResolver.openFileDescriptor(uri, "r")?.use { it.statSize } ?: -1L
        } catch (e: IOException) {
            -1L
        } catch (e: RuntimeException) {
            -1L
        }

    private fun Cursor.stringOf(column: String): String? {
        val index = getColumnIndex(column)
        return if (index < 0 || isNull(index)) null else getString(index)
    }

    private fun Cursor.longOf(column: String): Long? {
        val index = getColumnIndex(column)
        return if (index < 0 || isNull(index)) null else getLong(index)
    }
}
