package com.aero.share.feature.transfer

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aero.share.core.storage.apk.InstallEvent
import com.aero.share.core.storage.apk.InstallEvents
import com.aero.share.di.AppContainer
import com.aero.share.transfer.model.TransferSnapshot
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

/**
 * One transfer on screen. The transfer itself lives in the coordinator (and its foreground service), so leaving the screen
 * never stops it; this class only watches it, passes the buttons on, and keeps the last result of the system installer
 * for received packages.
 */
internal class TransferViewModel(private val container: AppContainer, private val id: String) : ViewModel() {
    private val coordinator = container.coordinator
    private val installResult = MutableStateFlow<InstallEvent?>(null)

    /** The live transfer; null once it was dismissed or when the id is unknown (for example after the app was restarted). */
    val snapshot: StateFlow<TransferSnapshot?> = coordinator.observe(id)

    /** What the system installer last reported, if anything. */
    val install: StateFlow<InstallEvent?> get() = installResult

    init {
        // The system installer is a separate window; its result is collected here, which outlives the screen being stopped.
        viewModelScope.launch {
            InstallEvents.flow.collect { event -> installResult.value = event }
        }
    }

    fun pause() = coordinator.pause(id)

    fun resume() = coordinator.resume(id)

    fun cancel() = coordinator.cancel(id)

    fun retry() = coordinator.retry(id)

    /** Removes a finished transfer from the live list. It stays in History. */
    fun dismiss() = coordinator.dismiss(id)

    fun canInstall(): Boolean = container.apkInstaller.canRequestInstall()

    fun openInstallSettings() = container.apkInstaller.openInstallPermissionSettings()

    fun install(uri: String) {
        installResult.value = null
        viewModelScope.launch { container.apkInstaller.install(uri) }
    }
}
