package com.aero.share.feature.send

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.aero.share.R
import com.aero.share.core.common.labelRes
import com.aero.share.core.designsystem.AeroBadge
import com.aero.share.core.designsystem.AeroButton
import com.aero.share.core.designsystem.AeroButtonStyle
import com.aero.share.core.designsystem.AeroCard
import com.aero.share.core.designsystem.AeroDeviceIcon
import com.aero.share.core.designsystem.AeroDialogFrame
import com.aero.share.core.designsystem.AeroScreen
import com.aero.share.core.designsystem.AeroText
import com.aero.share.core.designsystem.AeroTextField
import com.aero.share.core.designsystem.AeroTheme
import com.aero.share.core.designsystem.AeroTopBar
import com.aero.share.network.pairing.QrScannerView

/** One device the person can choose: icon, name, how it was found, its badges and the selection mark. */
@Composable
internal fun RecipientCard(row: RecipientRow, onToggle: () -> Unit) {
    val colors = AeroTheme.colors
    val name = row.name.ifBlank { stringResource(R.string.common_unknown_device) }
    val kindText = stringResource(row.kind.labelRes())
    val detail = when {
        row.source == RecipientSource.MANUAL -> stringResource(R.string.send_recipient_source_manual)
        row.source == RecipientSource.QR -> stringResource(R.string.send_recipient_source_qr)
        !row.visible -> stringResource(R.string.send_recipient_not_visible)
        else -> row.quality?.let { quality -> stringResource(R.string.common_pair, kindText, stringResource(quality.labelRes())) } ?: kindText
    }
    val transports = row.transports.sortedBy { it.ordinal }.map { stringResource(it.labelRes()) }.joinToString(", ")
    AeroCard(modifier = Modifier.semantics { this.selected = row.selected }, onClick = onToggle) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(AeroTheme.dimens.radiusSmall))
                    .background(colors.accentContainer),
                contentAlignment = Alignment.Center,
            ) {
                AeroDeviceIcon(kind = row.kind)
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                AeroText(text = name, style = AeroTheme.typography.bodyStrong, maxLines = 1)
                AeroText(text = detail, style = AeroTheme.typography.caption, color = colors.textSecondary, maxLines = 1)
                val address = row.address
                if (address != null) {
                    AeroText(text = address, style = AeroTheme.typography.caption, color = colors.textSecondary, maxLines = 1)
                } else if (transports.isNotEmpty()) {
                    AeroText(text = transports, style = AeroTheme.typography.caption, color = colors.textSecondary, maxLines = 1)
                }
            }
            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                if (row.trusted) AeroBadge(text = stringResource(R.string.common_trust_trusted), color = colors.success)
                if (row.blocked) AeroBadge(text = stringResource(R.string.common_trust_blocked), color = colors.danger)
            }
            Spacer(Modifier.width(12.dp))
            SelectionIndicator(selected = row.selected)
        }
    }
}

/** A trusted device that cannot be reached right now: shown dimmed and without a selection mark. */
@Composable
internal fun OfflineCard(row: OfflineRow) {
    val colors = AeroTheme.colors
    AeroCard(modifier = Modifier.alpha(0.55f)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(AeroTheme.dimens.radiusSmall))
                    .background(colors.surfaceAlt),
                contentAlignment = Alignment.Center,
            ) {
                AeroDeviceIcon(kind = row.kind)
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                AeroText(
                    text = row.name.ifBlank { stringResource(R.string.common_unknown_device) },
                    style = AeroTheme.typography.bodyStrong,
                    maxLines = 1,
                )
                AeroText(
                    text = stringResource(R.string.send_recipient_not_visible),
                    style = AeroTheme.typography.caption,
                    color = colors.textSecondary,
                    maxLines = 1,
                )
            }
        }
    }
}

@Composable
internal fun RecipientsBottomBar(chosen: Int, onContinue: () -> Unit) {
    val colors = AeroTheme.colors
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(colors.surfaceElevated)
            .padding(horizontal = AeroTheme.dimens.screenPadding, vertical = 12.dp),
    ) {
        AeroText(
            text = if (chosen == 0) {
                stringResource(R.string.send_recipients_none_chosen)
            } else {
                pluralStringResource(R.plurals.send_recipients_chosen, chosen, chosen)
            },
            color = colors.textSecondary,
        )
        Spacer(Modifier.height(10.dp))
        AeroButton(
            text = stringResource(R.string.send_recipients_continue),
            onClick = onContinue,
            modifier = Modifier.fillMaxWidth(),
            enabled = chosen > 0,
        )
    }
}

/** Two fields, checked with [RecipientsLogic.parseManual]; the port is pre-filled with the one receivers listen on first. */
@Composable
internal fun ManualAddressDialog(onDismiss: () -> Unit, onAdd: (String, Int) -> Unit) {
    var host by rememberSaveable { mutableStateOf("") }
    var port by rememberSaveable { mutableStateOf(RecipientsLogic.DEFAULT_PORT.toString()) }
    var hostError by rememberSaveable { mutableStateOf(false) }
    var portError by rememberSaveable { mutableStateOf(false) }
    AeroDialogFrame(onDismiss = onDismiss) {
        AeroText(text = stringResource(R.string.send_manual_title), style = AeroTheme.typography.titleSmall)
        Spacer(Modifier.height(12.dp))
        AeroText(text = stringResource(R.string.send_manual_text), color = AeroTheme.colors.textSecondary)
        Spacer(Modifier.height(16.dp))
        AeroTextField(
            value = host,
            onValueChange = {
                host = it
                hostError = false
            },
            modifier = Modifier.fillMaxWidth(),
            label = stringResource(R.string.send_manual_host),
            placeholder = stringResource(R.string.send_manual_host_hint),
            keyboardType = KeyboardType.Uri,
            isError = hostError,
            supportingText = if (hostError) stringResource(R.string.send_manual_error_host) else null,
        )
        Spacer(Modifier.height(12.dp))
        AeroTextField(
            value = port,
            onValueChange = {
                port = it
                portError = false
            },
            modifier = Modifier.fillMaxWidth(),
            label = stringResource(R.string.send_manual_port),
            keyboardType = KeyboardType.Number,
            isError = portError,
            supportingText = if (portError) stringResource(R.string.send_manual_error_port) else null,
        )
        Spacer(Modifier.height(20.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
            AeroButton(text = stringResource(R.string.common_cancel), onClick = onDismiss, style = AeroButtonStyle.Ghost)
            Spacer(Modifier.width(8.dp))
            AeroButton(
                text = stringResource(R.string.send_manual_add),
                onClick = {
                    when (val target = RecipientsLogic.parseManual(host, port)) {
                        is ManualTarget.Valid -> onAdd(target.host, target.port)
                        ManualTarget.InvalidHost -> hostError = true
                        ManualTarget.InvalidPort -> portError = true
                    }
                },
            )
        }
    }
}

/** The camera view that reads a pairing QR code. Only shown after the camera permission was explained and allowed. */
@Composable
internal fun ScannerPane(onScanned: (String) -> Unit, onError: (String) -> Unit, onClose: () -> Unit) {
    val colors = AeroTheme.colors
    AeroScreen {
        AeroTopBar(title = stringResource(R.string.send_scan_title), onBack = onClose)
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = AeroTheme.dimens.screenPadding)
                .clip(RoundedCornerShape(AeroTheme.dimens.radius))
                .background(colors.surfaceAlt),
        ) {
            QrScannerView(modifier = Modifier.fillMaxSize(), onScanned = onScanned, onError = onError)
        }
        AeroText(
            text = stringResource(R.string.send_scan_hint),
            modifier = Modifier.fillMaxWidth().padding(AeroTheme.dimens.screenPadding),
            color = colors.textSecondary,
            textAlign = TextAlign.Center,
        )
        AeroButton(
            text = stringResource(R.string.common_cancel),
            onClick = onClose,
            modifier = Modifier.fillMaxWidth().padding(horizontal = AeroTheme.dimens.screenPadding).padding(bottom = 12.dp),
            style = AeroButtonStyle.Secondary,
        )
    }
}
