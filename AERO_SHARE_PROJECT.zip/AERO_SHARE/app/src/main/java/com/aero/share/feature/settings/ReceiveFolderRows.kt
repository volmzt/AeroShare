package com.aero.share.feature.settings

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.aero.share.R
import com.aero.share.core.designsystem.AeroDivider
import com.aero.share.core.designsystem.AeroSettingsRow
import com.aero.share.core.designsystem.AeroTheme
import com.aero.share.domain.AppSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** The Android side of the receive-folder setting. It follows the same rules as the code that really saves the files. */
internal object ReceiveFolderReader {
    /** Touches the folder provider, so call it off the main thread. */
    fun read(context: Context, rawUri: String?): ReceiveFolder {
        if (rawUri.isNullOrBlank()) return ReceiveFolder.Default
        return try {
            val uri = Uri.parse(rawUri)
            val persisted = context.contentResolver.persistedUriPermissions.any { grant -> grant.uri == uri && grant.isWritePermission }
            val folder = DocumentFile.fromTreeUri(context, uri)
            val canWrite = folder != null && folder.exists() && folder.canWrite()
            SettingsLogic.folderState(rawUri, persisted, canWrite, folder?.name)
        } catch (e: RuntimeException) {
            ReceiveFolder.Unavailable
        }
    }

    /** Keeps access to the chosen folder across restarts; false when the provider refuses. */
    fun keep(context: Context, uri: Uri): Boolean = try {
        context.contentResolver.takePersistableUriPermission(
            uri,
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
        )
        true
    } catch (e: RuntimeException) {
        false
    }

    /** Gives back the write access to a folder that is not used for receiving any more (read access is left alone). */
    fun release(context: Context, rawUri: String?) {
        if (rawUri.isNullOrBlank()) return
        try {
            context.contentResolver.releasePersistableUriPermission(Uri.parse(rawUri), Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        } catch (e: RuntimeException) {
            // Never held or already released: there is nothing to undo.
        }
    }
}

/**
 * The "Save received files to" rows: where files go now, a picker for another folder, and a way back to the default.
 * [onChosen] gets the folder's URI as text, or null for the default folder.
 */
@Composable
internal fun ReceiveFolderRows(settings: AppSettings, onChosen: (String?) -> Unit) {
    val context = LocalContext.current
    val raw = settings.saveDirectoryUri
    var refresh by remember { mutableIntStateOf(0) }
    var failed by rememberSaveable { mutableStateOf(false) }

    // Access can be taken away in the system settings while the app is in the background.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { refresh += 1 }

    val initial: ReceiveFolder = if (raw.isNullOrBlank()) ReceiveFolder.Default else ReceiveFolder.Custom("")
    val folder by produceState(initial, raw, refresh) {
        value = withContext(Dispatchers.IO) { ReceiveFolderReader.read(context, raw) }
    }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            if (ReceiveFolderReader.keep(context, uri)) {
                failed = false
                val chosen = uri.toString()
                if (raw != chosen) ReceiveFolderReader.release(context, raw)
                onChosen(chosen)
            } else {
                failed = true
            }
        }
    }

    val unnamed = stringResource(R.string.set_folder_chosen)
    val state = folder
    val subtitle = when (state) {
        ReceiveFolder.Default -> stringResource(R.string.recv_destination_default)
        is ReceiveFolder.Custom -> if (state.name.isEmpty()) unnamed else state.name
        ReceiveFolder.Unavailable -> stringResource(R.string.set_folder_unavailable)
    }
    AeroSettingsRow(
        title = stringResource(R.string.set_folder_title),
        subtitle = subtitle,
        icon = Icons.Rounded.Folder,
        onClick = { launcher.launch(null) },
    )
    if (!raw.isNullOrBlank()) {
        AeroDivider()
        AeroSettingsRow(
            title = stringResource(R.string.set_folder_reset),
            subtitle = stringResource(R.string.set_folder_reset_hint),
            icon = Icons.Rounded.Close,
            onClick = {
                ReceiveFolderReader.release(context, raw)
                failed = false
                onChosen(null)
            },
        )
    }
    if (state == ReceiveFolder.Unavailable) {
        SettingsNote(text = stringResource(R.string.store_folder_lost), color = AeroTheme.colors.warning)
    }
    if (failed) {
        SettingsNote(text = stringResource(R.string.set_folder_failed), color = AeroTheme.colors.danger)
    }
}
