package com.aero.share.network.transport

import com.aero.share.domain.CapabilityProvider
import com.aero.share.domain.DiscoveryController
import com.aero.share.domain.DiscoveryProblem
import com.aero.share.domain.DiscoveryState
import com.aero.share.domain.NearbyDevice
import com.aero.share.domain.PowerPolicy
import com.aero.share.domain.SettingsRepository
import com.aero.share.domain.Visibility
import com.aero.share.transfer.model.TransportKind
import java.util.concurrent.atomic.AtomicBoolean
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/** The LAN half of discovery (mDNS and multicast beacons). */
internal interface LanSource {
    val devices: StateFlow<List<NearbyDevice>>
    val problem: StateFlow<DiscoveryProblem?>
    val methods: StateFlow<Set<String>>
    fun start()
    fun stop()
    fun refresh()
    fun startAdvertising(port: Int)
    fun stopAdvertising()
}

/** The Wi-Fi Direct half of discovery. */
internal interface DirectSource {
    val peers: StateFlow<List<NearbyDevice>>

    /** True while Wi-Fi Direct discovery or advertising is really up. */
    val active: StateFlow<Boolean>
    fun start()
    fun stop()
    fun refresh()
    fun startAdvertising(port: Int)
    fun stopAdvertising()
}

/**
 * Reference-counted discovery over all mechanisms. Screens register by owner tag; the mechanisms run only while at least
 * one owner needs them and stop completely afterwards (no battery use in the background). One serial loop applies the
 * wanted state, so start/stop, settings changes, capability changes and network problems can never interleave.
 */
internal class DiscoveryCoordinator(
    private val scope: CoroutineScope,
    private val lan: LanSource,
    private val direct: DirectSource,
    private val capabilities: CapabilityProvider,
    private val settings: SettingsRepository,
    private val power: PowerPolicy,
    private val log: (String) -> Unit,
    private val minRefreshMs: Long = DEFAULT_MIN_REFRESH_MS,
    private val minDirectRefreshMs: Long = DEFAULT_MIN_DIRECT_REFRESH_MS,
) : DiscoveryController {
    private val lock = Any()
    private val discoveryOwners = LinkedHashSet<String>()
    private val advertiseOwners = LinkedHashMap<String, Int>()
    private val kick = Channel<Unit>(Channel.CONFLATED)
    private val refreshRequested = AtomicBoolean(false)
    private val deviceState = MutableStateFlow<List<NearbyDevice>>(emptyList())
    private val discoveryState = MutableStateFlow(DiscoveryState())

    // Applied state: written by the loop only; the periodic refresh reads the two flags.
    @Volatile private var appliedLanDiscovery = false
    @Volatile private var appliedDirectDiscovery = false
    private var appliedLanAdvertPort: Int? = null
    private var appliedDirectAdvertPort: Int? = null
    private var refreshJob: Job? = null

    override val devices: StateFlow<List<NearbyDevice>> = deviceState.asStateFlow()
    override val state: StateFlow<DiscoveryState> = discoveryState.asStateFlow()

    init {
        scope.launch {
            for (ignored in kick) reconcile()
        }
        scope.launch {
            combine(lan.devices, direct.peers) { fromLan, fromDirect -> DeviceMerge.merge(fromLan, fromDirect) }
                .collect { merged -> deviceState.value = merged }
        }
        scope.launch {
            combine(lan.problem, lan.methods, direct.active, capabilities.capabilities, settings.settings) { _, _, _, _, _ -> }
                .collect { kick.trySend(Unit) }
        }
    }

    override fun startDiscovery(owner: String) {
        val added = synchronized(lock) { discoveryOwners.add(owner) }
        if (added) {
            capabilities.refresh()
            kick.trySend(Unit)
        }
    }

    override fun stopDiscovery(owner: String) {
        val removed = synchronized(lock) { discoveryOwners.remove(owner) }
        if (removed) kick.trySend(Unit)
    }

    override fun refresh() {
        capabilities.refresh()
        refreshRequested.set(true)
        kick.trySend(Unit)
    }

    override fun startAdvertising(owner: String, port: Int) {
        val changed = synchronized(lock) { advertiseOwners.put(owner, port) != port }
        if (changed) kick.trySend(Unit)
    }

    override fun stopAdvertising(owner: String) {
        val removed = synchronized(lock) { advertiseOwners.remove(owner) != null }
        if (removed) kick.trySend(Unit)
    }

    private fun reconcile() {
        val current = settings.settings.value
        val p2pCapability = capabilities.capabilities.value.stateOf(TransportKind.WIFI_DIRECT)
        val wanted = synchronized(lock) { Pair(discoveryOwners.isNotEmpty(), advertiseOwners.values.lastOrNull()) }
        val discoveryOwned = wanted.first
        val advertisePort = wanted.second
        val route = DiscoveryRules.route(
            RouteInputs(
                discoveryOwned = discoveryOwned,
                advertisePort = advertisePort,
                visible = current.visibility == Visibility.VISIBLE,
                lanEnabled = current.lanDiscoveryEnabled,
                p2pEnabled = current.wifiDirectEnabled,
                p2pCapability = p2pCapability,
            ),
        )
        apply(route, advertisePort)
        if (refreshRequested.getAndSet(false)) {
            if (route.lanDiscovery) lan.refresh()
            if (route.p2pDiscovery) direct.refresh()
        }
        if (route.lanDiscovery || route.p2pDiscovery) ensureRefreshJob() else cancelRefreshJob()
        discoveryState.value = DiscoveryRules.state(
            StateInputs(
                route = route,
                discoveryOwned = discoveryOwned,
                lanEnabled = current.lanDiscoveryEnabled,
                p2pEnabled = current.wifiDirectEnabled,
                lanProblem = lan.problem.value,
                lanMethods = lan.methods.value,
                p2pRunning = direct.active.value,
                p2pCapability = p2pCapability,
            ),
        )
    }

    private fun apply(route: RoutePlan, port: Int?) {
        if (route.lanDiscovery != appliedLanDiscovery) {
            if (route.lanDiscovery) lan.start() else lan.stop()
            appliedLanDiscovery = route.lanDiscovery
            log("lan discovery " + onOff(route.lanDiscovery))
        }
        if (route.p2pDiscovery != appliedDirectDiscovery) {
            if (route.p2pDiscovery) direct.start() else direct.stop()
            appliedDirectDiscovery = route.p2pDiscovery
            log("wifi-direct discovery " + onOff(route.p2pDiscovery))
        }
        val lanPort = if (route.lanAdvertising) port else null
        if (lanPort != appliedLanAdvertPort) {
            if (lanPort != null) lan.startAdvertising(lanPort) else lan.stopAdvertising()
            appliedLanAdvertPort = lanPort
            log("lan advertising " + onOff(lanPort != null))
        }
        val directPort = if (route.p2pAdvertising) port else null
        if (directPort != appliedDirectAdvertPort) {
            if (directPort != null) direct.startAdvertising(directPort) else direct.stopAdvertising()
            appliedDirectAdvertPort = directPort
            log("wifi-direct advertising " + onOff(directPort != null))
        }
    }

    /** Re-queries while somebody looks at the list. The interval follows the power mode; Wi-Fi Direct is queried less often. */
    private fun ensureRefreshJob() {
        if (refreshJob?.isActive == true) return
        refreshJob = scope.launch {
            var sinceDirect = 0L
            while (isActive) {
                val interval = power.discoveryIntervalMs().coerceAtLeast(minRefreshMs)
                delay(interval)
                if (appliedLanDiscovery) lan.refresh()
                sinceDirect += interval
                if (appliedDirectDiscovery && sinceDirect >= maxOf(interval * DIRECT_REFRESH_FACTOR, minDirectRefreshMs)) {
                    direct.refresh()
                    sinceDirect = 0L
                }
            }
        }
    }

    private fun cancelRefreshJob() {
        refreshJob?.cancel()
        refreshJob = null
    }

    private fun onOff(value: Boolean): String = if (value) "on" else "off"

    companion object {
        const val DEFAULT_MIN_REFRESH_MS = 5_000L
        const val DEFAULT_MIN_DIRECT_REFRESH_MS = 45_000L
        private const val DIRECT_REFRESH_FACTOR = 3L
    }
}
