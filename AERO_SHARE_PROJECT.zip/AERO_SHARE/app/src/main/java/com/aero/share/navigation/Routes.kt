package com.aero.share.navigation

/**
 * String routes of the NavHost. This file has no Android dependencies so the rules around routes can be unit-tested.
 * Screens never build routes themselves: they call [AeroNavigator].
 */
internal object Routes {
    const val HOME = "home"
    const val DEVICES = "devices"
    const val SETTINGS = "settings"
    const val SETTINGS_SECTION = "settings/{section}"
    const val DIAGNOSTICS = "diagnostics"
    const val ABOUT = "about"
    const val HISTORY = "history"
    const val SEND_PICK = "send/pick"
    const val SEND_RECIPIENTS = "send/recipients"
    const val SEND_CONFIRM = "send/confirm"
    const val RECEIVE = "receive"
    const val TRANSFER = "transfer/{id}"

    const val ARG_SECTION = "section"
    const val ARG_ID = "id"

    private const val HEX = "0123456789ABCDEF"

    /** Destinations of the bottom bar, in display order. Only these show the bar. */
    val TABS: List<String> = listOf(HOME, DEVICES, SETTINGS)

    /** Index of [route] in the bottom bar, or -1 when the route is not a tab. */
    fun tabIndex(route: String?): Int = if (route == null) -1 else TABS.indexOf(route)

    fun isTab(route: String?): Boolean = tabIndex(route) >= 0

    fun settingsSection(section: SettingsSection): String = "settings/" + section.name

    /** The section named by a route argument, or null for anything that is not a known section. */
    fun sectionOf(argument: String?): SettingsSection? =
        if (argument == null) null else SettingsSection.entries.firstOrNull { it.name == argument }

    fun transfer(id: String): String = "transfer/" + encodeArgument(id)

    /**
     * Percent-encodes everything except unreserved characters, so an id can never add a path segment or a query.
     * Navigation decodes path arguments again before a screen reads them.
     */
    fun encodeArgument(value: String): String {
        val bytes = value.toByteArray(Charsets.UTF_8)
        val out = StringBuilder(bytes.size + 8)
        for (b in bytes) {
            val c = b.toInt() and 0xFF
            val unreserved = (c >= 'a'.code && c <= 'z'.code) ||
                (c >= 'A'.code && c <= 'Z'.code) ||
                (c >= '0'.code && c <= '9'.code) ||
                c == '-'.code || c == '_'.code || c == '.'.code || c == '~'.code
            if (unreserved) {
                out.append(c.toChar())
            } else {
                out.append('%').append(HEX[c shr 4]).append(HEX[c and 0x0F])
            }
        }
        return out.toString()
    }
}
