package com.aero.share.domain

import com.aero.share.transfer.model.CompressionMode
import com.aero.share.transfer.model.ConflictPolicy
import kotlinx.coroutines.flow.StateFlow

enum class ThemeMode { SYSTEM, DARK, LIGHT }

enum class LanguagePref(val tag: String?) {
    SYSTEM(null), ENGLISH("en"), UKRAINIAN("uk"), RUSSIAN("ru")
}

/** Accent palette. Orange is the brand default. Values are 0xAARRGGBB. */
enum class AccentColor(val primary: Long, val secondary: Long) {
    ORANGE(0xFFFF7900, 0xFFFF9A35),
    BLUE(0xFF2F8CFF, 0xFF6AAEFF),
    GREEN(0xFF1FC46B, 0xFF5CDB95),
    PURPLE(0xFF9B6BFF, 0xFFBB9AFF),
    PINK(0xFFFF4F9A, 0xFFFF86B8),
    TEAL(0xFF14B8A6, 0xFF5EEAD4),
}

enum class PowerMode { BALANCED, PERFORMANCE, ENERGY_SAVING }

enum class Visibility { VISIBLE, HIDDEN }

/** AUTO picks the best transport; the others express a user preference that is still validated at runtime. */
enum class TransportMode { AUTO, LAN_ONLY, WIFI_DIRECT_PREFERRED }

/** Every field is a persisted, user-visible setting that changes real behavior. */
data class AppSettings(
    // General
    val language: LanguagePref = LanguagePref.SYSTEM,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    /** null = use the device model name. */
    val customDeviceName: String? = null,
    /** Start searching for nearby devices as soon as Home opens. */
    val discoverOnLaunch: Boolean = true,
    /** SAF tree URI of the receive folder; null = Downloads/AERO SHARE. */
    val saveDirectoryUri: String? = null,
    val notificationsEnabled: Boolean = true,
    val notifyIncomingRequests: Boolean = true,
    val notifyTransferResults: Boolean = true,
    // Connections
    val transportMode: TransportMode = TransportMode.AUTO,
    val lanDiscoveryEnabled: Boolean = true,
    val wifiDirectEnabled: Boolean = true,
    val visibility: Visibility = Visibility.VISIBLE,
    /** Reveals manual IP connection (send) and shows the local address/port (receive). */
    val advancedConnectionEnabled: Boolean = false,
    val connectionTimeoutSec: Int = 15,
    val qrTtlSeconds: Int = 120,
    val qrSingleUse: Boolean = true,
    // Transfers
    /** Never true by default. Unknown devices always need explicit approval regardless of this flag. */
    val autoAcceptTrusted: Boolean = false,
    val blockUnknownDevices: Boolean = false,
    val compression: CompressionMode = CompressionMode.OFF,
    val conflictPolicy: ConflictPolicy = ConflictPolicy.KEEP_BOTH,
    /** Ask for confirmation before sending more than this many bytes (0 = never ask). */
    val largeTransferWarnBytes: Long = 2L * 1024 * 1024 * 1024,
    /** Unfinished received data older than this is deleted by the cleanup worker. */
    val partialRetentionDays: Int = 3,
    /** History older than this is removed (0 = keep forever). */
    val historyRetentionDays: Int = 0,
    // Power
    val powerMode: PowerMode = PowerMode.BALANCED,
    // Customization
    val accent: AccentColor = AccentColor.ORANGE,
    val animationsEnabled: Boolean = true,
    val reducedMotion: Boolean = false,
    val hapticsEnabled: Boolean = true,
    val soundsEnabled: Boolean = true,
    val glassEffects: Boolean = false,
    val compactLists: Boolean = false,
    // App state
    val onboardingCompleted: Boolean = false,
)

interface SettingsRepository {
    /** Hot state; the first value is the persisted one (no default flash). */
    val settings: StateFlow<AppSettings>

    suspend fun update(transform: (AppSettings) -> AppSettings)
}
