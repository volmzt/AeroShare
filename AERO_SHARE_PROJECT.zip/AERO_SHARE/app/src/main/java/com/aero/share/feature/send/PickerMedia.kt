package com.aero.share.feature.send

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.aero.share.R
import com.aero.share.core.designsystem.AeroButton
import com.aero.share.core.designsystem.AeroButtonStyle
import com.aero.share.core.designsystem.AeroCard
import com.aero.share.core.designsystem.AeroEmptyState
import com.aero.share.core.designsystem.AeroProgressBar
import com.aero.share.core.designsystem.AeroText
import com.aero.share.core.designsystem.AeroTheme

/**
 * One media list (Recent, Images, Videos or Audio). Without permission it explains why it is needed first; with only
 * "selected photos" access it says so instead of pretending to show the whole library.
 */
@Composable
internal fun MediaTab(
    tab: PickerTab,
    state: MediaListState,
    selectedIds: Set<String>,
    thumbnails: ThumbnailLoader,
    permissionDenied: Boolean,
    onToggle: (MediaEntry) -> Unit,
    onLoadMore: () -> Unit,
    onRequest: () -> Unit,
    onOpenSettings: () -> Unit,
    onRetry: () -> Unit,
) {
    if (state.access == MediaAccess.NONE) {
        PermissionExplanation(denied = permissionDenied, onRequest = onRequest, onOpenSettings = onOpenSettings)
        return
    }
    Column(modifier = Modifier.fillMaxSize()) {
        if (state.access == MediaAccess.PARTIAL) PartialAccessStrip(onManage = onRequest)
        when {
            state.failed -> CenteredScroll(modifier = Modifier.weight(1f)) {
                AeroEmptyState(
                    icon = Icons.Rounded.Warning,
                    title = stringResource(R.string.send_media_error_title),
                    message = stringResource(R.string.send_media_error_text),
                    actionText = stringResource(R.string.common_retry),
                    onAction = onRetry,
                )
            }
            !state.loaded -> CenteredScroll(modifier = Modifier.weight(1f)) {
                AeroProgressBar(progress = 0f, modifier = Modifier.width(160.dp), indeterminate = true)
                AeroText(
                    text = stringResource(R.string.send_loading),
                    modifier = Modifier.padding(top = 12.dp),
                    color = AeroTheme.colors.textSecondary,
                )
            }
            state.entries.isEmpty() -> CenteredScroll(modifier = Modifier.weight(1f)) {
                AeroEmptyState(
                    icon = Icons.Rounded.Image,
                    title = stringResource(R.string.send_media_empty_title),
                    message = stringResource(R.string.send_media_empty_text),
                )
            }
            tab == PickerTab.AUDIO -> MediaList(
                entries = state.entries,
                selectedIds = selectedIds,
                onToggle = onToggle,
                onLoadMore = onLoadMore,
                modifier = Modifier.weight(1f),
            )
            else -> MediaGrid(
                entries = state.entries,
                selectedIds = selectedIds,
                thumbnails = thumbnails,
                onToggle = onToggle,
                onLoadMore = onLoadMore,
                modifier = Modifier.weight(1f),
            )
        }
    }
}

@Composable
private fun PermissionExplanation(denied: Boolean, onRequest: () -> Unit, onOpenSettings: () -> Unit) {
    val message = if (denied) {
        stringResource(R.string.perm_media_message) + "\n\n" + stringResource(R.string.perm_denied_hint)
    } else {
        stringResource(R.string.perm_media_message)
    }
    CenteredScroll {
        AeroEmptyState(
            icon = Icons.Rounded.Image,
            title = stringResource(R.string.perm_media_title),
            message = message,
            // After a refusal Android may not show its dialog again, so the app settings are the only way back.
            actionText = stringResource(if (denied) R.string.common_open_settings else R.string.common_allow),
            onAction = if (denied) onOpenSettings else onRequest,
        )
    }
}

@Composable
private fun PartialAccessStrip(onManage: () -> Unit) {
    AeroCard(modifier = Modifier.fillMaxWidth().padding(horizontal = AeroTheme.dimens.screenPadding, vertical = 8.dp)) {
        AeroText(text = stringResource(R.string.send_partial_text), style = AeroTheme.typography.caption, color = AeroTheme.colors.textSecondary)
        Row(modifier = Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.End) {
            AeroButton(text = stringResource(R.string.send_partial_manage), onClick = onManage, style = AeroButtonStyle.Secondary)
        }
    }
}

@Composable
private fun MediaGrid(
    entries: List<MediaEntry>,
    selectedIds: Set<String>,
    thumbnails: ThumbnailLoader,
    onToggle: (MediaEntry) -> Unit,
    onLoadMore: () -> Unit,
    modifier: Modifier,
) {
    val gridState = rememberLazyGridState()
    val latestLoadMore = rememberUpdatedState(onLoadMore)
    val count = entries.size
    LaunchedEffect(gridState, count) {
        snapshotFlow { gridState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0 }
            .collect { last -> if (last >= count - PickerLogic.LOAD_AHEAD) latestLoadMore.value() }
    }
    LazyVerticalGrid(
        columns = GridCells.Fixed(PickerLogic.GRID_COLUMNS),
        modifier = modifier.fillMaxSize(),
        state = gridState,
        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        items(entries, key = { entry -> entry.item.id }, contentType = { "media" }) { entry ->
            MediaCell(
                entry = entry,
                selected = entry.item.id in selectedIds,
                thumbnails = thumbnails,
                onToggle = { onToggle(entry) },
            )
        }
    }
}

@Composable
private fun MediaList(
    entries: List<MediaEntry>,
    selectedIds: Set<String>,
    onToggle: (MediaEntry) -> Unit,
    onLoadMore: () -> Unit,
    modifier: Modifier,
) {
    val listState = rememberLazyListState()
    val latestLoadMore = rememberUpdatedState(onLoadMore)
    val count = entries.size
    LaunchedEffect(listState, count) {
        snapshotFlow { listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0 }
            .collect { last -> if (last >= count - PickerLogic.LOAD_AHEAD) latestLoadMore.value() }
    }
    LazyColumn(modifier = modifier.fillMaxSize(), state = listState) {
        items(entries, key = { entry -> entry.item.id }, contentType = { "media" }) { entry ->
            MediaRow(entry = entry, selected = entry.item.id in selectedIds, onToggle = { onToggle(entry) })
        }
    }
}
