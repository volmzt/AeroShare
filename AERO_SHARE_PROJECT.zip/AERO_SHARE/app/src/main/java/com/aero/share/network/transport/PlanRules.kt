package com.aero.share.network.transport

import com.aero.share.domain.CapabilityState
import com.aero.share.domain.PlanResult
import com.aero.share.domain.TransportMode
import com.aero.share.transfer.model.TransferFailure
import java.net.NoRouteToHostException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

/**
 * Stable, non-sensitive reasons attached to a failed plan ([PlanResult.Failed.detail]). The UI may map them to more
 * specific hints than the [TransferFailure] alone. They never contain addresses, names or tokens.
 */
object PlanDetail {
    const val QR_EXPIRED = "qr-expired"
    const val HOTSPOT_MANUAL_JOIN = "hotspot-manual-join"
    const val HOTSPOT_JOIN_FAILED = "hotspot-join-failed"
    const val LAN_TIMEOUT = "lan-timeout"
    const val LAN_REFUSED = "lan-refused"
    const val LAN_NO_ROUTE = "lan-no-route"
    const val LAN_ONLY_NO_ADDRESS = "lan-only-no-address"
    const val NO_ROUTE = "no-route"
    const val WIFI_OFF = "wifi-off"
    const val WIFI_DIRECT_DISABLED = "wifi-direct-disabled"
    const val WIFI_DIRECT_UNSUPPORTED = "wifi-direct-unsupported"
    const val WIFI_DIRECT_PERMISSION = "wifi-direct-permission"
    const val WIFI_DIRECT_REJECTED = "wifi-direct-rejected"
    const val WIFI_DIRECT_BUSY = "wifi-direct-busy"
    const val WIFI_DIRECT_FAILED = "wifi-direct-failed"
    const val WIFI_DIRECT_PEER_ADDRESS = "wifi-direct-peer-address"
}

internal enum class Route { LAN, WIFI_DIRECT }

/** Result of one TCP connection attempt used to test reachability. */
internal enum class ProbeOutcome { REACHABLE, REFUSED, TIMED_OUT, NO_ROUTE }

internal object ProbeClassifier {
    fun classify(error: Throwable): ProbeOutcome {
        if (error is SocketTimeoutException) return ProbeOutcome.TIMED_OUT
        if (error is NoRouteToHostException || error is UnknownHostException) return ProbeOutcome.NO_ROUTE
        val message = error.message.orEmpty().lowercase()
        return when {
            "refused" in message -> ProbeOutcome.REFUSED
            "timed out" in message || "timeout" in message -> ProbeOutcome.TIMED_OUT
            else -> ProbeOutcome.NO_ROUTE
        }
    }
}

internal object PlanRules {
    /** Phones disagree about the time by seconds, rarely by minutes; the receiver enforces the real expiry anyway. */
    const val QR_SKEW_GRACE_MS = 60_000L

    /** The routes to try, best first. Wi-Fi Direct is only listed when the device is allowed to use it. */
    fun routes(mode: TransportMode, hasAddresses: Boolean, hasP2pAddress: Boolean, p2pUsable: Boolean): List<Route> {
        val lan = if (hasAddresses) Route.LAN else null
        val direct = if (hasP2pAddress && p2pUsable) Route.WIFI_DIRECT else null
        return when (mode) {
            TransportMode.AUTO -> listOfNotNull(lan, direct)
            TransportMode.LAN_ONLY -> listOfNotNull(lan)
            TransportMode.WIFI_DIRECT_PREFERRED -> listOfNotNull(direct, lan)
        }
    }

    /** Why [routes] is empty. */
    fun noRoute(mode: TransportMode, hasP2pAddress: Boolean, p2pEnabled: Boolean, p2pCapability: CapabilityState): PlanResult.Failed {
        if (!hasP2pAddress) {
            val detail = if (mode == TransportMode.LAN_ONLY) PlanDetail.LAN_ONLY_NO_ADDRESS else PlanDetail.NO_ROUTE
            return PlanResult.Failed(TransferFailure.UNREACHABLE, detail)
        }
        if (mode == TransportMode.LAN_ONLY) return PlanResult.Failed(TransferFailure.UNREACHABLE, PlanDetail.LAN_ONLY_NO_ADDRESS)
        if (!p2pEnabled) return PlanResult.Failed(TransferFailure.UNREACHABLE, PlanDetail.WIFI_DIRECT_DISABLED)
        return when (p2pCapability) {
            CapabilityState.PERMISSION_MISSING -> PlanResult.Failed(TransferFailure.PERMISSION, PlanDetail.WIFI_DIRECT_PERMISSION)
            CapabilityState.RADIO_OFF -> PlanResult.Failed(TransferFailure.UNREACHABLE, PlanDetail.WIFI_OFF)
            CapabilityState.UNSUPPORTED -> PlanResult.Failed(TransferFailure.UNREACHABLE, PlanDetail.WIFI_DIRECT_UNSUPPORTED)
            else -> PlanResult.Failed(TransferFailure.UNREACHABLE, PlanDetail.NO_ROUTE)
        }
    }

    /**
     * Failure for a set of failed connection attempts. Only timeouts on addresses that the device itself announced point
     * to a network that blocks device-to-device traffic (client isolation); a refused connection means the device is
     * there but not receiving.
     */
    fun failureFromProbes(outcomes: List<ProbeOutcome>, discovered: Boolean): PlanResult.Failed {
        if (outcomes.isEmpty()) return PlanResult.Failed(TransferFailure.UNREACHABLE, PlanDetail.NO_ROUTE)
        if (outcomes.any { it == ProbeOutcome.REFUSED }) return PlanResult.Failed(TransferFailure.UNREACHABLE, PlanDetail.LAN_REFUSED)
        if (outcomes.all { it == ProbeOutcome.TIMED_OUT }) {
            val failure = if (discovered) TransferFailure.NETWORK_BLOCKED else TransferFailure.TIMEOUT
            return PlanResult.Failed(failure, PlanDetail.LAN_TIMEOUT)
        }
        return PlanResult.Failed(TransferFailure.UNREACHABLE, PlanDetail.LAN_NO_ROUTE)
    }

    /** Failure of a Wi-Fi Direct connection attempt. */
    fun directFailure(reason: P2pFailure): PlanResult.Failed = when (reason) {
        P2pFailure.UNSUPPORTED -> PlanResult.Failed(TransferFailure.UNREACHABLE, PlanDetail.WIFI_DIRECT_UNSUPPORTED)
        P2pFailure.PERMISSION -> PlanResult.Failed(TransferFailure.PERMISSION, PlanDetail.WIFI_DIRECT_PERMISSION)
        P2pFailure.RADIO_OFF -> PlanResult.Failed(TransferFailure.UNREACHABLE, PlanDetail.WIFI_OFF)
        P2pFailure.BUSY -> PlanResult.Failed(TransferFailure.BUSY, PlanDetail.WIFI_DIRECT_BUSY)
        P2pFailure.TIMEOUT -> PlanResult.Failed(TransferFailure.TIMEOUT, PlanDetail.WIFI_DIRECT_REJECTED)
        P2pFailure.DECLINED -> PlanResult.Failed(TransferFailure.DECLINED, PlanDetail.WIFI_DIRECT_REJECTED)
        P2pFailure.PEER_ADDRESS_UNKNOWN -> PlanResult.Failed(TransferFailure.UNREACHABLE, PlanDetail.WIFI_DIRECT_PEER_ADDRESS)
        P2pFailure.FAILED -> PlanResult.Failed(TransferFailure.UNREACHABLE, PlanDetail.WIFI_DIRECT_FAILED)
    }

    /** The group formed but the other phone did not accept a connection on it. */
    fun directProbeFailure(outcomes: List<ProbeOutcome>): PlanResult.Failed {
        val timedOut = outcomes.isNotEmpty() && outcomes.all { it == ProbeOutcome.TIMED_OUT }
        val failure = if (timedOut) TransferFailure.TIMEOUT else TransferFailure.UNREACHABLE
        return PlanResult.Failed(failure, PlanDetail.WIFI_DIRECT_FAILED)
    }

    /** Of two failures, the one that tells the user more about what to do. [current] wins ties. */
    fun moreSpecific(current: PlanResult.Failed?, candidate: PlanResult.Failed): PlanResult.Failed {
        if (current == null) return candidate
        return if (rank(candidate.failure) > rank(current.failure)) candidate else current
    }

    fun isExpired(expiresAt: Long, now: Long): Boolean = now - QR_SKEW_GRACE_MS > expiresAt

    private fun rank(failure: TransferFailure): Int = when (failure) {
        TransferFailure.PERMISSION -> 5
        TransferFailure.NETWORK_BLOCKED -> 4
        TransferFailure.BUSY -> 3
        TransferFailure.TIMEOUT -> 2
        TransferFailure.UNREACHABLE -> 1
        else -> 0
    }
}
