package com.aero.share.feature.send

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aero.share.di.AppContainer
import com.aero.share.domain.DeviceRecord
import com.aero.share.domain.DiscoveryState
import com.aero.share.domain.DiscoveryStatus
import com.aero.share.domain.NearbyDevice
import com.aero.share.domain.Recipient
import com.aero.share.feature.home.HomeEmpty
import com.aero.share.feature.home.HomeLogic
import com.aero.share.navigation.PairingLink
import com.aero.share.navigation.PairingLinks
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

internal data class RecipientsUi(
    val sections: RecipientSections = RecipientSections(emptyList(), emptyList(), emptyList()),
    val empty: HomeEmpty? = null,
    val searching: Boolean = false,
    val chosenCount: Int = 0,
    /** The "connect by address" action is offered only when the advanced connection setting is on. */
    val advanced: Boolean = false,
)

/** What happened to a scanned QR code. */
internal sealed interface ScanOutcome {
    data class Added(val name: String) : ScanOutcome
    data object Invalid : ScanOutcome
    data object Expired : ScanOutcome
}

/**
 * Searches for nearby devices while the recipient screen is visible (and only then), joins the result with what the person
 * already decided about each device, and records every choice straight into the [SendSession].
 */
internal class RecipientsViewModel(private val container: AppContainer) : ViewModel() {
    private val longSearch = MutableStateFlow(false)
    private var resumed = false
    private var started = false
    private var timer: Job? = null

    private data class Inputs(val nearby: List<NearbyDevice>, val known: List<DeviceRecord>, val chosen: List<Recipient>)

    private data class SearchInputs(val discovery: DiscoveryState, val longEnough: Boolean)

    private val inputs = combine(container.discovery.devices, container.devices.devices, container.sendSession.recipients) { nearby, known, chosen ->
        Inputs(nearby, known, chosen)
    }
    private val searchInputs = combine(container.discovery.state, longSearch) { discovery, longEnough ->
        SearchInputs(discovery, longEnough)
    }

    val state: StateFlow<RecipientsUi> = combine(inputs, searchInputs, container.settings.settings) { input, search, settings ->
        val sections = RecipientsLogic.sections(input.nearby, input.known, input.chosen)
        RecipientsUi(
            sections = sections,
            empty = HomeLogic.emptyState(
                deviceCount = sections.nearby.size,
                discovery = search.discovery,
                searchedLongEnough = search.longEnough,
                // Somebody who is choosing a recipient wants a search, whatever "search on launch" says.
                searchWanted = true,
            ),
            searching = search.discovery.status == DiscoveryStatus.SEARCHING,
            chosenCount = input.chosen.size,
            advanced = settings.advancedConnectionEnabled,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), RecipientsUi())

    fun onResume() {
        resumed = true
        // The radio state may have changed while another screen (for example the system Wi-Fi settings) was in front.
        container.capabilities.refresh()
        beginSearch()
    }

    fun onPause() {
        resumed = false
        endSearch()
    }

    fun searchNow() {
        if (!resumed) return
        if (started) {
            restartTimer()
            container.discovery.refresh()
        } else {
            beginSearch()
        }
    }

    /** The system permission dialog was closed; whatever the answer, look at the situation again. */
    fun onPermissionResult() {
        container.capabilities.refresh()
        searchNow()
    }

    fun toggle(row: RecipientRow) {
        container.sendSession.toggleRecipient(row.recipient)
    }

    /** A pairing code was read by the camera: a usable one becomes a recipient that is already authenticated. */
    fun onScanned(text: String): ScanOutcome =
        when (val link = PairingLinks.evaluate(text, System.currentTimeMillis())) {
            is PairingLink.Usable -> {
                container.sendSession.upsertRecipient(Recipient.Qr(link.payload))
                ScanOutcome.Added(link.payload.name)
            }
            is PairingLink.Invalid -> ScanOutcome.Invalid
            is PairingLink.Expired -> ScanOutcome.Expired
        }

    fun addManual(host: String, port: Int) {
        container.sendSession.upsertRecipient(Recipient.Manual(host, port))
    }

    private fun beginSearch() {
        if (!started) {
            started = true
            container.discovery.startDiscovery(OWNER)
        }
        restartTimer()
    }

    private fun endSearch() {
        if (started) {
            started = false
            container.discovery.stopDiscovery(OWNER)
        }
        timer?.cancel()
        timer = null
        longSearch.value = false
    }

    private fun restartTimer() {
        timer?.cancel()
        longSearch.value = false
        timer = viewModelScope.launch {
            delay(HomeLogic.NONE_FOUND_AFTER_MS)
            longSearch.value = true
        }
    }

    override fun onCleared() {
        endSearch()
    }

    private companion object {
        const val OWNER = "send"
    }
}
