package com.aero.share.core.designsystem

import android.content.Context
import android.media.AudioManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import com.aero.share.domain.SettingsRepository

/**
 * Haptic and sound feedback. Both follow the user's switches live: the settings are read at the moment of every call.
 * Sounds are the system's own click sounds (no audio assets) and are subject to the system "touch sounds" setting.
 */
class FeedbackManager(context: Context, private val settings: SettingsRepository) {
    private val appContext: Context = context.applicationContext
    private val vibrator: Vibrator? = findVibrator(appContext)
    private val audio: AudioManager? = appContext.getSystemService(AudioManager::class.java)

    private enum class Kind { TAP, SUCCESS, ERROR }

    /** A light tick for ordinary presses. */
    fun tap() {
        vibrate(Kind.TAP)
        sound(AudioManager.FX_KEY_CLICK)
    }

    /** A firmer confirmation, e.g. when a transfer finished. */
    fun success() {
        vibrate(Kind.SUCCESS)
        sound(AudioManager.FX_KEYPRESS_RETURN)
    }

    /** Two short pulses for a failure. */
    fun error() {
        vibrate(Kind.ERROR)
        sound(AudioManager.FX_KEYPRESS_INVALID)
    }

    private fun vibrate(kind: Kind) {
        if (!settings.settings.value.hapticsEnabled) return
        val device = vibrator ?: return
        try {
            if (!device.hasVibrator()) return
            device.vibrate(effectFor(kind))
        } catch (e: RuntimeException) {
            // Feedback is a nicety: a vibrator that refuses (or a missing permission on a locked-down device) is ignored.
        }
    }

    private fun sound(effect: Int) {
        if (!settings.settings.value.soundsEnabled) return
        try {
            audio?.playSoundEffect(effect)
        } catch (e: RuntimeException) {
            // Same as above: sounds are optional.
        }
    }

    private fun effectFor(kind: Kind): VibrationEffect = when (kind) {
        Kind.TAP ->
            if (Build.VERSION.SDK_INT >= 29) VibrationEffect.createPredefined(VibrationEffect.EFFECT_TICK)
            else VibrationEffect.createOneShot(10L, VibrationEffect.DEFAULT_AMPLITUDE)
        Kind.SUCCESS ->
            if (Build.VERSION.SDK_INT >= 29) VibrationEffect.createPredefined(VibrationEffect.EFFECT_HEAVY_CLICK)
            else VibrationEffect.createOneShot(30L, VibrationEffect.DEFAULT_AMPLITUDE)
        Kind.ERROR -> VibrationEffect.createWaveform(longArrayOf(0L, 35L, 70L, 35L), -1)
    }

    private companion object {
        fun findVibrator(context: Context): Vibrator? {
            if (Build.VERSION.SDK_INT >= 31) {
                return context.getSystemService(VibratorManager::class.java)?.defaultVibrator
            }
            @Suppress("DEPRECATION") // VibratorManager exists only from API 31; this is the only way on API 26-30.
            val legacy = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            return legacy
        }
    }
}
