package com.aero.share.feature.settings

import android.os.Build
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aero.share.BuildConfig
import com.aero.share.core.permissions.Permissions
import com.aero.share.di.AppContainer
import com.aero.share.domain.DiscoveryState
import com.aero.share.domain.RadioStatus
import com.aero.share.domain.ReceiverStatus
import com.aero.share.domain.TransportCapability
import java.util.TimeZone
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

/**
 * Collects what is true on this device right now: what the radios and permissions allow, what discovery and the receiver
 * are doing, the recent events, and the settings that matter for connecting. Nothing here is simulated: each value comes
 * from the component that owns it.
 */
internal class DiagnosticsViewModel(private val container: AppContainer) : ViewModel() {
    private val permissionTick = MutableStateFlow(0)

    private data class Link(
        val capabilities: List<TransportCapability>,
        val radio: RadioStatus,
        val discovery: DiscoveryState,
        val nearbyCount: Int,
        val receiver: ReceiverStatus,
    )

    private val link = combine(
        container.capabilities.capabilities,
        container.capabilities.radio,
        container.discovery.state,
        container.discovery.devices,
        container.coordinator.receiver,
    ) { capabilities, radio, discovery, nearby, receiver ->
        Link(capabilities, radio, discovery, nearby.size, receiver.status)
    }

    /** Null until the first values arrived. */
    val state: StateFlow<DiagnosticsInput?> = combine(
        link,
        container.coordinator.activeCount,
        container.diagnostics.entries,
        container.settings.settings,
        permissionTick,
    ) { current, active, log, settings, _ ->
        DiagnosticsInput(
            appVersion = BuildConfig.VERSION_NAME,
            buildNumber = BuildConfig.BUILD_NUMBER,
            androidRelease = Build.VERSION.RELEASE.orEmpty(),
            sdkInt = Build.VERSION.SDK_INT,
            deviceModel = deviceModel(),
            capabilities = current.capabilities,
            radio = current.radio,
            discovery = current.discovery,
            nearbyCount = current.nearbyCount,
            receiver = current.receiver,
            activeTransfers = active,
            permissions = permissionLines(),
            canInstallPackages = container.apkInstaller.canRequestInstall(),
            settings = settings,
            log = log,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    /** Re-reads the radios and permissions, which the person may have changed in the system settings. */
    fun refresh() {
        container.capabilities.refresh()
        permissionTick.value = permissionTick.value + 1
    }

    fun clearLog() {
        container.diagnostics.clear()
    }

    fun reportText(input: DiagnosticsInput): String = DiagnosticsReport.build(input, TimeZone.getDefault())

    private fun permissionLines(): List<PermissionLine> {
        val context = container.application
        return listOf(
            PermissionLine(PermissionKind.NEARBY, Permissions.allGranted(context, Permissions.nearby())),
            PermissionLine(PermissionKind.CAMERA, Permissions.allGranted(context, Permissions.camera())),
            PermissionLine(PermissionKind.NOTIFICATIONS, NotificationManagerCompat.from(context).areNotificationsEnabled()),
        )
    }

    private fun deviceModel(): String {
        val maker = Build.MANUFACTURER.orEmpty().trim()
        val model = Build.MODEL.orEmpty().trim()
        return if (model.startsWith(maker, ignoreCase = true)) model else "$maker $model".trim()
    }
}
