package com.aero.share.core.storage

import android.app.DownloadManager
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.DocumentsContract
import android.provider.MediaStore
import androidx.core.content.FileProvider
import com.aero.share.domain.SettingsRepository
import java.io.File

/** Opens, shares and locates received files with normal Android intents. Received files are never executed by AERO SHARE. */
class FileOpenerImpl(
    private val context: Context,
    private val settings: SettingsRepository,
) : FileOpener {

    override fun open(uri: String, mimeType: String?): Boolean {
        val data = viewable(uri) ?: return false
        val type = mimeType ?: MimeTypes.fromName(uri.substringAfterLast('/'))
        // Packages are installed only through the explicit install flow (ApkInstaller), never by "opening" them.
        if (type == APK_MIME || uri.endsWith(".apk", ignoreCase = true) || uri.endsWith(".aeroapks", ignoreCase = true)) return false
        val intent = Intent(Intent.ACTION_VIEW)
            .setDataAndType(data, type)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        return start(intent)
    }

    override fun share(uris: List<String>, mimeTypes: List<String?>): Boolean {
        val list = uris.mapNotNull { viewable(it) }
        if (list.isEmpty()) return false
        val known = mimeTypes.filterNotNull().distinct()
        val type = if (known.size == 1 && mimeTypes.none { it == null }) known[0] else "*/*"
        val intent = if (list.size == 1) {
            Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, list[0])
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(list))
        }
        intent.type = type
        val clip = ClipData.newRawUri("files", list[0])
        for (index in 1 until list.size) clip.addItem(ClipData.Item(list[index]))
        intent.clipData = clip
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        return start(Intent.createChooser(intent, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    override fun openReceiveFolder(): Boolean {
        val tree = settings.settings.value.saveDirectoryUri
        if (tree != null) {
            try {
                val treeUri = Uri.parse(tree)
                val folder = DocumentsContract.buildDocumentUriUsingTree(treeUri, DocumentsContract.getTreeDocumentId(treeUri))
                val intent = Intent(Intent.ACTION_VIEW)
                    .setDataAndType(folder, DocumentsContract.Document.MIME_TYPE_DIR)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
                if (start(intent)) return true
            } catch (e: IllegalArgumentException) {
                // not a tree URI: fall through to the default folder
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val folder = DocumentsContract.buildDocumentUri(EXTERNAL_STORAGE_AUTHORITY, "primary:Download/AERO SHARE")
            val intent = Intent(Intent.ACTION_VIEW)
                .setDataAndType(folder, DocumentsContract.Document.MIME_TYPE_DIR)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (start(intent)) return true
        }
        return start(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun start(intent: Intent): Boolean =
        try {
            context.startActivity(intent)
            true
        } catch (e: ActivityNotFoundException) {
            false
        } catch (e: SecurityException) {
            false
        }

    /** A URI other apps may read: content URIs as they are, file:// paths converted to MediaStore or FileProvider URIs. */
    private fun viewable(raw: String): Uri? {
        val uri = Uri.parse(raw)
        return when (uri.scheme) {
            "content" -> uri
            "file" -> {
                val file = File(uri.path ?: return null)
                mediaStoreUri(file) ?: try {
                    FileProvider.getUriForFile(context, "${context.packageName}.files", file)
                } catch (e: IllegalArgumentException) {
                    null
                }
            }
            else -> null
        }
    }

    @Suppress("DEPRECATION") // FileColumns.DATA is only used for file:// paths, which exist on Android 8-9 only
    private fun mediaStoreUri(file: File): Uri? {
        return try {
            val collection = MediaStore.Files.getContentUri("external")
            context.contentResolver.query(
                collection,
                arrayOf(MediaStore.Files.FileColumns._ID),
                "${MediaStore.Files.FileColumns.DATA} = ?",
                arrayOf(file.path),
                null,
            )?.use { c -> if (c.moveToFirst()) ContentUris.withAppendedId(collection, c.getLong(0)) else null }
        } catch (e: RuntimeException) {
            null
        }
    }

    private companion object {
        const val APK_MIME = "application/vnd.android.package-archive"
        const val EXTERNAL_STORAGE_AUTHORITY = "com.android.externalstorage.documents"
    }
}
