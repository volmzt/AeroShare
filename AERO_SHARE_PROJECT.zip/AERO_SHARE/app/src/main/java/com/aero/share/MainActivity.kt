package com.aero.share

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.core.content.IntentCompat
import com.aero.share.core.common.LocaleHelper
import com.aero.share.di.AppContainer
import com.aero.share.navigation.AeroRoot

/** Single activity. Hosts the Compose UI and forwards share-sheet / pairing-link intents to the UI layer. */
class MainActivity : ComponentActivity() {
    private lateinit var container: AppContainer

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(LocaleHelper.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        container = (application as AeroApp).container
        if (savedInstanceState == null) handleIntent(intent)
        setContent { AeroRoot(container) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        if (intent == null) return
        when (intent.action) {
            Intent.ACTION_SEND -> {
                val uri = IntentCompat.getParcelableExtra(intent, Intent.EXTRA_STREAM, Uri::class.java)
                if (uri != null) container.launch.sharedUris.value = listOf(uri.toString())
            }
            Intent.ACTION_SEND_MULTIPLE -> {
                val uris = IntentCompat.getParcelableArrayListExtra(intent, Intent.EXTRA_STREAM, Uri::class.java)
                if (!uris.isNullOrEmpty()) container.launch.sharedUris.value = uris.map { it.toString() }
            }
            Intent.ACTION_VIEW -> {
                val link = intent.data?.toString()
                if (link != null && link.startsWith("aero://pair")) container.launch.pairingLink.value = link
            }
        }
    }
}
