package com.aero.share.feature.settings

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.aero.share.R
import com.aero.share.core.designsystem.AeroOptionCard
import com.aero.share.domain.AppSettings
import com.aero.share.domain.PowerMode

/** Speed against battery use. The choice changes buffer sizes, how often devices are looked for and the Wi-Fi mode. */
@Composable
internal fun PowerSection(settings: AppSettings, viewModel: SettingsViewModel) {
    PowerMode.entries.forEachIndexed { index, option ->
        if (index > 0) Spacer(Modifier.height(10.dp))
        AeroOptionCard(
            title = stringResource(option.titleRes()),
            description = stringResource(option.descriptionRes()),
            selected = settings.powerMode == option,
            onClick = { viewModel.update { current -> current.copy(powerMode = option) } },
        )
    }
    SettingsNote(text = stringResource(R.string.set_power_note))
}
