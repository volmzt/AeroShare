package com.aero.share.core.designsystem

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.sizeIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

enum class AeroButtonStyle { Primary, Secondary, Ghost, Danger }

/**
 * Text button in one of four styles. Primary uses the accent (with the label colour that reads best on it), Secondary is a
 * quiet bordered surface, Ghost is text only and Danger is for destructive actions. Labels may wrap to two lines.
 */
@Composable
fun AeroButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    style: AeroButtonStyle = AeroButtonStyle.Primary,
    icon: ImageVector? = null,
    enabled: Boolean = true,
) {
    val colors = AeroTheme.colors
    val shape = RoundedCornerShape(AeroTheme.dimens.radiusSmall)
    val fill: Color
    val content: Color
    val stroke: Color?
    when (style) {
        AeroButtonStyle.Primary -> {
            fill = colors.accent
            content = colors.onAccent
            stroke = null
        }
        AeroButtonStyle.Secondary -> {
            fill = colors.surfaceAlt
            content = colors.textPrimary
            stroke = colors.divider
        }
        AeroButtonStyle.Ghost -> {
            fill = Color.Transparent
            content = colors.accentText
            stroke = null
        }
        AeroButtonStyle.Danger -> {
            fill = colors.danger
            content = colors.onDanger
            stroke = null
        }
    }
    val bordered = if (stroke != null) Modifier.border(1.dp, stroke, shape) else Modifier
    Row(
        modifier = modifier
            .alpha(if (enabled) 1f else 0.4f)
            .heightIn(min = 52.dp)
            .aeroClickable(enabled = enabled, role = Role.Button, onClick = onClick)
            .clip(shape)
            .background(fill, shape)
            .then(bordered)
            .padding(horizontal = 18.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            AeroIcon(icon = icon, contentDescription = null, tint = content, size = 20.dp)
            Spacer(Modifier.width(8.dp))
        }
        AeroText(
            text = text,
            style = AeroTheme.typography.bodyStrong,
            color = content,
            maxLines = 2,
            textAlign = TextAlign.Center,
        )
    }
}

/** Icon-only button with a 48 dp touch target. [contentDescription] is required: it is what screen readers announce. */
@Composable
fun AeroIconButton(
    icon: ImageVector,
    contentDescription: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    tint: Color = AeroTheme.colors.textPrimary,
    enabled: Boolean = true,
) {
    Box(
        modifier = modifier
            .sizeIn(minWidth = 48.dp, minHeight = 48.dp)
            .alpha(if (enabled) 1f else 0.4f)
            .aeroClickable(enabled = enabled, role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        AeroIcon(icon = icon, contentDescription = contentDescription, tint = tint, size = 24.dp)
    }
}
