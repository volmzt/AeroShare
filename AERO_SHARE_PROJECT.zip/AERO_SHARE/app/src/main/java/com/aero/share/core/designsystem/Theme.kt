package com.aero.share.core.designsystem

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.provider.Settings
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import com.aero.share.domain.AccentColor
import com.aero.share.domain.AppSettings
import com.aero.share.domain.ThemeMode

/** All colours of the interface. Built from [AeroPalette]; the accent follows the user's choice. */
@Immutable
class AeroColors(
    val background: Color,
    val surface: Color,
    val surfaceAlt: Color,
    val surfaceElevated: Color,
    val accent: Color,
    val accentSecondary: Color,
    /** Label colour on top of [accent] fills. */
    val onAccent: Color,
    /** The accent used as text or icon colour; darker than [accent] in the light theme when that is needed for contrast. */
    val accentText: Color,
    /** Soft translucent accent wash for selected rows and chips. */
    val accentContainer: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val divider: Color,
    val success: Color,
    val warning: Color,
    val danger: Color,
    val onDanger: Color,
    val scrim: Color,
    val isDark: Boolean,
)

@Immutable
class AeroTypography(
    val display: TextStyle,
    val title: TextStyle,
    val titleSmall: TextStyle,
    val body: TextStyle,
    val bodyStrong: TextStyle,
    val caption: TextStyle,
    val label: TextStyle,
    val mono: TextStyle,
) {
    companion object {
        /** Sizes are in sp so Android's font scaling applies everywhere; the smallest text is 13 sp. */
        fun default(): AeroTypography = AeroTypography(
            display = TextStyle(fontSize = 30.sp, lineHeight = 36.sp, fontWeight = FontWeight.Bold),
            title = TextStyle(fontSize = 22.sp, lineHeight = 28.sp, fontWeight = FontWeight.SemiBold),
            titleSmall = TextStyle(fontSize = 18.sp, lineHeight = 24.sp, fontWeight = FontWeight.SemiBold),
            body = TextStyle(fontSize = 16.sp, lineHeight = 22.sp, fontWeight = FontWeight.Normal),
            bodyStrong = TextStyle(fontSize = 16.sp, lineHeight = 22.sp, fontWeight = FontWeight.SemiBold),
            caption = TextStyle(fontSize = 13.sp, lineHeight = 18.sp, fontWeight = FontWeight.Normal),
            label = TextStyle(fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight.Medium),
            mono = TextStyle(fontSize = 14.sp, lineHeight = 20.sp, fontFamily = FontFamily.Monospace),
        )
    }
}

@Immutable
class AeroDimens(
    val screenPadding: Dp,
    val cardPadding: Dp,
    val gap: Dp,
    val gapSmall: Dp,
    /** Medium corner radius of cards; never pill-shaped. */
    val radius: Dp,
    val radiusSmall: Dp,
    val minTouch: Dp,
    val listItemHeight: Dp,
) {
    companion object {
        val Regular = AeroDimens(
            screenPadding = 20.dp,
            cardPadding = 16.dp,
            gap = 12.dp,
            gapSmall = 8.dp,
            radius = 16.dp,
            radiusSmall = 12.dp,
            minTouch = 48.dp,
            listItemHeight = 64.dp,
        )
        val Compact = AeroDimens(
            screenPadding = 16.dp,
            cardPadding = 12.dp,
            gap = 8.dp,
            gapSmall = 6.dp,
            radius = 14.dp,
            radiusSmall = 10.dp,
            minTouch = 48.dp,
            listItemHeight = 52.dp,
        )
    }
}

/** [enabled] is false when animations are off, reduced motion is on or the system animation scale is zero. Durations in ms. */
@Immutable
class AeroMotion(val enabled: Boolean, val short: Int, val medium: Int) {
    companion object {
        fun of(enabled: Boolean): AeroMotion =
            if (enabled) AeroMotion(true, 160, 260) else AeroMotion(false, 0, 0)
    }
}

internal fun PaletteTokens.toColors(): AeroColors = AeroColors(
    background = Color(background),
    surface = Color(surface),
    surfaceAlt = Color(surfaceAlt),
    surfaceElevated = Color(surfaceElevated),
    accent = Color(accent),
    accentSecondary = Color(accentSecondary),
    onAccent = Color(onAccent),
    accentText = Color(accentText),
    accentContainer = Color(accentContainer),
    textPrimary = Color(textPrimary),
    textSecondary = Color(textSecondary),
    divider = Color(divider),
    success = Color(success),
    warning = Color(warning),
    danger = Color(danger),
    onDanger = Color(onDanger),
    scrim = Color(scrim),
    isDark = isDark,
)

private val DefaultColors: AeroColors = AeroPalette.tokens(dark = true, accent = AccentColor.ORANGE).toColors()
private val DefaultTypography: AeroTypography = AeroTypography.default()

internal val LocalAeroColors = staticCompositionLocalOf { DefaultColors }
internal val LocalAeroTypography = staticCompositionLocalOf { DefaultTypography }
internal val LocalAeroDimens = staticCompositionLocalOf { AeroDimens.Regular }
internal val LocalAeroMotion = staticCompositionLocalOf { AeroMotion.of(true) }

/** True when the optional glass look is on (translucent cards over a soft accent glow). */
internal val LocalAeroGlass = staticCompositionLocalOf { false }

/** Access to the current design tokens. */
object AeroTheme {
    val colors: AeroColors
        @Composable @ReadOnlyComposable get() = LocalAeroColors.current

    val typography: AeroTypography
        @Composable @ReadOnlyComposable get() = LocalAeroTypography.current

    val dimens: AeroDimens
        @Composable @ReadOnlyComposable get() = LocalAeroDimens.current

    val motion: AeroMotion
        @Composable @ReadOnlyComposable get() = LocalAeroMotion.current
}

/** Provides colours, type, spacing and motion for [settings] and keeps the status/navigation bar icons readable. */
@Composable
fun AeroTheme(settings: AppSettings, content: @Composable () -> Unit) {
    val systemDark = isSystemInDarkTheme()
    val dark = when (settings.themeMode) {
        ThemeMode.SYSTEM -> systemDark
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
    }
    val colors = remember(dark, settings.accent) { AeroPalette.tokens(dark, settings.accent).toColors() }
    val typography = remember { AeroTypography.default() }
    val dimens = if (settings.compactLists) AeroDimens.Compact else AeroDimens.Regular

    val context = LocalContext.current
    val systemAnimations = remember(context) { systemAnimationsEnabled(context) }
    val motion = remember(settings.animationsEnabled, settings.reducedMotion, systemAnimations) {
        AeroMotion.of(settings.animationsEnabled && !settings.reducedMotion && systemAnimations)
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = view.context.findActivity()?.window
            if (window != null) {
                val controller = WindowCompat.getInsetsController(window, view)
                controller.isAppearanceLightStatusBars = !dark
                controller.isAppearanceLightNavigationBars = !dark
            }
        }
    }

    CompositionLocalProvider(
        LocalAeroColors provides colors,
        LocalAeroTypography provides typography,
        LocalAeroDimens provides dimens,
        LocalAeroMotion provides motion,
        LocalAeroGlass provides settings.glassEffects,
    ) {
        content()
    }
}

/** Android's "animator duration scale" developer/accessibility setting; zero means the user switched animations off. */
private fun systemAnimationsEnabled(context: Context): Boolean =
    try {
        Settings.Global.getFloat(context.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) != 0f
    } catch (e: RuntimeException) {
        true
    }

internal fun Context.findActivity(): Activity? {
    var current: Context? = this
    while (current is ContextWrapper) {
        if (current is Activity) return current
        current = current.baseContext
    }
    return null
}
