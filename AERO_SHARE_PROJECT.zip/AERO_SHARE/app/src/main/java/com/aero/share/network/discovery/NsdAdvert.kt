package com.aero.share.network.discovery

import com.aero.share.transfer.model.DeviceKind
import com.aero.share.transfer.security.Fingerprints

/** The DNS-SD (mDNS) advertisement of AERO SHARE: service type, name and the TXT record, with strict parsing. */
internal object NsdAdvert {
    const val SERVICE_TYPE = "_aeroshare._tcp."
    const val PROTOCOL_VERSION = 1
    const val SERVICE_NAME_LENGTH = 20

    /** Unique per device and stable; the visible device name travels in the TXT record, not here. */
    fun serviceName(deviceId: String): String = deviceId.take(SERVICE_NAME_LENGTH)

    /** TXT record keys: id, fp (fingerprint), n (name), k (kind), v (protocol), av (app version), c (capabilities). */
    fun attributes(presence: Beacon.Presence): Map<String, String> = linkedMapOf(
        "id" to presence.deviceId,
        "fp" to presence.fingerprint,
        "n" to DiscoveryText.clean(presence.name, BeaconCodec.MAX_NAME_BYTES),
        "k" to presence.kind.code.toString(),
        "v" to PROTOCOL_VERSION.toString(),
        "av" to DiscoveryText.clean(presence.appVersion, BeaconCodec.MAX_VERSION_BYTES),
        "c" to presence.capabilities.toString(),
    )

    /** Null when the record is not a valid AERO advertisement. Nothing that cannot be verified is trusted. */
    fun parse(attributes: Map<String, ByteArray?>, port: Int): Beacon.Presence? {
        if (port !in 1..65535) return null
        fun text(key: String): String? = attributes[key]?.let { String(it, Charsets.UTF_8) }
        val fingerprint = text("fp") ?: return null
        val id = text("id") ?: return null
        if (!Fingerprints.isValid(fingerprint) || id != fingerprint.take(Beacon.DEVICE_ID_LENGTH)) return null
        if (text("v")?.toIntOrNull() != PROTOCOL_VERSION) return null
        return Beacon.Presence(
            goodbye = false,
            fingerprint = fingerprint,
            name = DiscoveryText.clean(text("n").orEmpty(), BeaconCodec.MAX_NAME_BYTES),
            kind = text("k")?.toIntOrNull()?.let { DeviceKind.fromCode(it) } ?: DeviceKind.OTHER,
            port = port,
            appVersion = DiscoveryText.clean(text("av").orEmpty(), BeaconCodec.MAX_VERSION_BYTES),
            capabilities = text("c")?.toIntOrNull() ?: 0,
        )
    }
}
