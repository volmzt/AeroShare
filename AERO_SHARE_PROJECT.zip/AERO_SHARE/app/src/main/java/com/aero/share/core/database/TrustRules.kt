package com.aero.share.core.database

import com.aero.share.domain.DeviceRecord
import com.aero.share.transfer.model.PeerTrust

/** Pure trust decision over a snapshot of stored devices (no Android or Room types, unit tested on the JVM). */
object TrustRules {
    /**
     * - the record matches id AND fingerprint: BLOCKED if blocked, TRUSTED if trusted, otherwise KNOWN
     * - the id exists with another fingerprint (changed key): never trusted; still BLOCKED when the record is blocked
     * - the fingerprint belongs to a blocked record under another id: BLOCKED
     * - everything else: UNKNOWN
     */
    fun trustOf(snapshot: Map<String, DeviceRecord>, deviceId: String, fingerprint: String): PeerTrust {
        val byId = snapshot[deviceId]
        if (byId != null) {
            if (byId.fingerprint == fingerprint) {
                return when {
                    byId.blocked -> PeerTrust.BLOCKED
                    byId.trusted -> PeerTrust.TRUSTED
                    else -> PeerTrust.KNOWN
                }
            }
            return if (byId.blocked) PeerTrust.BLOCKED else PeerTrust.UNKNOWN
        }
        if (snapshot.values.any { it.blocked && it.fingerprint == fingerprint }) return PeerTrust.BLOCKED
        return PeerTrust.UNKNOWN
    }
}
