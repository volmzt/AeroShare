package com.aero.share.di

import android.app.Application
import com.aero.share.core.common.DiagnosticsLog
import com.aero.share.core.database.AeroDatabase
import com.aero.share.core.database.RoomDeviceRepository
import com.aero.share.core.database.RoomHistoryRepository
import com.aero.share.core.datastore.DataStoreSettingsRepository
import com.aero.share.core.designsystem.FeedbackManager
import com.aero.share.core.security.AndroidLocalDeviceProvider
import com.aero.share.core.security.AppPeerPolicy
import com.aero.share.core.security.IdentityStore
import com.aero.share.core.storage.DestinationResolver
import com.aero.share.core.storage.FileOpenerImpl
import com.aero.share.core.storage.apk.ApkInstallerImpl
import com.aero.share.core.storage.source.SendSourceFactory
import com.aero.share.feature.send.SendSession
import com.aero.share.network.discovery.LanDiscovery
import com.aero.share.network.transport.AppCapabilityProvider
import com.aero.share.network.transport.AppTransportPlanner
import com.aero.share.network.transport.CompositeDiscovery
import com.aero.share.network.transport.WifiDirectManager
import com.aero.share.transfer.AppPowerPolicy
import com.aero.share.transfer.AppTransferCoordinator
import kotlinx.coroutines.CoroutineScope

/** Single place where the object graph is assembled. */
object AppContainerFactory {
    fun create(app: Application, scope: CoroutineScope): AppContainer {
        val diagnostics = DiagnosticsLog()
        val settings = DataStoreSettingsRepository(app, scope)
        val identity = IdentityStore(app).loadOrCreate()
        val localDevice = AndroidLocalDeviceProvider(app, identity, settings, scope)
        val db = AeroDatabase.create(app)
        val devices = RoomDeviceRepository(db, scope)
        val history = RoomHistoryRepository(db)
        val peerPolicy = AppPeerPolicy(devices, settings)
        val power = AppPowerPolicy(settings, app)

        val lan = LanDiscovery(app, scope, localDevice, settings, power, diagnostics)
        val p2p = WifiDirectManager(app, scope, localDevice, settings, diagnostics)
        val capabilities = AppCapabilityProvider(app, scope, p2p)
        val discovery = CompositeDiscovery(app, scope, lan, p2p, capabilities, settings, power, diagnostics)
        val planner = AppTransportPlanner(app, scope, p2p, capabilities, settings, diagnostics)

        val destination = DestinationResolver(app, settings)
        val sources = SendSourceFactory(app)
        val coordinator = AppTransferCoordinator(
            context = app,
            scope = scope,
            identity = identity,
            settings = settings,
            localDevice = localDevice,
            devices = devices,
            history = history,
            peerPolicy = peerPolicy,
            discovery = discovery,
            planner = planner,
            power = power,
            destination = destination,
            sources = sources,
            diagnostics = diagnostics,
        )

        return AppContainer(
            application = app,
            settings = settings,
            localDevice = localDevice,
            devices = devices,
            history = history,
            discovery = discovery,
            capabilities = capabilities,
            planner = planner,
            coordinator = coordinator,
            apkInstaller = ApkInstallerImpl(app),
            fileOpener = FileOpenerImpl(app, settings),
            power = power,
            diagnostics = diagnostics,
            feedback = FeedbackManager(app, settings),
            sendSession = SendSession(),
            launch = LaunchRequests(),
        )
    }
}
