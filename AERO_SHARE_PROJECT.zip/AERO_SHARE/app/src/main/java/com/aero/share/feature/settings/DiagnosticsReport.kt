package com.aero.share.feature.settings

import com.aero.share.core.common.DiagnosticEntry
import com.aero.share.domain.AppSettings
import com.aero.share.domain.DiscoveryState
import com.aero.share.domain.RadioStatus
import com.aero.share.domain.ReceiverStatus
import com.aero.share.domain.TransportCapability
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/** The permissions the diagnostics page reports on; [reportName] is the plain English label used in the shared report. */
internal enum class PermissionKind(val reportName: String) {
    NEARBY("Nearby devices"),
    CAMERA("Camera"),
    NOTIFICATIONS("Notifications"),
}

/** One permission and whether it is granted right now. */
internal data class PermissionLine(val kind: PermissionKind, val granted: Boolean)

/** Everything the diagnostics page and the shared report are made from. */
internal data class DiagnosticsInput(
    val appVersion: String,
    val buildNumber: Int,
    val androidRelease: String,
    val sdkInt: Int,
    val deviceModel: String,
    val capabilities: List<TransportCapability>,
    val radio: RadioStatus,
    val discovery: DiscoveryState,
    val nearbyCount: Int,
    val receiver: ReceiverStatus,
    val activeTransfers: Int,
    val permissions: List<PermissionLine>,
    val canInstallPackages: Boolean,
    val settings: AppSettings,
    val log: List<DiagnosticEntry>,
)

/**
 * The text a person can copy or share with whoever helps them. It is written in English on purpose, so a report from any
 * language reads the same. It never contains the device name, the chosen folder, file names, addresses, keys or tokens.
 */
internal object DiagnosticsReport {
    const val MAX_EVENTS = 50

    /** The newest events, oldest first. */
    fun recentEvents(log: List<DiagnosticEntry>): List<DiagnosticEntry> = log.takeLast(MAX_EVENTS)

    fun build(input: DiagnosticsInput, zone: TimeZone): String {
        val out = StringBuilder()
        out.appendLine("AERO SHARE diagnostics")
        out.appendLine("App: ${input.appVersion} (build ${input.buildNumber})")
        out.appendLine("Android: ${input.androidRelease} (API ${input.sdkInt})")
        out.appendLine("Device: ${input.deviceModel}")

        out.appendLine()
        out.appendLine("Ways to connect")
        if (input.capabilities.isEmpty()) {
            out.appendLine("- not checked yet")
        } else {
            for (capability in input.capabilities.sortedBy { item -> item.kind.ordinal }) {
                out.appendLine("- ${capability.kind.name}: ${capability.state.name}")
            }
        }

        val radio = input.radio
        out.appendLine()
        out.appendLine("Radios")
        out.appendLine("- Wi-Fi: ${onOff(radio.wifiEnabled)}, ${if (radio.wifiConnected) "connected" else "not connected"}")
        val bluetooth = if (radio.bluetoothSupported) onOff(radio.bluetoothEnabled) else "not supported"
        out.appendLine("- Bluetooth: $bluetooth (not used to transfer files)")
        out.appendLine("- Location services: ${onOff(radio.locationEnabled)}")

        val discovery = input.discovery
        val problem = discovery.problem?.let { found -> " (${found.name})" }.orEmpty()
        val methods = discovery.activeMethods.sorted().joinToString(", ").ifEmpty { "none" }
        out.appendLine()
        out.appendLine("State")
        out.appendLine("- Receiver: ${input.receiver.name}")
        out.appendLine("- Discovery: ${discovery.status.name}$problem")
        out.appendLine("- Announcing this device: ${yesNo(discovery.advertising)}")
        out.appendLine("- Discovery methods: $methods")
        out.appendLine("- Nearby devices: ${input.nearbyCount}")
        out.appendLine("- Active transfers: ${input.activeTransfers}")

        out.appendLine()
        out.appendLine("Permissions")
        for (line in input.permissions) {
            out.appendLine("- ${line.kind.reportName}: ${if (line.granted) "granted" else "not granted"}")
        }
        out.appendLine("- Install other apps: ${if (input.canInstallPackages) "allowed" else "not allowed"}")

        val settings = input.settings
        out.appendLine()
        out.appendLine("Settings")
        out.appendLine("- Connection mode: ${settings.transportMode.name}")
        out.appendLine("- Wi-Fi network discovery: ${onOff(settings.lanDiscoveryEnabled)}")
        out.appendLine("- Wi-Fi Direct: ${onOff(settings.wifiDirectEnabled)}")
        out.appendLine("- Visibility: ${settings.visibility.name}")
        out.appendLine("- Manual address: ${onOff(settings.advancedConnectionEnabled)}")
        out.appendLine("- Connection timeout: ${settings.connectionTimeoutSec} s")
        out.appendLine("- Power mode: ${settings.powerMode.name}")
        out.appendLine("- Compression: ${settings.compression.name}")
        out.appendLine("- Same-name files: ${settings.conflictPolicy.name}")
        out.appendLine("- Automatic acceptance from trusted devices: ${onOff(settings.autoAcceptTrusted)}")
        out.appendLine("- Block new devices: ${onOff(settings.blockUnknownDevices)}")
        out.appendLine("- One-time QR codes: ${onOff(settings.qrSingleUse)}")
        out.appendLine("- QR code lifetime: ${settings.qrTtlSeconds} s")
        out.appendLine("- Receive folder: ${if (settings.saveDirectoryUri.isNullOrBlank()) "default" else "custom"}")

        val events = recentEvents(input.log)
        val format = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ROOT)
        format.timeZone = zone
        out.appendLine()
        out.appendLine("Recent events (${events.size})")
        if (events.isEmpty()) {
            out.appendLine("- none")
        } else {
            for (entry in events) {
                out.appendLine("${format.format(Date(entry.timestamp))} [${oneLine(entry.category)}] ${oneLine(entry.message)}")
            }
        }
        return out.toString()
    }

    private fun onOff(value: Boolean): String = if (value) "on" else "off"

    private fun yesNo(value: Boolean): String = if (value) "yes" else "no"

    /** A log message never breaks the line structure of the report. */
    private fun oneLine(text: String): String = text.replace('\r', ' ').replace('\n', ' ').trim()
}
