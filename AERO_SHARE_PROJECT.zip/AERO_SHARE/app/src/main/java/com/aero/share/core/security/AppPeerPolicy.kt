package com.aero.share.core.security

import com.aero.share.domain.DeviceRepository
import com.aero.share.domain.SettingsRepository
import com.aero.share.transfer.engine.PeerPolicy
import com.aero.share.transfer.model.PeerInfo
import com.aero.share.transfer.model.PeerTrust

/**
 * Decides how much a connecting device is trusted. Trust comes only from the stored record AND the authenticated
 * certificate fingerprint; a device announcing a known id with another key is treated as unknown.
 * With "block unknown devices" on, devices that were never used before are refused outright.
 */
class AppPeerPolicy(
    private val devices: DeviceRepository,
    private val settings: SettingsRepository,
) : PeerPolicy {
    override suspend fun trustOf(peer: PeerInfo): PeerTrust {
        val trust = devices.trustOf(peer.deviceId, peer.fingerprint)
        return if (trust == PeerTrust.UNKNOWN && settings.settings.value.blockUnknownDevices) PeerTrust.BLOCKED else trust
    }
}
