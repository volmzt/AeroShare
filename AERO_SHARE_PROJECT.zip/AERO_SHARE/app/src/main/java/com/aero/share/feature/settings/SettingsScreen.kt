package com.aero.share.feature.settings

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BugReport
import androidx.compose.material.icons.rounded.Info
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.getValue
import com.aero.share.BuildConfig
import com.aero.share.R
import com.aero.share.core.designsystem.AeroDivider
import com.aero.share.core.designsystem.AeroGroup
import com.aero.share.core.designsystem.AeroLogo
import com.aero.share.core.designsystem.AeroSectionHeader
import com.aero.share.core.designsystem.AeroSettingsRow
import com.aero.share.core.designsystem.AeroText
import com.aero.share.core.designsystem.AeroTheme
import com.aero.share.di.LocalAppContainer
import com.aero.share.navigation.AeroNavigator
import com.aero.share.navigation.SettingsSection

/** The Settings tab: the seven groups of settings, then diagnostics and the about page. */
@Composable
fun SettingsScreen(navigator: AeroNavigator) {
    SettingsPage(title = stringResource(R.string.nav_settings), onBack = null) {
        Spacer(Modifier.height(8.dp))
        AeroGroup {
            SettingsSection.entries.forEachIndexed { index, section ->
                if (index > 0) AeroDivider()
                AeroSettingsRow(
                    title = stringResource(section.titleRes()),
                    subtitle = stringResource(section.summaryRes()),
                    icon = section.icon(),
                    onClick = { navigator.openSettingsSection(section) },
                )
            }
        }
        AeroSectionHeader(text = stringResource(R.string.set_more_title))
        AeroGroup {
            AeroSettingsRow(
                title = stringResource(R.string.diag_title),
                subtitle = stringResource(R.string.set_diagnostics_summary),
                icon = Icons.Rounded.BugReport,
                onClick = { navigator.openDiagnostics() },
            )
            AeroDivider()
            AeroSettingsRow(
                title = stringResource(R.string.about_title),
                subtitle = stringResource(R.string.set_about_summary),
                icon = Icons.Rounded.Info,
                onClick = { navigator.openAbout() },
            )
        }
        SettingsFooter()
    }
}

/** The name and version at the bottom of the list, so the build in use can be read without opening anything. */
@Composable
private fun SettingsFooter() {
    Column(
        modifier = Modifier.fillMaxWidth().padding(top = 28.dp, bottom = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        AeroLogo(size = 40.dp)
        Spacer(Modifier.height(8.dp))
        AeroText(text = stringResource(R.string.app_name), style = AeroTheme.typography.bodyStrong)
        AeroText(
            text = stringResource(R.string.about_version_build, BuildConfig.VERSION_NAME, BuildConfig.BUILD_NUMBER),
            style = AeroTheme.typography.caption,
            color = AeroTheme.colors.textSecondary,
        )
    }
}

/** One group of settings opened from the list. Every control here writes a stored setting that the app really uses. */
@Composable
fun SettingsSectionScreen(section: SettingsSection, navigator: AeroNavigator) {
    val container = LocalAppContainer.current
    val viewModel: SettingsViewModel = viewModel(factory = viewModelFactory { initializer { SettingsViewModel(container) } })
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    SettingsPage(title = stringResource(section.titleRes()), onBack = { navigator.back() }) {
        Spacer(Modifier.height(8.dp))
        when (section) {
            SettingsSection.GENERAL -> GeneralSection(settings, viewModel)
            SettingsSection.CONNECTIONS -> ConnectionsSection(settings, viewModel, navigator)
            SettingsSection.TRANSFERS -> TransfersSection(settings, viewModel, navigator)
            SettingsSection.POWER -> PowerSection(settings, viewModel)
            SettingsSection.CUSTOMIZATION -> CustomizationSection(settings, viewModel)
            SettingsSection.SECURITY -> SecuritySection(settings, viewModel, navigator)
            SettingsSection.PLUGINS -> PluginsSection()
        }
    }
}
