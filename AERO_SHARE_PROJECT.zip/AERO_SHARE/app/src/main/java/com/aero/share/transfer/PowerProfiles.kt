package com.aero.share.transfer

import com.aero.share.domain.PowerMode
import com.aero.share.transfer.engine.EngineConfig

/** Concrete tunables of one power mode. Plain data, so the mapping can be unit-tested without Android. */
internal data class PowerProfile(
    val chunkSize: Int,
    val discoveryIntervalMs: Long,
    val beaconIntervalMs: Long,
    val lowLatencyWifi: Boolean,
)

internal object PowerProfiles {
    val BALANCED = PowerProfile(
        chunkSize = 256 * 1024,
        discoveryIntervalMs = 8_000L,
        beaconIntervalMs = 5_000L,
        lowLatencyWifi = false,
    )
    val PERFORMANCE = PowerProfile(
        chunkSize = 512 * 1024,
        discoveryIntervalMs = 4_000L,
        beaconIntervalMs = 3_000L,
        lowLatencyWifi = true,
    )
    val ENERGY_SAVING = PowerProfile(
        chunkSize = 128 * 1024,
        discoveryIntervalMs = 20_000L,
        beaconIntervalMs = 10_000L,
        lowLatencyWifi = false,
    )

    /**
     * [constrained] is true when the device is hot or in battery saver. The performance mode never overrides that:
     * it falls back to the balanced values instead of fighting the system's thermal and battery management.
     */
    fun of(mode: PowerMode, constrained: Boolean): PowerProfile = when (mode) {
        PowerMode.PERFORMANCE -> if (constrained) BALANCED else PERFORMANCE
        PowerMode.BALANCED -> BALANCED
        PowerMode.ENERGY_SAVING -> ENERGY_SAVING
    }

    fun engineConfig(profile: PowerProfile, connectionTimeoutSec: Int): EngineConfig {
        val connectMs = connectionTimeoutSec.coerceIn(MIN_TIMEOUT_SEC, MAX_TIMEOUT_SEC) * 1000
        return EngineConfig(
            chunkSize = profile.chunkSize,
            connectTimeoutMs = connectMs,
            idleTimeoutMs = maxOf(30_000, 3 * connectMs),
        )
    }

    private const val MIN_TIMEOUT_SEC = 5
    private const val MAX_TIMEOUT_SEC = 120
}
