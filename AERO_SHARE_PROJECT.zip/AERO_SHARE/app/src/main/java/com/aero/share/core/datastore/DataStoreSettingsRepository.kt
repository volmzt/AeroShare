package com.aero.share.core.datastore

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStoreFile
import com.aero.share.domain.AccentColor
import com.aero.share.domain.AppSettings
import com.aero.share.domain.LanguagePref
import com.aero.share.domain.PowerMode
import com.aero.share.domain.SettingsRepository
import com.aero.share.domain.ThemeMode
import com.aero.share.domain.TransportMode
import com.aero.share.domain.Visibility
import com.aero.share.transfer.model.CompressionMode
import com.aero.share.transfer.model.ConflictPolicy
import java.io.IOException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

/**
 * Settings persisted in a Preferences DataStore (one key per [AppSettings] field). The first value of [settings] is the
 * persisted one, so the UI never flashes defaults. Language and theme are also mirrored synchronously
 * (see [SettingsMirror]) because the language is needed before DataStore can be read.
 */
class DataStoreSettingsRepository private constructor(
    private val store: DataStore<Preferences>,
    scope: CoroutineScope,
    private val onChanged: (AppSettings) -> Unit,
) : SettingsRepository {

    /** Production constructor: file `aero_settings` in the app's DataStore directory. */
    constructor(context: Context, scope: CoroutineScope) : this(
        PreferenceDataStoreFactory.create(scope = CoroutineScope(scope.coroutineContext + Dispatchers.IO)) {
            context.applicationContext.preferencesDataStoreFile(FILE_NAME)
        },
        scope,
        mirrorWriter(context.applicationContext),
    )

    /** Constructor for tests and custom storage: no mirror is written. */
    constructor(store: DataStore<Preferences>, scope: CoroutineScope) : this(store, scope, {})

    private val state: MutableStateFlow<AppSettings>

    override val settings: StateFlow<AppSettings> get() = state.asStateFlow()

    init {
        val initial = runBlocking(Dispatchers.IO) { store.data.safe().first().toSettings() }
        state = MutableStateFlow(initial)
        onChanged(initial)
        scope.launch(Dispatchers.IO) {
            store.data.safe().map { it.toSettings() }.distinctUntilChanged().collect { latest ->
                state.value = latest
                onChanged(latest)
            }
        }
    }

    override suspend fun update(transform: (AppSettings) -> AppSettings) {
        var written: AppSettings? = null
        store.edit { prefs ->
            val current = prefs.toSettings()
            val next = transform(current).normalized()
            prefs.write(current, next)
            written = next
        }
        written?.let {
            state.value = it
            onChanged(it)
        }
    }

    private fun Flow<Preferences>.safe(): Flow<Preferences> = catch { error ->
        if (error is IOException) emit(emptyPreferences()) else throw error
    }

    private object Keys {
        val language = stringPreferencesKey("language")
        val themeMode = stringPreferencesKey("theme_mode")
        val customDeviceName = stringPreferencesKey("custom_device_name")
        val discoverOnLaunch = booleanPreferencesKey("discover_on_launch")
        val saveDirectoryUri = stringPreferencesKey("save_directory_uri")
        val notificationsEnabled = booleanPreferencesKey("notifications_enabled")
        val notifyIncomingRequests = booleanPreferencesKey("notify_incoming_requests")
        val notifyTransferResults = booleanPreferencesKey("notify_transfer_results")
        val transportMode = stringPreferencesKey("transport_mode")
        val lanDiscoveryEnabled = booleanPreferencesKey("lan_discovery_enabled")
        val wifiDirectEnabled = booleanPreferencesKey("wifi_direct_enabled")
        val visibility = stringPreferencesKey("visibility")
        val advancedConnectionEnabled = booleanPreferencesKey("advanced_connection_enabled")
        val connectionTimeoutSec = intPreferencesKey("connection_timeout_sec")
        val qrTtlSeconds = intPreferencesKey("qr_ttl_seconds")
        val qrSingleUse = booleanPreferencesKey("qr_single_use")
        val autoAcceptTrusted = booleanPreferencesKey("auto_accept_trusted")
        val blockUnknownDevices = booleanPreferencesKey("block_unknown_devices")
        val compression = stringPreferencesKey("compression")
        val conflictPolicy = stringPreferencesKey("conflict_policy")
        val largeTransferWarnBytes = longPreferencesKey("large_transfer_warn_bytes")
        val partialRetentionDays = intPreferencesKey("partial_retention_days")
        val historyRetentionDays = intPreferencesKey("history_retention_days")
        val powerMode = stringPreferencesKey("power_mode")
        val accent = stringPreferencesKey("accent")
        val animationsEnabled = booleanPreferencesKey("animations_enabled")
        val reducedMotion = booleanPreferencesKey("reduced_motion")
        val hapticsEnabled = booleanPreferencesKey("haptics_enabled")
        val soundsEnabled = booleanPreferencesKey("sounds_enabled")
        val glassEffects = booleanPreferencesKey("glass_effects")
        val compactLists = booleanPreferencesKey("compact_lists")
        val onboardingCompleted = booleanPreferencesKey("onboarding_completed")
    }

    private inline fun <reified E : Enum<E>> Preferences.enumOf(key: Preferences.Key<String>, default: E): E {
        val name = this[key] ?: return default
        return enumValues<E>().firstOrNull { it.name == name } ?: default
    }

    private fun Preferences.toSettings(): AppSettings {
        val d = AppSettings()
        return AppSettings(
            language = enumOf(Keys.language, d.language),
            themeMode = enumOf(Keys.themeMode, d.themeMode),
            customDeviceName = this[Keys.customDeviceName],
            discoverOnLaunch = this[Keys.discoverOnLaunch] ?: d.discoverOnLaunch,
            saveDirectoryUri = this[Keys.saveDirectoryUri],
            notificationsEnabled = this[Keys.notificationsEnabled] ?: d.notificationsEnabled,
            notifyIncomingRequests = this[Keys.notifyIncomingRequests] ?: d.notifyIncomingRequests,
            notifyTransferResults = this[Keys.notifyTransferResults] ?: d.notifyTransferResults,
            transportMode = enumOf(Keys.transportMode, d.transportMode),
            lanDiscoveryEnabled = this[Keys.lanDiscoveryEnabled] ?: d.lanDiscoveryEnabled,
            wifiDirectEnabled = this[Keys.wifiDirectEnabled] ?: d.wifiDirectEnabled,
            visibility = enumOf(Keys.visibility, d.visibility),
            advancedConnectionEnabled = this[Keys.advancedConnectionEnabled] ?: d.advancedConnectionEnabled,
            connectionTimeoutSec = this[Keys.connectionTimeoutSec] ?: d.connectionTimeoutSec,
            qrTtlSeconds = this[Keys.qrTtlSeconds] ?: d.qrTtlSeconds,
            qrSingleUse = this[Keys.qrSingleUse] ?: d.qrSingleUse,
            autoAcceptTrusted = this[Keys.autoAcceptTrusted] ?: d.autoAcceptTrusted,
            blockUnknownDevices = this[Keys.blockUnknownDevices] ?: d.blockUnknownDevices,
            compression = enumOf(Keys.compression, d.compression),
            conflictPolicy = enumOf(Keys.conflictPolicy, d.conflictPolicy),
            largeTransferWarnBytes = this[Keys.largeTransferWarnBytes] ?: d.largeTransferWarnBytes,
            partialRetentionDays = this[Keys.partialRetentionDays] ?: d.partialRetentionDays,
            historyRetentionDays = this[Keys.historyRetentionDays] ?: d.historyRetentionDays,
            powerMode = enumOf(Keys.powerMode, d.powerMode),
            accent = enumOf(Keys.accent, d.accent),
            animationsEnabled = this[Keys.animationsEnabled] ?: d.animationsEnabled,
            reducedMotion = this[Keys.reducedMotion] ?: d.reducedMotion,
            hapticsEnabled = this[Keys.hapticsEnabled] ?: d.hapticsEnabled,
            soundsEnabled = this[Keys.soundsEnabled] ?: d.soundsEnabled,
            glassEffects = this[Keys.glassEffects] ?: d.glassEffects,
            compactLists = this[Keys.compactLists] ?: d.compactLists,
            onboardingCompleted = this[Keys.onboardingCompleted] ?: d.onboardingCompleted,
        ).normalized()
    }

    /** Writes only the keys whose value changed (null removes the key). */
    private fun MutablePreferences.write(old: AppSettings, new: AppSettings) {
        putEnum(Keys.language, old.language, new.language)
        putEnum(Keys.themeMode, old.themeMode, new.themeMode)
        put(Keys.customDeviceName, old.customDeviceName, new.customDeviceName)
        put(Keys.discoverOnLaunch, old.discoverOnLaunch, new.discoverOnLaunch)
        put(Keys.saveDirectoryUri, old.saveDirectoryUri, new.saveDirectoryUri)
        put(Keys.notificationsEnabled, old.notificationsEnabled, new.notificationsEnabled)
        put(Keys.notifyIncomingRequests, old.notifyIncomingRequests, new.notifyIncomingRequests)
        put(Keys.notifyTransferResults, old.notifyTransferResults, new.notifyTransferResults)
        putEnum(Keys.transportMode, old.transportMode, new.transportMode)
        put(Keys.lanDiscoveryEnabled, old.lanDiscoveryEnabled, new.lanDiscoveryEnabled)
        put(Keys.wifiDirectEnabled, old.wifiDirectEnabled, new.wifiDirectEnabled)
        putEnum(Keys.visibility, old.visibility, new.visibility)
        put(Keys.advancedConnectionEnabled, old.advancedConnectionEnabled, new.advancedConnectionEnabled)
        put(Keys.connectionTimeoutSec, old.connectionTimeoutSec, new.connectionTimeoutSec)
        put(Keys.qrTtlSeconds, old.qrTtlSeconds, new.qrTtlSeconds)
        put(Keys.qrSingleUse, old.qrSingleUse, new.qrSingleUse)
        put(Keys.autoAcceptTrusted, old.autoAcceptTrusted, new.autoAcceptTrusted)
        put(Keys.blockUnknownDevices, old.blockUnknownDevices, new.blockUnknownDevices)
        putEnum(Keys.compression, old.compression, new.compression)
        putEnum(Keys.conflictPolicy, old.conflictPolicy, new.conflictPolicy)
        put(Keys.largeTransferWarnBytes, old.largeTransferWarnBytes, new.largeTransferWarnBytes)
        put(Keys.partialRetentionDays, old.partialRetentionDays, new.partialRetentionDays)
        put(Keys.historyRetentionDays, old.historyRetentionDays, new.historyRetentionDays)
        putEnum(Keys.powerMode, old.powerMode, new.powerMode)
        putEnum(Keys.accent, old.accent, new.accent)
        put(Keys.animationsEnabled, old.animationsEnabled, new.animationsEnabled)
        put(Keys.reducedMotion, old.reducedMotion, new.reducedMotion)
        put(Keys.hapticsEnabled, old.hapticsEnabled, new.hapticsEnabled)
        put(Keys.soundsEnabled, old.soundsEnabled, new.soundsEnabled)
        put(Keys.glassEffects, old.glassEffects, new.glassEffects)
        put(Keys.compactLists, old.compactLists, new.compactLists)
        put(Keys.onboardingCompleted, old.onboardingCompleted, new.onboardingCompleted)
    }

    private fun <T> MutablePreferences.put(key: Preferences.Key<T>, old: T?, new: T?) {
        if (old == new) return
        if (new == null) remove(key) else this[key] = new
    }

    private fun MutablePreferences.putEnum(key: Preferences.Key<String>, old: Enum<*>, new: Enum<*>) {
        if (old != new) this[key] = new.name
    }

    companion object {
        private const val FILE_NAME = "aero_settings"
        const val MAX_DEVICE_NAME_LENGTH = 40

        private fun mirrorWriter(context: Context): (AppSettings) -> Unit = { s ->
            SettingsMirror.write(context, s.language.tag, s.themeMode.name)
        }

        /** Clamps every value to its supported range; also used when reading, so hand-edited files cannot break the app. */
        internal fun AppSettings.normalized(): AppSettings = copy(
            customDeviceName = customDeviceName?.trim()?.take(MAX_DEVICE_NAME_LENGTH)?.takeIf { it.isNotEmpty() },
            saveDirectoryUri = saveDirectoryUri?.takeIf { it.isNotBlank() },
            connectionTimeoutSec = connectionTimeoutSec.coerceIn(5, 120),
            qrTtlSeconds = qrTtlSeconds.coerceIn(30, 600),
            partialRetentionDays = partialRetentionDays.coerceIn(1, 60),
            historyRetentionDays = historyRetentionDays.coerceIn(0, 3650),
            largeTransferWarnBytes = largeTransferWarnBytes.coerceAtLeast(0L),
        )
    }
}
