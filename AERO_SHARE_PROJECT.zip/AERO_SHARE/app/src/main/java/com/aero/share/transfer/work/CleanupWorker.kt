package com.aero.share.transfer.work

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.aero.share.AeroApp
import com.aero.share.core.storage.IncomingParts
import com.aero.share.di.AppContainer
import com.aero.share.transfer.storage.StagedIncomingStorage
import kotlinx.coroutines.CancellationException
import java.io.File

/**
 * Daily housekeeping: removes unfinished received data that was never resumed, leftover temporary APK bundles and (when the
 * user chose a retention period) old history rows. Received files themselves are never touched.
 */
class CleanupWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        val container: AppContainer = try {
            (applicationContext as AeroApp).container
        } catch (e: UninitializedPropertyAccessException) {
            return Result.retry()
        } catch (e: ClassCastException) {
            return Result.failure()
        }
        val settings = container.settings.settings.value
        val now = System.currentTimeMillis()
        val log = container.diagnostics

        val staged = try {
            StagedIncomingStorage.purgeOlderThan(
                IncomingParts.root(applicationContext),
                CleanupRules.partialCutoff(now, settings.partialRetentionDays),
            )
        } catch (e: Exception) {
            log.add("cleanup", "staging purge failed: " + e.javaClass.simpleName)
            0
        }

        var temporary = 0
        val tempCutoff = CleanupRules.tempCutoff(now)
        for (name in CleanupRules.TEMP_DIRS) {
            temporary += try {
                purgeChildren(File(applicationContext.cacheDir, name), tempCutoff)
            } catch (e: Exception) {
                log.add("cleanup", "temporary purge failed: " + e.javaClass.simpleName)
                0
            }
        }

        val historyCutoff = CleanupRules.historyCutoff(now, settings.historyRetentionDays)
        if (historyCutoff != null) {
            try {
                container.history.deleteOlderThan(historyCutoff)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                log.add("cleanup", "history purge failed: " + e.javaClass.simpleName)
            }
        }

        log.add("cleanup", "removed $staged staged parts and $temporary temporary entries")
        return Result.success()
    }

    private fun purgeChildren(dir: File, cutoff: Long): Int {
        val children = dir.listFiles() ?: return 0
        var removed = 0
        for (child in children) {
            if (child.lastModified() < cutoff && child.deleteRecursively()) removed++
        }
        return removed
    }
}
