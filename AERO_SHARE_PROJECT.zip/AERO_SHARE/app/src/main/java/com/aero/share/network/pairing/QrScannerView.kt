package com.aero.share.network.pairing

import android.content.Context
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.google.zxing.BarcodeFormat
import com.google.zxing.BinaryBitmap
import com.google.zxing.DecodeHintType
import com.google.zxing.LuminanceSource
import com.google.zxing.MultiFormatReader
import com.google.zxing.PlanarYUVLuminanceSource
import com.google.zxing.ReaderException
import com.google.zxing.common.HybridBinarizer
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/** Error code passed to `onError` when the camera cannot be started. The caller shows its own localized message. */
const val QR_SCANNER_ERROR_CAMERA = "camera"

/**
 * Camera preview that reads QR codes (CameraX + ZXing, QR only, also inverted codes). Every distinct text is delivered
 * once, on the main thread. The CALLER must hold the CAMERA permission before showing this view (and explain why it asks
 * for it); without it, or without a camera, `onError` is called with [QR_SCANNER_ERROR_CAMERA]. The camera runs only
 * while the view is in the composition and its lifecycle owner is started, and nothing is recorded or stored.
 */
@Composable
fun QrScannerView(
    modifier: Modifier = Modifier,
    onScanned: (String) -> Unit,
    onError: (String) -> Unit,
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val latestScanned by rememberUpdatedState(onScanned)
    val latestError by rememberUpdatedState(onError)
    val previewView = remember(context) {
        PreviewView(context).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
    }
    DisposableEffect(lifecycleOwner, previewView) {
        val session = QrCameraSession(
            context = context,
            owner = lifecycleOwner,
            previewView = previewView,
            onScanned = { text -> latestScanned(text) },
            onError = { code -> latestError(code) },
        )
        session.start()
        onDispose { session.stop() }
    }
    AndroidView(factory = { previewView }, modifier = modifier)
}

private class QrCameraSession(
    private val context: Context,
    private val owner: LifecycleOwner,
    private val previewView: PreviewView,
    private val onScanned: (String) -> Unit,
    private val onError: (String) -> Unit,
) {
    private val mainExecutor = ContextCompat.getMainExecutor(context)
    private val analysisExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private val analyzer = QrAnalyzer { text -> mainExecutor.execute { if (!stopped) onScanned(text) } }

    @Volatile
    private var stopped = false
    private var provider: ProcessCameraProvider? = null

    fun start() {
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener(
            {
                if (!stopped) {
                    try {
                        val camera = future.get()
                        provider = camera
                        val preview = Preview.Builder().build()
                        preview.setSurfaceProvider(previewView.surfaceProvider)
                        val analysis = ImageAnalysis.Builder()
                            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                            .build()
                        analysis.setAnalyzer(analysisExecutor, analyzer)
                        camera.unbindAll()
                        camera.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
                    } catch (e: Exception) {
                        if (!stopped) onError(QR_SCANNER_ERROR_CAMERA)
                    }
                }
            },
            mainExecutor,
        )
    }

    fun stop() {
        stopped = true
        try {
            provider?.unbindAll()
        } catch (e: Exception) {
            // the camera is released with the process anyway
        }
        analysisExecutor.shutdown()
    }
}

/** Decodes the luminance plane of every camera frame. QR detection does not depend on the frame's rotation. */
private class QrAnalyzer(private val onResult: (String) -> Unit) : ImageAnalysis.Analyzer {
    private val reader = MultiFormatReader().also {
        it.setHints(
            mapOf<DecodeHintType, Any>(
                DecodeHintType.POSSIBLE_FORMATS to listOf(BarcodeFormat.QR_CODE),
                DecodeHintType.TRY_HARDER to true,
            ),
        )
    }
    private var last: String? = null

    override fun analyze(image: ImageProxy) {
        try {
            val plane = image.planes[0]
            val buffer = plane.buffer
            val rowStride = plane.rowStride
            val width = image.width
            val height = image.height
            val data = ByteArray(buffer.remaining())
            buffer.get(data)
            if (rowStride < width || data.size < rowStride * (height - 1) + width) return
            val source = PlanarYUVLuminanceSource(data, rowStride, height, 0, 0, width, height, false)
            val text = decode(source) ?: return
            if (text != last) {
                last = text
                onResult(text)
            }
        } catch (e: Exception) {
            // a frame that cannot be read is skipped
        } finally {
            image.close()
        }
    }

    private fun decode(source: LuminanceSource): String? {
        for (candidate in arrayOf<LuminanceSource>(source, source.invert())) {
            try {
                return reader.decodeWithState(BinaryBitmap(HybridBinarizer(candidate))).text
            } catch (e: ReaderException) {
                // nothing found in this attempt
            } finally {
                reader.reset()
            }
        }
        return null
    }
}
