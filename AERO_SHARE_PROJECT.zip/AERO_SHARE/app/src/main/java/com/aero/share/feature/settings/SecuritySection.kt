package com.aero.share.feature.settings

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.aero.share.R
import com.aero.share.core.designsystem.AeroCard
import com.aero.share.core.designsystem.AeroChoiceRow
import com.aero.share.core.designsystem.AeroDivider
import com.aero.share.core.designsystem.AeroGroup
import com.aero.share.core.designsystem.AeroSectionHeader
import com.aero.share.core.designsystem.AeroSettingsRow
import com.aero.share.core.designsystem.AeroSwitchRow
import com.aero.share.core.designsystem.AeroText
import com.aero.share.core.designsystem.AeroTheme
import com.aero.share.domain.AppSettings
import com.aero.share.navigation.AeroNavigator

/**
 * Who may send to this device and how pairing codes behave. Turning on automatic acceptance asks first, because it lowers
 * the protection that explicit approval gives.
 */
@Composable
internal fun SecuritySection(settings: AppSettings, viewModel: SettingsViewModel, navigator: AeroNavigator) {
    AeroCard {
        AeroText(text = stringResource(R.string.set_security_info_title), style = AeroTheme.typography.bodyStrong)
        Spacer(Modifier.height(6.dp))
        AeroText(text = stringResource(R.string.set_security_info), color = AeroTheme.colors.textSecondary)
    }

    AeroSectionHeader(text = stringResource(R.string.set_incoming_header))
    AeroGroup {
        AutoAcceptRow(settings = settings, viewModel = viewModel)
        AeroDivider()
        AeroSwitchRow(
            title = stringResource(R.string.set_block_title),
            subtitle = stringResource(R.string.set_block_text),
            checked = settings.blockUnknownDevices,
            onCheckedChange = { on -> viewModel.update { current -> current.copy(blockUnknownDevices = on) } },
        )
        AeroDivider()
        AeroSettingsRow(
            title = stringResource(R.string.set_manage_title),
            subtitle = stringResource(R.string.set_manage_text),
            icon = Icons.Rounded.VerifiedUser,
            onClick = { navigator.openDevices() },
        )
        AeroDivider()
        VisibilityRow(settings = settings, viewModel = viewModel)
    }

    AeroSectionHeader(text = stringResource(R.string.set_pairing_header))
    AeroGroup {
        AeroSwitchRow(
            title = stringResource(R.string.set_qr_single_title),
            subtitle = stringResource(R.string.set_qr_single_text),
            checked = settings.qrSingleUse,
            onCheckedChange = { on -> viewModel.update { current -> current.copy(qrSingleUse = on) } },
        )
        AeroDivider()
        AeroChoiceRow(
            title = stringResource(R.string.set_qr_ttl_title),
            subtitle = stringResource(R.string.set_qr_ttl_text),
            options = SettingsLogic.QR_LIFETIMES.map { seconds -> seconds to secondsText(seconds) },
            selected = SettingsLogic.nearestInt(SettingsLogic.QR_LIFETIMES, settings.qrTtlSeconds),
            onSelected = { seconds -> viewModel.update { current -> current.copy(qrTtlSeconds = seconds) } },
        )
    }
    SettingsNote(text = stringResource(R.string.set_pairing_note))
}
