package com.aero.share.feature.receive

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.aero.share.R
import com.aero.share.core.designsystem.AeroBottomSheet
import com.aero.share.core.designsystem.AeroButton
import com.aero.share.core.designsystem.AeroButtonStyle
import com.aero.share.core.designsystem.AeroGroup
import com.aero.share.core.designsystem.AeroProgressBar
import com.aero.share.core.designsystem.AeroSwitchRow
import com.aero.share.core.designsystem.AeroText
import com.aero.share.core.designsystem.AeroTheme
import com.aero.share.transfer.PairingReasons
import kotlinx.coroutines.delay

/**
 * The pairing code, large and on a white card so any scanner can read it in either theme. It counts down to its expiry,
 * says honestly how it can be used, and can include a temporary hotspot for two devices that share no Wi-Fi network.
 */
@Composable
internal fun QrSheet(
    state: QrUi,
    hotspotOffer: HotspotOffer,
    singleUse: Boolean,
    onHotspotChange: (Boolean) -> Unit,
    onNewCode: () -> Unit,
    onDismiss: () -> Unit,
) {
    val loading = state is QrUi.Loading
    AeroBottomSheet(onDismiss = onDismiss) {
        AeroText(text = stringResource(R.string.qr_title), style = AeroTheme.typography.titleSmall)
        Spacer(Modifier.height(4.dp))
        AeroText(text = stringResource(R.string.qr_subtitle), color = AeroTheme.colors.textSecondary)
        Spacer(Modifier.height(16.dp))
        when (state) {
            QrUi.Hidden -> Unit
            is QrUi.Loading -> LoadingPane(hotspot = state.hotspot)
            is QrUi.Ready -> ReadyPane(state = state, singleUse = singleUse, onNewCode = onNewCode)
            is QrUi.Failed -> FailedPane(reason = state.reason, onRetry = onNewCode)
        }
        if (hotspotOffer != HotspotOffer.NONE) {
            Spacer(Modifier.height(16.dp))
            AeroGroup {
                AeroSwitchRow(
                    title = stringResource(R.string.qr_hotspot_title),
                    subtitle = stringResource(R.string.qr_hotspot_text),
                    checked = state.hotspot,
                    onCheckedChange = onHotspotChange,
                    enabled = !loading,
                )
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            AeroButton(
                text = stringResource(R.string.qr_new),
                onClick = onNewCode,
                style = AeroButtonStyle.Secondary,
                enabled = !loading,
            )
            AeroButton(text = stringResource(R.string.common_close), onClick = onDismiss, modifier = Modifier.weight(1f))
        }
    }
}

@Composable
private fun LoadingPane(hotspot: Boolean) {
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 24.dp)) {
        AeroProgressBar(progress = 0f, indeterminate = true)
        Spacer(Modifier.height(12.dp))
        AeroText(
            text = stringResource(if (hotspot) R.string.qr_loading_hotspot else R.string.qr_loading),
            color = AeroTheme.colors.textSecondary,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

@Composable
private fun ReadyPane(state: QrUi.Ready, singleUse: Boolean, onNewCode: () -> Unit) {
    val colors = AeroTheme.colors
    var now by remember(state.expiresAt) { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(state.expiresAt) {
        while (!QrLogic.isExpired(state.expiresAt, now)) {
            delay(250L)
            now = System.currentTimeMillis()
        }
    }
    val remaining = QrLogic.remainingSeconds(state.expiresAt, now)
    val expired = remaining == 0L
    Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .widthIn(max = 320.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(AeroTheme.dimens.radius))
                .background(Color.White)
                .padding(12.dp),
        ) {
            Image(
                bitmap = state.image,
                contentDescription = stringResource(R.string.qr_image_description),
                modifier = Modifier.fillMaxWidth().aspectRatio(1f).alpha(if (expired) 0.12f else 1f),
            )
        }
        Spacer(Modifier.height(12.dp))
        if (expired) {
            AeroText(
                text = stringResource(R.string.qr_expired),
                style = AeroTheme.typography.bodyStrong,
                color = colors.warning,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(8.dp))
            AeroButton(text = stringResource(R.string.qr_new), onClick = onNewCode)
        } else {
            AeroText(
                text = stringResource(R.string.qr_valid_for, QrLogic.clock(remaining)),
                style = AeroTheme.typography.bodyStrong,
                textAlign = TextAlign.Center,
            )
        }
        Spacer(Modifier.height(8.dp))
        AeroText(
            text = stringResource(if (singleUse) R.string.qr_note_single else R.string.qr_note_multi),
            style = AeroTheme.typography.caption,
            color = colors.textSecondary,
            textAlign = TextAlign.Center,
        )
        if (state.hotspotIncluded) {
            Spacer(Modifier.height(6.dp))
            AeroText(
                text = stringResource(R.string.qr_note_hotspot),
                style = AeroTheme.typography.caption,
                color = colors.textSecondary,
                textAlign = TextAlign.Center,
            )
        } else if (state.hotspot) {
            Spacer(Modifier.height(6.dp))
            AeroText(
                text = stringResource(R.string.qr_hotspot_failed),
                style = AeroTheme.typography.caption,
                color = colors.warning,
                textAlign = TextAlign.Center,
            )
        }
    }
}

@Composable
private fun FailedPane(reason: String, onRetry: () -> Unit) {
    val message = when (reason) {
        PairingReasons.NO_NETWORK -> R.string.qr_error_no_network
        PairingReasons.RECEIVER_ERROR -> R.string.qr_error_receiver
        PairingReasons.QR_TOO_LONG -> R.string.qr_error_too_long
        else -> R.string.qr_error_generic
    }
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        AeroText(text = stringResource(R.string.qr_error_title), style = AeroTheme.typography.bodyStrong, color = AeroTheme.colors.danger)
        Spacer(Modifier.height(6.dp))
        AeroText(text = stringResource(message), color = AeroTheme.colors.textSecondary)
        Spacer(Modifier.height(12.dp))
        AeroButton(text = stringResource(R.string.common_retry), onClick = onRetry, style = AeroButtonStyle.Secondary)
    }
}
