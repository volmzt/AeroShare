package com.aero.share.navigation

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Devices
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.aero.share.R
import com.aero.share.core.designsystem.AeroBottomBar
import com.aero.share.core.designsystem.AeroNavItem
import com.aero.share.core.designsystem.AeroTheme
import com.aero.share.core.designsystem.AeroToastHost
import com.aero.share.core.designsystem.AeroToastState
import com.aero.share.core.designsystem.LocalAeroToast
import com.aero.share.core.designsystem.LocalFeedback
import com.aero.share.core.designsystem.findActivity
import com.aero.share.core.designsystem.rememberAeroToastState
import com.aero.share.di.AppContainer
import com.aero.share.di.LocalAppContainer
import com.aero.share.feature.onboarding.OnboardingScreen
import com.aero.share.feature.receive.IncomingRequestHost

/**
 * Root of the UI, called by `MainActivity.setContent`. Provides the container, haptics and toasts, applies the theme
 * chosen in the settings, shows the first-launch onboarding once and then the main navigation.
 */
@Composable
fun AeroRoot(container: AppContainer) {
    val settings by container.settings.settings.collectAsStateWithLifecycle()
    val toast = rememberAeroToastState()

    CompositionLocalProvider(
        LocalAppContainer provides container,
        LocalFeedback provides container.feedback,
        LocalAeroToast provides toast,
    ) {
        AeroTheme(settings) {
            Box(modifier = Modifier.fillMaxSize().background(AeroTheme.colors.background)) {
                if (settings.onboardingCompleted) {
                    MainHost(container, toast)
                } else {
                    OnboardingScreen(onFinished = {})
                }
            }
        }
    }
}

/** Navigation graph, bottom bar (tabs only), the global incoming-request prompt and toasts. */
@Composable
private fun MainHost(container: AppContainer, toast: AeroToastState) {
    val context = LocalContext.current
    val navController = rememberNavController()
    val navigator = remember(navController) {
        NavControllerNavigator(navController) { context.findActivity()?.finish() }
    }
    val backStackEntry by navController.currentBackStackEntryAsState()
    val tabIndex = Routes.tabIndex(backStackEntry?.destination?.route)
    val showBar = tabIndex >= 0

    val items = listOf(
        AeroNavItem(stringResource(R.string.nav_home), Icons.Rounded.Home),
        AeroNavItem(stringResource(R.string.nav_devices), Icons.Rounded.Devices),
        AeroNavItem(stringResource(R.string.nav_settings), Icons.Rounded.Settings),
    )

    ExternalRequestsEffect(container, navigator, toast)

    Column(modifier = Modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                // The bar below draws behind the system navigation bar itself, so screens must not pad for it twice.
                .then(if (showBar) Modifier.consumeWindowInsets(WindowInsets.navigationBars) else Modifier),
        ) {
            AeroNavHost(navController = navController, navigator = navigator, modifier = Modifier.fillMaxSize())
            IncomingRequestHost(navigator)
            AeroToastHost(
                state = toast,
                modifier = Modifier.align(Alignment.BottomCenter).safeDrawingPadding(),
            )
        }
        if (showBar) {
            AeroBottomBar(
                items = items,
                selectedIndex = tabIndex,
                onSelect = { index ->
                    when (index) {
                        0 -> navigator.openHome()
                        1 -> navigator.openDevices()
                        else -> navigator.openSettings()
                    }
                },
            )
        }
    }
}
