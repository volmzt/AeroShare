package com.aero.share.feature.send

import android.content.ContentResolver
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.util.LruCache
import android.util.Size
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import java.io.IOException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext

/**
 * Small previews of photos and videos for the picker. Decoding happens off the main thread, a few at a time, and finished
 * previews are kept in a memory cache sized to a sixteenth of the app's heap. A preview that cannot be made is simply left
 * out: the cell then shows the plain file-type icon.
 */
internal class ThumbnailLoader(context: Context) {
    private val appContext: Context = context.applicationContext
    private val resolver: ContentResolver = appContext.contentResolver
    private val gate = Semaphore(PARALLEL_DECODES)
    private val cache = object : LruCache<String, Bitmap>(cacheKilobytes()) {
        override fun sizeOf(key: String, value: Bitmap): Int = (value.byteCount / 1024).coerceAtLeast(1)
    }

    /** The preview if it is already in memory, so a cell that scrolls back into view does not flash. */
    fun cached(uri: String): ImageBitmap? = cache.get(uri)?.asImageBitmap()

    suspend fun load(uri: String, kind: MediaKind, sizePx: Int): ImageBitmap? {
        cache.get(uri)?.let { return it.asImageBitmap() }
        val bitmap = gate.withPermit { withContext(Dispatchers.IO) { decode(uri, kind, sizePx) } } ?: return null
        cache.put(uri, bitmap)
        return bitmap.asImageBitmap()
    }

    private fun decode(uriText: String, kind: MediaKind, sizePx: Int): Bitmap? {
        // Before Android 10 there is no system call for audio artwork, and reading it by hand is not worth the cost.
        if (kind == MediaKind.AUDIO && Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        val uri = Uri.parse(uriText)
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                resolver.loadThumbnail(uri, Size(sizePx, sizePx), null)
            } else {
                when (kind) {
                    MediaKind.IMAGE -> decodeImage(uri, sizePx)
                    MediaKind.VIDEO -> decodeVideo(uri, sizePx)
                    MediaKind.AUDIO -> null
                }
            }
        } catch (e: IOException) {
            null
        } catch (e: SecurityException) {
            null
        } catch (e: RuntimeException) {
            null
        }
    }

    /** Two passes: read the size first, then decode a version shrunk by a power of two so a 48 MP photo never fills memory. */
    private fun decodeImage(uri: Uri, target: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { stream -> BitmapFactory.decodeStream(stream, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        val options = BitmapFactory.Options().apply {
            inSampleSize = PickerLogic.sampleSizeFor(bounds.outWidth, bounds.outHeight, target)
        }
        val decoded = resolver.openInputStream(uri)?.use { stream -> BitmapFactory.decodeStream(stream, null, options) }
            ?: return null
        val degrees = rotationOf(uri)
        if (degrees == 0) return decoded
        val matrix = Matrix().apply { postRotate(degrees.toFloat()) }
        return Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, matrix, true)
    }

    private fun rotationOf(uri: Uri): Int =
        try {
            val orientation = resolver.openInputStream(uri)?.use { stream ->
                ExifInterface(stream).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            } ?: ExifInterface.ORIENTATION_NORMAL
            when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90
                ExifInterface.ORIENTATION_ROTATE_180 -> 180
                ExifInterface.ORIENTATION_ROTATE_270 -> 270
                else -> 0
            }
        } catch (e: IOException) {
            0
        } catch (e: RuntimeException) {
            0
        }

    private fun decodeVideo(uri: Uri, target: Int): Bitmap? {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(appContext, uri)
            val frame = retriever.getFrameAtTime(0L) ?: return null
            val longest = maxOf(frame.width, frame.height)
            if (longest <= target) return frame
            val scale = target.toFloat() / longest.toFloat()
            val width = (frame.width * scale).toInt().coerceAtLeast(1)
            val height = (frame.height * scale).toInt().coerceAtLeast(1)
            return Bitmap.createScaledBitmap(frame, width, height, true)
        } finally {
            retriever.release()
        }
    }

    private companion object {
        const val PARALLEL_DECODES = 4

        fun cacheKilobytes(): Int = (Runtime.getRuntime().maxMemory() / 1024L / 16L).toInt().coerceIn(2_048, 65_536)
    }
}
