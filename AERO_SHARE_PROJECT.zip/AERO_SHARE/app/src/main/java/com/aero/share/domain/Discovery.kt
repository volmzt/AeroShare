package com.aero.share.domain

import com.aero.share.transfer.engine.SocketConnector
import com.aero.share.transfer.model.DeviceKind
import com.aero.share.transfer.model.TransferFailure
import com.aero.share.transfer.model.TransportKind
import com.aero.share.transfer.pairing.QrPayload
import kotlinx.coroutines.flow.StateFlow

/** Measured link quality. UNKNOWN is the neutral value: it is never replaced by an invented estimate. */
enum class LinkQuality { UNKNOWN, WEAK, FAIR, STRONG }

data class NearbyDevice(
    val deviceId: String,
    val name: String,
    val kind: DeviceKind,
    /** From the advertisement (not authenticated until the TLS handshake). null if not advertised. */
    val fingerprint: String?,
    val appVersion: String?,
    /** Reachable IP addresses on the LAN (may be empty for Wi-Fi Direct only peers). */
    val addresses: List<String>,
    val port: Int,
    /** Transports over which this device can currently be reached. */
    val transports: Set<TransportKind>,
    val quality: LinkQuality,
    /** SystemClock.elapsedRealtime() of the last advertisement. */
    val lastSeenElapsed: Long,
    /** Wi-Fi Direct MAC address when discovered as a p2p peer. */
    val p2pAddress: String? = null,
    val capabilities: Int = 0,
)

enum class DiscoveryStatus { IDLE, SEARCHING, PROBLEM }

enum class DiscoveryProblem { WIFI_OFF, NO_NETWORK, PERMISSION_MISSING, UNAVAILABLE }

data class DiscoveryState(
    val status: DiscoveryStatus = DiscoveryStatus.IDLE,
    val problem: DiscoveryProblem? = null,
    val advertising: Boolean = false,
    /** Which methods are currently active, for diagnostics: e.g. "mdns", "multicast", "wifi-direct". */
    val activeMethods: Set<String> = emptySet(),
)

/** Reference counted by owner tag so several screens can ask for discovery without stopping each other. */
interface DiscoveryController {
    val devices: StateFlow<List<NearbyDevice>>
    val state: StateFlow<DiscoveryState>

    fun startDiscovery(owner: String)
    fun stopDiscovery(owner: String)

    /** Clears stale entries and sends a fresh query. */
    fun refresh()

    /** Announces this device (unless visibility is HIDDEN). [port] is the receiver's TLS port. */
    fun startAdvertising(owner: String, port: Int)
    fun stopAdvertising(owner: String)
}

enum class CapabilityState { AVAILABLE, RADIO_OFF, PERMISSION_MISSING, UNSUPPORTED, NO_NETWORK }

data class TransportCapability(val kind: TransportKind, val state: CapabilityState)

data class RadioStatus(
    val wifiEnabled: Boolean,
    val wifiConnected: Boolean,
    val bluetoothSupported: Boolean,
    val bluetoothEnabled: Boolean,
    val locationEnabled: Boolean,
    val sdkInt: Int,
)

interface CapabilityProvider {
    val capabilities: StateFlow<List<TransportCapability>>
    val radio: StateFlow<RadioStatus>
    fun refresh()
}

/** How to reach a device right now. [connector] may bind sockets to a specific Network (Wi-Fi Direct / hotspot). */
data class ConnectionPlan(
    val host: String,
    val port: Int,
    val transport: TransportKind,
    val expectedFingerprint: String?,
    val connector: SocketConnector,
)

sealed interface PlanResult {
    data class Ready(val plan: ConnectionPlan) : PlanResult
    data class Failed(val failure: TransferFailure, val detail: String?) : PlanResult
}

interface TransportPlanner {
    /** Chooses and prepares the best transport (may create a Wi-Fi Direct group or join a hotspot). */
    suspend fun plan(device: NearbyDevice): PlanResult

    /** Plans from a scanned pairing QR (joins the hotspot described in it when needed). */
    suspend fun planFromQr(payload: QrPayload): PlanResult

    fun planManual(host: String, port: Int): ConnectionPlan

    /** Tears down transient networks created for [plan] (Wi-Fi Direct group, network request). Safe to call twice. */
    suspend fun release(plan: ConnectionPlan)

    /** Starts a local-only hotspot for QR pairing; null if unsupported/denied. Must be stopped with [stopHotspot]. */
    suspend fun startHotspot(): com.aero.share.transfer.pairing.HotspotCredentials?
    fun stopHotspot()
}
