package com.aero.share.core.storage.apk

import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

/** The `aero-app.json` entry of a bundle. It is informational only; the installer trusts nothing but the APK files. */
data class ApkBundleManifest(
    val packageName: String,
    val versionName: String?,
    val versionCode: Long,
    val label: String?,
    val splits: List<String>,
) {
    fun toJson(): String {
        val root = JSONObject()
        root.put("format", FORMAT)
        root.put("package", packageName)
        root.put("versionName", versionName ?: JSONObject.NULL)
        root.put("versionCode", versionCode)
        root.put("label", label ?: JSONObject.NULL)
        val array = JSONArray()
        for (split in splits) array.put(split)
        root.put("splits", array)
        return root.toString()
    }

    companion object {
        const val FORMAT = 1
        private val packagePattern = Regex("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+")

        /** Null when the text is not a valid version-1 manifest. */
        fun parse(text: String): ApkBundleManifest? {
            try {
                val root = JSONObject(text)
                val pkg = root.optString("package", "")
                if (root.optInt("format", 0) != FORMAT || !packagePattern.matches(pkg)) return null
                val splits = ArrayList<String>()
                val array = root.optJSONArray("splits")
                if (array != null) {
                    for (index in 0 until minOf(array.length(), ApkBundle.MAX_SPLITS)) {
                        val name = array.optString(index, "")
                        if (ApkBundle.isApkEntry(name)) splits.add(name)
                    }
                }
                return ApkBundleManifest(
                    packageName = pkg,
                    versionName = textOrNull(root, "versionName"),
                    versionCode = root.optLong("versionCode", 0L),
                    label = textOrNull(root, "label"),
                    splits = splits,
                )
            } catch (e: JSONException) {
                return null
            }
        }

        private fun textOrNull(root: JSONObject, key: String): String? =
            if (root.isNull(key)) null else root.optString(key, "").takeIf { it.isNotEmpty() }
    }
}
