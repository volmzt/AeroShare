package com.aero.share.network.transport

import com.aero.share.domain.CapabilityState
import com.aero.share.domain.RadioStatus
import com.aero.share.domain.TransportCapability
import com.aero.share.transfer.model.TransportKind

/** What the device reports right now. [CapabilityRules] turns it into honest capability states. */
internal data class CapabilityFacts(
    val sdkInt: Int,
    val hasWifiHardware: Boolean,
    val hasWifiDirect: Boolean,
    val wifiEnabled: Boolean,
    /** A Wi-Fi or Ethernet network with an IPv4 address exists (internet access is not required). */
    val lanConnected: Boolean,
    val wifiConnected: Boolean,
    /** NEARBY_WIFI_DEVICES on API 33+, fine location before. */
    val nearbyGranted: Boolean,
    val locationEnabled: Boolean,
    val bluetoothSupported: Boolean = false,
    val bluetoothEnabled: Boolean = false,
)

internal object CapabilityRules {
    /** Up to this API level Wi-Fi Direct discovery and the local-only hotspot need the location switch to be on. */
    const val LAST_SDK_NEEDING_LOCATION = 32
    const val MIN_SDK_HOTSPOT = 26

    fun compute(f: CapabilityFacts): List<TransportCapability> = listOf(
        TransportCapability(TransportKind.LAN, lan(f)),
        TransportCapability(TransportKind.WIFI_DIRECT, wifiDirect(f)),
        TransportCapability(TransportKind.HOTSPOT, hotspot(f)),
        TransportCapability(TransportKind.MANUAL, lan(f)),
    )

    fun radio(f: CapabilityFacts): RadioStatus = RadioStatus(
        wifiEnabled = f.wifiEnabled,
        wifiConnected = f.wifiConnected,
        bluetoothSupported = f.bluetoothSupported,
        bluetoothEnabled = f.bluetoothEnabled,
        locationEnabled = f.locationEnabled,
        sdkInt = f.sdkInt,
    )

    private fun lan(f: CapabilityFacts): CapabilityState = when {
        f.lanConnected -> CapabilityState.AVAILABLE
        f.hasWifiHardware && !f.wifiEnabled -> CapabilityState.RADIO_OFF
        else -> CapabilityState.NO_NETWORK
    }

    private fun wifiDirect(f: CapabilityFacts): CapabilityState = when {
        !f.hasWifiHardware || !f.hasWifiDirect -> CapabilityState.UNSUPPORTED
        !f.nearbyGranted -> CapabilityState.PERMISSION_MISSING
        !f.wifiEnabled -> CapabilityState.RADIO_OFF
        needsLocation(f) -> CapabilityState.RADIO_OFF
        else -> CapabilityState.AVAILABLE
    }

    /** The local-only hotspot works with Wi-Fi on or off (the system switches modes), so only location matters. */
    private fun hotspot(f: CapabilityFacts): CapabilityState = when {
        f.sdkInt < MIN_SDK_HOTSPOT || !f.hasWifiHardware -> CapabilityState.UNSUPPORTED
        !f.nearbyGranted -> CapabilityState.PERMISSION_MISSING
        needsLocation(f) -> CapabilityState.RADIO_OFF
        else -> CapabilityState.AVAILABLE
    }

    private fun needsLocation(f: CapabilityFacts): Boolean = f.sdkInt <= LAST_SDK_NEEDING_LOCATION && !f.locationEnabled
}

/** State of [kind] in a capability list; a missing entry counts as UNSUPPORTED. */
internal fun List<TransportCapability>.stateOf(kind: TransportKind): CapabilityState =
    firstOrNull { it.kind == kind }?.state ?: CapabilityState.UNSUPPORTED
