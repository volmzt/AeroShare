package com.aero.share.core.storage

import android.content.Context
import android.net.Uri
import android.os.Build
import androidx.documentfile.provider.DocumentFile
import com.aero.share.domain.SettingsRepository
import com.aero.share.transfer.storage.IncomingStorage

/**
 * Chooses where received files go, using the CURRENT settings every time an offer is accepted:
 * the folder picked by the user (when its permission is still valid), otherwise Downloads/AERO SHARE.
 */
class DestinationResolver(
    private val context: Context,
    private val settings: SettingsRepository,
) {
    fun storage(): IncomingStorage {
        val s = settings.settings.value
        val parts = IncomingParts.root(context)
        val custom = customFolder()
        if (custom != null) {
            return SafTreeIncomingStorage(context, custom.first, parts, s.conflictPolicy, custom.second)
        }
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStoreIncomingStorage(context, parts, s.conflictPolicy)
        } else {
            LegacyIncomingStorage.create(context, parts, s.conflictPolicy)
        }
    }

    /** Human readable destination, for the receive screen and settings. */
    fun label(): String {
        customFolder()?.let { return it.second }
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStoreIncomingStorage.LABEL
        } else {
            LegacyIncomingStorage.label(context, LegacyIncomingStorage.hasPublicAccess(context))
        }
    }

    /** True when a custom folder is configured but cannot be used any more (permission revoked or folder deleted). */
    fun customFolderBroken(): Boolean = settings.settings.value.saveDirectoryUri != null && customFolder() == null

    private fun customFolder(): Pair<Uri, String>? {
        val raw = settings.settings.value.saveDirectoryUri ?: return null
        return try {
            val uri = Uri.parse(raw)
            val permitted = context.contentResolver.persistedUriPermissions.any { it.uri == uri && it.isWritePermission }
            if (!permitted) return null
            val doc = DocumentFile.fromTreeUri(context, uri) ?: return null
            if (!doc.exists() || !doc.canWrite()) return null
            uri to (doc.name ?: raw)
        } catch (e: RuntimeException) {
            null
        }
    }
}
