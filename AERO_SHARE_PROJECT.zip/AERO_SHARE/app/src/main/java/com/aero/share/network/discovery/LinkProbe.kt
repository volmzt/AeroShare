package com.aero.share.network.discovery

import com.aero.share.domain.LinkQuality
import java.io.IOException
import java.net.InetSocketAddress
import java.net.Socket

/**
 * Measures how long a TCP connection to a device takes. Nothing is sent and no TLS is started: the connection is closed
 * immediately. The result is only ever a measured value; when the probe fails the quality stays UNKNOWN.
 */
internal object LinkProbe {
    const val TIMEOUT_MS = 1500
    private const val STRONG_BELOW_MS = 30L
    private const val FAIR_BELOW_MS = 120L

    fun classify(connectMillis: Long): LinkQuality = when {
        connectMillis < STRONG_BELOW_MS -> LinkQuality.STRONG
        connectMillis < FAIR_BELOW_MS -> LinkQuality.FAIR
        else -> LinkQuality.WEAK
    }

    /** Connect time in milliseconds, or null when the device did not accept the connection in time. */
    fun measure(host: String, port: Int, timeoutMs: Int = TIMEOUT_MS, bind: ((Socket) -> Unit)? = null): Long? {
        val socket = Socket()
        try {
            bind?.invoke(socket)
            val start = System.nanoTime()
            socket.connect(InetSocketAddress(host, port), timeoutMs)
            return (System.nanoTime() - start) / 1_000_000L
        } catch (e: IOException) {
            return null
        } catch (e: IllegalArgumentException) {
            return null
        } catch (e: SecurityException) {
            return null
        } finally {
            try {
                socket.close()
            } catch (e: IOException) {
                // nothing left to release
            }
        }
    }
}
