package com.aero.share.feature.onboarding

import androidx.annotation.StringRes
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Devices
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material.icons.rounded.WifiTethering
import androidx.compose.ui.graphics.vector.ImageVector
import com.aero.share.R

/** One page of the first-launch tour. A null [icon] means the page shows the AERO SHARE logo instead. */
internal data class OnboardingPage(
    @StringRes val title: Int,
    @StringRes val text: Int,
    val icon: ImageVector?,
)

internal object OnboardingPages {
    val all: List<OnboardingPage> = listOf(
        OnboardingPage(R.string.onb_p1_title, R.string.onb_p1_text, null),
        OnboardingPage(R.string.onb_p2_title, R.string.onb_p2_text, Icons.Rounded.WifiTethering),
        OnboardingPage(R.string.onb_p3_title, R.string.onb_p3_text, Icons.Rounded.Devices),
        OnboardingPage(R.string.onb_p4_title, R.string.onb_p4_text, Icons.Rounded.VerifiedUser),
        OnboardingPage(R.string.onb_p5_title, R.string.onb_p5_text, Icons.Rounded.Lock),
        OnboardingPage(R.string.onb_p6_title, R.string.onb_p6_text, Icons.Rounded.Shield),
    )
}
