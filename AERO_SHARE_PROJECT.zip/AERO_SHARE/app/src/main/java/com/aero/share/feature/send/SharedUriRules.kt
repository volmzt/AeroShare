package com.aero.share.feature.send

/** Decisions about items that arrive from other apps (the share sheet) or from the system file picker. */
internal object SharedUriRules {
    /** More than this many shared items are ignored; no sender needs more and a flood must not freeze the app. */
    const val MAX_SHARED = 2_000

    /** Name used when the provider reports none and the URI has no usable last segment. */
    const val FALLBACK_NAME = "file"

    /**
     * Only `content://` is accepted. A `file://` URI would let another app make this one read any file it can reach, so such
     * items are dropped instead of being sent.
     */
    fun isAcceptable(scheme: String?): Boolean = scheme != null && scheme.equals("content", ignoreCase = true)

    /** The name to show and send: what the provider reported, else the last URI segment, always free of path separators. */
    fun displayName(reported: String?, lastSegment: String?): String {
        val fromSegment = lastSegment?.substringAfterLast('/')?.substringAfterLast(':')
        val raw = when {
            !reported.isNullOrBlank() -> reported
            !fromSegment.isNullOrBlank() -> fromSegment
            else -> FALLBACK_NAME
        }
        val cleaned = raw.replace('/', '_').replace('\\', '_').trim()
        return if (cleaned.isEmpty() || cleaned == "." || cleaned == "..") FALLBACK_NAME else cleaned
    }

    /** Distinct, non-blank URI strings in their original order, capped at [MAX_SHARED]. */
    fun distinct(uris: List<String>): List<String> {
        val seen = HashSet<String>()
        val result = ArrayList<String>()
        for (text in uris) {
            if (text.isBlank() || !seen.add(text)) continue
            result.add(text)
            if (result.size >= MAX_SHARED) break
        }
        return result
    }
}
