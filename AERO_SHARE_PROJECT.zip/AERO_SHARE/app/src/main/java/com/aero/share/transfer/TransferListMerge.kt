package com.aero.share.transfer

import com.aero.share.transfer.model.TransferSnapshot

/** Combines the send queue and the receive sessions into the one list the UI shows, newest first. */
internal object TransferListMerge {
    /** [sequenceOf] gives every transfer a creation number that stays stable while the transfer changes state. */
    fun merge(
        sends: List<TransferSnapshot>,
        receives: Collection<TransferSnapshot>,
        sequenceOf: (String) -> Long,
    ): List<TransferSnapshot> {
        val byId = LinkedHashMap<String, TransferSnapshot>()
        for (snapshot in sends) byId[snapshot.id] = snapshot
        for (snapshot in receives) byId[snapshot.id] = snapshot
        return byId.values.sortedByDescending { sequenceOf(it.id) }
    }
}
