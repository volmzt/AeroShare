package com.aero.share.core.storage.apk

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.content.pm.Signature
import android.net.Uri
import android.os.Build
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import com.aero.share.core.storage.UriMetadata
import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.security.DigestInputStream
import java.security.MessageDigest
import java.util.zip.ZipInputStream

/**
 * Reads the details of an APK or an `.aeroapks` bundle: package name, version, signing certificates, icon and warnings.
 * This is metadata inspection only and is never presented as malware scanning.
 *
 * The package manager can only parse files by path, so the APK (for bundles: only `base.apk`) is copied to the cache
 * while the SHA-256 of the whole source is computed in the same pass. Packages above [MAX_INSPECT_BYTES] (or when the
 * cache is too full) get a hash and no details.
 */
internal class ApkInfoReader(private val context: Context) {
    private val pm: PackageManager = context.packageManager
    private val workDir = File(context.cacheDir, "apk-inspect")

    private class BundleFacts(val manifest: ApkBundleManifest?, val splitNames: List<String>, val sawBase: Boolean)

    /** Null when the source cannot be read at all. */
    fun read(uriString: String): ApkInfo? {
        val uri = Uri.parse(uriString)
        val meta = UriMetadata.query(context, uri) ?: return null
        val fileName = meta.name ?: uri.lastPathSegment ?: DEFAULT_NAME
        try {
            purgeStale()
            val work = File.createTempFile("inspect", ".apk", directory())
            try {
                return if (ApkBundle.isBundleName(fileName)) {
                    readBundle(uriString, uri, fileName, meta.size, work)
                } else {
                    readApk(uriString, uri, fileName, meta.size, work)
                }
            } finally {
                work.delete()
            }
        } catch (e: IOException) {
            return null
        } catch (e: SecurityException) {
            return null
        }
    }

    private fun readApk(uriString: String, uri: Uri, fileName: String, size: Long, work: File): ApkInfo {
        val digest = MessageDigest.getInstance("SHA-256")
        val inspectable = canInspect(size)
        open(uri).use { raw ->
            val input = DigestInputStream(raw, digest)
            if (inspectable) {
                FileOutputStream(work).use { out -> input.copyTo(out, BUFFER) }
            } else {
                drain(input)
            }
        }
        val archive = if (inspectable) archiveInfo(work) else null
        return describe(uriString, fileName, size, hex(digest.digest()), archive, work, inspected = inspectable, bundle = null)
    }

    private fun readBundle(uriString: String, uri: Uri, fileName: String, size: Long, work: File): ApkInfo {
        val digest = MessageDigest.getInstance("SHA-256")
        val inspectable = canInspect(size)
        var manifest: ApkBundleManifest? = null
        var sawBase = false
        var baseCopied = false
        val splitNames = ArrayList<String>()
        open(uri).use { raw ->
            val counted = DigestInputStream(raw, digest)
            val zip = ZipInputStream(BufferedInputStream(counted, BUFFER))
            ApkBundle.forEachEntry(zip) { name ->
                when (name) {
                    ApkBundle.MANIFEST_ENTRY -> {
                        val text = readText(zip, ApkBundle.MAX_MANIFEST_BYTES)
                        if (text != null) manifest = ApkBundleManifest.parse(text)
                    }
                    ApkBundle.BASE_ENTRY -> {
                        sawBase = true
                        if (inspectable) {
                            FileOutputStream(work).use { out -> zip.copyTo(out, BUFFER) }
                            baseCopied = true
                        }
                    }
                    else -> if (splitNames.size < ApkBundle.MAX_SPLITS) splitNames.add(name)
                }
            }
            // Bytes after the last local entry (the central directory) still belong to the hash.
            drain(counted)
        }
        val archive = if (baseCopied) archiveInfo(work) else null
        val facts = BundleFacts(manifest, splitNames, sawBase)
        return describe(uriString, fileName, size, hex(digest.digest()), archive, work, inspected = baseCopied, bundle = facts)
    }

    private fun describe(
        uri: String,
        fileName: String,
        size: Long,
        sha256: String?,
        archive: PackageInfo?,
        file: File,
        inspected: Boolean,
        bundle: BundleFacts?,
    ): ApkInfo {
        val warnings = ArrayList<ApkWarning>()
        val manifest = bundle?.manifest
        val splitCount = bundle?.splitNames?.size ?: 0
        if (archive == null) {
            if (inspected || (bundle != null && !bundle.sawBase)) warnings.add(ApkWarning.INVALID)
            return ApkInfo(
                uri = uri,
                fileName = fileName,
                appName = manifest?.label,
                packageName = manifest?.packageName,
                versionName = manifest?.versionName,
                versionCode = manifest?.versionCode,
                sizeBytes = size,
                icon = null,
                sha256 = sha256,
                signerSha256 = emptyList(),
                isBundle = bundle != null,
                splitCount = splitCount,
                installedVersionName = null,
                warnings = warnings,
            )
        }

        val app = archive.applicationInfo
        if (app != null) {
            app.sourceDir = file.path
            app.publicSourceDir = file.path
        }
        val packageName: String? = archive.packageName
        val versionCode = versionCodeOf(archive)
        val signers = signerHashes(archive)
        val installed = if (packageName == null) null else installedInfo(packageName)
        if (installed != null) {
            val installedSigners = signerHashes(installed)
            if (signers.isNotEmpty() && installedSigners.isNotEmpty() && signers.none { it in installedSigners }) {
                warnings.add(ApkWarning.SIGNER_MISMATCH)
            }
            if (versionCodeOf(installed) > versionCode) warnings.add(ApkWarning.DOWNGRADE)
        }
        if (app != null && app.minSdkVersion > Build.VERSION.SDK_INT) warnings.add(ApkWarning.MIN_SDK_TOO_HIGH)
        if (bundle != null) {
            if (!bundle.sawBase || (manifest != null && manifest.packageName != packageName)) warnings.add(ApkWarning.INVALID)
            if (missingAbi(bundle.splitNames)) warnings.add(ApkWarning.INCOMPLETE_SPLITS)
        }
        return ApkInfo(
            uri = uri,
            fileName = fileName,
            appName = (if (app != null) labelOf(app) else null) ?: manifest?.label,
            packageName = packageName,
            versionName = archive.versionName ?: manifest?.versionName,
            versionCode = versionCode,
            sizeBytes = size,
            icon = if (app != null) iconOf(app) else null,
            sha256 = sha256,
            signerSha256 = signers,
            isBundle = bundle != null,
            splitCount = splitCount,
            installedVersionName = installed?.versionName,
            warnings = warnings,
        )
    }

    @Suppress("DEPRECATION") // the Int overloads are the only ones before Android 13
    private fun archiveInfo(file: File): PackageInfo? =
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                pm.getPackageArchiveInfo(file.path, PackageManager.PackageInfoFlags.of(signingFlag().toLong()))
            } else {
                pm.getPackageArchiveInfo(file.path, signingFlag())
            }
        } catch (e: RuntimeException) {
            null
        }

    /** The installed package, when this app can see it (only apps with a launcher entry are visible, see the manifest). */
    @Suppress("DEPRECATION")
    private fun installedInfo(packageName: String): PackageInfo? =
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                pm.getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(signingFlag().toLong()))
            } else {
                pm.getPackageInfo(packageName, signingFlag())
            }
        } catch (e: PackageManager.NameNotFoundException) {
            null
        } catch (e: RuntimeException) {
            null
        }

    @Suppress("DEPRECATION") // GET_SIGNATURES is the only way to read certificates before Android 9
    private fun signingFlag(): Int =
        if (Build.VERSION.SDK_INT >= 28) PackageManager.GET_SIGNING_CERTIFICATES else PackageManager.GET_SIGNATURES

    @Suppress("DEPRECATION")
    private fun signerHashes(info: PackageInfo): List<String> {
        val certificates: Array<Signature>? = if (Build.VERSION.SDK_INT >= 28) {
            val signing = info.signingInfo
            if (signing == null) {
                null
            } else if (signing.hasMultipleSigners()) {
                signing.apkContentsSigners
            } else {
                signing.signingCertificateHistory
            }
        } else {
            info.signatures
        }
        if (certificates == null) return emptyList()
        return certificates.map { hex(MessageDigest.getInstance("SHA-256").digest(it.toByteArray())) }.distinct()
    }

    @Suppress("DEPRECATION")
    private fun versionCodeOf(info: PackageInfo): Long =
        if (Build.VERSION.SDK_INT >= 28) info.longVersionCode else info.versionCode.toLong()

    private fun labelOf(app: ApplicationInfo): String? =
        try {
            app.loadLabel(pm).toString().trim().takeIf { it.isNotEmpty() }
        } catch (e: RuntimeException) {
            null
        }

    private fun iconOf(app: ApplicationInfo): ImageBitmap? =
        try {
            app.loadIcon(pm).toBitmap(ICON_PX, ICON_PX).asImageBitmap()
        } catch (e: RuntimeException) {
            null
        }

    /** True when the bundle carries ABI splits but none of them is for a processor type of this device. */
    private fun missingAbi(splitNames: List<String>): Boolean {
        val abis = splitNames.mapNotNull { ApkBundle.abiOf(it) }
        if (abis.isEmpty()) return false
        return Build.SUPPORTED_ABIS.none { it in abis }
    }

    private fun canInspect(size: Long): Boolean =
        size <= MAX_INSPECT_BYTES && directory().usableSpace >= size + SAFETY_BYTES

    private fun directory(): File {
        workDir.mkdirs()
        return workDir
    }

    private fun purgeStale() {
        val cutoff = System.currentTimeMillis() - STALE_MILLIS
        directory().listFiles()?.forEach { if (it.lastModified() < cutoff) it.delete() }
    }

    private fun open(uri: Uri): InputStream =
        context.contentResolver.openInputStream(uri) ?: throw IOException("cannot open the package")

    private fun drain(input: InputStream) {
        val buffer = ByteArray(BUFFER)
        while (true) {
            if (input.read(buffer) < 0) break
        }
    }

    /** Reads at most [limit] bytes as UTF-8 text; null when the entry is larger. */
    private fun readText(input: InputStream, limit: Int): String? {
        val out = ByteArrayOutputStream()
        val buffer = ByteArray(4096)
        while (true) {
            val read = input.read(buffer)
            if (read < 0) break
            if (out.size() + read > limit) return null
            out.write(buffer, 0, read)
        }
        return String(out.toByteArray(), Charsets.UTF_8)
    }

    private fun hex(bytes: ByteArray): String {
        val out = StringBuilder(bytes.size * 2)
        for (b in bytes) {
            val v = b.toInt() and 0xFF
            out.append(HEX[v shr 4])
            out.append(HEX[v and 0x0F])
        }
        return out.toString()
    }

    private companion object {
        const val DEFAULT_NAME = "package.apk"
        const val BUFFER = 128 * 1024
        const val ICON_PX = 192
        const val MAX_INSPECT_BYTES = 1L shl 30
        const val SAFETY_BYTES = 64L * 1024 * 1024
        const val STALE_MILLIS = 60L * 60L * 1000L
        const val HEX = "0123456789abcdef"
    }
}
