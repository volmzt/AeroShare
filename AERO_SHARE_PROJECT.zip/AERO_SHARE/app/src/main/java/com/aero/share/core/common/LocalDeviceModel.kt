package com.aero.share.core.common

import com.aero.share.transfer.model.DeviceKind

/**
 * Pure rules for how this device presents itself to peers (name and kind).
 * Kept free of Android types so that it can be unit tested on the JVM.
 */
object LocalDeviceModel {
    /** Longest device name that is announced to peers. */
    const val MAX_NAME_LENGTH = 40

    /** Smallest screen width (dp) from which a device is announced as a tablet. */
    const val TABLET_MIN_WIDTH_DP = 600

    /** Trims [rawModel] (Build.MODEL); null when it is missing or blank so the caller can use a fallback name. */
    fun cleanModel(rawModel: String?): String? =
        rawModel?.trim()?.takeIf { it.isNotEmpty() }?.take(MAX_NAME_LENGTH)

    /** [DeviceKind.TABLET] when the smallest screen width is at least 600 dp, otherwise [DeviceKind.PHONE]. */
    fun kindFor(smallestScreenWidthDp: Int): DeviceKind =
        if (smallestScreenWidthDp >= TABLET_MIN_WIDTH_DP) DeviceKind.TABLET else DeviceKind.PHONE

    /** The custom name when it is not blank (trimmed, at most [MAX_NAME_LENGTH] characters), otherwise [defaultName]. */
    fun displayName(customName: String?, defaultName: String): String =
        customName?.trim()?.takeIf { it.isNotEmpty() }?.take(MAX_NAME_LENGTH)?.trimEnd() ?: defaultName
}
