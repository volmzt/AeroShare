package com.aero.share.navigation

/** Sections of the settings area (each is a page; the list page shows them as groups). */
enum class SettingsSection { GENERAL, CONNECTIONS, TRANSFERS, POWER, CUSTOMIZATION, SECURITY, PLUGINS }

/**
 * The only navigation surface features use. Implemented by the NavHost owner. Features never touch NavController.
 * Screens must call these instead of hardcoding routes.
 */
interface AeroNavigator {
    fun back()

    /** Bottom navigation tabs. */
    fun openHome()
    fun openDevices()
    fun openSettings()

    fun openHistory()
    fun openSettingsSection(section: SettingsSection)
    fun openDiagnostics()
    fun openAbout()

    /** Send flow: picker -> recipients -> confirm -> transfer. */
    fun openSendPicker()
    fun openRecipients()
    fun openConfirm()

    fun openReceive()

    /** Shows the progress/completion screen of [id]. [replaceCurrent] pops the current screen first. */
    fun openTransfer(id: String, replaceCurrent: Boolean = false)

    /** Pops everything above Home. */
    fun backToHome()
}
