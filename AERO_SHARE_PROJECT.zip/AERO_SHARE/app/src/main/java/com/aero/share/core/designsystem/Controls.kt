package com.aero.share.core.designsystem

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.sizeIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

/** Track and thumb only; the touch handling is done by the caller so a whole row can be the switch. */
@Composable
private fun SwitchVisual(checked: Boolean, enabled: Boolean) {
    val colors = AeroTheme.colors
    val motion = AeroTheme.motion
    val duration = if (motion.enabled) motion.short else 0
    val thumbOffset by animateDpAsState(if (checked) 24.dp else 4.dp, tween(duration), label = "switch-thumb")
    val trackColor by animateColorAsState(if (checked) colors.accent else colors.surfaceElevated, tween(duration), label = "switch-track")
    val thumbColor by animateColorAsState(if (checked) colors.onAccent else colors.textSecondary, tween(duration), label = "switch-thumb-color")
    val shape = RoundedCornerShape(16.dp)
    Box(
        modifier = Modifier
            .size(width = 52.dp, height = 32.dp)
            .alpha(if (enabled) 1f else 0.4f)
            .clip(shape)
            .background(trackColor)
            .border(1.dp, if (checked) colors.accent else colors.divider, shape),
    ) {
        Box(
            modifier = Modifier
                .offset(x = thumbOffset, y = 4.dp)
                .size(24.dp)
                .clip(CircleShape)
                .background(thumbColor),
        )
    }
}

@Composable
fun AeroSwitch(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
) {
    val feedback = LocalFeedback.current
    Box(
        modifier = modifier
            .sizeIn(minWidth = 48.dp, minHeight = 48.dp)
            .toggleable(
                value = checked,
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                enabled = enabled,
                role = Role.Switch,
                onValueChange = { value ->
                    feedback.tap()
                    onCheckedChange(value)
                },
            ),
        contentAlignment = Alignment.Center,
    ) {
        SwitchVisual(checked = checked, enabled = enabled)
    }
}

@Composable
private fun RowIcon(icon: ImageVector) {
    val colors = AeroTheme.colors
    Box(
        modifier = Modifier
            .size(40.dp)
            .clip(RoundedCornerShape(AeroTheme.dimens.radiusSmall))
            .background(colors.surfaceAlt),
        contentAlignment = Alignment.Center,
    ) {
        AeroIcon(icon = icon, contentDescription = null, tint = colors.accentText, size = 22.dp)
    }
}

@Composable
private fun RowTexts(title: String, subtitle: String?, modifier: Modifier) {
    val colors = AeroTheme.colors
    Column(modifier = modifier) {
        AeroText(
            text = title,
            style = AeroTheme.typography.body.copy(fontWeight = FontWeight.Medium),
            color = colors.textPrimary,
        )
        if (subtitle != null) {
            AeroText(text = subtitle, style = AeroTheme.typography.caption, color = colors.textSecondary)
        }
    }
}

/** A list row: optional icon tile, title, optional subtitle and a trailing slot (a chevron when it is clickable). */
@Composable
fun AeroSettingsRow(
    title: String,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    icon: ImageVector? = null,
    onClick: (() -> Unit)? = null,
    enabled: Boolean = true,
    trailing: (@Composable () -> Unit)? = null,
) {
    val colors = AeroTheme.colors
    val dimens = AeroTheme.dimens
    val pressable = if (onClick != null) {
        modifier.aeroRowClickable(enabled = enabled, role = Role.Button, onClick = onClick)
    } else {
        modifier
    }
    Row(
        modifier = pressable
            .fillMaxWidth()
            .heightIn(min = dimens.listItemHeight)
            .alpha(if (enabled) 1f else 0.5f)
            .padding(horizontal = dimens.cardPadding, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(dimens.gap),
    ) {
        if (icon != null) RowIcon(icon)
        RowTexts(title, subtitle, Modifier.weight(1f))
        if (trailing != null) {
            trailing()
        } else if (onClick != null) {
            AeroIcon(
                icon = Icons.AutoMirrored.Rounded.KeyboardArrowRight,
                contentDescription = null,
                tint = colors.textSecondary,
            )
        }
    }
}

/** A row that is a switch as a whole: the whole row toggles and is announced as a switch. */
@Composable
fun AeroSwitchRow(
    title: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    icon: ImageVector? = null,
    enabled: Boolean = true,
) {
    val dimens = AeroTheme.dimens
    val feedback = LocalFeedback.current
    Row(
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = dimens.listItemHeight)
            .alpha(if (enabled) 1f else 0.5f)
            .toggleable(
                value = checked,
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                enabled = enabled,
                role = Role.Switch,
                onValueChange = { value ->
                    feedback.tap()
                    onCheckedChange(value)
                },
            )
            .padding(horizontal = dimens.cardPadding, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(dimens.gap),
    ) {
        if (icon != null) RowIcon(icon)
        RowTexts(title, subtitle, Modifier.weight(1f))
        SwitchVisual(checked = checked, enabled = enabled)
    }
}

/**
 * Choose one of several values. Up to four short options are shown as a segmented control, anything longer as a list of
 * radio rows, so labels never get squeezed.
 */
@Composable
fun <T> AeroChoiceRow(
    title: String,
    options: List<Pair<T, String>>,
    selected: T,
    onSelected: (T) -> Unit,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
) {
    val colors = AeroTheme.colors
    val dimens = AeroTheme.dimens
    val feedback = LocalFeedback.current
    val segmented = options.size in 2..4 && options.all { it.second.length <= 10 }
    Column(modifier = modifier.fillMaxWidth().padding(horizontal = dimens.cardPadding, vertical = 12.dp)) {
        RowTexts(title, subtitle, Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        if (segmented) {
            val outer = RoundedCornerShape(dimens.radiusSmall)
            val inner = RoundedCornerShape(dimens.radiusSmall - 3.dp)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(outer)
                    .background(colors.surfaceAlt)
                    .border(1.dp, colors.divider, outer)
                    .padding(3.dp),
                horizontalArrangement = Arrangement.spacedBy(3.dp),
            ) {
                for (option in options) {
                    val isSelected = option.first == selected
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 44.dp)
                            .clip(inner)
                            .background(if (isSelected) colors.accent else androidx.compose.ui.graphics.Color.Transparent)
                            .selectable(
                                selected = isSelected,
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null,
                                role = Role.RadioButton,
                                onClick = {
                                    feedback.tap()
                                    onSelected(option.first)
                                },
                            )
                            .padding(horizontal = 6.dp, vertical = 8.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        AeroText(
                            text = option.second,
                            style = AeroTheme.typography.label,
                            color = if (isSelected) colors.onAccent else colors.textPrimary,
                            textAlign = TextAlign.Center,
                            maxLines = 2,
                        )
                    }
                }
            }
        } else {
            for (option in options) {
                val isSelected = option.first == selected
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 48.dp)
                        .selectable(
                            selected = isSelected,
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                            role = Role.RadioButton,
                            onClick = {
                                feedback.tap()
                                onSelected(option.first)
                            },
                        ),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    RadioDot(isSelected)
                    AeroText(
                        text = option.second,
                        modifier = Modifier.weight(1f),
                        color = if (isSelected) colors.textPrimary else colors.textSecondary,
                    )
                }
            }
        }
    }
}

@Composable
private fun RadioDot(selected: Boolean) {
    val colors = AeroTheme.colors
    Box(
        modifier = Modifier
            .size(22.dp)
            .border(2.dp, if (selected) colors.accent else colors.textSecondary, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        if (selected) {
            Box(Modifier.size(10.dp).clip(CircleShape).background(colors.accent))
        }
    }
}

/** A large selectable card with a radio indicator: for few options that each need an explanation. */
@Composable
fun AeroOptionCard(
    title: String,
    description: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
) {
    val colors = AeroTheme.colors
    val dimens = AeroTheme.dimens
    val feedback = LocalFeedback.current
    val shape = RoundedCornerShape(dimens.radius)
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(shape)
            .background(if (selected) colors.accentContainer else colors.surface, shape)
            .border(if (selected) 2.dp else 1.dp, if (selected) colors.accent else colors.divider, shape)
            .selectable(
                selected = selected,
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                role = Role.RadioButton,
                onClick = {
                    feedback.tap()
                    onClick()
                },
            )
            .padding(dimens.cardPadding),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(dimens.gap),
    ) {
        if (icon != null) RowIcon(icon)
        Column(modifier = Modifier.weight(1f)) {
            AeroText(text = title, style = AeroTheme.typography.bodyStrong)
            Spacer(Modifier.height(2.dp))
            AeroText(text = description, style = AeroTheme.typography.caption, color = colors.textSecondary)
        }
        RadioDot(selected)
    }
}

/** Single-line (or multi-line) text input drawn with the app's own look. */
@Composable
fun AeroTextField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    label: String? = null,
    placeholder: String? = null,
    singleLine: Boolean = true,
    keyboardType: KeyboardType = KeyboardType.Text,
    isError: Boolean = false,
    supportingText: String? = null,
) {
    val colors = AeroTheme.colors
    val shape = RoundedCornerShape(AeroTheme.dimens.radiusSmall)
    Column(modifier = modifier) {
        if (label != null) {
            AeroText(text = label, style = AeroTheme.typography.caption, color = colors.textSecondary)
            Spacer(Modifier.height(6.dp))
        }
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier.fillMaxWidth(),
            textStyle = AeroTheme.typography.body.copy(color = colors.textPrimary),
            singleLine = singleLine,
            keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
            cursorBrush = SolidColor(colors.accent),
            decorationBox = { inner ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 52.dp)
                        .clip(shape)
                        .background(colors.surfaceAlt)
                        .border(1.dp, if (isError) colors.danger else colors.divider, shape)
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    contentAlignment = Alignment.CenterStart,
                ) {
                    if (value.isEmpty() && placeholder != null) {
                        AeroText(text = placeholder, color = colors.textSecondary, maxLines = 1)
                    }
                    inner()
                }
            },
        )
        if (supportingText != null) {
            Spacer(Modifier.height(6.dp))
            AeroText(
                text = supportingText,
                style = AeroTheme.typography.caption,
                color = if (isError) colors.danger else colors.textSecondary,
            )
        }
    }
}
