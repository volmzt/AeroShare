package com.aero.share.network.discovery

/** An address of this device on the active network with its prefix length (used to tell on-link addresses from others). */
data class LocalSubnet(val address: String, val prefixLength: Int)

/** Which addresses of another device are worth trying. Pure string logic, no DNS lookups. */
internal object AddressRules {
    /**
     * IPv4 addresses first, then global/unique-local IPv6. Dropped: loopback, wildcard, multicast, reserved, link-local
     * IPv6 (needs a scope id) and, when the local subnets are known, IPv4 addresses that are not on one of them.
     */
    fun usable(addresses: Collection<String>, subnets: List<LocalSubnet>): List<String> {
        val v4Subnets = subnets.mapNotNull { s -> ipv4ToInt(s.address)?.let { it to s.prefixLength } }
        val v4 = LinkedHashSet<String>()
        val v6 = LinkedHashSet<String>()
        for (raw in addresses) {
            val address = raw.trim().removePrefix("/")
            val value = ipv4ToInt(address)
            if (value != null) {
                val onLink = v4Subnets.isEmpty() || v4Subnets.any { (network, prefix) -> sameSubnet(value, network, prefix) }
                if (isUsableV4(value) && onLink) v4.add(address)
            } else if (isUsableV6(address)) {
                v6.add(address)
            }
        }
        return v4.toList() + v6.toList()
    }

    /** Strict dotted quad ("192.168.1.5"); null for anything else. */
    fun ipv4ToInt(text: String): Int? {
        val parts = text.split('.')
        if (parts.size != 4) return null
        var value = 0
        for (part in parts) {
            if (part.isEmpty() || part.length > 3 || !part.all { it in '0'..'9' }) return null
            val octet = part.toInt()
            if (octet > 255) return null
            value = (value shl 8) or octet
        }
        return value
    }

    private fun isUsableV4(value: Int): Boolean {
        val first = (value ushr 24) and 0xFF
        return first != 0 && first != 127 && first < 224
    }

    private fun sameSubnet(a: Int, b: Int, prefixLength: Int): Boolean {
        val prefix = prefixLength.coerceIn(0, 32)
        val mask = if (prefix == 0) 0 else -1 shl (32 - prefix)
        return (a and mask) == (b and mask)
    }

    private fun isUsableV6(address: String): Boolean {
        if (!address.contains(':') || address.contains('%')) return false
        val lower = address.lowercase()
        if (!lower.all { it in '0'..'9' || it in 'a'..'f' || it == ':' }) return false
        if (lower == "::" || lower == "::1") return false
        if (lower.startsWith("fe8") || lower.startsWith("fe9") || lower.startsWith("fea") || lower.startsWith("feb")) return false
        if (lower.startsWith("ff")) return false
        return true
    }
}
