package com.aero.share.feature.send

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import androidx.documentfile.provider.DocumentFile
import com.aero.share.core.storage.source.FolderEnumerator
import com.aero.share.transfer.engine.SendableFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** What a chosen folder holds: [files] that can be sent, their total [bytes], and [skipped] entries that cannot be read. */
internal data class FolderTotals(val files: Int, val bytes: Long, val skipped: Int)

/**
 * Counts the files of a folder chosen with the system folder picker. It uses the very same walk the transfer uses, so the
 * numbers shown in the selection are the numbers that will be sent.
 */
internal object FolderScanner {
    suspend fun measure(context: Context, treeUri: Uri, name: String): FolderTotals = withContext(Dispatchers.IO) {
        val files = ArrayList<SendableFile>()
        var counter = 0
        val skipped = FolderEnumerator.enumerate(context, treeUri, name, files) { counter++ }
        var bytes = 0L
        for (file in files) bytes += file.size
        FolderTotals(files = files.size, bytes = bytes, skipped = skipped)
    }

    /** The folder's own name; falls back to the last part of its document id when the provider does not report one. */
    fun nameOf(context: Context, treeUri: Uri): String {
        val reported = try {
            DocumentFile.fromTreeUri(context, treeUri)?.name
        } catch (e: RuntimeException) {
            null
        }
        if (!reported.isNullOrBlank()) return SharedUriRules.displayName(reported, null)
        val fromId = try {
            DocumentsContract.getTreeDocumentId(treeUri).substringAfterLast(':').substringAfterLast('/')
        } catch (e: IllegalArgumentException) {
            null
        }
        return SharedUriRules.displayName(null, fromId)
    }
}
