package com.aero.share

import android.app.Application
import android.content.Context
import com.aero.share.core.common.LocaleHelper
import com.aero.share.di.AppContainer
import com.aero.share.di.AppContainerFactory
import com.aero.share.transfer.service.Notifications
import com.aero.share.transfer.work.CleanupScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/** Application: builds the dependency container once and registers notification channels and maintenance work. */
class AeroApp : Application() {
    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    lateinit var container: AppContainer
        private set

    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(LocaleHelper.wrap(base))
    }

    override fun onCreate() {
        super.onCreate()
        container = AppContainerFactory.create(this, appScope)
        Notifications.createChannels(this)
        CleanupScheduler.schedule(this)
    }
}
