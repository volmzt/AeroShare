package com.aero.share.feature.send

import com.aero.share.domain.Recipient
import com.aero.share.domain.SelectionItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/**
 * Identity of a recipient, so one device is never listed twice: devices are identified by their id (whether they were found
 * nearby or scanned from a QR code), manual targets by their address.
 */
internal object RecipientKeys {
    fun ofDevice(deviceId: String): String = "id:" + deviceId

    fun of(recipient: Recipient): String = when (recipient) {
        is Recipient.Nearby -> ofDevice(recipient.device.deviceId)
        is Recipient.Qr -> ofDevice(recipient.payload.deviceId)
        is Recipient.Manual -> "ip:" + recipient.host.trim().lowercase() + ":" + recipient.port
    }
}

/**
 * What the person has chosen to send and who should get it, kept while they move between the picker, the recipient list and
 * the confirmation. It lives in memory only: after the process dies the send screens find it empty and return to Home.
 * Items are identified by [SelectionItem.id], so choosing the same file twice never lists it twice.
 */
class SendSession {
    private val selectionState = MutableStateFlow<List<SelectionItem>>(emptyList())
    private val recipientState = MutableStateFlow<List<Recipient>>(emptyList())

    val selection: StateFlow<List<SelectionItem>> = selectionState.asStateFlow()
    val recipients: StateFlow<List<Recipient>> = recipientState.asStateFlow()

    /** Appends the items that are not selected yet; the order of selection is kept. */
    fun add(items: List<SelectionItem>) {
        if (items.isEmpty()) return
        selectionState.update { current ->
            val known = HashSet<String>(current.size + items.size)
            for (item in current) known.add(item.id)
            val fresh = items.filter { item -> known.add(item.id) }
            if (fresh.isEmpty()) current else current + fresh
        }
    }

    /** Selects the item, or removes it when it is already selected. */
    fun toggle(item: SelectionItem) {
        selectionState.update { current ->
            if (current.any { it.id == item.id }) current.filter { it.id != item.id } else current + item
        }
    }

    fun remove(id: String) {
        selectionState.update { current ->
            if (current.any { it.id == id }) current.filter { it.id != id } else current
        }
    }

    fun clearSelection() {
        selectionState.value = emptyList()
    }

    /** Replaces the recipients; duplicates (same device or same address) are dropped, the first one wins. */
    fun setRecipients(list: List<Recipient>) {
        val seen = HashSet<String>()
        recipientState.value = list.filter { recipient -> seen.add(RecipientKeys.of(recipient)) }
    }

    /** Adds the recipient, or removes it when it is already chosen. */
    fun toggleRecipient(recipient: Recipient) {
        val key = RecipientKeys.of(recipient)
        recipientState.update { current ->
            if (current.any { RecipientKeys.of(it) == key }) {
                current.filter { RecipientKeys.of(it) != key }
            } else {
                current + recipient
            }
        }
    }

    /** Adds the recipient or, when the same device is already chosen, replaces it in place (a scanned QR code beats a nearby entry). */
    fun upsertRecipient(recipient: Recipient) {
        val key = RecipientKeys.of(recipient)
        recipientState.update { current ->
            if (current.any { RecipientKeys.of(it) == key }) {
                current.map { existing -> if (RecipientKeys.of(existing) == key) recipient else existing }
            } else {
                current + recipient
            }
        }
    }

    fun removeRecipient(key: String) {
        recipientState.update { current -> current.filter { RecipientKeys.of(it) != key } }
    }

    fun clearAll() {
        selectionState.value = emptyList()
        recipientState.value = emptyList()
    }
}
