package com.aero.share.core.security

import android.content.Context
import android.os.Build
import com.aero.share.core.common.LocalDeviceModel
import com.aero.share.domain.AppSettings
import com.aero.share.domain.LocalDeviceInfo
import com.aero.share.domain.LocalDeviceProvider
import com.aero.share.domain.SettingsRepository
import com.aero.share.transfer.security.DeviceIdentity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

/** This device as announced to peers: name (custom or `Build.MODEL`), kind (tablet by screen size) and identity. */
class AndroidLocalDeviceProvider(
    context: Context,
    private val identity: DeviceIdentity,
    settings: SettingsRepository,
    scope: CoroutineScope,
) : LocalDeviceProvider {
    private val defaultName: String = LocalDeviceModel.cleanModel(Build.MODEL) ?: FALLBACK_NAME
    private val kind = LocalDeviceModel.kindFor(context.resources.configuration.smallestScreenWidthDp)

    override val info: StateFlow<LocalDeviceInfo> =
        settings.settings
            .map { build(it) }
            .stateIn(scope, SharingStarted.Eagerly, build(settings.settings.value))

    private fun build(settings: AppSettings) = LocalDeviceInfo(
        deviceId = identity.deviceId,
        defaultName = defaultName,
        name = LocalDeviceModel.displayName(settings.customDeviceName, defaultName),
        kind = kind,
        fingerprint = identity.fingerprint,
    )

    private companion object {
        const val FALLBACK_NAME = "Android device"
    }
}
