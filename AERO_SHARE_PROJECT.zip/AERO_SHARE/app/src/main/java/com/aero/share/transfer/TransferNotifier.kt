package com.aero.share.transfer

import android.app.Activity
import android.app.Application
import android.content.Context
import android.os.Bundle
import com.aero.share.domain.PendingIncoming
import com.aero.share.domain.SettingsRepository
import com.aero.share.transfer.model.TransferSnapshot
import com.aero.share.transfer.service.Notifications
import java.util.concurrent.atomic.AtomicInteger

/** Knows whether one of the app's screens is visible, so result notifications are not shown to someone watching the transfer. */
internal class AppVisibility(context: Context) {
    private val started = AtomicInteger(0)

    val isForeground: Boolean get() = started.get() > 0

    init {
        val application = context.applicationContext as? Application
        application?.registerActivityLifecycleCallbacks(object : Application.ActivityLifecycleCallbacks {
            override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {}

            override fun onActivityStarted(activity: Activity) {
                started.incrementAndGet()
            }

            override fun onActivityResumed(activity: Activity) {}

            override fun onActivityPaused(activity: Activity) {}

            override fun onActivityStopped(activity: Activity) {
                if (started.decrementAndGet() < 0) started.set(0)
            }

            override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}

            override fun onActivityDestroyed(activity: Activity) {}
        })
    }
}

/**
 * Applies the user's notification settings before anything is posted. The mandatory foreground-service notification is not
 * handled here: it is always shown while the service runs.
 */
internal class TransferNotifier(
    private val context: Context,
    private val settings: SettingsRepository,
) {
    private val visibility = AppVisibility(context)

    fun incoming(pending: PendingIncoming) {
        val current = settings.settings.value
        if (!current.notificationsEnabled || !current.notifyIncomingRequests) return
        Notifications.postIncoming(context, pending)
    }

    fun cancelIncoming(transferId: String) {
        Notifications.cancelIncoming(context, transferId)
    }

    fun result(snapshot: TransferSnapshot) {
        val current = settings.settings.value
        if (!current.notificationsEnabled || !current.notifyTransferResults) return
        if (visibility.isForeground) return
        Notifications.postResult(context, snapshot)
    }
}
