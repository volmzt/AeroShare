package com.aero.share.feature.onboarding

import androidx.activity.compose.BackHandler
import androidx.annotation.StringRes
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.QrCodeScanner
import androidx.compose.material.icons.rounded.WifiTethering
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aero.share.R
import com.aero.share.core.designsystem.AeroButton
import com.aero.share.core.designsystem.AeroButtonStyle
import com.aero.share.core.designsystem.AeroCard
import com.aero.share.core.designsystem.AeroChoiceRow
import com.aero.share.core.designsystem.AeroIcon
import com.aero.share.core.designsystem.AeroLogo
import com.aero.share.core.designsystem.AeroScreen
import com.aero.share.core.designsystem.AeroText
import com.aero.share.core.designsystem.AeroTheme
import com.aero.share.core.designsystem.findActivity
import com.aero.share.di.LocalAppContainer
import com.aero.share.domain.LanguagePref
import com.aero.share.domain.ThemeMode
import kotlinx.coroutines.launch

/**
 * First-launch tour: six short pages, no account and no permission request (the permissions page only explains what is
 * asked and when). The last page applies theme and language immediately; "Get started" marks the tour as done.
 */
@Composable
fun OnboardingScreen(onFinished: () -> Unit) {
    val container = LocalAppContainer.current
    val settings by container.settings.settings.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    val activity = LocalContext.current.findActivity()
    val motion = AeroTheme.motion
    val pagerState = rememberPagerState(pageCount = { OnboardingFlow.COUNT })
    val page = pagerState.currentPage

    val goTo: (Int) -> Unit = { target ->
        scope.launch {
            if (motion.enabled) pagerState.animateScrollToPage(target) else pagerState.scrollToPage(target)
        }
    }
    val finish: () -> Unit = {
        scope.launch {
            container.settings.update { it.copy(onboardingCompleted = true) }
            onFinished()
        }
    }

    val previous = OnboardingFlow.previous(page)
    BackHandler(enabled = previous != null) { if (previous != null) goTo(previous) }

    AeroScreen {
        Row(
            modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp).padding(horizontal = 8.dp),
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (OnboardingFlow.showsSkip(page)) {
                AeroButton(text = stringResource(R.string.common_skip), onClick = finish, style = AeroButtonStyle.Ghost)
            }
        }

        HorizontalPager(state = pagerState, modifier = Modifier.weight(1f).fillMaxWidth()) { index ->
            PageContent(OnboardingPages.all[index]) {
                when (index) {
                    OnboardingFlow.PERMISSIONS -> PermissionList()
                    OnboardingFlow.LAST -> LookAndLanguage(
                        theme = settings.themeMode,
                        language = settings.language,
                        onTheme = { mode -> scope.launch { container.settings.update { it.copy(themeMode = mode) } } },
                        onLanguage = { pref ->
                            scope.launch {
                                container.settings.update { it.copy(language = pref) }
                                // The language is applied when the activity is created, so it has to be recreated.
                                activity?.recreate()
                            }
                        },
                    )
                    else -> Unit
                }
            }
        }

        Footer(
            page = page,
            onNext = { OnboardingFlow.next(page)?.let(goTo) },
            onFinish = finish,
        )
    }
}

@Composable
private fun PageContent(page: OnboardingPage, extra: @Composable ColumnScope.() -> Unit) {
    val colors = AeroTheme.colors
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = AeroTheme.dimens.screenPadding + 4.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(
            modifier = Modifier
                .size(120.dp)
                .clip(RoundedCornerShape(34.dp))
                .background(colors.accentContainer),
            contentAlignment = Alignment.Center,
        ) {
            val icon = page.icon
            if (icon == null) {
                AeroLogo(size = 76.dp)
            } else {
                AeroIcon(icon = icon, contentDescription = null, tint = colors.accentText, size = 60.dp)
            }
        }
        Spacer(Modifier.height(28.dp))
        AeroText(
            text = stringResource(page.title),
            style = AeroTheme.typography.display,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(12.dp))
        AeroText(
            text = stringResource(page.text),
            color = colors.textSecondary,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(20.dp))
        extra()
    }
}

/** Page 4: every permission the app can ask for, why, and when. Nothing is requested here. */
@Composable
private fun PermissionList() {
    AeroCard(modifier = Modifier.fillMaxWidth()) {
        PermissionRow(Icons.Rounded.WifiTethering, R.string.perm_nearby_title, R.string.onb_perm_nearby_when)
        Spacer(Modifier.height(12.dp))
        PermissionRow(Icons.Rounded.Notifications, R.string.perm_notifications_title, R.string.onb_perm_notifications_when)
        Spacer(Modifier.height(12.dp))
        PermissionRow(Icons.Rounded.QrCodeScanner, R.string.perm_camera_title, R.string.onb_perm_camera_when)
        Spacer(Modifier.height(12.dp))
        PermissionRow(Icons.Rounded.Image, R.string.perm_media_title, R.string.onb_perm_media_when)
    }
}

@Composable
private fun PermissionRow(icon: ImageVector, @StringRes title: Int, @StringRes whenAsked: Int) {
    val colors = AeroTheme.colors
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(AeroTheme.dimens.radiusSmall))
                .background(colors.accentContainer),
            contentAlignment = Alignment.Center,
        ) {
            AeroIcon(icon = icon, contentDescription = null, tint = colors.accentText, size = 22.dp)
        }
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            AeroText(text = stringResource(title), style = AeroTheme.typography.bodyStrong)
            AeroText(text = stringResource(whenAsked), style = AeroTheme.typography.caption, color = colors.textSecondary)
        }
    }
}

/** Page 6: theme and language, applied at once. */
@Composable
private fun LookAndLanguage(
    theme: ThemeMode,
    language: LanguagePref,
    onTheme: (ThemeMode) -> Unit,
    onLanguage: (LanguagePref) -> Unit,
) {
    AeroText(
        text = stringResource(R.string.onb_look_text),
        color = AeroTheme.colors.textSecondary,
        textAlign = TextAlign.Center,
    )
    Spacer(Modifier.height(16.dp))
    AeroCard(modifier = Modifier.fillMaxWidth()) {
        AeroChoiceRow(
            title = stringResource(R.string.onb_theme_label),
            options = listOf(
                ThemeMode.SYSTEM to stringResource(R.string.common_theme_system),
                ThemeMode.DARK to stringResource(R.string.common_theme_dark),
                ThemeMode.LIGHT to stringResource(R.string.common_theme_light),
            ),
            selected = theme,
            onSelected = onTheme,
        )
        Spacer(Modifier.height(16.dp))
        AeroChoiceRow(
            title = stringResource(R.string.onb_language_label),
            options = listOf(
                LanguagePref.SYSTEM to stringResource(R.string.common_language_system),
                LanguagePref.ENGLISH to stringResource(R.string.common_language_english),
                LanguagePref.UKRAINIAN to stringResource(R.string.common_language_ukrainian),
                LanguagePref.RUSSIAN to stringResource(R.string.common_language_russian),
            ),
            selected = language,
            onSelected = onLanguage,
        )
    }
}

@Composable
private fun Footer(page: Int, onNext: () -> Unit, onFinish: () -> Unit) {
    val colors = AeroTheme.colors
    val description = stringResource(R.string.onb_page_of, page + 1, OnboardingFlow.COUNT)
    Column(
        modifier = Modifier.fillMaxWidth().padding(horizontal = AeroTheme.dimens.screenPadding, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Row(
            modifier = Modifier.clearAndSetSemantics { contentDescription = description },
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            for (index in 0 until OnboardingFlow.COUNT) {
                val active = index == page
                Box(
                    modifier = Modifier
                        .size(width = if (active) 24.dp else 8.dp, height = 8.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (active) colors.accent else colors.divider),
                )
            }
        }
        Spacer(Modifier.height(16.dp))
        if (page == OnboardingFlow.LAST) {
            AeroButton(
                text = stringResource(R.string.onb_get_started),
                onClick = onFinish,
                modifier = Modifier.fillMaxWidth(),
            )
        } else {
            AeroButton(
                text = stringResource(R.string.common_next),
                onClick = onNext,
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}
