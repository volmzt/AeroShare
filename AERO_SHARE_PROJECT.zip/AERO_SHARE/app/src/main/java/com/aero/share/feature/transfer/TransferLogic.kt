package com.aero.share.feature.transfer

import com.aero.share.transfer.model.TransferDirection
import com.aero.share.transfer.model.TransferFailure
import com.aero.share.transfer.model.TransferState

/** The big line at the top of a transfer: what is going on with whom, in the right direction and tense. */
internal enum class Headline { SENDING, RECEIVING, SENT, RECEIVED, SEND_FAILED, RECEIVE_FAILED, CANCELLED }

/**
 * NONE shows nothing, INDETERMINATE a moving segment (something is happening but there is nothing to measure yet),
 * DETERMINATE the real fraction. A transfer that has not moved any data never shows a bar that looks like progress.
 */
internal enum class ProgressStyle { NONE, INDETERMINATE, DETERMINATE }

/** Which buttons make sense right now. */
internal data class Controls(val pause: Boolean, val resume: Boolean, val cancel: Boolean, val retry: Boolean) {
    val any: Boolean get() = pause || resume || cancel || retry
}

internal enum class EtaKind { HIDDEN, LESS_THAN_MINUTE, MINUTES, HOURS }

/** An estimate of the time left, already rounded for display. [value] is minutes or hours, depending on [kind]. */
internal data class Eta(val kind: EtaKind, val value: Int = 0)

internal object TransferLogic {
    private const val MINUTE_MS = 60_000L
    private const val HOUR_MS = 3_600_000L
    private const val LESS_THAN_MINUTE_MS = 45_000L
    private const val HOURS_FROM_MS = 90L * MINUTE_MS
    private const val MAX_ETA_HOURS = 99L

    fun headline(direction: TransferDirection, state: TransferState): Headline {
        val sending = direction == TransferDirection.SEND
        return when (state) {
            TransferState.COMPLETED -> if (sending) Headline.SENT else Headline.RECEIVED
            TransferState.FAILED -> if (sending) Headline.SEND_FAILED else Headline.RECEIVE_FAILED
            TransferState.CANCELLED -> Headline.CANCELLED
            TransferState.WAITING,
            TransferState.PREPARING,
            TransferState.CONNECTING,
            TransferState.AWAITING_ACCEPTANCE,
            TransferState.TRANSFERRING,
            TransferState.PAUSED,
            TransferState.INTERRUPTED,
            TransferState.VERIFYING,
            -> if (sending) Headline.SENDING else Headline.RECEIVING
        }
    }

    fun progressStyle(state: TransferState, transferredBytes: Long): ProgressStyle = when (state) {
        TransferState.WAITING,
        TransferState.COMPLETED,
        -> ProgressStyle.NONE
        TransferState.PREPARING,
        TransferState.CONNECTING,
        TransferState.AWAITING_ACCEPTANCE,
        -> ProgressStyle.INDETERMINATE
        TransferState.TRANSFERRING,
        TransferState.PAUSED,
        TransferState.VERIFYING,
        TransferState.INTERRUPTED,
        -> ProgressStyle.DETERMINATE
        TransferState.FAILED,
        TransferState.CANCELLED,
        -> if (transferredBytes > 0L) ProgressStyle.DETERMINATE else ProgressStyle.NONE
    }

    /** Failures that trying again cannot fix on its own. An unknown reason may well be temporary. */
    fun retryable(failure: TransferFailure?): Boolean = when (failure) {
        TransferFailure.BLOCKED,
        TransferFailure.AUTH_FAILED,
        TransferFailure.UNSUPPORTED_VERSION,
        TransferFailure.SOURCE_UNREADABLE,
        -> false
        else -> true
    }

    /**
     * Only a transfer that this device sends can be retried from here: a received one is started again by the sender. A
     * transfer that the other device paused can only be resumed there.
     */
    fun controls(
        state: TransferState,
        direction: TransferDirection,
        failure: TransferFailure?,
        pausedByPeer: Boolean,
    ): Controls {
        val sending = direction == TransferDirection.SEND
        return when (state) {
            TransferState.WAITING,
            TransferState.PREPARING,
            TransferState.CONNECTING,
            TransferState.AWAITING_ACCEPTANCE,
            TransferState.VERIFYING,
            -> Controls(pause = false, resume = false, cancel = true, retry = false)
            TransferState.TRANSFERRING -> Controls(pause = true, resume = false, cancel = true, retry = false)
            TransferState.PAUSED -> Controls(pause = false, resume = !pausedByPeer, cancel = true, retry = false)
            TransferState.INTERRUPTED -> Controls(pause = false, resume = false, cancel = true, retry = sending)
            TransferState.FAILED -> Controls(pause = false, resume = false, cancel = false, retry = sending && retryable(failure))
            TransferState.COMPLETED,
            TransferState.CANCELLED,
            -> Controls(pause = false, resume = false, cancel = false, retry = false)
        }
    }

    /** The time left is an estimate: it is only offered while data is moving, and rounded so it does not jitter. */
    fun eta(state: TransferState, etaMillis: Long?, bytesPerSecond: Long): Eta {
        if (state != TransferState.TRANSFERRING || etaMillis == null || etaMillis < 0L || bytesPerSecond <= 0L) {
            return Eta(EtaKind.HIDDEN)
        }
        return when {
            etaMillis < LESS_THAN_MINUTE_MS -> Eta(EtaKind.LESS_THAN_MINUTE)
            etaMillis < HOURS_FROM_MS -> {
                val minutes = ((etaMillis + MINUTE_MS / 2L) / MINUTE_MS).toInt()
                Eta(EtaKind.MINUTES, if (minutes < 1) 1 else minutes)
            }
            else -> {
                val hours = (etaMillis + HOUR_MS / 2L) / HOUR_MS
                if (hours > MAX_ETA_HOURS) Eta(EtaKind.HIDDEN) else Eta(EtaKind.HOURS, hours.toInt())
            }
        }
    }

    /** The 1-based number of the file in progress, or null when there is none or the numbers do not add up. */
    fun fileNumber(currentFileIndex: Int, totalFiles: Int): Int? =
        if (totalFiles > 0 && currentFileIndex in 1..totalFiles) currentFileIndex else null

    /** Whether the file name, speed and time lines are worth showing: only while data is (or was just) moving. */
    fun showsLiveDetails(state: TransferState): Boolean = when (state) {
        TransferState.TRANSFERRING,
        TransferState.PAUSED,
        TransferState.VERIFYING,
        TransferState.INTERRUPTED,
        -> true
        TransferState.WAITING,
        TransferState.PREPARING,
        TransferState.CONNECTING,
        TransferState.AWAITING_ACCEPTANCE,
        TransferState.COMPLETED,
        TransferState.FAILED,
        TransferState.CANCELLED,
        -> false
    }

    /** The speed is shown only while data flows. A paused or finished transfer has no speed. */
    fun showsSpeed(state: TransferState, bytesPerSecond: Long): Boolean =
        state == TransferState.TRANSFERRING && bytesPerSecond > 0L

    /** A verification code is for the person to compare; once the other side has answered it is no longer useful. */
    fun showsVerificationCode(state: TransferState, code: String?): Boolean =
        state == TransferState.AWAITING_ACCEPTANCE && !code.isNullOrBlank()

    /** Finished transfers offer "Done"; running ones keep going in the background when the screen is left. */
    fun isFinished(state: TransferState): Boolean = state.isTerminal

    /** The most files a "share" of received files may include; sharing hundreds of files at once is not useful. */
    const val MAX_SHARE_FILES = 100

    /** At most this many received packages get an install card. */
    const val MAX_APK_CARDS = 5
}
