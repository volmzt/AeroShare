package com.aero.share.core.common

import android.content.Context
import android.content.res.Configuration
import com.aero.share.core.datastore.SettingsMirror
import java.util.Locale

/** Applies the in-app language choice (EN / UK / RU) to a base context. "System" leaves the context untouched. */
object LocaleHelper {
    /** Call from `attachBaseContext` of the Application and every Activity. */
    fun wrap(base: Context): Context {
        val tag = SettingsMirror.language(base) ?: return base
        val locale = Locale.forLanguageTag(tag)
        if (locale.language.isEmpty()) return base
        Locale.setDefault(locale)
        val config = Configuration(base.resources.configuration)
        config.setLocale(locale)
        return base.createConfigurationContext(config)
    }

    /** The explicitly chosen language tag or null for "follow the system". */
    fun currentTag(context: Context): String? = SettingsMirror.language(context)
}
