package com.aero.share.feature.send

import androidx.annotation.StringRes
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.aero.share.R
import com.aero.share.core.common.Formatters
import com.aero.share.core.designsystem.AeroButton
import com.aero.share.core.designsystem.AeroButtonStyle
import com.aero.share.core.designsystem.AeroCategoryIcon
import com.aero.share.core.designsystem.AeroIcon
import com.aero.share.core.designsystem.AeroProgressBar
import com.aero.share.core.designsystem.AeroText
import com.aero.share.core.designsystem.AeroTheme
import com.aero.share.core.storage.apk.ApkInfo
import com.aero.share.core.storage.apk.ApkWarning
import com.aero.share.di.LocalAppContainer
import com.aero.share.transfer.model.FileCategory

private sealed interface ApkLoad {
    data object Loading : ApkLoad
    data object Failed : ApkLoad
    data class Ready(val info: ApkInfo) : ApkLoad
}

/** Reads the package at [uri] (off the main thread) and shows what it is; says so plainly when it cannot be read. */
@Composable
internal fun ApkInspection(uri: String, modifier: Modifier = Modifier) {
    val container = LocalAppContainer.current
    var load by remember(uri) { mutableStateOf<ApkLoad>(ApkLoad.Loading) }
    LaunchedEffect(uri) {
        val info = container.apkInstaller.inspect(uri)
        load = if (info == null) ApkLoad.Failed else ApkLoad.Ready(info)
    }
    when (val current = load) {
        ApkLoad.Loading -> Column(modifier = modifier.fillMaxWidth()) {
            AeroProgressBar(progress = 0f, modifier = Modifier.fillMaxWidth(), indeterminate = true)
            Spacer(Modifier.height(8.dp))
            AeroText(
                text = stringResource(R.string.apkui_loading),
                style = AeroTheme.typography.caption,
                color = AeroTheme.colors.textSecondary,
            )
        }
        ApkLoad.Failed -> AeroText(
            text = stringResource(R.string.apkui_unreadable),
            modifier = modifier.fillMaxWidth(),
            style = AeroTheme.typography.caption,
            color = AeroTheme.colors.danger,
        )
        is ApkLoad.Ready -> ApkInfoPanel(info = current.info, modifier = modifier)
    }
}

/**
 * What the package says about itself: name, version, size, and any warnings. This is an inspection of metadata, not a
 * malware scan, and the panel says so.
 */
@Composable
internal fun ApkInfoPanel(info: ApkInfo, modifier: Modifier = Modifier) {
    val colors = AeroTheme.colors
    var technical by rememberSaveable(info.uri) { mutableStateOf(false) }
    Column(modifier = modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            val icon = info.icon
            if (icon != null) {
                Image(
                    bitmap = icon,
                    contentDescription = null,
                    modifier = Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)),
                )
            } else {
                AeroCategoryIcon(category = FileCategory.APK)
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                AeroText(text = info.appName ?: info.fileName, style = AeroTheme.typography.bodyStrong, maxLines = 2)
                val packageName = info.packageName
                if (packageName != null) {
                    AeroText(text = packageName, style = AeroTheme.typography.caption, color = colors.textSecondary, maxLines = 1)
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        val version = versionText(info)
        if (version.isNotEmpty()) Fact(label = stringResource(R.string.apkui_version), value = version)
        Fact(label = stringResource(R.string.apkui_size), value = Formatters.bytes(info.sizeBytes))
        val installed = info.installedVersionName
        if (installed != null) Fact(label = stringResource(R.string.apkui_installed), value = installed)
        if (info.isBundle) {
            AeroText(
                text = pluralStringResource(R.plurals.apkui_bundle, info.splitCount + 1, info.splitCount + 1),
                style = AeroTheme.typography.caption,
                color = colors.textSecondary,
            )
        }
        for (warning in info.warnings) {
            Spacer(Modifier.height(8.dp))
            val tint = if (warning == ApkWarning.INVALID || warning == ApkWarning.SIGNER_MISMATCH) colors.danger else colors.warning
            Row(verticalAlignment = Alignment.Top) {
                AeroIcon(icon = Icons.Rounded.Warning, contentDescription = null, tint = tint, size = 20.dp)
                Spacer(Modifier.width(8.dp))
                AeroText(text = stringResource(warning.textRes()), style = AeroTheme.typography.caption, color = tint)
            }
        }
        Spacer(Modifier.height(4.dp))
        AeroButton(
            text = stringResource(if (technical) R.string.apkui_hide_technical else R.string.apkui_show_technical),
            onClick = { technical = !technical },
            style = AeroButtonStyle.Ghost,
        )
        if (technical) {
            val hash = info.sha256
            if (hash != null) TechnicalValue(label = stringResource(R.string.apkui_sha256), value = hash)
            for (signer in info.signerSha256) {
                TechnicalValue(label = stringResource(R.string.apkui_signer), value = signer)
            }
        }
        Spacer(Modifier.height(4.dp))
        AeroText(
            text = stringResource(R.string.apkui_scan_note),
            style = AeroTheme.typography.caption,
            color = colors.textSecondary,
        )
    }
}

private fun versionText(info: ApkInfo): String {
    val name = info.versionName
    val code = info.versionCode
    return when {
        name != null && code != null -> "$name ($code)"
        name != null -> name
        code != null -> code.toString()
        else -> ""
    }
}

@Composable
private fun Fact(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        AeroText(
            text = label,
            modifier = Modifier.weight(0.4f),
            style = AeroTheme.typography.caption,
            color = AeroTheme.colors.textSecondary,
        )
        AeroText(text = value, modifier = Modifier.weight(0.6f), style = AeroTheme.typography.caption)
    }
}

@Composable
private fun TechnicalValue(label: String, value: String) {
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        AeroText(text = label, style = AeroTheme.typography.caption, color = AeroTheme.colors.textSecondary)
        AeroText(text = value, style = AeroTheme.typography.mono)
    }
}

@StringRes
private fun ApkWarning.textRes(): Int = when (this) {
    ApkWarning.SIGNER_MISMATCH -> R.string.apkui_warning_signer_mismatch
    ApkWarning.DOWNGRADE -> R.string.apkui_warning_downgrade
    ApkWarning.MIN_SDK_TOO_HIGH -> R.string.apkui_warning_min_sdk
    ApkWarning.INVALID -> R.string.apkui_warning_invalid
    ApkWarning.INCOMPLETE_SPLITS -> R.string.apkui_warning_incomplete_splits
}
