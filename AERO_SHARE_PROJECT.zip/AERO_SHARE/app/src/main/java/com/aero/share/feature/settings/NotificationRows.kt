package com.aero.share.feature.settings

import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.aero.share.R
import com.aero.share.core.common.SystemIntents
import com.aero.share.core.designsystem.AeroDialog
import com.aero.share.core.designsystem.AeroDivider
import com.aero.share.core.designsystem.AeroSettingsRow
import com.aero.share.core.designsystem.AeroSwitchRow
import com.aero.share.core.designsystem.AeroTheme
import com.aero.share.core.designsystem.LocalAeroToast
import com.aero.share.core.permissions.Permissions
import com.aero.share.domain.AppSettings

/**
 * The notification rows. Turning notifications on asks for the system permission first (Android 13 and later), after
 * explaining why; if it is refused the setting stays off, so the switch never promises something the system blocks.
 */
@Composable
internal fun NotificationRows(settings: AppSettings, viewModel: SettingsViewModel) {
    val context = LocalContext.current
    val toast = LocalAeroToast.current
    var explain by rememberSaveable { mutableStateOf(false) }
    var denied by rememberSaveable { mutableStateOf(false) }
    var allowed by remember { mutableStateOf(NotificationManagerCompat.from(context).areNotificationsEnabled()) }
    val openFailed = stringResource(R.string.set_open_failed)
    val detailsEnabled = SettingsLogic.notificationDetailsEnabled(settings.notificationsEnabled)

    // The person may switch notifications on or off in the system settings and come back.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        allowed = NotificationManagerCompat.from(context).areNotificationsEnabled()
    }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        val granted = grants.isNotEmpty() && grants.values.all { ok -> ok }
        denied = !granted
        if (granted) {
            allowed = NotificationManagerCompat.from(context).areNotificationsEnabled()
            viewModel.update { current -> current.copy(notificationsEnabled = true) }
        }
    }

    AeroSwitchRow(
        title = stringResource(R.string.set_notifications_title),
        subtitle = stringResource(R.string.set_notifications_text),
        checked = settings.notificationsEnabled,
        onCheckedChange = { on ->
            val permissionMissing = SettingsLogic.needsNotificationPermission(
                Build.VERSION.SDK_INT,
                Permissions.allGranted(context, Permissions.notifications()),
            )
            if (on && permissionMissing) {
                explain = true
            } else {
                denied = false
                viewModel.update { current -> current.copy(notificationsEnabled = on) }
            }
        },
    )
    AeroDivider()
    AeroSwitchRow(
        title = stringResource(R.string.set_notify_requests_title),
        subtitle = stringResource(R.string.set_notify_requests_text),
        checked = settings.notifyIncomingRequests,
        enabled = detailsEnabled,
        onCheckedChange = { on -> viewModel.update { current -> current.copy(notifyIncomingRequests = on) } },
    )
    AeroDivider()
    AeroSwitchRow(
        title = stringResource(R.string.set_notify_results_title),
        subtitle = stringResource(R.string.set_notify_results_text),
        checked = settings.notifyTransferResults,
        enabled = detailsEnabled,
        onCheckedChange = { on -> viewModel.update { current -> current.copy(notifyTransferResults = on) } },
    )
    AeroDivider()
    AeroSettingsRow(
        title = stringResource(R.string.set_notify_system_title),
        subtitle = stringResource(R.string.set_notify_system_text),
        icon = Icons.Rounded.Notifications,
        onClick = {
            if (!SystemIntents.openNotificationSettings(context)) toast.show(openFailed)
        },
    )
    if (settings.notificationsEnabled && !allowed) {
        SettingsNote(text = stringResource(R.string.set_notifications_blocked), color = AeroTheme.colors.warning)
    }
    if (denied) {
        SettingsNote(text = stringResource(R.string.perm_denied_hint), color = AeroTheme.colors.warning)
    }

    if (explain) {
        AeroDialog(
            title = stringResource(R.string.perm_notifications_title),
            message = stringResource(R.string.perm_notifications_message),
            confirmText = stringResource(R.string.common_allow),
            dismissText = stringResource(R.string.common_not_now),
            onConfirm = {
                explain = false
                val permissions = Permissions.notifications()
                if (permissions.isNotEmpty()) launcher.launch(permissions)
            },
            onDismiss = { explain = false },
        )
    }
}
