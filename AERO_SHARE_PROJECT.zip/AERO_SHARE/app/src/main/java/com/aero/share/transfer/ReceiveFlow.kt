package com.aero.share.transfer

import android.os.SystemClock
import com.aero.share.core.common.DiagnosticsLog
import com.aero.share.domain.DeviceRepository
import com.aero.share.domain.HistoryRepository
import com.aero.share.domain.PendingIncoming
import com.aero.share.domain.PowerPolicy
import com.aero.share.domain.SettingsRepository
import com.aero.share.transfer.engine.DeclineReason
import com.aero.share.transfer.engine.IncomingListener
import com.aero.share.transfer.engine.IncomingOffer
import com.aero.share.transfer.engine.OfferDecision
import com.aero.share.transfer.engine.ReceiveSession
import com.aero.share.transfer.engine.TransferResult
import com.aero.share.transfer.model.PeerInfo
import com.aero.share.transfer.model.PeerTrust
import com.aero.share.transfer.model.TransferFailure
import com.aero.share.transfer.model.TransferSnapshot
import com.aero.share.transfer.model.TransferState
import com.aero.share.transfer.model.TransferTracker
import com.aero.share.transfer.model.TransportKind
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap

/**
 * Receiving side of the coordinator: decides what happens with an incoming offer (automatic acceptance only for trusted
 * devices when the user allowed it, otherwise the user decides), follows every accepted session and offers the controls
 * pause/resume/cancel. Text that came from the other device is cleaned before it is shown.
 */
internal class ReceiveFlow(
    private val scope: CoroutineScope,
    private val settings: SettingsRepository,
    private val power: PowerPolicy,
    private val devices: DeviceRepository,
    private val history: HistoryRepository,
    private val notifier: TransferNotifier,
    private val hotspot: HotspotState,
    private val diagnostics: DiagnosticsLog,
    private val onSessionStarted: (String) -> Unit,
) : IncomingListener {

    private class OfferContext(val peer: PeerInfo, val remoteAddress: String, val transport: TransportKind)

    private val awaiting = ConcurrentHashMap<String, CompletableDeferred<Boolean>>()
    private val offerContexts = ConcurrentHashMap<String, OfferContext>()
    private val sessions = ConcurrentHashMap<String, ReceiveSession>()
    private val pendingState = MutableStateFlow<List<PendingIncoming>>(emptyList())
    private val snapshotState = MutableStateFlow<Map<String, TransferSnapshot>>(emptyMap())

    val pending: StateFlow<List<PendingIncoming>> get() = pendingState
    val snapshots: StateFlow<Map<String, TransferSnapshot>> get() = snapshotState

    // ---------------------------------------------------------------- engine callbacks

    override suspend fun onOffer(offer: IncomingOffer): OfferDecision {
        val id = offer.transferId
        val transport = TransportInference.infer(offer.remoteAddress, LocalAddresses.enumerate(), hotspot.subnets)
        offerContexts[id] = OfferContext(offer.peer, offer.remoteAddress, transport)

        if (offer.trust == PeerTrust.TRUSTED && settings.settings.value.autoAcceptTrusted) {
            diagnostics.add("transfer", "incoming accepted automatically (trusted device)")
            return OfferDecision.Accept
        }

        val pending = describe(offer, transport)
        val answer = CompletableDeferred<Boolean>()
        awaiting[id] = answer
        pendingState.update { list -> list.filterNot { it.transferId == id } + pending }
        notifier.incoming(pending)
        try {
            return if (answer.await()) {
                OfferDecision.Accept
            } else {
                recordDeclined(pending, offer.peer.deviceId, TransferFailure.DECLINED)
                OfferDecision.Decline(DeclineReason.USER)
            }
        } catch (e: CancellationException) {
            // The engine cancels this call when the answer time is up (or the server stops).
            val expired = e is TimeoutCancellationException ||
                SystemClock.elapsedRealtime() + CLOCK_SLACK_MS >= pending.expiresAtElapsed
            if (expired) recordDeclined(pending, offer.peer.deviceId, TransferFailure.TIMEOUT)
            throw e
        } finally {
            awaiting.remove(id, answer)
            pendingState.update { list -> list.filterNot { it.transferId == id } }
            notifier.cancelIncoming(id)
        }
    }

    override fun onSession(session: ReceiveSession) {
        val id = session.transferId
        val context = offerContexts.remove(id)
        val transport = context?.transport
        if (transport != null) session.tracker.update { it.copy(transport = transport) }
        sessions[id] = session
        onSessionStarted(id)
        publish(session, session.tracker.current)
        if (context != null) rememberPeer(context)
        scope.launch { follow(session) }
    }

    override fun onRejected(peer: PeerInfo?, remoteAddress: String, failure: TransferFailure) {
        diagnostics.add("transfer", "incoming connection refused: " + failure.name)
    }

    // ---------------------------------------------------------------- controls

    fun respond(transferId: String, accept: Boolean) {
        awaiting[transferId]?.complete(accept)
    }

    fun pause(id: String): Boolean {
        val session = sessions[id] ?: return false
        session.control.pause()
        return true
    }

    fun resume(id: String): Boolean {
        val session = sessions[id] ?: return false
        session.control.resume()
        return true
    }

    fun cancel(id: String): Boolean {
        val session = sessions[id] ?: return false
        session.control.cancel()
        return true
    }

    /** True when [id] belongs to a received transfer (whether or not it was removed). */
    fun dismiss(id: String): Boolean {
        val snapshot = snapshotState.value[id] ?: return false
        val finished = snapshot.state.isTerminal || snapshot.state == TransferState.INTERRUPTED
        if (finished) {
            snapshotState.update { it - id }
            sessions.remove(id)
        }
        return true
    }

    // ---------------------------------------------------------------- following a session

    private suspend fun follow(session: ReceiveSession) = coroutineScope {
        val collector = launch {
            session.tracker.state.collect { snapshot -> publish(session, snapshot) }
        }
        val result: TransferResult? = try {
            session.completion.await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            null
        }
        collector.cancelAndJoin()
        settle(session.tracker, result)
        publish(session, session.tracker.current)
    }

    /** Makes sure a session that ended without publishing a final state does not stay "active" forever. */
    private fun settle(tracker: TransferTracker, result: TransferResult?) {
        val now = System.currentTimeMillis()
        tracker.update { s ->
            if (s.state.isTerminal || s.state == TransferState.INTERRUPTED) {
                s
            } else {
                when (result) {
                    is TransferResult.Completed -> s.copy(
                        state = TransferState.COMPLETED,
                        finishedAt = s.finishedAt ?: now,
                        bytesPerSecond = 0L,
                        etaMillis = null,
                    )
                    is TransferResult.Failed -> s.copy(
                        state = if (result.resumable) TransferState.INTERRUPTED else TransferState.FAILED,
                        failure = result.failure,
                        failureDetail = result.detail,
                        resumable = result.resumable,
                        finishedAt = now,
                        bytesPerSecond = 0L,
                        etaMillis = null,
                    )
                    TransferResult.Cancelled -> s.copy(
                        state = TransferState.CANCELLED,
                        finishedAt = now,
                        bytesPerSecond = 0L,
                        etaMillis = null,
                    )
                    null -> s.copy(
                        state = TransferState.INTERRUPTED,
                        failure = TransferFailure.INTERRUPTED,
                        resumable = true,
                        finishedAt = now,
                        bytesPerSecond = 0L,
                        etaMillis = null,
                    )
                }
            }
        }
    }

    /** Only the newest session of a transfer id may update its entry: an older, superseded one must not overwrite it. */
    private fun publish(session: ReceiveSession, snapshot: TransferSnapshot) {
        val id = session.transferId
        if (sessions[id] !== session) return
        val cleaned = sanitize(snapshot)
        snapshotState.update { it + (id to cleaned) }
    }

    private fun sanitize(snapshot: TransferSnapshot): TransferSnapshot {
        val name = DisplayText.clean(snapshot.peerName)
        val title = snapshot.title?.let { DisplayText.clean(it, MAX_TITLE) }
        return if (name == snapshot.peerName && title == snapshot.title) snapshot else snapshot.copy(peerName = name, title = title)
    }

    // ---------------------------------------------------------------- helpers

    private fun describe(offer: IncomingOffer, transport: TransportKind): PendingIncoming {
        val name = DisplayText.clean(offer.peer.name).ifEmpty { offer.peer.deviceId.take(FALLBACK_NAME_CHARS) }
        val expiresAt = SystemClock.elapsedRealtime() + power.engineConfig().acceptTimeoutMs
        return PendingIncoming(
            transferId = offer.transferId,
            peerName = name,
            peerKind = offer.peer.kind,
            trust = offer.trust,
            authenticatedByQr = offer.authenticatedByQr,
            verificationCode = offer.verificationCode,
            transport = transport,
            title = offer.title?.let { DisplayText.clean(it, MAX_TITLE) },
            fileCount = offer.fileCount,
            totalBytes = offer.totalBytes,
            categories = offer.categories,
            destinationLabel = offer.destinationLabel,
            freeBytes = offer.freeBytes,
            isResume = offer.isResume,
            expiresAtElapsed = expiresAt,
        )
    }

    private fun recordDeclined(pending: PendingIncoming, peerId: String, failure: TransferFailure) {
        val item = HistoryMapper.declined(pending, failure, peerId, System.currentTimeMillis())
        scope.launch {
            try {
                history.add(item)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                diagnostics.add("history", "write failed: " + e.javaClass.simpleName)
            }
        }
    }

    private fun rememberPeer(context: OfferContext) {
        scope.launch {
            try {
                devices.upsertSeen(context.peer, context.remoteAddress, context.transport)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                diagnostics.add("devices", "could not remember a peer: " + e.javaClass.simpleName)
            }
        }
    }

    private companion object {
        const val MAX_TITLE = 120
        const val FALLBACK_NAME_CHARS = 6
        const val CLOCK_SLACK_MS = 1_000L
    }
}
