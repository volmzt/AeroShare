package com.aero.share.network.transport

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.wifi.WifiManager
import android.net.wifi.p2p.WifiP2pManager
import android.net.wifi.p2p.nsd.WifiP2pDnsSdServiceInfo
import android.net.wifi.p2p.nsd.WifiP2pDnsSdServiceRequest
import android.os.Looper
import android.os.SystemClock
import androidx.core.content.ContextCompat
import com.aero.share.BuildConfig
import com.aero.share.core.common.DiagnosticsLog
import com.aero.share.core.permissions.Permissions
import com.aero.share.domain.LocalDeviceProvider
import com.aero.share.domain.NearbyDevice
import com.aero.share.domain.SettingsRepository
import com.aero.share.domain.Visibility
import com.aero.share.network.discovery.Beacon
import com.aero.share.transfer.model.Capabilities
import com.aero.share.transfer.security.Fingerprints
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Wi-Fi Direct (Wi-Fi P2P): finds AERO SHARE devices through DNS-SD service discovery, publishes this device's service
 * while it is receiving, and forms a group for a transfer. Nothing runs unless it is asked for (receivers, the channel's
 * discovery and the published service exist only between a start and the matching stop).
 *
 * Honest limits: Wi-Fi Direct behaves differently on every manufacturer. Discovery can need several seconds and
 * sometimes fails until Wi-Fi is toggled; the receiving user must accept the system invitation prompt; some phones drop
 * the normal Wi-Fi network while a group exists. [available] is false without the hardware feature, and no method here
 * ever reports success that the framework did not confirm. LAN transfer stays the primary path.
 *
 * All state changes happen under one lock; the framework's callbacks arrive on the main thread and only take that lock
 * briefly.
 */
class WifiDirectManager(
    context: Context,
    private val scope: CoroutineScope,
    private val local: LocalDeviceProvider,
    private val settings: SettingsRepository,
    private val diagnostics: DiagnosticsLog,
) {
    private val app = context.applicationContext
    private val manager: WifiP2pManager? = app.getSystemService(Context.WIFI_P2P_SERVICE) as? WifiP2pManager
    private val wifi: WifiManager? = app.getSystemService(WifiManager::class.java)
    private val connector: P2pConnector? = manager?.let { P2pConnector(it, scope) { message -> log(message) } }
    private val lock = Any()
    private val table = P2pPeerTable { local.info.value.deviceId }
    private val peerState = MutableStateFlow<List<NearbyDevice>>(emptyList())
    private val activeState = MutableStateFlow(false)
    private val connectMutex = Mutex()

    /** False when the device has no Wi-Fi Direct feature. Never claimed otherwise. */
    val available: Boolean = manager != null && app.packageManager.hasSystemFeature(PackageManager.FEATURE_WIFI_DIRECT)

    /** AERO SHARE devices seen through Wi-Fi Direct: transport WIFI_DIRECT, p2pAddress set, quality UNKNOWN. */
    val peers: StateFlow<List<NearbyDevice>> = peerState.asStateFlow()

    /** True while discovery or the published service is confirmed by the framework. */
    val active: StateFlow<Boolean> = activeState.asStateFlow()

    private data class Advert(val port: Int, val name: String)

    // Wanted state, written by the public functions.
    private var discoveryWanted = false
    private var advertisePort: Int? = null
    private var connecting = 0

    // Applied state, written under the lock by apply() and the callbacks.
    private var channel: WifiP2pManager.Channel? = null
    private var receiverRegistered = false
    private var listenersSet = false
    private var discovering = false
    private var discoveryConfirmed = false
    private var serviceInfo: WifiP2pDnsSdServiceInfo? = null
    private var advertised: Advert? = null
    private var advertConfirmed = false
    private var expiryJob: Job? = null
    private var lastRefresh = 0L
    private var refreshGapMs = 0L

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION -> {
                    val state = intent.getIntExtra(WifiP2pManager.EXTRA_WIFI_STATE, WifiP2pManager.WIFI_P2P_STATE_DISABLED)
                    if (state == WifiP2pManager.WIFI_P2P_STATE_ENABLED) apply() else onP2pDisabled()
                }
                WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION -> onConnectionChanged()
                WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION -> onPeersChanged()
            }
        }
    }

    // ---- public API

    fun start() {
        synchronized(lock) { discoveryWanted = true }
        apply()
    }

    fun stop() {
        synchronized(lock) { discoveryWanted = false }
        apply()
    }

    /** Publishes the service (unless visibility is HIDDEN) with the receiver's TLS [port]. */
    fun startAdvertising(port: Int) {
        synchronized(lock) { advertisePort = port }
        apply()
    }

    fun stopAdvertising() {
        synchronized(lock) { advertisePort = null }
        apply()
    }

    /** Re-runs peer and service discovery, drops entries that went silent and re-publishes a changed name. */
    fun refresh() {
        val now = SystemClock.elapsedRealtime()
        val ready = synchronized(lock) {
            if (lastRefresh != 0L) refreshGapMs = now - lastRefresh
            lastRefresh = now
            if (table.expire(now, ttlLocked())) publishLocked()
            discovering && discoveryConfirmed
        }
        apply()
        if (ready) discoverNow()
    }

    /**
     * Forms a Wi-Fi Direct group with [peer] (which must have a p2pAddress) and returns it. Failures carry a
     * [P2pFailure]; there is a 30 s limit for the other phone's user to accept the invitation.
     */
    @SuppressLint("MissingPermission")
    suspend fun connect(peer: NearbyDevice): Result<P2pGroup> = connectMutex.withLock {
        val mac = peer.p2pAddress?.let { P2pPeerTable.normalizeMac(it) }
            ?: return@withLock failure(P2pFailure.PEER_ADDRESS_UNKNOWN, "the device has no Wi-Fi Direct address")
        val helper = connector
        if (!available || helper == null) return@withLock failure(P2pFailure.UNSUPPORTED, "Wi-Fi Direct is not available")
        if (!Permissions.allGranted(app, Permissions.nearby())) {
            return@withLock failure(P2pFailure.PERMISSION, "the nearby-devices permission is missing")
        }
        if (!wifiOn()) return@withLock failure(P2pFailure.RADIO_OFF, "Wi-Fi is off")
        synchronized(lock) { connecting += 1 }
        try {
            apply()
            val current = synchronized(lock) { channel }
                ?: return@withLock failure(P2pFailure.FAILED, "the Wi-Fi Direct channel is unavailable")
            helper.connect(current, peer, mac)
        } finally {
            synchronized(lock) { connecting -= 1 }
            apply()
        }
    }

    /** Leaves the group formed by [connect]. Fire and forget; use [disconnectAwait] to wait for it. */
    fun disconnect() {
        scope.launch { disconnectAwait() }
    }

    suspend fun disconnectAwait() {
        val helper = connector ?: return
        val current = synchronized(lock) { channel } ?: return
        helper.removeGroup(current)
    }

    // ---- reconciliation

    private fun apply() {
        synchronized(lock) { applyLocked() }
    }

    @SuppressLint("MissingPermission")
    private fun applyLocked() {
        val wantAny = discoveryWanted || advertisePort != null || connecting > 0
        if (!wantAny) {
            teardownLocked()
            return
        }
        val mgr = manager
        if (mgr == null || !available) return
        if (!Permissions.allGranted(app, Permissions.nearby())) return
        registerReceiverLocked()
        if (!wifiOn()) {
            resetAppliedLocked()
            return
        }
        val ch = ensureChannelLocked(mgr) ?: return
        applyDiscoveryLocked(mgr, ch)
        applyAdvertisingLocked(mgr, ch)
        updateActiveLocked()
    }

    private fun ensureChannelLocked(mgr: WifiP2pManager): WifiP2pManager.Channel? {
        channel?.let { return it }
        val created: WifiP2pManager.Channel? = try {
            mgr.initialize(app, Looper.getMainLooper(), WifiP2pManager.ChannelListener { onChannelLost() })
        } catch (e: RuntimeException) {
            null
        }
        channel = created
        listenersSet = false
        if (created == null) log("the Wi-Fi Direct channel could not be created")
        return created
    }

    private fun onChannelLost() {
        synchronized(lock) {
            channel = null
            resetAppliedLocked()
        }
        connector?.clearGroup()
        log("the Wi-Fi Direct channel was lost")
        scope.launch {
            delay(CHANNEL_RETRY_MS)
            apply()
        }
    }

    @SuppressLint("MissingPermission")
    private fun applyDiscoveryLocked(mgr: WifiP2pManager, ch: WifiP2pManager.Channel) {
        if (discoveryWanted && !discovering) {
            discovering = true
            discoveryConfirmed = false
            installListenersLocked(mgr, ch)
            try {
                mgr.clearServiceRequests(
                    ch,
                    action("clear service requests") { addServiceRequest(mgr, ch) },
                )
            } catch (e: RuntimeException) {
                failDiscovery("clear service requests threw " + e.javaClass.simpleName)
            }
            ensureExpiryLocked()
        } else if (!discoveryWanted && discovering) {
            stopDiscoveryLocked(mgr, ch)
        }
    }

    @SuppressLint("MissingPermission")
    private fun addServiceRequest(mgr: WifiP2pManager, ch: WifiP2pManager.Channel) {
        if (!synchronized(lock) { discovering }) return
        try {
            mgr.addServiceRequest(
                ch,
                WifiP2pDnsSdServiceRequest.newInstance(),
                action("add service request") { ok ->
                    synchronized(lock) {
                        if (ok) {
                            discoveryConfirmed = true
                        } else {
                            discovering = false
                            discoveryConfirmed = false
                        }
                        updateActiveLocked()
                    }
                    if (ok) discoverNow()
                },
            )
        } catch (e: RuntimeException) {
            failDiscovery("add service request threw " + e.javaClass.simpleName)
        }
    }

    private fun failDiscovery(message: String) {
        log(message)
        synchronized(lock) {
            discovering = false
            discoveryConfirmed = false
            updateActiveLocked()
        }
    }

    private fun installListenersLocked(mgr: WifiP2pManager, ch: WifiP2pManager.Channel) {
        if (listenersSet) return
        try {
            mgr.setDnsSdResponseListeners(
                ch,
                WifiP2pManager.DnsSdServiceResponseListener { _, _, _ -> },
                WifiP2pManager.DnsSdTxtRecordListener { fullDomainName, record, device ->
                    onTxtRecord(fullDomainName, record, device.deviceAddress)
                },
            )
            listenersSet = true
        } catch (e: RuntimeException) {
            log("service listeners could not be set (" + e.javaClass.simpleName + ")")
        }
    }

    @SuppressLint("MissingPermission")
    private fun stopDiscoveryLocked(mgr: WifiP2pManager, ch: WifiP2pManager.Channel) {
        discovering = false
        discoveryConfirmed = false
        try {
            mgr.clearServiceRequests(ch, action("clear service requests"))
            mgr.stopPeerDiscovery(ch, action("stop peer discovery"))
        } catch (e: RuntimeException) {
            log("stopping discovery threw " + e.javaClass.simpleName)
        }
        if (table.clear()) publishLocked()
        expiryJob?.cancel()
        expiryJob = null
        updateActiveLocked()
    }

    @SuppressLint("MissingPermission")
    private fun applyAdvertisingLocked(mgr: WifiP2pManager, ch: WifiP2pManager.Channel) {
        val port = advertisePort
        val visible = settings.settings.value.visibility == Visibility.VISIBLE
        val desired = if (port != null && visible) Advert(port, local.info.value.name) else null
        if (desired == advertised) return
        val previous = serviceInfo
        if (previous != null) {
            // The new service is added when apply() runs again after the old one is gone.
            serviceInfo = null
            advertised = null
            advertConfirmed = false
            try {
                mgr.removeLocalService(ch, previous, action("remove local service") { apply() })
            } catch (e: RuntimeException) {
                log("removing the service threw " + e.javaClass.simpleName)
            }
            return
        }
        if (desired == null) return
        val info = localServiceInfo(desired.port) ?: return
        serviceInfo = info
        advertised = desired
        try {
            mgr.addLocalService(
                ch,
                info,
                action("add local service") { ok ->
                    synchronized(lock) {
                        if (serviceInfo === info) {
                            if (ok) {
                                advertConfirmed = true
                            } else {
                                serviceInfo = null
                                advertised = null
                            }
                        }
                        updateActiveLocked()
                    }
                },
            )
        } catch (e: RuntimeException) {
            log("publishing the service threw " + e.javaClass.simpleName)
            serviceInfo = null
            advertised = null
        }
    }

    @SuppressLint("MissingPermission")
    private fun teardownLocked() {
        val mgr = manager
        val ch = channel
        if (mgr != null && ch != null) {
            try {
                if (discovering) {
                    mgr.clearServiceRequests(ch, action("clear service requests"))
                    mgr.stopPeerDiscovery(ch, action("stop peer discovery"))
                }
                serviceInfo?.let { mgr.removeLocalService(ch, it, action("remove local service")) }
            } catch (e: RuntimeException) {
                log("teardown threw " + e.javaClass.simpleName)
            }
        }
        resetAppliedLocked()
        unregisterReceiverLocked()
    }

    private fun resetAppliedLocked() {
        discovering = false
        discoveryConfirmed = false
        serviceInfo = null
        advertised = null
        advertConfirmed = false
        listenersSet = false
        if (table.clear()) publishLocked()
        expiryJob?.cancel()
        expiryJob = null
        updateActiveLocked()
    }

    private fun updateActiveLocked() {
        activeState.value = discoveryConfirmed || advertConfirmed
    }

    // ---- discovery results

    @SuppressLint("MissingPermission")
    private fun discoverNow() {
        val mgr = manager ?: return
        val ch = synchronized(lock) { if (discovering) channel else null } ?: return
        try {
            mgr.discoverPeers(ch, action("discover peers") { discoverServicesNow(mgr, ch) })
        } catch (e: RuntimeException) {
            log("discovering peers threw " + e.javaClass.simpleName)
        }
    }

    @SuppressLint("MissingPermission")
    private fun discoverServicesNow(mgr: WifiP2pManager, ch: WifiP2pManager.Channel) {
        if (!synchronized(lock) { discovering }) return
        try {
            mgr.discoverServices(ch, action("discover services"))
        } catch (e: RuntimeException) {
            log("discovering services threw " + e.javaClass.simpleName)
        }
    }

    private fun onTxtRecord(fullDomainName: String, record: Map<String, String>, mac: String?) {
        if (mac == null || !P2pServiceRecord.isAeroService(fullDomainName)) return
        val presence = P2pServiceRecord.parse(record) ?: return
        synchronized(lock) {
            if (discovering && table.onService(mac, presence, SystemClock.elapsedRealtime())) publishLocked()
        }
    }

    private fun publishLocked() {
        peerState.value = table.snapshot()
    }

    /** Entries live two refresh periods plus slack, so slow power modes do not make devices flicker. */
    private fun ttlLocked(): Long = (maxOf(MIN_TTL_MS, 2 * refreshGapMs + EXTRA_TTL_MS)).coerceAtMost(MAX_TTL_MS)

    private fun ensureExpiryLocked() {
        if (expiryJob?.isActive == true) return
        expiryJob = scope.launch(Dispatchers.Default) {
            while (isActive) {
                delay(EXPIRY_TICK_MS)
                synchronized(lock) {
                    if (table.expire(SystemClock.elapsedRealtime(), ttlLocked())) publishLocked()
                }
            }
        }
    }

    // ---- group events

    private fun onP2pDisabled() {
        synchronized(lock) { resetAppliedLocked() }
        connector?.clearGroup()
    }

    @SuppressLint("MissingPermission")
    private fun onConnectionChanged() {
        val mgr = manager ?: return
        val helper = connector ?: return
        val ch = synchronized(lock) { channel } ?: return
        try {
            mgr.requestConnectionInfo(ch, WifiP2pManager.ConnectionInfoListener { info -> helper.onConnectionInfo(info, helloTarget()) })
        } catch (e: RuntimeException) {
            log("reading the connection info threw " + e.javaClass.simpleName)
        }
    }

    @SuppressLint("MissingPermission")
    private fun onPeersChanged() {
        val mgr = manager ?: return
        val helper = connector ?: return
        if (!helper.hasPending()) return
        val ch = synchronized(lock) { channel } ?: return
        try {
            mgr.requestPeers(ch, WifiP2pManager.PeerListListener { list -> helper.onPeers(list.deviceList) })
        } catch (e: RuntimeException) {
            log("reading the peer list threw " + e.javaClass.simpleName)
        }
    }

    /** What to tell a group owner after another phone connected to us; null unless this device is visibly receiving. */
    private fun helloTarget(): HelloTarget? {
        val port = synchronized(lock) { advertisePort } ?: return null
        if (settings.settings.value.visibility != Visibility.VISIBLE) return null
        val fingerprint = local.info.value.fingerprint
        if (!Fingerprints.isValid(fingerprint)) return null
        return HelloTarget(port, fingerprint)
    }

    // ---- helpers

    private fun registerReceiverLocked() {
        if (receiverRegistered) return
        val filter = IntentFilter()
        filter.addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION)
        filter.addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION)
        filter.addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION)
        ContextCompat.registerReceiver(app, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        receiverRegistered = true
    }

    private fun unregisterReceiverLocked() {
        if (!receiverRegistered) return
        receiverRegistered = false
        try {
            app.unregisterReceiver(receiver)
        } catch (e: IllegalArgumentException) {
            // already unregistered
        }
    }

    private fun localServiceInfo(port: Int): WifiP2pDnsSdServiceInfo? {
        val me = local.info.value
        if (!Fingerprints.isValid(me.fingerprint)) return null
        val presence = Beacon.Presence(
            goodbye = false,
            fingerprint = me.fingerprint,
            name = me.name,
            kind = me.kind,
            port = port,
            appVersion = BuildConfig.VERSION_NAME,
            capabilities = Capabilities.ALL,
        )
        return WifiP2pDnsSdServiceInfo.newInstance(
            P2pServiceRecord.instanceName(me.deviceId),
            P2pServiceRecord.SERVICE_TYPE,
            P2pServiceRecord.attributes(presence),
        )
    }

    private fun wifiOn(): Boolean = try {
        wifi?.isWifiEnabled == true
    } catch (e: SecurityException) {
        false
    }

    private fun action(what: String, onDone: (Boolean) -> Unit = {}): WifiP2pManager.ActionListener =
        object : WifiP2pManager.ActionListener {
            override fun onSuccess() {
                onDone(true)
            }

            override fun onFailure(reason: Int) {
                log(what + " failed (" + P2pReasons.name(reason) + ")")
                onDone(false)
            }
        }

    private fun failure(reason: P2pFailure, message: String): Result<P2pGroup> =
        Result.failure(P2pException(reason, message))

    private fun log(message: String) {
        diagnostics.add("wifi-direct", message)
    }

    private companion object {
        const val MIN_TTL_MS = 90_000L
        const val EXTRA_TTL_MS = 30_000L
        const val MAX_TTL_MS = 600_000L
        const val EXPIRY_TICK_MS = 10_000L
        const val CHANNEL_RETRY_MS = 2_000L
    }
}
