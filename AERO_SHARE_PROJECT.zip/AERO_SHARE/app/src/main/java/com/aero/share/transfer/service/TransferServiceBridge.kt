package com.aero.share.transfer.service

import com.aero.share.transfer.model.TransferDirection
import com.aero.share.transfer.model.TransferState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.lang.ref.WeakReference
import java.util.concurrent.atomic.AtomicReference

/** What a notification button asks for. */
enum class ServiceAction { PAUSE, RESUME, CANCEL, ACCEPT, DECLINE, STOP_RECEIVING }

/** The part of a transfer the foreground notification needs. Deliberately has no peer name or file name. */
data class ServiceTransfer(
    val id: String,
    val direction: TransferDirection,
    val state: TransferState,
    val transferredBytes: Long,
    val totalBytes: Long,
    val bytesPerSecond: Long,
)

/** Everything the foreground service needs to know; the coordinator publishes a new value whenever it changes. */
data class ServiceState(
    val active: List<ServiceTransfer> = emptyList(),
    val waiting: Int = 0,
    val receiving: Boolean = false,
    val lowLatencyWifi: Boolean = false,
) {
    /** Nothing to show and nothing to keep alive: the service stops itself. */
    val idle: Boolean get() = active.isEmpty() && waiting == 0 && !receiving

    /** The CPU and Wi-Fi locks are held only while a transfer really runs. */
    val holdsLocks: Boolean get() = active.isNotEmpty()

    /** Changes when the layout of the notification changes, not when only a progress number does. */
    fun layoutKey(): String {
        val builder = StringBuilder()
        for (transfer in active) {
            builder.append(transfer.id).append(':').append(transfer.state.name).append(',')
        }
        return builder.append('|').append(waiting).append('|').append(receiving).toString()
    }
}

/**
 * Link between the Android service and the coordinator. The coordinator publishes [state] and registers itself as the
 * [Host]; the service renders the state and forwards notification buttons back. Only a weak reference to the host is kept,
 * and nothing here holds an Android Context.
 */
object TransferServiceBridge {
    interface Host {
        fun onServiceAction(action: ServiceAction, transferId: String?)

        /** The system ran out of foreground time (Android 15 limits data-sync services): end everything cleanly. */
        fun onServiceTimeout()

        /** The service went away; a new one must be started if work is still going on. */
        fun onServiceStopped()
    }

    private val hostRef = AtomicReference<WeakReference<Host>?>(null)
    private val mutableState = MutableStateFlow(ServiceState())

    val state: StateFlow<ServiceState> get() = mutableState.asStateFlow()

    fun attach(host: Host) {
        hostRef.set(WeakReference(host))
    }

    fun update(state: ServiceState) {
        mutableState.value = state
    }

    internal fun dispatch(action: ServiceAction, transferId: String?) {
        host()?.onServiceAction(action, transferId)
    }

    internal fun timeout() {
        host()?.onServiceTimeout()
    }

    internal fun serviceStopped() {
        host()?.onServiceStopped()
    }

    private fun host(): Host? = hostRef.get()?.get()
}
