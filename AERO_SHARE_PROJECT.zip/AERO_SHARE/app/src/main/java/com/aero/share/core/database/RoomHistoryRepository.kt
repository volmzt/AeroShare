package com.aero.share.core.database

import com.aero.share.domain.HistoryItem
import com.aero.share.domain.HistoryRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/** Transfer history in Room. Clearing history never deletes received files. */
class RoomHistoryRepository(db: AeroDatabase) : HistoryRepository {
    private val dao = db.history()

    override val items: Flow<List<HistoryItem>> = dao.observeAll().map { list -> list.map { it.toItem() } }

    override suspend fun add(item: HistoryItem) = dao.upsert(HistoryEntity.from(item))

    override suspend fun find(id: String): HistoryItem? = dao.find(id)?.toItem()

    override suspend fun delete(id: String) = dao.delete(id)

    override suspend fun clear() = dao.clear()

    override suspend fun deleteOlderThan(timestamp: Long) = dao.deleteOlderThan(timestamp)
}
