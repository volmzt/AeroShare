package com.aero.share.core.common

import androidx.annotation.StringRes
import com.aero.share.R
import com.aero.share.domain.HistoryStatus
import com.aero.share.domain.LinkQuality
import com.aero.share.transfer.model.DeviceKind
import com.aero.share.transfer.model.FileCategory
import com.aero.share.transfer.model.PeerTrust
import com.aero.share.transfer.model.TransferFailure
import com.aero.share.transfer.model.TransferState
import com.aero.share.transfer.model.TransportKind

/*
 * One place that turns the enums of the domain layer into string resources. Every `when` is exhaustive without an `else`
 * branch, so adding a value to an enum is a compile error here until its text exists in all three languages.
 */

/** Short sentence saying what went wrong. */
@StringRes
fun TransferFailure.messageRes(): Int = when (this) {
    TransferFailure.DECLINED -> R.string.err_failure_declined
    TransferFailure.BUSY -> R.string.err_failure_busy
    TransferFailure.BLOCKED -> R.string.err_failure_blocked
    TransferFailure.UNREACHABLE -> R.string.err_failure_unreachable
    TransferFailure.TIMEOUT -> R.string.err_failure_timeout
    TransferFailure.NETWORK_BLOCKED -> R.string.err_failure_network_blocked
    TransferFailure.AUTH_FAILED -> R.string.err_failure_auth_failed
    TransferFailure.UNSUPPORTED_VERSION -> R.string.err_failure_unsupported_version
    TransferFailure.INTEGRITY -> R.string.err_failure_integrity
    TransferFailure.NO_SPACE -> R.string.err_failure_no_space
    TransferFailure.STORAGE -> R.string.err_failure_storage
    TransferFailure.SOURCE_CHANGED -> R.string.err_failure_source_changed
    TransferFailure.SOURCE_UNREADABLE -> R.string.err_failure_source_unreadable
    TransferFailure.PROTOCOL -> R.string.err_failure_protocol
    TransferFailure.PEER_CANCELLED -> R.string.err_failure_peer_cancelled
    TransferFailure.INTERRUPTED -> R.string.err_failure_interrupted
    TransferFailure.PERMISSION -> R.string.err_failure_permission
    TransferFailure.INTERNAL -> R.string.err_failure_internal
}

/** What the person can try next. */
@StringRes
fun TransferFailure.hintRes(): Int = when (this) {
    TransferFailure.DECLINED -> R.string.err_hint_declined
    TransferFailure.BUSY -> R.string.err_hint_busy
    TransferFailure.BLOCKED -> R.string.err_hint_blocked
    TransferFailure.UNREACHABLE -> R.string.err_hint_unreachable
    TransferFailure.TIMEOUT -> R.string.err_hint_timeout
    TransferFailure.NETWORK_BLOCKED -> R.string.err_hint_network_blocked
    TransferFailure.AUTH_FAILED -> R.string.err_hint_auth_failed
    TransferFailure.UNSUPPORTED_VERSION -> R.string.err_hint_unsupported_version
    TransferFailure.INTEGRITY -> R.string.err_hint_integrity
    TransferFailure.NO_SPACE -> R.string.err_hint_no_space
    TransferFailure.STORAGE -> R.string.err_hint_storage
    TransferFailure.SOURCE_CHANGED -> R.string.err_hint_source_changed
    TransferFailure.SOURCE_UNREADABLE -> R.string.err_hint_source_unreadable
    TransferFailure.PROTOCOL -> R.string.err_hint_protocol
    TransferFailure.PEER_CANCELLED -> R.string.err_hint_peer_cancelled
    TransferFailure.INTERRUPTED -> R.string.err_hint_interrupted
    TransferFailure.PERMISSION -> R.string.err_hint_permission
    TransferFailure.INTERNAL -> R.string.err_hint_internal
}

@StringRes
fun TransferState.labelRes(): Int = when (this) {
    TransferState.WAITING -> R.string.state_waiting
    TransferState.PREPARING -> R.string.state_preparing
    TransferState.CONNECTING -> R.string.state_connecting
    TransferState.AWAITING_ACCEPTANCE -> R.string.state_awaiting
    TransferState.TRANSFERRING -> R.string.state_transferring
    TransferState.PAUSED -> R.string.state_paused
    TransferState.INTERRUPTED -> R.string.state_interrupted
    TransferState.VERIFYING -> R.string.state_verifying
    TransferState.COMPLETED -> R.string.state_completed
    TransferState.FAILED -> R.string.state_failed
    TransferState.CANCELLED -> R.string.state_cancelled
}

@StringRes
fun TransportKind.labelRes(): Int = when (this) {
    TransportKind.LAN -> R.string.transport_lan
    TransportKind.WIFI_DIRECT -> R.string.transport_wifi_direct
    TransportKind.HOTSPOT -> R.string.transport_hotspot
    TransportKind.MANUAL -> R.string.transport_manual
}

@StringRes
fun FileCategory.labelRes(): Int = when (this) {
    FileCategory.IMAGE -> R.string.category_image
    FileCategory.VIDEO -> R.string.category_video
    FileCategory.AUDIO -> R.string.category_audio
    FileCategory.DOCUMENT -> R.string.category_document
    FileCategory.ARCHIVE -> R.string.category_archive
    FileCategory.APK -> R.string.category_apk
    FileCategory.OTHER -> R.string.category_other
}

/** UNKNOWN is deliberately neutral ("Available"): the app never invents a signal strength it has not measured. */
@StringRes
fun LinkQuality.labelRes(): Int = when (this) {
    LinkQuality.UNKNOWN -> R.string.quality_unknown
    LinkQuality.WEAK -> R.string.quality_weak
    LinkQuality.FAIR -> R.string.quality_fair
    LinkQuality.STRONG -> R.string.quality_strong
}

@StringRes
fun DeviceKind.labelRes(): Int = when (this) {
    DeviceKind.PHONE -> R.string.common_kind_phone
    DeviceKind.TABLET -> R.string.common_kind_tablet
    DeviceKind.COMPUTER -> R.string.common_kind_computer
    DeviceKind.OTHER -> R.string.common_kind_other
}

@StringRes
fun PeerTrust.labelRes(): Int = when (this) {
    PeerTrust.TRUSTED -> R.string.common_trust_trusted
    PeerTrust.KNOWN -> R.string.common_trust_known
    PeerTrust.UNKNOWN -> R.string.common_trust_unknown
    PeerTrust.BLOCKED -> R.string.common_trust_blocked
}

/** History rows only know the three final outcomes; they reuse the transfer state wording. */
@StringRes
fun HistoryStatus.labelRes(): Int = when (this) {
    HistoryStatus.COMPLETED -> R.string.state_completed
    HistoryStatus.FAILED -> R.string.state_failed
    HistoryStatus.CANCELLED -> R.string.state_cancelled
}
