package com.aero.share.feature.transfer

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Share
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.aero.share.R
import com.aero.share.core.common.Formatters
import com.aero.share.core.designsystem.AeroButton
import com.aero.share.core.designsystem.AeroButtonStyle
import com.aero.share.core.designsystem.AeroCard
import com.aero.share.core.designsystem.AeroCategoryIcon
import com.aero.share.core.designsystem.AeroDivider
import com.aero.share.core.designsystem.AeroText
import com.aero.share.core.designsystem.AeroTheme
import com.aero.share.core.designsystem.LocalAeroToast
import com.aero.share.core.designsystem.aeroRowClickable
import com.aero.share.core.storage.apk.InstallEvent
import com.aero.share.di.LocalAppContainer
import com.aero.share.feature.send.ApkInspection
import com.aero.share.transfer.model.FileCategory
import com.aero.share.transfer.model.SavedFile

private const val LISTED_FILES = 6

/**
 * What can be done with files that just arrived: open one, open the folder, share, and install a received app through the
 * system installer. Nothing is opened or installed by itself.
 */
@Composable
internal fun ReceivedFilesCard(files: List<SavedFile>) {
    val container = LocalAppContainer.current
    val toast = LocalAeroToast.current
    val openFailed = stringResource(R.string.xfer_open_failed)
    val shareFailed = stringResource(R.string.xfer_share_failed)
    val folderFailed = stringResource(R.string.xfer_folder_failed)
    AeroCard {
        AeroText(
            text = pluralStringResource(R.plurals.xfer_saved_title, files.size, files.size),
            style = AeroTheme.typography.bodyStrong,
        )
        Spacer(Modifier.height(6.dp))
        val shown = files.take(LISTED_FILES)
        shown.forEachIndexed { index, file ->
            if (index > 0) AeroDivider()
            SavedFileRow(file = file, onOpen = {
                if (!container.fileOpener.open(file.uri, file.mimeType)) toast.show(openFailed)
            })
        }
        if (files.size > shown.size) {
            AeroText(
                text = pluralStringResource(R.plurals.xfer_saved_more, files.size - shown.size, files.size - shown.size),
                style = AeroTheme.typography.caption,
                color = AeroTheme.colors.textSecondary,
                modifier = Modifier.padding(top = 8.dp),
            )
        }
        Spacer(Modifier.height(12.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            AeroButton(
                text = stringResource(R.string.xfer_open_folder),
                onClick = { if (!container.fileOpener.openReceiveFolder()) toast.show(folderFailed) },
                modifier = Modifier.weight(1f),
                style = AeroButtonStyle.Secondary,
                icon = Icons.Rounded.Folder,
            )
            if (files.size <= TransferLogic.MAX_SHARE_FILES) {
                AeroButton(
                    text = stringResource(R.string.xfer_share),
                    onClick = {
                        val shared = container.fileOpener.share(files.map { it.uri }, files.map { it.mimeType })
                        if (!shared) toast.show(shareFailed)
                    },
                    modifier = Modifier.weight(1f),
                    style = AeroButtonStyle.Secondary,
                    icon = Icons.Rounded.Share,
                )
            }
        }
    }
}

@Composable
private fun SavedFileRow(file: SavedFile, onOpen: () -> Unit) {
    val colors = AeroTheme.colors
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 48.dp)
            .aeroRowClickable(role = Role.Button, onClick = onOpen),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AeroCategoryIcon(category = file.category)
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f).padding(vertical = 6.dp)) {
            AeroText(text = file.displayName, maxLines = 1)
            AeroText(text = Formatters.bytes(file.size), style = AeroTheme.typography.caption, color = colors.textSecondary)
        }
    }
}

/** A received package: what it says about itself, and the way into the system installer. */
@Composable
internal fun ReceivedAppCard(
    file: SavedFile,
    canInstall: Boolean,
    onInstall: (String) -> Unit,
    onInstallSettings: () -> Unit,
) {
    AeroCard {
        ApkInspection(uri = file.uri)
        Spacer(Modifier.height(12.dp))
        if (canInstall) {
            AeroButton(
                text = stringResource(R.string.xfer_install_action),
                onClick = { onInstall(file.uri) },
                modifier = Modifier.fillMaxWidth(),
                icon = Icons.Rounded.Download,
            )
        } else {
            AeroText(text = stringResource(R.string.xfer_install_permission_text), color = AeroTheme.colors.textSecondary)
            Spacer(Modifier.height(10.dp))
            AeroButton(
                text = stringResource(R.string.xfer_install_permission_action),
                onClick = onInstallSettings,
                modifier = Modifier.fillMaxWidth(),
                style = AeroButtonStyle.Secondary,
            )
        }
    }
}

/** The system installer is a separate window; this line says what it reported. */
@Composable
internal fun InstallResultLine(event: InstallEvent?) {
    val colors = AeroTheme.colors
    when (event) {
        null -> Unit
        is InstallEvent.Started -> AeroText(
            text = stringResource(R.string.xfer_install_started),
            style = AeroTheme.typography.caption,
            color = colors.textSecondary,
        )
        is InstallEvent.Success -> AeroText(
            text = stringResource(R.string.xfer_install_success),
            style = AeroTheme.typography.bodyStrong,
            color = colors.success,
        )
        is InstallEvent.Failure -> AeroText(
            text = stringResource(R.string.xfer_install_failed, event.message),
            color = colors.danger,
        )
        InstallEvent.Cancelled -> AeroText(
            text = stringResource(R.string.xfer_install_cancelled),
            style = AeroTheme.typography.caption,
            color = colors.textSecondary,
        )
    }
}

/** The received packages that get an install card. */
internal fun receivedApps(files: List<SavedFile>): List<SavedFile> =
    files.filter { file -> file.category == FileCategory.APK }.take(TransferLogic.MAX_APK_CARDS)
