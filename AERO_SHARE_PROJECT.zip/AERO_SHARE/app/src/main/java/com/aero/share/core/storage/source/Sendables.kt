package com.aero.share.core.storage.source

import android.content.ContentResolver
import android.net.Uri
import com.aero.share.transfer.engine.SendableFile
import com.aero.share.transfer.engine.SourceVersion
import com.aero.share.transfer.model.FileCategory
import java.io.File
import java.io.FileInputStream
import java.io.FilterInputStream
import java.io.IOException
import java.io.InputStream

/** A file reached through a content URI (picker, share sheet, MediaStore, SAF tree). Opened lazily, never fully read into memory. */
internal class ContentUriSendable(
    override val id: Int,
    override val relativePath: String,
    override val size: Long,
    override val lastModified: Long,
    override val category: FileCategory,
    override val mimeType: String?,
    private val uri: Uri,
    private val resolver: ContentResolver,
    private val versionProbe: () -> SourceVersion?,
) : SendableFile {

    override fun open(offset: Long): InputStream {
        val descriptor = resolver.openFileDescriptor(uri, "r") ?: throw IOException("cannot open source")
        try {
            val stream = FileInputStream(descriptor.fileDescriptor)
            if (offset > 0L) stream.channel.position(offset)
            return object : FilterInputStream(stream) {
                override fun close() {
                    try {
                        super.close()
                    } finally {
                        descriptor.close()
                    }
                }
            }
        } catch (e: IOException) {
            descriptor.close()
            throw e
        }
    }

    override fun currentVersion(): SourceVersion? = versionProbe()
}

/** A plain file (installed APKs, generated APK bundles). */
internal class FileSendable(
    override val id: Int,
    override val relativePath: String,
    private val file: File,
    override val category: FileCategory,
    override val mimeType: String?,
) : SendableFile {
    override val size: Long = file.length()
    override val lastModified: Long = file.lastModified()

    override fun open(offset: Long): InputStream {
        val stream = FileInputStream(file)
        try {
            if (offset > 0L) stream.channel.position(offset)
        } catch (e: IOException) {
            stream.close()
            throw e
        }
        return stream
    }

    override fun currentVersion(): SourceVersion? = if (file.isFile) SourceVersion(file.length(), file.lastModified()) else null
}
