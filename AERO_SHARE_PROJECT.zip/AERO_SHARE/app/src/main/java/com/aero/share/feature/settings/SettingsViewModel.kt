package com.aero.share.feature.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aero.share.di.AppContainer
import com.aero.share.domain.AppSettings
import com.aero.share.domain.LanguagePref
import com.aero.share.domain.LocalDeviceInfo
import com.aero.share.domain.TransportCapability
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

/**
 * Reads and writes the settings for the settings pages. Every change is stored at once and the rest of the app (theme,
 * discovery, notifications, the engine) reads the same stored values, so nothing here is only cosmetic.
 */
internal class SettingsViewModel(private val container: AppContainer) : ViewModel() {
    val settings: StateFlow<AppSettings> = container.settings.settings
    val capabilities: StateFlow<List<TransportCapability>> = container.capabilities.capabilities
    val device: StateFlow<LocalDeviceInfo> = container.localDevice.info

    fun update(transform: (AppSettings) -> AppSettings) {
        viewModelScope.launch { container.settings.update(transform) }
    }

    /** Stores the language and then runs [applied]; the page restarts its activity there so every text is redrawn. */
    fun setLanguage(language: LanguagePref, applied: () -> Unit) {
        viewModelScope.launch {
            container.settings.update { current -> current.copy(language = language) }
            applied()
        }
    }

    /** An empty [input] goes back to the model name. */
    fun setDeviceName(input: String) {
        val name = SettingsLogic.customNameOf(input)
        update { current -> current.copy(customDeviceName = name) }
    }

    fun refreshCapabilities() {
        container.capabilities.refresh()
    }
}
