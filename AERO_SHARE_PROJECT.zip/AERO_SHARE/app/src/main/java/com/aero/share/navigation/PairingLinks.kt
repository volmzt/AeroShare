package com.aero.share.navigation

import com.aero.share.network.transport.PlanRules
import com.aero.share.transfer.pairing.QrPayload

/** What an `aero://pair?...` link opened from outside the app turned out to be. */
internal sealed interface PairingLink {
    /** A well-formed, not yet expired link. */
    data class Usable(val payload: QrPayload) : PairingLink

    /** Not an AERO SHARE pairing link, or malformed. */
    data object Invalid : PairingLink

    /** Well-formed but past its expiry (a small clock-skew grace is allowed, the receiver enforces the real expiry). */
    data object Expired : PairingLink
}

internal object PairingLinks {
    fun evaluate(link: String, nowMillis: Long): PairingLink {
        val payload = QrPayload.parse(link) ?: return PairingLink.Invalid
        return if (PlanRules.isExpired(payload.expiresAt, nowMillis)) PairingLink.Expired else PairingLink.Usable(payload)
    }
}
