package com.aero.share.feature.home

import com.aero.share.domain.DeviceRecord
import com.aero.share.domain.DiscoveryProblem
import com.aero.share.domain.DiscoveryState
import com.aero.share.domain.DiscoveryStatus
import com.aero.share.domain.NearbyDevice
import com.aero.share.transfer.model.TransferDirection
import com.aero.share.transfer.model.TransferSnapshot
import com.aero.share.transfer.model.TransferState

/** Why the "Nearby devices" list is empty. Every value has its own text and action on screen. */
internal enum class HomeEmpty { SEARCHING, NONE_FOUND, IDLE, WIFI_OFF, NO_NETWORK, PERMISSION, UNAVAILABLE }

/** One row of the nearby list, ready to draw. [displayName] is blank when the device did not announce a name. */
internal data class HomeDevice(
    val device: NearbyDevice,
    val displayName: String,
    val trusted: Boolean,
    val blocked: Boolean,
)

/** The running (or interrupted) transfer shown above the Send card, and how many more there are behind it. */
internal data class HomeBanner(val transfer: TransferSnapshot, val additional: Int)

internal enum class BannerKind { SENDING, RECEIVING, INTERRUPTED }

internal enum class BannerProgress { NONE, INDETERMINATE, DETERMINATE }

/** Decisions of the Home screen that do not need Android, kept apart so they can be unit-tested. */
internal object HomeLogic {
    /** After this long without a single device the empty state stops saying "looking" and offers tips instead. */
    const val NONE_FOUND_AFTER_MS = 8_000L

    /**
     * What to show instead of the device list, or null while there are devices.
     * [searchWanted] is true when discovery is meant to run on this screen (the setting is on, or the person asked for it).
     */
    fun emptyState(
        deviceCount: Int,
        discovery: DiscoveryState,
        searchedLongEnough: Boolean,
        searchWanted: Boolean,
    ): HomeEmpty? {
        if (deviceCount > 0) return null
        return when (discovery.status) {
            DiscoveryStatus.PROBLEM -> when (discovery.problem ?: DiscoveryProblem.UNAVAILABLE) {
                DiscoveryProblem.WIFI_OFF -> HomeEmpty.WIFI_OFF
                DiscoveryProblem.NO_NETWORK -> HomeEmpty.NO_NETWORK
                DiscoveryProblem.PERMISSION_MISSING -> HomeEmpty.PERMISSION
                DiscoveryProblem.UNAVAILABLE -> HomeEmpty.UNAVAILABLE
            }
            // Discovery is about to start (the first frames after the screen opened): do not flash "paused".
            DiscoveryStatus.IDLE -> if (searchWanted) HomeEmpty.SEARCHING else HomeEmpty.IDLE
            DiscoveryStatus.SEARCHING -> if (searchedLongEnough) HomeEmpty.NONE_FOUND else HomeEmpty.SEARCHING
        }
    }

    /** Joins live discovery with what the person decided about each device (alias, trusted, blocked). */
    fun devices(nearby: List<NearbyDevice>, known: List<DeviceRecord>): List<HomeDevice> {
        val byId = HashMap<String, DeviceRecord>(known.size * 2)
        for (record in known) byId[record.deviceId] = record
        val rows = ArrayList<HomeDevice>(nearby.size)
        for (device in nearby) {
            val record = byId[device.deviceId]
            val alias = record?.alias?.trim().orEmpty()
            rows.add(
                HomeDevice(
                    device = device,
                    displayName = if (alias.isNotEmpty()) alias else device.name.trim(),
                    trusted = record?.trusted == true,
                    blocked = record?.blocked == true,
                ),
            )
        }
        // Stable order so rows do not jump around while devices come and go: trusted first, blocked last, then by name.
        return rows.sortedWith(
            compareBy<HomeDevice> { it.blocked }
                .thenByDescending { it.trusted }
                .thenBy { it.displayName.lowercase() }
                .thenBy { it.device.deviceId },
        )
    }

    /** The transfer to announce on Home: an active one if there is any, otherwise a queued or interrupted one. */
    fun banner(transfers: List<TransferSnapshot>): HomeBanner? {
        val relevant = transfers.filter { it.state.isActive || it.state == TransferState.WAITING || it.state == TransferState.INTERRUPTED }
        if (relevant.isEmpty()) return null
        val primary = relevant.firstOrNull { it.state.isActive } ?: relevant.first()
        return HomeBanner(primary, relevant.size - 1)
    }

    fun bannerKind(transfer: TransferSnapshot): BannerKind = when {
        transfer.state == TransferState.INTERRUPTED -> BannerKind.INTERRUPTED
        transfer.direction == TransferDirection.SEND -> BannerKind.SENDING
        else -> BannerKind.RECEIVING
    }

    fun bannerProgress(transfer: TransferSnapshot): BannerProgress = when (transfer.state) {
        TransferState.TRANSFERRING, TransferState.PAUSED, TransferState.VERIFYING ->
            if (transfer.totalBytes > 0L) BannerProgress.DETERMINATE else BannerProgress.INDETERMINATE
        TransferState.PREPARING, TransferState.CONNECTING, TransferState.AWAITING_ACCEPTANCE -> BannerProgress.INDETERMINATE
        TransferState.WAITING, TransferState.INTERRUPTED, TransferState.COMPLETED, TransferState.FAILED, TransferState.CANCELLED ->
            BannerProgress.NONE
    }

    /** Byte counts are only meaningful once data is flowing and the total is known. */
    fun bannerShowsSizes(transfer: TransferSnapshot): Boolean =
        transfer.totalBytes > 0L &&
            (transfer.state == TransferState.TRANSFERRING || transfer.state == TransferState.PAUSED)
}
