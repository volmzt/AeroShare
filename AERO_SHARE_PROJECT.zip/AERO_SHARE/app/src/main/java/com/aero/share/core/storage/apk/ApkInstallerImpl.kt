package com.aero.share.core.storage.apk

import android.app.PendingIntent
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.IntentSender
import android.content.pm.PackageInstaller
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.annotation.StringRes
import com.aero.share.R
import com.aero.share.core.common.LocaleHelper
import com.aero.share.core.storage.UriMetadata
import java.io.BufferedInputStream
import java.io.IOException
import java.io.InputStream
import java.util.zip.ZipInputStream
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.withContext

/** A problem with the package itself that has its own user-facing explanation. */
private class SourceProblem(@StringRes val messageRes: Int) : IOException()

/**
 * Installs through Android's PackageInstaller only. The user always confirms in the system window; the app never
 * installs silently and never starts an installation by itself (the UI calls [install] after a tap).
 */
class ApkInstallerImpl(private val context: Context) : ApkInstaller {
    private val reader = ApkInfoReader(context)

    override val events: SharedFlow<InstallEvent> get() = InstallEvents.flow

    override suspend fun inspect(uri: String): ApkInfo? = withContext(Dispatchers.IO) { reader.read(uri) }

    override fun canRequestInstall(): Boolean = context.packageManager.canRequestPackageInstalls()

    override fun openInstallPermissionSettings() {
        val direct = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${context.packageName}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            context.startActivity(direct)
        } catch (e: ActivityNotFoundException) {
            try {
                context.startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (inner: ActivityNotFoundException) {
                // This device has no settings screen for it; the install attempt reports the problem itself.
            }
        }
    }

    override suspend fun install(uri: String) {
        withContext(Dispatchers.IO) { runInstall(uri) }
    }

    private suspend fun runInstall(uriString: String) {
        if (!canRequestInstall()) {
            fail(R.string.apk_fail_permission)
            return
        }
        val installer = context.packageManager.packageInstaller
        val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
        params.setInstallReason(PackageManager.INSTALL_REASON_USER)
        if (Build.VERSION.SDK_INT >= 31) {
            params.setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_REQUIRED)
        }
        val sessionId = try {
            installer.createSession(params)
        } catch (e: IOException) {
            fail(R.string.apk_fail_generic, e.message)
            return
        } catch (e: SecurityException) {
            fail(R.string.apk_fail_generic, e.message)
            return
        }
        var committed = false
        try {
            installer.openSession(sessionId).use { session ->
                writePackage(session, Uri.parse(uriString))
                session.commit(resultSender(sessionId, uriString))
                committed = true
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: SourceProblem) {
            fail(e.messageRes)
        } catch (e: IOException) {
            fail(R.string.apk_fail_read, e.message)
        } catch (e: SecurityException) {
            fail(R.string.apk_fail_generic, e.message)
        } catch (e: IllegalStateException) {
            fail(R.string.apk_fail_generic, e.message)
        } finally {
            if (!committed) abandon(installer, sessionId)
        }
    }

    private suspend fun writePackage(session: PackageInstaller.Session, uri: Uri) {
        val name = UriMetadata.query(context, uri)?.name ?: uri.lastPathSegment.orEmpty()
        val raw = context.contentResolver.openInputStream(uri) ?: throw SourceProblem(R.string.apk_fail_read)
        raw.use { input ->
            if (ApkBundle.isBundleName(name)) {
                writeBundle(session, input)
            } else {
                writeEntry(session, ApkBundle.BASE_ENTRY, input)
            }
        }
    }

    private suspend fun writeBundle(session: PackageInstaller.Session, input: InputStream) {
        val zip = ZipInputStream(BufferedInputStream(input, BUFFER))
        val seen = HashSet<String>()
        ApkBundle.forEachEntry(zip) { name ->
            if (name != ApkBundle.MANIFEST_ENTRY) {
                if (!seen.add(name) || seen.size > ApkBundle.MAX_SPLITS + 1) throw SourceProblem(R.string.apk_fail_invalid)
                writeEntry(session, name, zip)
            }
        }
        if (ApkBundle.BASE_ENTRY !in seen) throw SourceProblem(R.string.apk_fail_no_base)
    }

    /** Streams one APK into the session. The size is unknown up front, so -1 is passed. */
    private suspend fun writeEntry(session: PackageInstaller.Session, entryName: String, input: InputStream) {
        session.openWrite(entryName, 0L, -1L).use { out ->
            val buffer = ByteArray(BUFFER)
            while (true) {
                val read = input.read(buffer)
                if (read < 0) break
                out.write(buffer, 0, read)
                currentCoroutineContext().ensureActive()
            }
            out.flush()
            session.fsync(out)
        }
    }

    private fun resultSender(sessionId: Int, uri: String): IntentSender {
        val intent = Intent(context, InstallResultReceiver::class.java)
            .setAction(InstallResultReceiver.ACTION_RESULT)
            .putExtra(InstallResultReceiver.EXTRA_URI, uri)
        var flags = PendingIntent.FLAG_UPDATE_CURRENT
        // The installer adds its status to this intent, so it must be mutable on Android 12+.
        if (Build.VERSION.SDK_INT >= 31) flags = flags or PendingIntent.FLAG_MUTABLE
        return PendingIntent.getBroadcast(context, sessionId, intent, flags).intentSender
    }

    private fun abandon(installer: PackageInstaller, sessionId: Int) {
        try {
            installer.abandonSession(sessionId)
        } catch (e: SecurityException) {
            // The session is already gone; nothing to clean up.
        } catch (e: IllegalArgumentException) {
            // Unknown session id: same.
        }
    }

    private fun fail(@StringRes id: Int, detail: String? = null) {
        val text = LocaleHelper.wrap(context).getString(id)
        InstallEvents.emit(InstallEvent.Failure(if (detail.isNullOrBlank()) text else "$text ($detail)"))
    }

    private companion object {
        const val BUFFER = 256 * 1024
    }
}
