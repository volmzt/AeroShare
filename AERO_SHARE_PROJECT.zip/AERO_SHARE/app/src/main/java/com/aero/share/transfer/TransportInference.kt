package com.aero.share.transfer

import com.aero.share.transfer.model.TransportKind

/**
 * Tells how an incoming connection reached this device. The engine only reports the remote address, so the transport is
 * inferred from the local interface that owns that subnet; it is shown in the UI as information, never used for security.
 */
internal object TransportInference {
    /** Default subnet of an Android Wi-Fi Direct group. */
    private const val WIFI_DIRECT_DEFAULT_PREFIX = "192.168.49."

    fun infer(remoteAddress: String, local: List<LocalAddress>, hotspot: List<Ipv4Subnet>): TransportKind {
        val clean = remoteAddress.substringBefore('%').removePrefix("/")
        val remote = Ipv4.parse(clean) ?: return TransportKind.LAN
        val owners = local.filter { owner ->
            val subnet = owner.subnet
            subnet != null && subnet.contains(remote)
        }
        if (owners.any { it.interfaceName.lowercase().startsWith("p2p") }) return TransportKind.WIFI_DIRECT
        if (hotspot.any { it.contains(remote) }) return TransportKind.HOTSPOT
        if (owners.isEmpty() && clean.startsWith(WIFI_DIRECT_DEFAULT_PREFIX)) return TransportKind.WIFI_DIRECT
        return TransportKind.LAN
    }
}
