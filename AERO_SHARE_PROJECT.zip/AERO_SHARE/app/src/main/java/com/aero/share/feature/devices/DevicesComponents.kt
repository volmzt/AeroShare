package com.aero.share.feature.devices

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.aero.share.R
import com.aero.share.core.common.labelRes
import com.aero.share.core.designsystem.AeroBadge
import com.aero.share.core.designsystem.AeroCard
import com.aero.share.core.designsystem.AeroDeviceIcon
import com.aero.share.core.designsystem.AeroGroup
import com.aero.share.core.designsystem.AeroSwitchRow
import com.aero.share.core.designsystem.AeroText
import com.aero.share.core.designsystem.AeroTheme
import com.aero.share.feature.send.dateText
import com.aero.share.feature.send.metaLine

/** "5 minutes ago", "3 days ago", a date for older times, or "never". */
@Composable
internal fun seenText(ago: SeenAgo, then: Long): String = when (ago.unit) {
    SeenUnit.NOW -> stringResource(R.string.dev_seen_now)
    SeenUnit.MINUTES -> pluralStringResource(R.plurals.dev_seen_minutes, ago.amount, ago.amount)
    SeenUnit.HOURS -> pluralStringResource(R.plurals.dev_seen_hours, ago.amount, ago.amount)
    SeenUnit.DAYS -> pluralStringResource(R.plurals.dev_seen_days, ago.amount, ago.amount)
    SeenUnit.DATE -> stringResource(R.string.dev_seen_date, dateText(then))
    SeenUnit.NEVER -> stringResource(R.string.dev_seen_never)
}

/** The visibility switch and what hiding does and does not do. Hidden mode is a convenience, never a security feature. */
@Composable
internal fun VisibilityCard(hidden: Boolean, onVisibleChange: (Boolean) -> Unit) {
    AeroGroup {
        AeroSwitchRow(
            title = stringResource(R.string.dev_visibility_title),
            subtitle = stringResource(if (hidden) R.string.dev_visibility_hidden else R.string.dev_visibility_visible),
            checked = !hidden,
            onCheckedChange = onVisibleChange,
        )
        AeroText(
            text = stringResource(R.string.dev_hidden_note),
            modifier = Modifier.padding(start = AeroTheme.dimens.cardPadding, end = AeroTheme.dimens.cardPadding, bottom = 12.dp),
            style = AeroTheme.typography.caption,
            color = AeroTheme.colors.textSecondary,
        )
    }
}

/** A stored device: icon, the name the person gave it, type and last contact, and the trust badge. */
@Composable
internal fun KnownDeviceRow(row: KnownRow, now: Long, onClick: () -> Unit) {
    val record = row.record
    val colors = AeroTheme.colors
    val typeText = record.model?.takeIf { model -> model.isNotBlank() } ?: stringResource(record.kind.labelRes())
    val seen = if (row.nearby != null) {
        stringResource(R.string.dev_nearby_now)
    } else {
        seenText(DevicesLogic.seenAgo(now, record.lastSeen), record.lastSeen)
    }
    val name = record.displayName.ifBlank { stringResource(R.string.common_unknown_device) }
    AeroCard(onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AeroDeviceIcon(kind = record.kind)
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                AeroText(text = name, style = AeroTheme.typography.bodyStrong, maxLines = 1)
                AeroText(
                    text = metaLine(listOf(typeText, seen)),
                    style = AeroTheme.typography.caption,
                    color = colors.textSecondary,
                    maxLines = 2,
                )
            }
            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                if (record.blocked) {
                    AeroBadge(text = stringResource(R.string.common_trust_blocked), color = colors.danger)
                } else if (record.trusted) {
                    AeroBadge(text = stringResource(R.string.common_trust_trusted))
                }
            }
        }
    }
}
