package com.aero.share.feature.receive

import com.aero.share.domain.CapabilityState
import com.aero.share.domain.TransportCapability
import com.aero.share.network.transport.stateOf
import com.aero.share.transfer.model.TransportKind

/** Time maths of the pairing QR code, which is shown with a countdown. */
internal object QrLogic {
    private const val SECOND_MS = 1_000L

    /** Whole seconds left, rounded up so that "0:00" is only shown once the code really has expired. */
    fun remainingSeconds(expiresAtMillis: Long, nowMillis: Long): Long {
        val left = expiresAtMillis - nowMillis
        return if (left <= 0L) 0L else (left + SECOND_MS - 1L) / SECOND_MS
    }

    fun isExpired(expiresAtMillis: Long, nowMillis: Long): Boolean = expiresAtMillis <= nowMillis

    /** "1:05": minutes, then two-digit seconds. */
    fun clock(seconds: Long): String {
        val total = if (seconds < 0L) 0L else seconds
        val minutes = total / 60L
        val rest = total % 60L
        return minutes.toString() + ":" + (if (rest < 10L) "0" else "") + rest.toString()
    }
}

/** Whether the temporary hotspot option can be offered next to the QR code, and what it needs first. */
internal enum class HotspotOffer { NONE, AVAILABLE, NEEDS_PERMISSION }

internal object ReceiveLogic {
    /**
     * The hotspot switch is shown when the hotspot works, or when it would work after the person allows the "nearby
     * devices" permission. Anything else (no Wi-Fi hardware, location switched off) hides it rather than offering a
     * switch that cannot succeed.
     */
    fun hotspotOffer(capabilities: List<TransportCapability>): HotspotOffer = when (capabilities.stateOf(TransportKind.HOTSPOT)) {
        CapabilityState.AVAILABLE -> HotspotOffer.AVAILABLE
        CapabilityState.PERMISSION_MISSING -> HotspotOffer.NEEDS_PERMISSION
        CapabilityState.RADIO_OFF,
        CapabilityState.UNSUPPORTED,
        CapabilityState.NO_NETWORK,
        -> HotspotOffer.NONE
    }

    /** "192.168.1.20:47474" for every local address, for connecting by address. Empty while the port is not known. */
    fun endpoints(addresses: List<String>, port: Int?): List<String> {
        if (port == null) return emptyList()
        return addresses.filter { address -> address.isNotBlank() }.map { address -> address.trim() + ":" + port.toString() }
    }
}

/** Whether there is room for what an incoming request wants to save. */
internal enum class StorageCheck { ENOUGH, UNKNOWN, TOO_LITTLE }

internal object IncomingLogic {
    private const val GROUP = 3

    /**
     * Verification codes are read aloud and compared, so digits come in groups of three ("482913" -> "482 913"). A code
     * that is already grouped stays as it is.
     */
    fun groupCode(code: String?): String {
        if (code == null) return ""
        val compact = code.filter { ch -> !ch.isWhitespace() }
        if (compact.isEmpty()) return ""
        val out = StringBuilder(compact.length + compact.length / GROUP)
        for (index in compact.indices) {
            if (index > 0 && index % GROUP == 0) out.append(' ')
            out.append(compact[index])
        }
        return out.toString()
    }

    /** Whole seconds until the request is declined by itself, rounded up. [nowElapsed] and the deadline use the same clock. */
    fun remainingSeconds(expiresAtElapsed: Long, nowElapsed: Long): Long {
        val left = expiresAtElapsed - nowElapsed
        return if (left <= 0L) 0L else (left + 999L) / 1000L
    }

    /** Free space unknown is not a problem (some storage cannot report it); too little is. */
    fun storage(freeBytes: Long?, totalBytes: Long): StorageCheck = when {
        freeBytes == null -> StorageCheck.UNKNOWN
        totalBytes > 0L && freeBytes < totalBytes -> StorageCheck.TOO_LITTLE
        else -> StorageCheck.ENOUGH
    }
}

/**
 * Counts the Receive screens that want the receiver switched on. Leaving a screen switches receiving off only when no
 * other screen holds the lease, and a switch-off that was postponed (because a transfer was still running) is dropped as
 * soon as a screen has been opened again.
 */
internal class ReceiveLease {
    private var holders = 0
    private var generation = 0L

    @Synchronized
    fun acquire() {
        holders += 1
        generation += 1L
    }

    /** Leaves. Returns the generation to give to [mayStop] later, or null while another holder remains. */
    @Synchronized
    fun release(): Long? {
        if (holders > 0) holders -= 1
        return if (holders == 0) generation else null
    }

    /** True while nobody has acquired the lease since [ticket] was handed out. */
    @Synchronized
    fun mayStop(ticket: Long): Boolean = holders == 0 && generation == ticket
}
