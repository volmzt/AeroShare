package com.aero.share.core.designsystem

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.delay

/** Container for dialogs with custom content. Closes on back press and on a tap outside. */
@Composable
fun AeroDialogFrame(onDismiss: () -> Unit, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        val colors = AeroTheme.colors
        val shape = RoundedCornerShape(AeroTheme.dimens.radius)
        Column(
            modifier = modifier
                .fillMaxWidth()
                .clip(shape)
                .background(colors.surfaceElevated, shape)
                .border(1.dp, colors.divider, shape)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            content = content,
        )
    }
}

@Composable
private fun DialogButtons(
    confirmText: String,
    onConfirm: () -> Unit,
    dismissText: String?,
    onDismiss: () -> Unit,
    danger: Boolean,
) {
    val confirmStyle = if (danger) AeroButtonStyle.Danger else AeroButtonStyle.Primary
    if (dismissText == null) {
        AeroButton(text = confirmText, onClick = onConfirm, modifier = Modifier.fillMaxWidth(), style = confirmStyle)
    } else {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            AeroButton(text = dismissText, onClick = onDismiss, modifier = Modifier.weight(1f), style = AeroButtonStyle.Secondary)
            AeroButton(text = confirmText, onClick = onConfirm, modifier = Modifier.weight(1f), style = confirmStyle)
        }
    }
}

/** Title, message and one or two buttons. [danger] colours the confirm button for destructive actions. */
@Composable
fun AeroDialog(
    title: String,
    message: String,
    confirmText: String,
    onConfirm: () -> Unit,
    dismissText: String? = null,
    onDismiss: () -> Unit,
    danger: Boolean = false,
) {
    AeroDialogFrame(onDismiss = onDismiss) {
        AeroText(text = title, style = AeroTheme.typography.titleSmall)
        Spacer(Modifier.height(12.dp))
        AeroText(text = message, color = AeroTheme.colors.textSecondary)
        Spacer(Modifier.height(20.dp))
        DialogButtons(confirmText, onConfirm, dismissText, onDismiss, danger)
    }
}

/**
 * Dialog with one text field. [validate] returns an error text to show (and blocks confirming) or null when the input is
 * fine; the value is trimmed before it is validated and handed to [onConfirm].
 */
@Composable
fun AeroInputDialog(
    title: String,
    initialValue: String,
    confirmText: String,
    dismissText: String,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit,
    label: String? = null,
    placeholder: String? = null,
    message: String? = null,
    maxLength: Int = Int.MAX_VALUE,
    keyboardType: KeyboardType = KeyboardType.Text,
    validate: (String) -> String? = { null },
) {
    var text by remember { mutableStateOf(initialValue) }
    var error by remember { mutableStateOf<String?>(null) }
    AeroDialogFrame(onDismiss = onDismiss) {
        AeroText(text = title, style = AeroTheme.typography.titleSmall)
        if (message != null) {
            Spacer(Modifier.height(8.dp))
            AeroText(text = message, color = AeroTheme.colors.textSecondary)
        }
        Spacer(Modifier.height(16.dp))
        AeroTextField(
            value = text,
            onValueChange = {
                text = it.take(maxLength)
                error = null
            },
            label = label,
            placeholder = placeholder,
            keyboardType = keyboardType,
            isError = error != null,
            supportingText = error,
        )
        Spacer(Modifier.height(20.dp))
        DialogButtons(
            confirmText = confirmText,
            onConfirm = {
                val value = text.trim()
                val problem = validate(value)
                if (problem == null) onConfirm(value) else error = problem
            },
            dismissText = dismissText,
            onDismiss = onDismiss,
            danger = false,
        )
    }
}

/** Sheet that slides in from the bottom edge (a full-width dialog window, so it works on every API level). */
@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun AeroBottomSheet(onDismiss: () -> Unit, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        val colors = AeroTheme.colors
        val topShape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
        val maxHeight = (LocalConfiguration.current.screenHeightDp * 0.9f).dp
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onDismiss),
            contentAlignment = Alignment.BottomCenter,
        ) {
            Column(
                modifier = modifier
                    .fillMaxWidth()
                    .heightIn(max = maxHeight)
                    .clip(topShape)
                    .background(colors.surfaceElevated, topShape)
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = {})
                    .navigationBarsPadding()
                    .verticalScroll(rememberScrollState())
                    .padding(start = 20.dp, end = 20.dp, bottom = 20.dp),
            ) {
                Box(
                    modifier = Modifier
                        .padding(vertical = 10.dp)
                        .size(width = 36.dp, height = 4.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(colors.divider)
                        .align(Alignment.CenterHorizontally),
                )
                content()
            }
        }
    }
}

/** Holds the message of the toast that is currently shown. */
class AeroToastState {
    var message: String? by mutableStateOf<String?>(null)
        private set

    /** Changes with every [show], so showing the same text twice restarts the timer. */
    var serial: Int by mutableIntStateOf(0)
        private set

    fun show(text: String) {
        message = text
        serial += 1
    }

    internal fun clear() {
        message = null
    }
}

@Composable
fun rememberAeroToastState(): AeroToastState = remember { AeroToastState() }

/** The toast state of the running app; screens call `LocalAeroToast.current.show(...)`. Without a host the call is a no-op. */
val LocalAeroToast = staticCompositionLocalOf { AeroToastState() }

/** Draws the current toast near the bottom of its parent for about three seconds. */
@Composable
fun AeroToastHost(state: AeroToastState, modifier: Modifier = Modifier) {
    val text = state.message
    LaunchedEffect(state.serial) {
        if (state.message != null) {
            delay(3_000L)
            state.clear()
        }
    }
    if (text != null) {
        val colors = AeroTheme.colors
        val shape = RoundedCornerShape(AeroTheme.dimens.radiusSmall)
        Box(
            modifier = modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            contentAlignment = Alignment.BottomCenter,
        ) {
            AeroText(
                text = text,
                modifier = Modifier
                    .clip(shape)
                    .background(colors.surfaceElevated, shape)
                    .border(1.dp, colors.divider, shape)
                    .padding(horizontal = 16.dp, vertical = 12.dp)
                    .semantics { liveRegion = LiveRegionMode.Polite },
                maxLines = 3,
            )
        }
    }
}
