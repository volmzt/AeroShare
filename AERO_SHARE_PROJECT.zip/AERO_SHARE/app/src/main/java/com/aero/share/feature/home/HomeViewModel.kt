package com.aero.share.feature.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aero.share.di.AppContainer
import com.aero.share.domain.DiscoveryState
import com.aero.share.domain.DiscoveryStatus
import com.aero.share.domain.Visibility
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** Everything the Home screen draws, derived from the live state of discovery, transfers and settings. */
internal data class HomeUiState(
    val deviceName: String = "",
    val hidden: Boolean = false,
    val searching: Boolean = false,
    val devices: List<HomeDevice> = emptyList(),
    val empty: HomeEmpty? = HomeEmpty.SEARCHING,
    val banner: HomeBanner? = null,
)

private data class SearchInputs(val discovery: DiscoveryState, val longEnough: Boolean, val manual: Boolean)

/**
 * Owns the discovery session of the Home screen: it searches while the screen is visible (when the setting allows it, or
 * once the person asked) and releases discovery as soon as the screen is paused, so nothing runs in the background.
 */
internal class HomeViewModel(private val container: AppContainer) : ViewModel() {
    private val longSearch = MutableStateFlow(false)
    private val manualSearch = MutableStateFlow(false)
    private var resumed = false
    private var started = false
    private var timer: Job? = null

    private val rowsFlow = combine(container.discovery.devices, container.devices.devices) { nearby, known ->
        HomeLogic.devices(nearby, known)
    }
    private val searchFlow = combine(container.discovery.state, longSearch, manualSearch) { state, long, manual ->
        SearchInputs(state, long, manual)
    }

    val state: StateFlow<HomeUiState> = combine(
        rowsFlow,
        searchFlow,
        container.coordinator.transfers,
        container.settings.settings,
        container.localDevice.info,
    ) { rows, search, transfers, settings, local ->
        HomeUiState(
            deviceName = local.name,
            hidden = settings.visibility == Visibility.HIDDEN,
            searching = search.discovery.status == DiscoveryStatus.SEARCHING,
            devices = rows,
            empty = HomeLogic.emptyState(
                deviceCount = rows.size,
                discovery = search.discovery,
                searchedLongEnough = search.longEnough,
                searchWanted = settings.discoverOnLaunch || search.manual,
            ),
            banner = HomeLogic.banner(transfers),
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HomeUiState())

    fun onResume() {
        resumed = true
        // The radio state may have changed while another screen (for example the system Wi-Fi settings) was in front.
        container.capabilities.refresh()
        if (container.settings.settings.value.discoverOnLaunch || manualSearch.value) beginSearch()
    }

    fun onPause() {
        resumed = false
        endSearch()
    }

    /** The refresh button and the "search" actions of the empty states. */
    fun searchNow() {
        manualSearch.value = true
        if (!resumed) return
        if (started) {
            restartTimer()
            container.discovery.refresh()
        } else {
            beginSearch()
        }
    }

    /** The system permission dialog was closed; whatever the answer, look at the situation again. */
    fun onPermissionResult() {
        container.capabilities.refresh()
        searchNow()
    }

    private fun beginSearch() {
        if (!started) {
            started = true
            container.discovery.startDiscovery(OWNER)
        }
        restartTimer()
    }

    private fun endSearch() {
        if (started) {
            started = false
            container.discovery.stopDiscovery(OWNER)
        }
        timer?.cancel()
        timer = null
        longSearch.value = false
    }

    private fun restartTimer() {
        timer?.cancel()
        longSearch.value = false
        timer = viewModelScope.launch {
            delay(HomeLogic.NONE_FOUND_AFTER_MS)
            longSearch.value = true
        }
    }

    override fun onCleared() {
        endSearch()
    }

    private companion object {
        const val OWNER = "home"
    }
}
