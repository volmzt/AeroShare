package com.aero.share.feature.transfer

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.aero.share.R
import com.aero.share.core.designsystem.AeroButton
import com.aero.share.core.designsystem.AeroButtonStyle
import com.aero.share.core.designsystem.AeroDialog
import com.aero.share.core.designsystem.AeroEmptyState
import com.aero.share.core.designsystem.AeroScreen
import com.aero.share.core.designsystem.AeroTheme
import com.aero.share.core.designsystem.AeroTopBar
import com.aero.share.core.designsystem.LocalFeedback
import com.aero.share.core.storage.apk.InstallEvent
import com.aero.share.di.LocalAppContainer
import com.aero.share.navigation.AeroNavigator
import com.aero.share.transfer.model.TransferDirection
import com.aero.share.transfer.model.TransferSnapshot
import com.aero.share.transfer.model.TransferState

/**
 * One transfer, live. Leaving the screen never stops the transfer: it runs in the background with a notification, and the
 * screen can be opened again from Home. Everything shown comes from the transfer itself, nothing is estimated for show.
 */
@Composable
fun TransferScreen(transferId: String, navigator: AeroNavigator) {
    val container = LocalAppContainer.current
    val viewModel: TransferViewModel = viewModel(
        key = transferId,
        factory = viewModelFactory { initializer { TransferViewModel(container, transferId) } },
    )
    val snapshot by viewModel.snapshot.collectAsStateWithLifecycle()
    val install by viewModel.install.collectAsStateWithLifecycle()
    var confirmCancel by rememberSaveable { mutableStateOf(false) }
    var leaving by remember { mutableStateOf(false) }
    var canInstall by remember { mutableStateOf(viewModel.canInstall()) }
    var previous by remember { mutableStateOf<TransferState?>(null) }
    val feedback = LocalFeedback.current
    val view = LocalView.current

    // The person may have allowed installing from AERO SHARE in the system settings and come back.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { canInstall = viewModel.canInstall() }

    val current = snapshot
    val state = current?.state

    // One short haptic when a transfer that was running ends, never for one that was already finished when opened.
    LaunchedEffect(state) {
        val before = previous
        if (before != null && state != null && !before.isTerminal && state.isTerminal) {
            if (state == TransferState.COMPLETED) feedback.success() else if (state == TransferState.FAILED) feedback.error()
        }
        previous = state
    }

    // While data is moving and the person is looking at it, the screen stays on so a long transfer is not interrupted.
    val keepScreenOn = state != null && state.isActive && state != TransferState.PAUSED
    DisposableEffect(keepScreenOn) {
        view.keepScreenOn = keepScreenOn
        onDispose { view.keepScreenOn = false }
    }

    AeroScreen {
        AeroTopBar(title = stringResource(R.string.xfer_title), onBack = { navigator.back() })
        if (leaving) return@AeroScreen
        if (current == null) {
            AeroEmptyState(
                icon = Icons.Rounded.Info,
                title = stringResource(R.string.xfer_gone_title),
                message = stringResource(R.string.xfer_gone_text),
                actionText = stringResource(R.string.xfer_gone_action),
                onAction = { navigator.backToHome() },
            )
        } else {
            TransferBody(
                snapshot = current,
                install = install,
                canInstall = canInstall,
                onInstall = { uri -> viewModel.install(uri) },
                onInstallSettings = { viewModel.openInstallSettings() },
                modifier = Modifier.weight(1f),
            )
            ControlsBar(
                snapshot = current,
                onPause = { viewModel.pause() },
                onResume = { viewModel.resume() },
                onCancel = { confirmCancel = true },
                onRetry = { viewModel.retry() },
                onDone = {
                    leaving = true
                    viewModel.dismiss()
                    navigator.backToHome()
                },
            )
        }
    }

    if (confirmCancel) {
        AeroDialog(
            title = stringResource(R.string.xfer_cancel_title),
            message = stringResource(R.string.xfer_cancel_message),
            confirmText = stringResource(R.string.xfer_cancel_confirm),
            dismissText = stringResource(R.string.xfer_cancel_keep),
            danger = true,
            onConfirm = {
                confirmCancel = false
                viewModel.cancel()
            },
            onDismiss = { confirmCancel = false },
        )
    }
}

@Composable
private fun TransferBody(
    snapshot: TransferSnapshot,
    install: InstallEvent?,
    canInstall: Boolean,
    onInstall: (String) -> Unit,
    onInstallSettings: () -> Unit,
    modifier: Modifier,
) {
    val state = snapshot.state
    Column(
        modifier = modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = AeroTheme.dimens.screenPadding, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(AeroTheme.dimens.gap),
    ) {
        TransferHero(snapshot)
        if (TransferLogic.showsVerificationCode(state, snapshot.verificationCode)) {
            SenderCodeCard(code = snapshot.verificationCode.orEmpty())
        }
        TransferProgressCard(snapshot)
        if (snapshot.failure != null && (state == TransferState.FAILED || state == TransferState.INTERRUPTED)) {
            FailureCard(snapshot)
        }
        if (state == TransferState.COMPLETED && snapshot.direction == TransferDirection.RECEIVE && snapshot.savedFiles.isNotEmpty()) {
            ReceivedFilesCard(files = snapshot.savedFiles)
            val apps = receivedApps(snapshot.savedFiles)
            for (app in apps) {
                ReceivedAppCard(file = app, canInstall = canInstall, onInstall = onInstall, onInstallSettings = onInstallSettings)
            }
            if (apps.isNotEmpty()) InstallResultLine(install)
        }
        TransferDetailsCard(snapshot)
    }
}

/** Buttons that fit the state: pause or resume, cancel, retry, or "Done" once the transfer has ended. */
@Composable
private fun ControlsBar(
    snapshot: TransferSnapshot,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onCancel: () -> Unit,
    onRetry: () -> Unit,
    onDone: () -> Unit,
) {
    val controls = TransferLogic.controls(snapshot.state, snapshot.direction, snapshot.failure, snapshot.pausedByPeer)
    val finished = TransferLogic.isFinished(snapshot.state)
    if (!controls.any && !finished) return
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = AeroTheme.dimens.screenPadding, vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        if (controls.pause) {
            AeroButton(
                text = stringResource(R.string.xfer_pause),
                onClick = onPause,
                modifier = Modifier.weight(1f),
                style = AeroButtonStyle.Secondary,
                icon = Icons.Rounded.Pause,
            )
        }
        if (controls.resume) {
            AeroButton(
                text = stringResource(R.string.xfer_resume),
                onClick = onResume,
                modifier = Modifier.weight(1f),
                icon = Icons.Rounded.PlayArrow,
            )
        }
        if (controls.retry) {
            AeroButton(
                text = stringResource(R.string.xfer_retry),
                onClick = onRetry,
                modifier = Modifier.weight(1f),
                icon = Icons.Rounded.Refresh,
            )
        }
        if (controls.cancel) {
            AeroButton(
                text = stringResource(R.string.xfer_cancel),
                onClick = onCancel,
                modifier = Modifier.weight(1f),
                style = AeroButtonStyle.Secondary,
            )
        }
        if (finished) {
            AeroButton(
                text = stringResource(R.string.xfer_done),
                onClick = onDone,
                modifier = Modifier.weight(1f),
                style = if (controls.retry) AeroButtonStyle.Secondary else AeroButtonStyle.Primary,
            )
        }
    }
}
