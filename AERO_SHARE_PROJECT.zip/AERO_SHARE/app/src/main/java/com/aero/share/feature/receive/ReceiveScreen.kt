package com.aero.share.feature.receive

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.aero.share.R
import com.aero.share.core.designsystem.AeroButton
import com.aero.share.core.designsystem.AeroButtonStyle
import com.aero.share.core.designsystem.AeroDialog
import com.aero.share.core.designsystem.AeroScreen
import com.aero.share.core.designsystem.AeroText
import com.aero.share.core.designsystem.AeroTheme
import com.aero.share.core.designsystem.AeroTopBar
import com.aero.share.core.designsystem.LocalAeroToast
import com.aero.share.core.permissions.Permissions
import com.aero.share.di.LocalAppContainer
import com.aero.share.domain.ReceiverStatus
import com.aero.share.navigation.AeroNavigator
import com.aero.share.navigation.SettingsSection

/**
 * Receive mode. While this screen is open the device listens for senders, announces itself on the network (unless it is
 * hidden) and can show a pairing QR code. Requests to send files appear on top of whatever is on screen, see
 * [IncomingRequestHost].
 */
@Composable
fun ReceiveScreen(navigator: AeroNavigator) {
    val container = LocalAppContainer.current
    val toast = LocalAeroToast.current
    val viewModel: ReceiveViewModel = viewModel(factory = viewModelFactory { initializer { ReceiveViewModel(container) } })
    val ui by viewModel.state.collectAsStateWithLifecycle()
    val qr by viewModel.qr.collectAsStateWithLifecycle()
    var explainNearby by rememberSaveable { mutableStateOf(false) }
    val deniedText = stringResource(R.string.perm_denied_hint)

    val nearbyLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        viewModel.refreshCapabilities()
        if (grants.values.all { granted -> granted }) viewModel.showQr(true) else toast.show(deniedText)
    }

    // The radios or permissions may have changed while the system settings were in front.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { viewModel.refreshCapabilities() }

    AeroScreen {
        AeroTopBar(title = stringResource(R.string.recv_title), onBack = { navigator.back() })
        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = AeroTheme.dimens.screenPadding, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(AeroTheme.dimens.gap),
        ) {
            item(key = "status") { ReceiveStatusCard(ui = ui, onRetry = { viewModel.retry() }) }
            if (!ui.visible) {
                item(key = "hidden") {
                    HiddenNote(onOpenSettings = { navigator.openSettingsSection(SettingsSection.CONNECTIONS) })
                }
            }
            if (ui.waiting > 0) {
                item(key = "waiting") {
                    AeroText(
                        text = pluralStringResource(R.plurals.recv_waiting, ui.waiting, ui.waiting),
                        style = AeroTheme.typography.bodyStrong,
                        color = AeroTheme.colors.accentText,
                    )
                }
            }
            item(key = "qr") {
                QrActionCard(
                    enabled = ui.status != ReceiverStatus.ERROR,
                    onClick = { viewModel.showQr(false) },
                )
            }
            item(key = "how") {
                InfoCard(title = stringResource(R.string.recv_how_title), text = stringResource(R.string.recv_how_text))
            }
            item(key = "destination") {
                InfoCard(
                    title = stringResource(R.string.recv_destination_title),
                    text = stringResource(if (ui.customFolder) R.string.recv_destination_custom else R.string.recv_destination_default),
                )
            }
            if (ui.endpoints.isNotEmpty()) {
                item(key = "advanced") { EndpointsCard(endpoints = ui.endpoints) }
            }
            item(key = "rename") {
                AeroButton(
                    text = stringResource(R.string.recv_rename_action),
                    onClick = { navigator.openSettingsSection(SettingsSection.GENERAL) },
                    style = AeroButtonStyle.Ghost,
                )
            }
        }
        StopBar(busy = ui.busy, onStop = { navigator.back() })
    }

    if (qr != QrUi.Hidden) {
        QrSheet(
            state = qr,
            hotspotOffer = ui.hotspotOffer,
            singleUse = ui.qrSingleUse,
            onHotspotChange = { wanted ->
                if (!wanted) {
                    viewModel.showQr(false)
                } else if (ui.hotspotOffer == HotspotOffer.NEEDS_PERMISSION) {
                    explainNearby = true
                } else {
                    viewModel.showQr(true)
                }
            },
            onNewCode = { viewModel.showQr(qr.hotspot) },
            onDismiss = { viewModel.closeQr() },
        )
    }
    if (explainNearby) {
        AeroDialog(
            title = stringResource(R.string.perm_nearby_title),
            message = stringResource(R.string.perm_nearby_message),
            confirmText = stringResource(R.string.common_allow),
            dismissText = stringResource(R.string.common_not_now),
            onConfirm = {
                explainNearby = false
                nearbyLauncher.launch(Permissions.nearby())
            },
            onDismiss = { explainNearby = false },
        )
    }
}
