package com.aero.share.feature.send

import android.Manifest
import android.content.Context
import android.os.Build
import com.aero.share.core.permissions.Permissions

/** Reads the current media permissions of the app and turns them into a [MediaAccess] per collection. */
internal object MediaPermissions {
    /** The permission that opens exactly this collection: per type from Android 13, one storage permission before. */
    private fun fullPermission(kind: MediaKind): String =
        if (Build.VERSION.SDK_INT >= 33) {
            when (kind) {
                MediaKind.IMAGE -> Manifest.permission.READ_MEDIA_IMAGES
                MediaKind.VIDEO -> Manifest.permission.READ_MEDIA_VIDEO
                MediaKind.AUDIO -> Manifest.permission.READ_MEDIA_AUDIO
            }
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }

    fun access(context: Context, kind: MediaKind): MediaAccess {
        val sdk = Build.VERSION.SDK_INT
        val visualSelected = sdk >= 34 && Permissions.isGranted(context, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)
        return PickerLogic.accessOf(
            sdkInt = sdk,
            kind = kind,
            fullGranted = Permissions.isGranted(context, fullPermission(kind)),
            visualSelectedGranted = visualSelected,
        )
    }

    fun tabAccess(context: Context, tab: PickerTab): MediaAccess =
        PickerLogic.tabAccess(PickerLogic.kindsOf(tab).map { kind -> access(context, kind) })

    /** The permissions to ask for when the person allows [tab]; the explanation was shown before this is used. */
    fun request(tab: PickerTab): Array<String> =
        Permissions.media(PickerLogic.categoriesOf(PickerLogic.kindsOf(tab)))
}
