package com.aero.share.core.storage

import android.content.Context
import java.io.File

/** Private staging area for incoming data of all storage backends (never user-visible, never contains finished files). */
object IncomingParts {
    fun root(context: Context): File {
        val dir = File(context.filesDir, "incoming")
        if (!dir.isDirectory) dir.mkdirs()
        return dir
    }
}
