package com.aero.share.network.discovery

import android.content.Context
import android.net.wifi.WifiManager
import android.os.SystemClock
import java.io.IOException
import java.net.DatagramPacket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.MulticastSocket
import java.net.NetworkInterface
import java.net.SocketAddress
import java.net.SocketException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * The multicast presence beacon (see [BeaconCodec]): listens on 239.255.42.99:47475 while it is started, announces this
 * device while advertising, answers queries with a unicast announcement. It is the fallback for networks where mDNS is
 * unreliable. The Wi-Fi multicast lock is held only while the socket is open.
 *
 * The address a datagram came from is the only address ever used for a device; addresses inside payloads do not exist.
 */
internal class MulticastBeacon(
    context: Context,
    private val scope: CoroutineScope,
    private val localAddresses: () -> Set<String>,
    /** What to announce right now, or null when this device must not be visible. */
    private val presence: () -> Beacon.Presence?,
    private val onPresence: (Beacon.Presence, String) -> Unit,
    private val log: (String) -> Unit,
) {
    private val wifi: WifiManager? = context.applicationContext.getSystemService(WifiManager::class.java)
    private val group: InetAddress = InetAddress.getByName(BeaconCodec.GROUP)
    private val sync = Any()
    private var socket: MulticastSocket? = null
    private var groupInterface: NetworkInterface? = null
    private var multicastLock: WifiManager.MulticastLock? = null
    private var receiveJob: Job? = null
    private var announceJob: Job? = null
    private var lastAnnounced: Beacon.Presence? = null
    private val lastReply = HashMap<String, Long>()

    val isActive: Boolean get() = synchronized(sync) { socket != null }

    /** Opens the socket on the interface of [lan]. Returns false (and logs why) when that is not possible. */
    fun start(lan: LanNetwork): Boolean {
        synchronized(sync) {
            if (socket != null) return true
            val name = lan.interfaceName
            val nif = if (name == null) null else try {
                NetworkInterface.getByName(name)
            } catch (e: SocketException) {
                null
            }
            if (nif == null) {
                log("multicast: network interface not available")
                return false
            }
            val lock = wifi?.createMulticastLock(LOCK_TAG)
            lock?.setReferenceCounted(false)
            lock?.acquire()
            try {
                val s = MulticastSocket(null as SocketAddress?)
                s.reuseAddress = true
                try {
                    lan.network.bindSocket(s)
                } catch (e: IOException) {
                    log("multicast: could not bind to the network")
                }
                s.bind(InetSocketAddress(BeaconCodec.PORT))
                s.networkInterface = nif
                s.timeToLive = 1
                s.soTimeout = RECEIVE_TIMEOUT_MS
                s.joinGroup(InetSocketAddress(group, BeaconCodec.PORT), nif)
                socket = s
                groupInterface = nif
                multicastLock = lock
                receiveJob = scope.launch(Dispatchers.IO) { receiveLoop(s) }
                return true
            } catch (e: IOException) {
                release(lock)
                log("multicast: socket failed (${e.javaClass.simpleName})")
                return false
            } catch (e: SecurityException) {
                release(lock)
                log("multicast: not permitted")
                return false
            }
        }
    }

    /** Says goodbye (if this device was announcing), leaves the group and closes everything. */
    fun stop() {
        goodbye()
        synchronized(sync) {
            val s = socket ?: return
            announceJob?.cancel()
            announceJob = null
            receiveJob?.cancel()
            receiveJob = null
            socket = null
            try {
                s.leaveGroup(InetSocketAddress(group, BeaconCodec.PORT), groupInterface)
            } catch (e: IOException) {
                // closing the socket leaves the group anyway
            }
            s.close()
            groupInterface = null
            release(multicastLock)
            multicastLock = null
            lastReply.clear()
        }
    }

    /** Starts or stops the periodic announcement. Stopping sends a goodbye. */
    fun setAdvertising(on: Boolean, intervalMs: Long) {
        synchronized(sync) {
            announceJob?.cancel()
            announceJob = null
            if (!on) {
                goodbye()
                return
            }
            if (socket == null) return
            announceJob = scope.launch(Dispatchers.IO) {
                while (isActive) {
                    announce()
                    delay(intervalMs)
                }
            }
        }
    }

    /** Asks everybody on the link to announce themselves. */
    fun query() {
        send(BeaconCodec.encodeQuery(), group, BeaconCodec.PORT)
    }

    /** Sends one announcement straight to [host] (used where multicast does not reach, e.g. a Wi-Fi Direct group). */
    fun announceTo(host: String) {
        scope.launch(Dispatchers.IO) {
            val current = presence() ?: return@launch
            val target = try {
                InetAddress.getByName(host)
            } catch (e: UnknownHostException) {
                return@launch
            }
            send(encodeOrNull(current) ?: return@launch, target, BeaconCodec.PORT)
        }
    }

    private fun announce() {
        val current = presence() ?: return
        val bytes = encodeOrNull(current) ?: return
        synchronized(sync) { lastAnnounced = current }
        send(bytes, group, BeaconCodec.PORT)
    }

    private fun goodbye() {
        val previous = synchronized(sync) {
            val value = lastAnnounced
            lastAnnounced = null
            value
        } ?: return
        send(encodeOrNull(previous.copy(goodbye = true)) ?: return, group, BeaconCodec.PORT)
    }

    private fun encodeOrNull(value: Beacon.Presence): ByteArray? =
        try {
            BeaconCodec.encode(value)
        } catch (e: IllegalArgumentException) {
            log("multicast: own announcement is invalid")
            null
        }

    private fun send(bytes: ByteArray, address: InetAddress, port: Int) {
        val s = synchronized(sync) { socket } ?: return
        try {
            s.send(DatagramPacket(bytes, bytes.size, address, port))
        } catch (e: IOException) {
            if (!s.isClosed) log("multicast: send failed (${e.javaClass.simpleName})")
        }
    }

    private fun receiveLoop(s: MulticastSocket) {
        val buffer = ByteArray(BeaconCodec.MAX_DATAGRAM + 1)
        val packet = DatagramPacket(buffer, buffer.size)
        while (!s.isClosed) {
            try {
                packet.length = buffer.size
                s.receive(packet)
            } catch (e: SocketTimeoutException) {
                continue
            } catch (e: IOException) {
                if (!s.isClosed) log("multicast: receiving stopped (${e.javaClass.simpleName})")
                return
            }
            handle(packet)
        }
    }

    private fun handle(packet: DatagramPacket) {
        val sender = packet.address ?: return
        val source = sender.hostAddress ?: return
        if (source in localAddresses()) return
        when (val beacon = BeaconCodec.decode(packet.data, packet.length)) {
            null -> Unit
            is Beacon.Query -> reply(sender, packet.port, source)
            is Beacon.Presence -> onPresence(beacon, source)
        }
    }

    /** A query is answered with one unicast announcement, at most twice per second per asker. */
    private fun reply(sender: InetAddress, port: Int, source: String) {
        val current = presence() ?: return
        val now = SystemClock.elapsedRealtime()
        synchronized(sync) {
            val last = lastReply[source]
            if (last != null && now - last < REPLY_GAP_MS) return
            if (lastReply.size > MAX_TRACKED_ASKERS) lastReply.clear()
            lastReply[source] = now
        }
        send(encodeOrNull(current) ?: return, sender, port)
    }

    private fun release(lock: WifiManager.MulticastLock?) {
        if (lock != null && lock.isHeld) lock.release()
    }

    private companion object {
        const val LOCK_TAG = "aero-share-discovery"
        const val RECEIVE_TIMEOUT_MS = 2000
        const val REPLY_GAP_MS = 500L
        const val MAX_TRACKED_ASKERS = 256
    }
}
