package com.aero.share.core.permissions

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import com.aero.share.transfer.model.FileCategory

/**
 * Central list of runtime permissions per feature. Permissions are requested only when the matching feature is first
 * used, after the UI has explained why.
 */
object Permissions {
    /** Wi-Fi Direct and local-only hotspot: NEARBY_WIFI_DEVICES on API 33+, fine location before that. */
    fun nearby(): Array<String> =
        if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.NEARBY_WIFI_DEVICES)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)

    fun camera(): Array<String> = arrayOf(Manifest.permission.CAMERA)

    fun notifications(): Array<String> =
        if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.POST_NOTIFICATIONS) else emptyArray()

    /** Permissions to browse media of [categories] through MediaStore. Documents/APK/other use the system picker. */
    fun media(categories: Set<FileCategory>): Array<String> {
        val wantsImages = FileCategory.IMAGE in categories
        val wantsVideo = FileCategory.VIDEO in categories
        val wantsAudio = FileCategory.AUDIO in categories
        return when {
            Build.VERSION.SDK_INT >= 34 -> buildList<String> {
                if (wantsImages) add(Manifest.permission.READ_MEDIA_IMAGES)
                if (wantsVideo) add(Manifest.permission.READ_MEDIA_VIDEO)
                if (wantsAudio) add(Manifest.permission.READ_MEDIA_AUDIO)
                if (wantsImages || wantsVideo) add(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)
            }.toTypedArray()
            Build.VERSION.SDK_INT >= 33 -> buildList<String> {
                if (wantsImages) add(Manifest.permission.READ_MEDIA_IMAGES)
                if (wantsVideo) add(Manifest.permission.READ_MEDIA_VIDEO)
                if (wantsAudio) add(Manifest.permission.READ_MEDIA_AUDIO)
            }.toTypedArray()
            else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }

    /** Only API 26-28 needs a write permission to save into the public Downloads folder. */
    fun legacyWrite(): Array<String> =
        if (Build.VERSION.SDK_INT <= 28) arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE) else emptyArray()

    fun isGranted(context: Context, permission: String): Boolean =
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

    fun missing(context: Context, permissions: Array<String>): List<String> =
        permissions.filter { !isGranted(context, it) }

    fun allGranted(context: Context, permissions: Array<String>): Boolean = missing(context, permissions).isEmpty()

    /**
     * On API 34+ the user may grant only selected photos/videos (READ_MEDIA_VISUAL_USER_SELECTED).
     * Listing then returns just those items; the UI must say so instead of pretending to see everything.
     */
    fun hasOnlyPartialMediaAccess(context: Context): Boolean =
        Build.VERSION.SDK_INT >= 34 &&
            isGranted(context, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED) &&
            !isGranted(context, Manifest.permission.READ_MEDIA_IMAGES) &&
            !isGranted(context, Manifest.permission.READ_MEDIA_VIDEO)
}
