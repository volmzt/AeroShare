package com.aero.share.feature.send

import com.aero.share.domain.AppItem
import com.aero.share.domain.FileItem
import com.aero.share.domain.FolderItem
import com.aero.share.domain.SelectionItem
import com.aero.share.transfer.model.FileCategory

/**
 * Totals of a selection. Sizes that are not known are never guessed: they are counted in [unknownSizeEntries] so the
 * screens can say that the total is incomplete.
 */
internal data class SelectionSummary(
    /** Entries the person chose: single files, folders and apps. */
    val entries: Int,
    /** Files that will actually be transferred, including the files inside the chosen folders. */
    val files: Int,
    val folders: Int,
    val apps: Int,
    val knownBytes: Long,
    val unknownSizeEntries: Int,
    /** Files and apps per category, in the order of [FileCategory]; folders are counted in [folders]. */
    val categories: List<Pair<FileCategory, Int>>,
) {
    val isEmpty: Boolean get() = entries == 0
    val sizeIsPartial: Boolean get() = unknownSizeEntries > 0
}

internal object SelectionMath {
    fun summarize(items: List<SelectionItem>): SelectionSummary {
        var files = 0
        var folders = 0
        var apps = 0
        var known = 0L
        var unknown = 0
        val counts = java.util.EnumMap<FileCategory, Int>(FileCategory::class.java)
        for (item in items) {
            if (item.size >= 0L) known += item.size else unknown++
            when (item) {
                is FileItem -> {
                    files++
                    counts[item.category] = (counts[item.category] ?: 0) + 1
                }
                is AppItem -> {
                    apps++
                    files++
                    counts[FileCategory.APK] = (counts[FileCategory.APK] ?: 0) + 1
                }
                is FolderItem -> {
                    folders++
                    files += item.fileCount.coerceAtLeast(0)
                }
            }
        }
        val categories = FileCategory.values().filter { counts.containsKey(it) }.map { it to (counts[it] ?: 0) }
        return SelectionSummary(
            entries = items.size,
            files = files,
            folders = folders,
            apps = apps,
            knownBytes = known,
            unknownSizeEntries = unknown,
            categories = categories,
        )
    }

    /** The tab chips of the picker show a dot when the selection already holds something of that kind. */
    fun ids(items: List<SelectionItem>): Set<String> {
        val result = HashSet<String>(items.size * 2)
        for (item in items) result.add(item.id)
        return result
    }
}
