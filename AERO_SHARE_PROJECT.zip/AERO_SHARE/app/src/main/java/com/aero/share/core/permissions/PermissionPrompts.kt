package com.aero.share.core.permissions

import android.content.Context

/**
 * Remembers which permission explanations were already shown, so the person is asked once at the right moment and is never
 * nagged. Only a yes/no flag per explanation is stored, on this device only.
 */
internal object PermissionPrompts {
    /** The notification permission, asked before the first transfer. */
    const val NOTIFICATIONS = "notifications"

    private const val FILE = "aero_permission_prompts"

    fun wasShown(context: Context, key: String): Boolean =
        context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE).getBoolean(key, false)

    fun markShown(context: Context, key: String) {
        context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putBoolean(key, true).apply()
    }
}
