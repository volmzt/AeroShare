package com.aero.share.feature.history

import com.aero.share.domain.HistoryFile
import com.aero.share.domain.HistoryItem
import com.aero.share.domain.HistoryStatus
import com.aero.share.feature.transfer.TransferLogic
import com.aero.share.transfer.model.TransferDirection
import java.util.TimeZone

internal enum class DirectionFilter { ALL, SENT, RECEIVED }

internal enum class StatusFilter { ALL, COMPLETED, FAILED, CANCELLED }

internal enum class DayBucket { TODAY, YESTERDAY, OTHER }

/** The two filter rows of the History screen. */
internal data class HistoryFilters(
    val direction: DirectionFilter = DirectionFilter.ALL,
    val status: StatusFilter = StatusFilter.ALL,
) {
    val active: Boolean get() = direction != DirectionFilter.ALL || status != StatusFilter.ALL
}

/** Records of one calendar day. [day] counts days since 1970 in the local time zone; [anchor] is the first record's time. */
internal data class HistoryGroup(val bucket: DayBucket, val day: Long, val anchor: Long, val items: List<HistoryItem>)

/** Decisions of the History screen that do not need Android, kept apart so they can be unit-tested. */
internal object HistoryLogic {
    /** The detail sheet lists this many files; the rest is summarised as "and N more". */
    const val MAX_LISTED_FILES = 100

    private const val DAY_MS = 86_400_000L

    fun matches(item: HistoryItem, filters: HistoryFilters): Boolean {
        val directionMatches = when (filters.direction) {
            DirectionFilter.ALL -> true
            DirectionFilter.SENT -> item.direction == TransferDirection.SEND
            DirectionFilter.RECEIVED -> item.direction == TransferDirection.RECEIVE
        }
        val statusMatches = when (filters.status) {
            StatusFilter.ALL -> true
            StatusFilter.COMPLETED -> item.status == HistoryStatus.COMPLETED
            StatusFilter.FAILED -> item.status == HistoryStatus.FAILED
            StatusFilter.CANCELLED -> item.status == HistoryStatus.CANCELLED
        }
        return directionMatches && statusMatches
    }

    fun filter(items: List<HistoryItem>, filters: HistoryFilters): List<HistoryItem> =
        if (filters.active) items.filter { item -> matches(item, filters) } else items

    /** Days since 1970-01-01 of [millis] on the calendar of [zone]. */
    fun epochDay(millis: Long, zone: TimeZone): Long = Math.floorDiv(millis + zone.getOffset(millis), DAY_MS)

    fun bucket(now: Long, then: Long, zone: TimeZone): DayBucket {
        val today = epochDay(now, zone)
        return when (epochDay(then, zone)) {
            today -> DayBucket.TODAY
            today - 1L -> DayBucket.YESTERDAY
            else -> DayBucket.OTHER
        }
    }

    /** Splits a newest-first list into runs of the same calendar day, keeping the order. */
    fun group(items: List<HistoryItem>, now: Long, zone: TimeZone): List<HistoryGroup> {
        val groups = ArrayList<HistoryGroup>()
        var run: MutableList<HistoryItem>? = null
        var runDay = 0L
        var runAnchor = 0L
        for (item in items) {
            val day = epochDay(item.timestamp, zone)
            val open = run
            if (open != null && day == runDay) {
                open.add(item)
            } else {
                if (open != null) groups.add(HistoryGroup(bucket(now, runAnchor, zone), runDay, runAnchor, open))
                val fresh = ArrayList<HistoryItem>()
                fresh.add(item)
                run = fresh
                runDay = day
                runAnchor = item.timestamp
            }
        }
        val last = run
        if (last != null) groups.add(HistoryGroup(bucket(now, runAnchor, zone), runDay, runAnchor, last))
        return groups
    }

    /** The files the detail sheet lists. */
    fun listedFiles(item: HistoryItem): List<HistoryFile> =
        if (item.files.size <= MAX_LISTED_FILES) item.files else item.files.subList(0, MAX_LISTED_FILES)

    /** How many files are not listed. */
    fun hiddenFileCount(item: HistoryItem): Int = (item.files.size - MAX_LISTED_FILES).coerceAtLeast(0)

    /** Files that exist on this device and can be opened: received ones, which carry a URI. Sent files have none. */
    fun openableFiles(item: HistoryItem): List<HistoryFile> = item.files.filter { file -> !file.uri.isNullOrEmpty() }

    /** The system share sheet gets a bounded number of files. */
    fun canShare(item: HistoryItem): Boolean = openableFiles(item).size in 1..TransferLogic.MAX_SHARE_FILES

    /** Fewer files arrived than were planned: the row says "2 of 5 files". */
    fun filesPartial(item: HistoryItem): Boolean =
        item.status != HistoryStatus.COMPLETED && item.fileCount > 0 && item.completedFiles < item.fileCount

    /** Some, but not all, of the bytes moved: the row says "1.2 MB of 3.4 MB". */
    fun bytesPartial(item: HistoryItem): Boolean =
        item.status != HistoryStatus.COMPLETED && item.totalBytes > 0L && item.transferredBytes in 1L until item.totalBytes

    /** Declined, cancelled and failed records say why when the reason is known. */
    fun showsFailure(item: HistoryItem): Boolean = item.status != HistoryStatus.COMPLETED && item.failure != null
}
