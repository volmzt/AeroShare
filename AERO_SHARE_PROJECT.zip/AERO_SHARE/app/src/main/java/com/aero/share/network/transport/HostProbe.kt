package com.aero.share.network.transport

import com.aero.share.transfer.engine.SocketConnector
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/** [host] is the first address that accepted a connection, or null when none did. */
internal data class ProbeSummary(val host: String?, val outcomes: List<ProbeOutcome>)

/**
 * Finds out which address of a device accepts a TCP connection. Attempts run in parallel; the first success wins and
 * the rest are left to finish on their own (a blocking connect cannot be interrupted, but it is bounded by the timeout).
 * The probe connects and closes at once: no TLS handshake, no data, nothing that identifies the user.
 */
internal class HostProbe(private val scope: CoroutineScope) {
    suspend fun probeAny(hosts: List<String>, port: Int, timeoutMs: Int, connector: SocketConnector): ProbeSummary {
        val unique = hosts.distinct()
        if (unique.isEmpty()) return ProbeSummary(null, emptyList())
        val done = CompletableDeferred<ProbeSummary>()
        val outcomes = CopyOnWriteArrayList<ProbeOutcome>()
        val remaining = AtomicInteger(unique.size)
        for (host in unique) {
            scope.launch(Dispatchers.IO) {
                val outcome = probeOnce(connector, host, port, timeoutMs)
                outcomes.add(outcome)
                if (outcome == ProbeOutcome.REACHABLE) {
                    done.complete(ProbeSummary(host, outcomes.toList()))
                } else if (remaining.decrementAndGet() == 0) {
                    done.complete(ProbeSummary(null, outcomes.toList()))
                }
            }
        }
        return withTimeoutOrNull(timeoutMs.toLong() + GRACE_MS) { done.await() }
            ?: ProbeSummary(null, listOf(ProbeOutcome.TIMED_OUT))
    }

    /** Tries [hosts] up to [attempts] times, [pauseMs] apart (a freshly formed Wi-Fi Direct link needs a moment). */
    suspend fun probeWithRetry(
        hosts: List<String>,
        port: Int,
        timeoutMs: Int,
        connector: SocketConnector,
        attempts: Int,
        pauseMs: Long,
    ): ProbeSummary {
        var last = ProbeSummary(null, emptyList())
        for (attempt in 0 until attempts) {
            last = probeAny(hosts, port, timeoutMs, connector)
            if (last.host != null) return last
            if (attempt < attempts - 1) kotlinx.coroutines.delay(pauseMs)
        }
        return last
    }

    private fun probeOnce(connector: SocketConnector, host: String, port: Int, timeoutMs: Int): ProbeOutcome {
        return try {
            val socket = connector.connect(host, port, timeoutMs)
            try {
                socket.close()
            } catch (e: java.io.IOException) {
                // the connection was established; closing problems do not matter
            }
            ProbeOutcome.REACHABLE
        } catch (e: Exception) {
            ProbeClassifier.classify(e)
        }
    }

    private companion object {
        const val GRACE_MS = 1_000L
    }
}
