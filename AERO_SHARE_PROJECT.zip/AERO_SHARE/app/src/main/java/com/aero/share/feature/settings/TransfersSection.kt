package com.aero.share.feature.settings

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.runtime.Composable
import androidx.compose.ui.res.stringResource
import com.aero.share.R
import com.aero.share.core.designsystem.AeroChoiceRow
import com.aero.share.core.designsystem.AeroDivider
import com.aero.share.core.designsystem.AeroGroup
import com.aero.share.core.designsystem.AeroSectionHeader
import com.aero.share.core.designsystem.AeroSettingsRow
import com.aero.share.domain.AppSettings
import com.aero.share.navigation.AeroNavigator
import com.aero.share.navigation.SettingsSection
import com.aero.share.transfer.model.CompressionMode
import com.aero.share.transfer.model.ConflictPolicy

/** How files are sent and stored, and when leftovers are cleaned up. */
@Composable
internal fun TransfersSection(settings: AppSettings, viewModel: SettingsViewModel, navigator: AeroNavigator) {
    AeroSectionHeader(text = stringResource(R.string.set_receiving_header))
    AeroGroup {
        ReceiveFolderRows(
            settings = settings,
            onChosen = { uri -> viewModel.update { current -> current.copy(saveDirectoryUri = uri) } },
        )
        AeroDivider()
        AutoAcceptRow(settings = settings, viewModel = viewModel)
        AeroDivider()
        AeroSettingsRow(
            title = stringResource(R.string.set_transfer_notifications_title),
            subtitle = stringResource(R.string.set_transfer_notifications_text),
            icon = Icons.Rounded.Notifications,
            onClick = { navigator.openSettingsSection(SettingsSection.GENERAL) },
        )
    }

    AeroSectionHeader(text = stringResource(R.string.set_sending_header))
    AeroGroup {
        AeroChoiceRow(
            title = stringResource(R.string.set_compression_title),
            subtitle = stringResource(R.string.set_compression_text),
            options = CompressionMode.entries.map { option -> option to stringResource(option.labelRes()) },
            selected = settings.compression,
            onSelected = { option -> viewModel.update { current -> current.copy(compression = option) } },
        )
        AeroDivider()
        AeroChoiceRow(
            title = stringResource(R.string.set_conflict_title),
            subtitle = stringResource(R.string.set_conflict_text),
            options = ConflictPolicy.entries.map { option -> option to stringResource(option.labelRes()) },
            selected = settings.conflictPolicy,
            onSelected = { option -> viewModel.update { current -> current.copy(conflictPolicy = option) } },
        )
        AeroDivider()
        AeroChoiceRow(
            title = stringResource(R.string.set_warn_title),
            subtitle = stringResource(R.string.set_warn_text),
            options = SettingsLogic.LARGE_TRANSFER_WARN_BYTES.map { bytes -> bytes to warnBytesText(bytes) },
            selected = SettingsLogic.nearestLong(SettingsLogic.LARGE_TRANSFER_WARN_BYTES, settings.largeTransferWarnBytes),
            onSelected = { bytes -> viewModel.update { current -> current.copy(largeTransferWarnBytes = bytes) } },
        )
    }

    AeroSectionHeader(text = stringResource(R.string.set_cleanup_header))
    AeroGroup {
        AeroChoiceRow(
            title = stringResource(R.string.set_partial_title),
            subtitle = stringResource(R.string.set_partial_text),
            options = SettingsLogic.PARTIAL_RETENTION_DAYS.map { days -> days to daysText(days) },
            selected = SettingsLogic.nearestInt(SettingsLogic.PARTIAL_RETENTION_DAYS, settings.partialRetentionDays),
            onSelected = { days -> viewModel.update { current -> current.copy(partialRetentionDays = days) } },
        )
        AeroDivider()
        AeroChoiceRow(
            title = stringResource(R.string.set_history_title),
            subtitle = stringResource(R.string.set_history_text),
            options = SettingsLogic.HISTORY_RETENTION_DAYS.map { days -> days to historyDaysText(days) },
            selected = SettingsLogic.nearestInt(SettingsLogic.HISTORY_RETENTION_DAYS, settings.historyRetentionDays),
            onSelected = { days -> viewModel.update { current -> current.copy(historyRetentionDays = days) } },
        )
    }
    SettingsNote(text = stringResource(R.string.set_cleanup_note))
}
