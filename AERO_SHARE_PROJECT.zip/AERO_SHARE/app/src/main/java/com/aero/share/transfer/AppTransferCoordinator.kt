package com.aero.share.transfer

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.SystemClock
import androidx.core.content.ContextCompat
import com.aero.share.BuildConfig
import com.aero.share.core.common.DiagnosticsLog
import com.aero.share.core.storage.DestinationResolver
import com.aero.share.core.storage.source.SendSourceFactory
import com.aero.share.domain.DeviceRepository
import com.aero.share.domain.DiscoveryController
import com.aero.share.domain.FolderItem
import com.aero.share.domain.HistoryRepository
import com.aero.share.domain.LocalDeviceProvider
import com.aero.share.domain.PairingQrResult
import com.aero.share.domain.PendingIncoming
import com.aero.share.domain.PowerPolicy
import com.aero.share.domain.ReceiverState
import com.aero.share.domain.ReceiverStatus
import com.aero.share.domain.Recipient
import com.aero.share.domain.SendJob
import com.aero.share.domain.SettingsRepository
import com.aero.share.domain.TransferCoordinator
import com.aero.share.domain.TransportPlanner
import com.aero.share.transfer.engine.PeerPolicy
import com.aero.share.transfer.model.Capabilities
import com.aero.share.transfer.model.LocalPeer
import com.aero.share.transfer.model.TransferControl
import com.aero.share.transfer.model.TransferDirection
import com.aero.share.transfer.model.TransferSnapshot
import com.aero.share.transfer.model.TransferState
import com.aero.share.transfer.model.TransferTracker
import com.aero.share.transfer.queue.QueuedJob
import com.aero.share.transfer.queue.TransferQueue
import com.aero.share.transfer.security.DeviceIdentity
import com.aero.share.transfer.service.Notifications
import com.aero.share.transfer.service.ServiceAction
import com.aero.share.transfer.service.ServiceState
import com.aero.share.transfer.service.ServiceTransfer
import com.aero.share.transfer.service.TransferService
import com.aero.share.transfer.service.TransferServiceBridge
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/**
 * The one object the UI talks to for transfers. It wires the engine (queue, sender, receiver), the route planner, the
 * foreground service, notifications, history and the device list together:
 *
 * - sending goes through a sequential queue ([SendFlow]); receiving through [ReceiveFlow] and [ReceiverController];
 * - [transfers] merges both into one list, newest first, and every finished transfer is written to the history once;
 * - the foreground service is started when something is active or the receiver listens and stops itself when idle.
 */
class AppTransferCoordinator(
    context: Context,
    scope: CoroutineScope,
    identity: DeviceIdentity,
    private val settings: SettingsRepository,
    private val localDevice: LocalDeviceProvider,
    devices: DeviceRepository,
    private val history: HistoryRepository,
    peerPolicy: PeerPolicy,
    discovery: DiscoveryController,
    planner: TransportPlanner,
    private val power: PowerPolicy,
    destination: DestinationResolver,
    sources: SendSourceFactory,
    private val diagnostics: DiagnosticsLog,
) : TransferCoordinator, TransferServiceBridge.Host {

    private val appContext: Context = context.applicationContext

    /** Same scope as the app's, plus a handler that records an unexpected error instead of crashing the process. */
    private val work: CoroutineScope = CoroutineScope(
        scope.coroutineContext + CoroutineExceptionHandler { _, error ->
            diagnostics.add("internal", "uncaught " + error.javaClass.simpleName)
        },
    )

    private val hasWifiDirect: Boolean =
        appContext.packageManager.hasSystemFeature(PackageManager.FEATURE_WIFI_DIRECT)

    private val sequence = AtomicLong(0L)
    private val order = ConcurrentHashMap<String, Long>()
    private val recorded = ConcurrentHashMap<String, String>()
    private val watchers = ConcurrentHashMap<String, MutableStateFlow<TransferSnapshot?>>()
    private val seen = ConcurrentHashMap.newKeySet<String>()
    private val serviceRequested = AtomicBoolean(false)

    @Volatile
    private var lastServiceAttempt = 0L

    private val transfersState = MutableStateFlow<List<TransferSnapshot>>(emptyList())
    private val activeState = MutableStateFlow(0)
    private val hotspot = HotspotState()
    private val notifier = TransferNotifier(appContext, settings)

    private val receiveFlow = ReceiveFlow(
        scope = work,
        settings = settings,
        power = power,
        devices = devices,
        history = history,
        notifier = notifier,
        hotspot = hotspot,
        diagnostics = diagnostics,
        onSessionStarted = { id -> order[id] = sequence.incrementAndGet() },
    )
    private val sendFlow = SendFlow(
        identity = identity,
        localPeer = { localPeer() },
        settings = settings,
        power = power,
        planner = planner,
        sources = sources,
        devices = devices,
        diagnostics = diagnostics,
    )
    private val queue = TransferQueue<SendPayload>(work, { job -> sendFlow.execute(job) })
    private val receiverController = ReceiverController(
        scope = work,
        identity = identity,
        localPeer = { localPeer() },
        localDevice = localDevice,
        peerPolicy = peerPolicy,
        power = power,
        destination = destination,
        discovery = discovery,
        listener = receiveFlow,
        diagnostics = diagnostics,
    )
    private val pairing = PairingQr(
        scope = work,
        receiver = receiverController,
        localDevice = localDevice,
        settings = settings,
        planner = planner,
        hotspot = hotspot,
        activeCount = activeState,
        diagnostics = diagnostics,
    )

    override val transfers: StateFlow<List<TransferSnapshot>> get() = transfersState
    override val pendingIncoming: StateFlow<List<PendingIncoming>> get() = receiveFlow.pending
    override val receiver: StateFlow<ReceiverState> get() = receiverController.state
    override val activeCount: StateFlow<Int> get() = activeState

    // ---------------------------------------------------------------- sending

    override fun send(job: SendJob): List<String> {
        if (job.items.isEmpty() || job.recipients.isEmpty()) return emptyList()
        // Rough totals so the transfer card is not empty while the selection is being prepared; the engine replaces
        // them with the exact numbers as soon as the files are resolved. No progress is ever invented.
        var estimatedFiles = 0
        var estimatedBytes = 0L
        for (item in job.items) {
            estimatedFiles += if (item is FolderItem) item.fileCount.coerceAtLeast(1) else 1
            estimatedBytes += item.size.coerceAtLeast(0L)
        }
        val ids = ArrayList<String>(job.recipients.size)
        for (recipient in job.recipients) {
            val id = UUID.randomUUID().toString()
            val snapshot = TransferSnapshot(
                id = id,
                direction = TransferDirection.SEND,
                state = TransferState.WAITING,
                peerName = DisplayText.clean(recipientName(recipient)),
                totalFiles = estimatedFiles,
                totalBytes = estimatedBytes,
            )
            order[id] = sequence.incrementAndGet()
            queue.enqueue(QueuedJob(id, SendPayload(job.items, recipient), TransferTracker(snapshot), TransferControl()))
            ids.add(id)
        }
        return ids
    }

    private fun recipientName(recipient: Recipient): String = when (recipient) {
        is Recipient.Nearby -> recipient.device.name
        is Recipient.Qr -> recipient.payload.name
        is Recipient.Manual -> recipient.host
    }

    // ---------------------------------------------------------------- receiving

    override fun startReceiving() {
        receiverController.request(true)
    }

    override fun stopReceiving() {
        pairing.shutdown()
        receiverController.request(false)
    }

    override fun respond(transferId: String, accept: Boolean) {
        receiveFlow.respond(transferId, accept)
    }

    override suspend fun createPairingQr(includeHotspot: Boolean): PairingQrResult = pairing.create(includeHotspot)

    // ---------------------------------------------------------------- controls

    override fun pause(id: String) {
        if (!receiveFlow.pause(id)) queue.pause(id)
    }

    override fun resume(id: String) {
        if (!receiveFlow.resume(id)) queue.resume(id)
    }

    override fun cancel(id: String) {
        if (!receiveFlow.cancel(id)) queue.cancel(id)
    }

    /** Only sent transfers can be retried from here; a received one is retried by the device that sends it. */
    override fun retry(id: String) {
        if (queue.get(id) == null) return
        order[id] = sequence.incrementAndGet()
        queue.retry(id)
    }

    override fun dismiss(id: String) {
        val snapshot = transfersState.value.firstOrNull { it.id == id } ?: return
        val finished = snapshot.state.isTerminal || snapshot.state == TransferState.INTERRUPTED
        if (!finished) return
        if (!receiveFlow.dismiss(id)) queue.remove(id)
        order.remove(id)
        recorded.remove(id)
    }

    override fun observe(id: String): StateFlow<TransferSnapshot?> =
        watchers.getOrPut(id) { MutableStateFlow(transfersState.value.firstOrNull { it.id == id }) }

    // ---------------------------------------------------------------- foreground service callbacks

    override fun onServiceAction(action: ServiceAction, transferId: String?) {
        when (action) {
            ServiceAction.PAUSE -> if (transferId != null) pause(transferId)
            ServiceAction.RESUME -> if (transferId != null) resume(transferId)
            ServiceAction.CANCEL -> if (transferId != null) cancel(transferId)
            ServiceAction.ACCEPT -> if (transferId != null) respond(transferId, true)
            ServiceAction.DECLINE -> if (transferId != null) respond(transferId, false)
            ServiceAction.STOP_RECEIVING -> stopReceiving()
        }
    }

    /** The system's time budget for the service is over: end everything cleanly, sends stay resumable. */
    override fun onServiceTimeout() {
        diagnostics.add("service", "foreground time budget used up")
        work.launch {
            sendFlow.interruptAll()
            pairing.shutdown()
            receiverController.request(false).await()
        }
    }

    override fun onServiceStopped() {
        serviceRequested.set(false)
    }

    // ---------------------------------------------------------------- derived state

    private class Sources(
        val sends: List<TransferSnapshot>,
        val receives: List<TransferSnapshot>,
        val receiver: ReceiverState,
    )

    private fun start() {
        TransferServiceBridge.attach(this)
        work.launch {
            combine(queue.snapshots, receiveFlow.snapshots, receiverController.state) { sends, receives, receiverState ->
                Sources(sends, receives.values.toList(), receiverState)
            }.collect { sources -> publish(sources) }
        }
        work.launch {
            // Channel names are stored by the system; rename them when the in-app language changes.
            settings.settings.map { it.language }.distinctUntilChanged().drop(1).collect {
                Notifications.createChannels(appContext)
            }
        }
    }

    private fun publish(sources: Sources) {
        val merged = TransferListMerge.merge(sources.sends, sources.receives) { id ->
            order.getOrPut(id) { sequence.incrementAndGet() }
        }
        transfersState.value = merged

        var active = 0
        var waiting = 0
        val activeTransfers = ArrayList<ServiceTransfer>()
        for (snapshot in merged) {
            if (snapshot.state.isActive) {
                active++
                activeTransfers.add(
                    ServiceTransfer(
                        id = snapshot.id,
                        direction = snapshot.direction,
                        state = snapshot.state,
                        transferredBytes = snapshot.transferredBytes,
                        totalBytes = snapshot.totalBytes,
                        bytesPerSecond = snapshot.bytesPerSecond,
                    ),
                )
            } else if (snapshot.state == TransferState.WAITING) {
                waiting++
            }
        }
        activeState.value = active
        val receiving = sources.receiver.status == ReceiverStatus.LISTENING ||
            sources.receiver.status == ReceiverStatus.STARTING
        pushService(ServiceState(activeTransfers, waiting, receiving, power.useLowLatencyWifiLock()))

        updateObservers(merged)
        recordFinished(merged)
        trimFinished(merged)
    }

    private fun pushService(state: ServiceState) {
        TransferServiceBridge.update(state)
        if (state.idle) {
            serviceRequested.set(false)
            return
        }
        if (serviceRequested.get()) return
        val now = SystemClock.elapsedRealtime()
        val previous = lastServiceAttempt
        if (previous != 0L && now - previous < SERVICE_RETRY_MS) return
        lastServiceAttempt = now
        if (serviceRequested.compareAndSet(false, true)) startService()
    }

    private fun startService() {
        try {
            ContextCompat.startForegroundService(appContext, Intent(appContext, TransferService::class.java))
        } catch (e: RuntimeException) {
            // For example "not allowed to start a foreground service right now". Transfers keep running while the app is
            // alive; the next state change tries again after a short pause.
            serviceRequested.set(false)
            diagnostics.add("service", "start refused: " + e.javaClass.simpleName)
        }
    }

    private fun updateObservers(list: List<TransferSnapshot>) {
        if (watchers.isEmpty()) return
        val byId = HashMap<String, TransferSnapshot>(list.size * 2 + 1)
        for (snapshot in list) byId[snapshot.id] = snapshot
        for ((id, flow) in watchers) {
            val snapshot = byId[id]
            if (snapshot != null) {
                seen.add(id)
                if (flow.value != snapshot) flow.value = snapshot
            } else if (seen.remove(id)) {
                // It existed and is gone: dismissed. Observers see null once, then the entry is dropped.
                flow.value = null
                watchers.remove(id)
            }
        }
    }

    /** Writes each finished transfer to the history exactly once per final state, and posts the result notification. */
    private fun recordFinished(list: List<TransferSnapshot>) {
        for (snapshot in list) {
            val over = snapshot.state.isTerminal || snapshot.state == TransferState.INTERRUPTED
            if (!over) continue
            val key = snapshot.state.name + ":" + (snapshot.finishedAt ?: 0L)
            if (recorded.put(snapshot.id, key) == key) continue
            onFinished(snapshot)
        }
    }

    private fun onFinished(snapshot: TransferSnapshot) {
        val items = if (snapshot.direction == TransferDirection.SEND) queue.get(snapshot.id)?.payload?.items else null
        val item = HistoryMapper.fromSnapshot(snapshot, items, System.currentTimeMillis())
        if (item != null) {
            work.launch {
                try {
                    history.add(item)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    diagnostics.add("history", "write failed: " + e.javaClass.simpleName)
                }
            }
        }
        notifier.result(snapshot)
    }

    /** The in-memory list keeps the newest finished transfers only; the history database keeps the rest. */
    private fun trimFinished(list: List<TransferSnapshot>) {
        var finished = 0
        for (snapshot in list) {
            val over = snapshot.state.isTerminal || snapshot.state == TransferState.INTERRUPTED
            if (!over) continue
            finished++
            if (finished > MAX_FINISHED_KEPT) dismiss(snapshot.id)
        }
    }

    private fun localPeer(): LocalPeer {
        val info = localDevice.info.value
        var capabilities = Capabilities.ALL
        if (!hasWifiDirect || !settings.settings.value.wifiDirectEnabled) {
            capabilities = capabilities and Capabilities.WIFI_DIRECT.inv()
        }
        return LocalPeer(
            deviceId = info.deviceId,
            name = info.name,
            kind = info.kind,
            appVersion = BuildConfig.VERSION_NAME,
            capabilities = capabilities,
        )
    }

    init {
        start()
    }

    private companion object {
        const val MAX_FINISHED_KEPT = 50
        const val SERVICE_RETRY_MS = 5_000L
    }
}
