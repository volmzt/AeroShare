package com.aero.share.core.storage.source

import com.aero.share.transfer.engine.SendableFile

/**
 * The user's selection turned into streams the engine can send.
 * [skipped] counts folder entries that could not be sent (unreadable or of unknown size). [cleanup] deletes temporary
 * files (APK bundles) and must be called when the transfer is over.
 */
class ResolvedSelection(
    val files: List<SendableFile>,
    val title: String?,
    val cleanup: () -> Unit,
    val skipped: Int = 0,
)
