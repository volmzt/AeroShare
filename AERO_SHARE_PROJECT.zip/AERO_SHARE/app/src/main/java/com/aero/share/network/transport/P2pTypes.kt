package com.aero.share.network.transport

/** A formed Wi-Fi Direct group as seen from this device. */
data class P2pGroup(
    val groupOwnerAddress: String,
    val isGroupOwner: Boolean,
    /** The other device's address when this device is the group owner (learned from its hello datagram). */
    val clientAddress: String?,
) {
    /** The address of the OTHER device: the group owner for a client, the learned client address for the group owner. */
    val peerAddress: String? get() = if (isGroupOwner) clientAddress else groupOwnerAddress
}

enum class P2pFailure { UNSUPPORTED, PERMISSION, RADIO_OFF, BUSY, TIMEOUT, DECLINED, PEER_ADDRESS_UNKNOWN, FAILED }

/** Why a Wi-Fi Direct connection could not be made. The message is technical and non-sensitive; the UI uses [reason]. */
class P2pException(val reason: P2pFailure, message: String) : Exception(message)
