package com.aero.share.core.storage.apk

import android.content.ActivityNotFoundException
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.os.Build
import com.aero.share.R
import com.aero.share.core.common.LocaleHelper

/**
 * Receives the status of a PackageInstaller session. When Android needs the user's confirmation it hands over an intent
 * that is started here; nothing is ever installed without that confirmation. Results go to [InstallEvents].
 */
class InstallResultReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val uri = intent.getStringExtra(EXTRA_URI).orEmpty()
        val status = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE)
        when (status) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> confirm(context, intent, uri)
            PackageInstaller.STATUS_SUCCESS ->
                InstallEvents.emit(InstallEvent.Success(intent.getStringExtra(PackageInstaller.EXTRA_PACKAGE_NAME)))
            PackageInstaller.STATUS_FAILURE_ABORTED -> InstallEvents.emit(InstallEvent.Cancelled)
            else -> InstallEvents.emit(
                InstallEvent.Failure(failureText(context, status, intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE))),
            )
        }
    }

    private fun confirm(context: Context, result: Intent, uri: String) {
        val prompt: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            result.getParcelableExtra(Intent.EXTRA_INTENT, Intent::class.java)
        } else {
            legacyPrompt(result)
        }
        if (prompt == null) {
            InstallEvents.emit(InstallEvent.Failure(failureText(context, PackageInstaller.STATUS_FAILURE, null)))
            return
        }
        prompt.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            context.startActivity(prompt)
            InstallEvents.emit(InstallEvent.Started(uri))
        } catch (e: ActivityNotFoundException) {
            InstallEvents.emit(InstallEvent.Failure(failureText(context, PackageInstaller.STATUS_FAILURE, e.message)))
        } catch (e: SecurityException) {
            InstallEvents.emit(InstallEvent.Failure(failureText(context, PackageInstaller.STATUS_FAILURE, e.message)))
        }
    }

    @Suppress("DEPRECATION") // the typed overload exists only on Android 13+
    private fun legacyPrompt(result: Intent): Intent? = result.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)

    private fun failureText(context: Context, status: Int, systemMessage: String?): String {
        val res = when (status) {
            PackageInstaller.STATUS_FAILURE_BLOCKED -> R.string.apk_fail_blocked
            PackageInstaller.STATUS_FAILURE_CONFLICT -> R.string.apk_fail_conflict
            PackageInstaller.STATUS_FAILURE_INCOMPATIBLE -> R.string.apk_fail_incompatible
            PackageInstaller.STATUS_FAILURE_INVALID -> R.string.apk_fail_invalid
            PackageInstaller.STATUS_FAILURE_STORAGE -> R.string.apk_fail_storage
            else -> R.string.apk_fail_generic
        }
        val text = LocaleHelper.wrap(context).getString(res)
        // The system text is English only; it is appended as a technical detail, never shown alone.
        return if (systemMessage.isNullOrBlank()) text else "$text ($systemMessage)"
    }

    companion object {
        const val ACTION_RESULT = "com.aero.share.action.INSTALL_RESULT"
        const val EXTRA_URI = "com.aero.share.extra.URI"
    }
}
