package com.aero.share.core.storage

import android.os.StatFs
import java.io.File

/** Free space helper; null means "unknown" (never a guessed number). */
object StorageSpace {
    fun freeBytes(path: File?): Long? {
        if (path == null) return null
        return try {
            val existing = generateSequence(path) { it.parentFile }.firstOrNull { it.exists() } ?: return null
            StatFs(existing.path).availableBytes
        } catch (e: IllegalArgumentException) {
            null
        } catch (e: RuntimeException) {
            null
        }
    }
}
