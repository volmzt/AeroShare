package com.aero.share.feature.receive

import androidx.compose.ui.graphics.ImageBitmap
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aero.share.di.AppContainer
import com.aero.share.domain.AppSettings
import com.aero.share.domain.PairingQrResult
import com.aero.share.domain.ReceiverState
import com.aero.share.domain.ReceiverStatus
import com.aero.share.domain.TransportCapability
import com.aero.share.domain.Visibility
import com.aero.share.network.pairing.QrCodes
import com.aero.share.transfer.PairingReasons
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

internal data class ReceiveUi(
    val deviceName: String,
    val status: ReceiverStatus,
    val visible: Boolean,
    /** "address:port" lines, only when the advanced connection setting is on. */
    val endpoints: List<String>,
    val hotspotOffer: HotspotOffer,
    /** Saving into a folder the person chose (otherwise Downloads/AERO SHARE). */
    val customFolder: Boolean,
    /** A pairing code works once (otherwise a few times) until it expires. */
    val qrSingleUse: Boolean,
    /** Incoming requests waiting for an answer. */
    val waiting: Int,
    /** A transfer is running right now, so receiving cannot simply be switched off. */
    val busy: Boolean,
)

/** What the QR sheet shows. [hotspot] is whether a temporary hotspot was asked for. */
internal sealed interface QrUi {
    val hotspot: Boolean

    data object Hidden : QrUi {
        override val hotspot: Boolean get() = false
    }

    data class Loading(override val hotspot: Boolean) : QrUi

    data class Ready(
        val image: ImageBitmap,
        val expiresAt: Long,
        override val hotspot: Boolean,
        /** The hotspot really is part of the code (it can fail even though it was asked for). */
        val hotspotIncluded: Boolean,
    ) : QrUi

    data class Failed(val reason: String, override val hotspot: Boolean) : QrUi
}

/** One lease for the whole process: all Receive screens share it. */
private val receiveLease = ReceiveLease()

/**
 * Receiving is on while the Receive screen is open: the receiver listens, announces this device (unless it is hidden) and can
 * create pairing codes. Leaving the screen switches it off again, or, when a transfer is still running, as soon as that
 * transfer has ended.
 */
internal class ReceiveViewModel(private val container: AppContainer) : ViewModel() {
    private val coordinator = container.coordinator
    private var qrRequest = 0
    private val qrState = MutableStateFlow<QrUi>(QrUi.Hidden)

    val qr: StateFlow<QrUi> get() = qrState

    init {
        receiveLease.acquire()
        coordinator.startReceiving()
    }

    private fun build(
        receiver: ReceiverState,
        settings: AppSettings,
        capabilities: List<TransportCapability>,
        waiting: Int,
        active: Int,
    ): ReceiveUi = ReceiveUi(
        deviceName = receiver.deviceName,
        status = receiver.status,
        visible = settings.visibility == Visibility.VISIBLE,
        endpoints = if (settings.advancedConnectionEnabled) ReceiveLogic.endpoints(receiver.addresses, receiver.port) else emptyList(),
        hotspotOffer = ReceiveLogic.hotspotOffer(capabilities),
        customFolder = settings.saveDirectoryUri != null,
        qrSingleUse = settings.qrSingleUse,
        waiting = waiting,
        busy = active > 0,
    )

    val state: StateFlow<ReceiveUi> = combine(
        coordinator.receiver,
        container.settings.settings,
        container.capabilities.capabilities,
        coordinator.pendingIncoming,
        coordinator.activeCount,
    ) { receiver, settings, capabilities, pending, active ->
        build(receiver, settings, capabilities, pending.size, active)
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5_000),
        build(
            coordinator.receiver.value,
            container.settings.settings.value,
            container.capabilities.capabilities.value,
            coordinator.pendingIncoming.value.size,
            coordinator.activeCount.value,
        ),
    )

    /** The receiver could not start (for example the port was taken): try again. */
    fun retry() = coordinator.startReceiving()

    fun refreshCapabilities() = container.capabilities.refresh()

    /**
     * Creates a pairing code. A request that is still running when the sheet is closed is allowed to finish, because
     * creating a code with a hotspot starts something that the pairing code itself stops again later; only its result is
     * dropped.
     */
    fun showQr(includeHotspot: Boolean) {
        qrRequest += 1
        val request = qrRequest
        qrState.value = QrUi.Loading(includeHotspot)
        viewModelScope.launch {
            val result = coordinator.createPairingQr(includeHotspot)
            val next: QrUi = when (result) {
                is PairingQrResult.Ready -> {
                    val image = withContext(Dispatchers.Default) { QrCodes.encodeOrNull(result.text, QR_SIZE_PX) }
                    if (image == null) {
                        QrUi.Failed(PairingReasons.QR_TOO_LONG, includeHotspot)
                    } else {
                        QrUi.Ready(image, result.expiresAt, includeHotspot, result.hotspotIncluded)
                    }
                }
                is PairingQrResult.Unavailable -> QrUi.Failed(result.reason, includeHotspot)
            }
            if (request == qrRequest) qrState.value = next
        }
    }

    fun closeQr() {
        qrRequest += 1
        qrState.value = QrUi.Hidden
    }

    override fun onCleared() {
        val ticket = receiveLease.release() ?: return
        if (coordinator.activeCount.value == 0) {
            coordinator.stopReceiving()
            return
        }
        // A transfer is still running: let it finish, then switch receiving off unless a Receive screen was opened again.
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
        scope.launch {
            try {
                coordinator.activeCount.first { count -> count == 0 }
                if (receiveLease.mayStop(ticket)) coordinator.stopReceiving()
            } finally {
                scope.cancel()
            }
        }
    }

    private companion object {
        const val QR_SIZE_PX = 720
    }
}
