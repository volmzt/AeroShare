package com.aero.share.domain

import com.aero.share.transfer.model.DeviceKind
import com.aero.share.transfer.model.FileCategory
import com.aero.share.transfer.model.PeerInfo
import com.aero.share.transfer.model.TransferDirection
import com.aero.share.transfer.model.TransferFailure
import com.aero.share.transfer.model.TransportKind
import kotlinx.coroutines.flow.Flow

/** This device as seen by others. */
data class LocalDeviceInfo(
    val deviceId: String,
    /** Build.MODEL based default name. */
    val defaultName: String,
    /** Custom name if configured, otherwise [defaultName]. */
    val name: String,
    val kind: DeviceKind,
    val fingerprint: String,
)

interface LocalDeviceProvider {
    val info: kotlinx.coroutines.flow.StateFlow<LocalDeviceInfo>
}

data class DeviceRecord(
    val deviceId: String,
    val name: String,
    val alias: String?,
    val kind: DeviceKind,
    val model: String?,
    val fingerprint: String,
    val firstSeen: Long,
    val lastSeen: Long,
    val trusted: Boolean,
    val blocked: Boolean,
    val capabilities: Int,
    val lastAddress: String?,
    val lastTransport: TransportKind?,
) {
    val displayName: String get() = alias?.takeIf { it.isNotBlank() } ?: name
}

interface DeviceRepository {
    /** Trusted first, then by last seen (newest first). */
    val devices: Flow<List<DeviceRecord>>

    suspend fun find(deviceId: String): DeviceRecord?

    /** Records that a device was seen/used. Never changes trust, block state or alias. */
    suspend fun upsertSeen(peer: PeerInfo, address: String?, transport: TransportKind?)

    suspend fun rename(deviceId: String, alias: String?)
    suspend fun setTrusted(deviceId: String, trusted: Boolean)
    suspend fun setBlocked(deviceId: String, blocked: Boolean)
    suspend fun forget(deviceId: String)

    /** Fast in-memory lookup used by the engine's peer policy. */
    fun trustOf(deviceId: String, fingerprint: String): com.aero.share.transfer.model.PeerTrust
}

enum class HistoryStatus { COMPLETED, FAILED, CANCELLED }

data class HistoryFile(
    val name: String,
    val size: Long,
    /** Content/file URI for received files that can be opened; null for sent files. */
    val uri: String?,
    val mimeType: String?,
    val category: FileCategory,
)

data class HistoryItem(
    val id: String,
    val direction: TransferDirection,
    val timestamp: Long,
    val peerName: String,
    val peerId: String?,
    val fileCount: Int,
    val completedFiles: Int,
    val totalBytes: Long,
    val transferredBytes: Long,
    val durationMillis: Long,
    val status: HistoryStatus,
    val failure: TransferFailure?,
    val transport: TransportKind?,
    val files: List<HistoryFile>,
)

interface HistoryRepository {
    /** Newest first. */
    val items: Flow<List<HistoryItem>>

    suspend fun add(item: HistoryItem)
    suspend fun find(id: String): HistoryItem?
    suspend fun delete(id: String)

    /** Clears history records only; received files are never deleted. */
    suspend fun clear()
    suspend fun deleteOlderThan(timestamp: Long)
}
