package com.aero.share.network.transport

import android.annotation.SuppressLint
import android.net.wifi.WpsInfo
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pDevice
import android.net.wifi.p2p.WifiP2pInfo
import android.net.wifi.p2p.WifiP2pManager
import android.os.SystemClock
import com.aero.share.domain.NearbyDevice
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

internal object P2pReasons {
    fun name(code: Int): String = when (code) {
        WifiP2pManager.ERROR -> "error"
        WifiP2pManager.P2P_UNSUPPORTED -> "unsupported"
        WifiP2pManager.BUSY -> "busy"
        WifiP2pManager.NO_SERVICE_REQUESTS -> "no-service-requests"
        else -> "code-$code"
    }
}

/** What a receiving phone tells the group owner about itself (see [P2pHello]). */
internal data class HelloTarget(val port: Int, val fingerprint: String)

/**
 * Makes and tears down one Wi-Fi Direct group. Honest notes on what is outside our control:
 *  - The other phone shows the system's "invitation to connect" prompt and its user has to accept it. There is no API
 *    for an app to skip that, and we do not try to.
 *  - Group formation is the least reliable part of Android networking: it differs between manufacturers and Android
 *    versions, and some phones drop their normal Wi-Fi connection while the group exists. Every step has a timeout and a
 *    precise failure, and the app never reports a connection that was not verified by the caller.
 *  - We ask to be the client (group owner intent 0) so that the receiving phone, whose address the sender needs, becomes
 *    the group owner. The outcome is decided by negotiation; when we do become the group owner, the other phone's
 *    address is learned from its [P2pHello] datagram.
 */
internal class P2pConnector(
    private val manager: WifiP2pManager,
    private val scope: CoroutineScope,
    private val log: (String) -> Unit,
) {
    private class Attempt(val mac: String) {
        val info = CompletableDeferred<WifiP2pInfo>()

        @Volatile
        var sawInvited = false
    }

    private val lock = Any()
    private var group: P2pGroup? = null
    private var groupMac: String? = null
    private var pending: Attempt? = null
    private var lastHelloOwner: String? = null
    private var lastHelloAt = 0L
    private val ignore = object : WifiP2pManager.ActionListener {
        override fun onSuccess() {}
        override fun onFailure(reason: Int) {}
    }

    fun hasPending(): Boolean = synchronized(lock) { pending != null }

    /** Forgets the group (Wi-Fi Direct went away). */
    fun clearGroup() {
        synchronized(lock) {
            group = null
            groupMac = null
        }
    }

    @SuppressLint("MissingPermission")
    suspend fun connect(channel: WifiP2pManager.Channel, peer: NearbyDevice, mac: String): Result<P2pGroup> {
        val known = synchronized(lock) { Pair(group, groupMac) }
        val existing = known.first
        if (existing != null) {
            if (known.second == mac && existing.peerAddress != null) return Result.success(existing)
            removeGroup(channel)
        }
        val hello = P2pHelloListener.open()
        if (hello == null) log("hello port is busy: the group owner role cannot be served")
        val attempt = Attempt(mac)
        synchronized(lock) { pending = attempt }
        var requested = false
        var succeeded = false
        try {
            val config = WifiP2pConfig()
            config.deviceAddress = mac
            config.wps.setup = WpsInfo.PBC
            config.groupOwnerIntent = 0
            val code = requestConnect(channel, config)
            if (code != RESULT_OK) {
                log("connect request failed (" + describe(code) + ")")
                return failure(reasonOf(code), "connect request failed")
            }
            requested = true
            val info = try {
                withTimeoutOrNull(CONNECT_TIMEOUT_MS) { attempt.info.await() }
            } catch (e: P2pException) {
                return failure(e.reason, e.message ?: "connection failed")
            }
            if (info == null) return failure(P2pFailure.TIMEOUT, "no group was formed in time")
            val owner = info.groupOwnerAddress?.hostAddress
                ?: return failure(P2pFailure.FAILED, "the group has no owner address")
            val formed = if (!info.isGroupOwner) {
                P2pGroup(owner, false, null)
            } else {
                val client = awaitClient(hello, peer)
                    ?: return failure(P2pFailure.PEER_ADDRESS_UNKNOWN, "the client did not announce its address")
                P2pGroup(owner, true, client)
            }
            synchronized(lock) {
                group = formed
                groupMac = mac
            }
            succeeded = true
            return Result.success(formed)
        } finally {
            hello?.close()
            synchronized(lock) { if (pending === attempt) pending = null }
            if (!succeeded) abort(channel, requested)
        }
    }

    /** Leaves or dissolves the group and waits (briefly) until the system has done it. Never throws. */
    @SuppressLint("MissingPermission")
    suspend fun removeGroup(channel: WifiP2pManager.Channel) {
        val done = CompletableDeferred<Unit>()
        try {
            manager.removeGroup(
                channel,
                object : WifiP2pManager.ActionListener {
                    override fun onSuccess() {
                        done.complete(Unit)
                    }

                    override fun onFailure(reason: Int) {
                        done.complete(Unit)
                    }
                },
            )
        } catch (e: RuntimeException) {
            done.complete(Unit)
        }
        withTimeoutOrNull(REMOVE_TIMEOUT_MS) { done.await() }
        clearGroup()
        delay(SETTLE_MS)
    }

    /**
     * Called with the connection info of every group change. While a connect is pending it completes the wait. Otherwise
     * (another phone connected to us) a client tells the group owner who it is, so that a sender that ended up as group
     * owner can find our address.
     */
    fun onConnectionInfo(info: WifiP2pInfo, helloTarget: HelloTarget?) {
        if (!info.groupFormed) {
            synchronized(lock) {
                if (pending == null) {
                    group = null
                    groupMac = null
                }
            }
            return
        }
        val attempt = synchronized(lock) { pending }
        if (attempt != null) {
            attempt.info.complete(info)
            return
        }
        if (info.isGroupOwner || helloTarget == null) return
        val owner = info.groupOwnerAddress?.hostAddress ?: return
        val now = SystemClock.elapsedRealtime()
        val send = synchronized(lock) {
            val repeated = owner == lastHelloOwner && now - lastHelloAt < HELLO_QUIET_MS
            if (!repeated) {
                lastHelloOwner = owner
                lastHelloAt = now
            }
            !repeated
        }
        if (send) {
            scope.launch(Dispatchers.IO) {
                P2pHelloSender.send(owner, P2pHello.PORT, helloTarget.fingerprint, helloTarget.port)
            }
        }
    }

    /** Detects a declined invitation: the peer was invited and then went back to available/failed. */
    fun onPeers(devices: Collection<WifiP2pDevice>) {
        val attempt = synchronized(lock) { pending } ?: return
        val device = devices.firstOrNull { it.deviceAddress.equals(attempt.mac, ignoreCase = true) } ?: return
        when (device.status) {
            WifiP2pDevice.INVITED -> attempt.sawInvited = true
            WifiP2pDevice.FAILED, WifiP2pDevice.AVAILABLE, WifiP2pDevice.UNAVAILABLE -> {
                if (attempt.sawInvited) {
                    attempt.info.completeExceptionally(P2pException(P2pFailure.DECLINED, "the invitation was not accepted"))
                }
            }
            else -> Unit
        }
    }

    @SuppressLint("MissingPermission")
    private suspend fun requestConnect(channel: WifiP2pManager.Channel, config: WifiP2pConfig): Int {
        val result = CompletableDeferred<Int>()
        try {
            manager.connect(
                channel,
                config,
                object : WifiP2pManager.ActionListener {
                    override fun onSuccess() {
                        result.complete(RESULT_OK)
                    }

                    override fun onFailure(reason: Int) {
                        result.complete(reason)
                    }
                },
            )
        } catch (e: SecurityException) {
            return RESULT_DENIED
        } catch (e: RuntimeException) {
            return WifiP2pManager.ERROR
        }
        return withTimeoutOrNull(REQUEST_TIMEOUT_MS) { result.await() } ?: RESULT_TIMEOUT
    }

    private suspend fun awaitClient(listener: P2pHelloListener?, peer: NearbyDevice): String? {
        if (listener == null) return null
        val from = listener.await(HELLO_TIMEOUT_MS) { hello -> matches(peer, hello) } ?: return null
        if (!from.isSiteLocalAddress) return null
        return from.hostAddress
    }

    private fun matches(peer: NearbyDevice, hello: P2pHello.Hello): Boolean {
        val expected = peer.fingerprint
        return if (expected != null) hello.fingerprint == expected else hello.fingerprint.startsWith(peer.deviceId)
    }

    /** Fire and forget: used when a connect is abandoned. Only touches the group when a request was really made. */
    @SuppressLint("MissingPermission")
    private fun abort(channel: WifiP2pManager.Channel, requested: Boolean) {
        if (!requested) return
        try {
            manager.cancelConnect(channel, ignore)
            manager.removeGroup(channel, ignore)
        } catch (e: RuntimeException) {
            log("abort failed (" + e.javaClass.simpleName + ")")
        }
    }

    private fun failure(reason: P2pFailure, message: String): Result<P2pGroup> =
        Result.failure(P2pException(reason, message))

    private fun reasonOf(code: Int): P2pFailure = when (code) {
        WifiP2pManager.BUSY -> P2pFailure.BUSY
        WifiP2pManager.P2P_UNSUPPORTED -> P2pFailure.UNSUPPORTED
        RESULT_DENIED -> P2pFailure.PERMISSION
        RESULT_TIMEOUT -> P2pFailure.TIMEOUT
        else -> P2pFailure.FAILED
    }

    private fun describe(code: Int): String = when (code) {
        RESULT_DENIED -> "permission denied"
        RESULT_TIMEOUT -> "no answer"
        else -> P2pReasons.name(code)
    }

    private companion object {
        const val RESULT_OK = -1
        const val RESULT_TIMEOUT = -2
        const val RESULT_DENIED = -3
        const val REQUEST_TIMEOUT_MS = 8_000L
        const val CONNECT_TIMEOUT_MS = 30_000L
        const val HELLO_TIMEOUT_MS = 12_000L
        const val REMOVE_TIMEOUT_MS = 4_000L
        const val SETTLE_MS = 400L
        const val HELLO_QUIET_MS = 5_000L
    }
}
