package com.aero.share.feature.send

import com.aero.share.domain.DeviceRecord
import com.aero.share.domain.LinkQuality
import com.aero.share.domain.NearbyDevice
import com.aero.share.domain.Recipient
import com.aero.share.feature.home.HomeLogic
import com.aero.share.transfer.model.DeviceKind
import com.aero.share.transfer.model.TransportKind

/** How a recipient got into the list. */
internal enum class RecipientSource { NEARBY, QR, MANUAL }

/** One selectable row of the recipient list. [recipient] is exactly what is added to, or removed from, the send session. */
internal data class RecipientRow(
    val key: String,
    val name: String,
    val kind: DeviceKind,
    val source: RecipientSource,
    val recipient: Recipient,
    val selected: Boolean,
    val trusted: Boolean,
    val blocked: Boolean,
    val transports: Set<TransportKind>,
    val quality: LinkQuality?,
    /** "host:port" for recipients that were added by a code or an address. */
    val address: String?,
    /** False for a chosen recipient that discovery does not currently see. */
    val visible: Boolean,
)

/** A trusted device that is not reachable right now; shown greyed out so its absence is explained, not mysterious. */
internal data class OfflineRow(val deviceId: String, val name: String, val kind: DeviceKind)

internal data class RecipientSections(
    /** Devices that discovery sees right now, in the same order as on Home. */
    val nearby: List<RecipientRow>,
    /** Chosen recipients that discovery does not list: scanned codes, typed addresses, devices that moved out of range. */
    val added: List<RecipientRow>,
    val offline: List<OfflineRow>,
)

/** The outcome of checking what was typed into the "connect by address" form. */
internal sealed interface ManualTarget {
    data class Valid(val host: String, val port: Int) : ManualTarget
    data object InvalidHost : ManualTarget
    data object InvalidPort : ManualTarget
}

internal object RecipientsLogic {
    /** The port a receiving device listens on first; the form pre-fills it so that most people only type the address. */
    const val DEFAULT_PORT = 47474

    fun sections(nearby: List<NearbyDevice>, known: List<DeviceRecord>, chosen: List<Recipient>): RecipientSections {
        val chosenByKey = LinkedHashMap<String, Recipient>()
        for (recipient in chosen) {
            val key = RecipientKeys.of(recipient)
            if (!chosenByKey.containsKey(key)) chosenByKey[key] = recipient
        }
        val recordById = HashMap<String, DeviceRecord>(known.size * 2)
        for (record in known) recordById[record.deviceId] = record

        val shownKeys = HashSet<String>()
        val nearbyRows = ArrayList<RecipientRow>()
        for (home in HomeLogic.devices(nearby, known)) {
            val key = RecipientKeys.ofDevice(home.device.deviceId)
            shownKeys.add(key)
            val picked = chosenByKey[key]
            nearbyRows.add(
                RecipientRow(
                    key = key,
                    name = home.displayName.ifBlank { home.device.name },
                    kind = home.device.kind,
                    source = if (picked is Recipient.Qr) RecipientSource.QR else RecipientSource.NEARBY,
                    recipient = picked ?: Recipient.Nearby(home.device),
                    selected = picked != null,
                    trusted = home.trusted,
                    blocked = home.blocked,
                    transports = home.device.transports,
                    quality = home.device.quality,
                    address = null,
                    visible = true,
                ),
            )
        }

        val addedRows = ArrayList<RecipientRow>()
        for ((key, recipient) in chosenByKey) {
            if (key in shownKeys) continue
            shownKeys.add(key)
            addedRows.add(rowOf(key, recipient, recordById))
        }

        val offline = known
            .filter { record -> record.trusted && !record.blocked && RecipientKeys.ofDevice(record.deviceId) !in shownKeys }
            .sortedBy { record -> record.displayName.lowercase() }
            .map { record -> OfflineRow(record.deviceId, record.displayName, record.kind) }
        return RecipientSections(nearby = nearbyRows, added = addedRows, offline = offline)
    }

    private fun rowOf(key: String, recipient: Recipient, recordById: Map<String, DeviceRecord>): RecipientRow = when (recipient) {
        is Recipient.Nearby -> {
            val record = recordById[recipient.device.deviceId]
            RecipientRow(
                key = key,
                name = record?.displayName ?: recipient.device.name,
                kind = recipient.device.kind,
                source = RecipientSource.NEARBY,
                recipient = recipient,
                selected = true,
                trusted = record?.trusted == true,
                blocked = record?.blocked == true,
                transports = recipient.device.transports,
                quality = null,
                address = null,
                visible = false,
            )
        }
        is Recipient.Qr -> {
            val record = recordById[recipient.payload.deviceId]
            val host = recipient.payload.hosts.firstOrNull()
            RecipientRow(
                key = key,
                name = record?.displayName ?: recipient.payload.name,
                kind = recipient.payload.kind,
                source = RecipientSource.QR,
                recipient = recipient,
                selected = true,
                trusted = record?.trusted == true,
                blocked = record?.blocked == true,
                transports = emptySet(),
                quality = null,
                address = host?.let { "$it:${recipient.payload.port}" },
                visible = false,
            )
        }
        is Recipient.Manual -> RecipientRow(
            key = key,
            name = recipient.host,
            kind = DeviceKind.OTHER,
            source = RecipientSource.MANUAL,
            recipient = recipient,
            selected = true,
            trusted = false,
            blocked = false,
            transports = emptySet(),
            quality = null,
            address = "${recipient.host}:${recipient.port}",
            visible = false,
        )
    }

    /**
     * Checks an IPv4 address and an optional port. Only addresses a device can really be reached at are accepted: not the
     * unspecified, loopback, multicast or broadcast ranges. Numbers are normalised, so "010.000.000.005" becomes "10.0.0.5"
     * and cannot be read as octal by the network stack.
     */
    fun parseManual(hostText: String, portText: String): ManualTarget {
        val parts = hostText.trim().split('.')
        if (parts.size != 4) return ManualTarget.InvalidHost
        val octets = IntArray(4)
        for ((index, part) in parts.withIndex()) {
            if (part.isEmpty() || part.length > 3 || !part.all { it in '0'..'9' }) return ManualTarget.InvalidHost
            val value = part.toInt()
            if (value > 255) return ManualTarget.InvalidHost
            octets[index] = value
        }
        if (octets[0] == 0 || octets[0] == 127 || octets[0] >= 224) return ManualTarget.InvalidHost
        val trimmed = portText.trim()
        val port = if (trimmed.isEmpty()) DEFAULT_PORT else (trimmed.toIntOrNull() ?: return ManualTarget.InvalidPort)
        if (port !in 1..65_535) return ManualTarget.InvalidPort
        return ManualTarget.Valid(octets.joinToString("."), port)
    }
}
