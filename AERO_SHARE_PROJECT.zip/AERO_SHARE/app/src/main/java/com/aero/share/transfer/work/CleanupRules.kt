package com.aero.share.transfer.work

/** Time rules of the daily cleanup, kept free of Android types so they can be unit-tested. */
internal object CleanupRules {
    const val DAY_MS = 24L * 60L * 60L * 1000L

    /** Cache folders written by the APK handling; anything older than a day is a leftover of an aborted transfer. */
    val TEMP_DIRS: List<String> = listOf("bundles", "apk-inspect")

    /** Unfinished received data older than the returned time is deleted. At least one day is always kept. */
    fun partialCutoff(now: Long, retentionDays: Int): Long = now - retentionDays.coerceAtLeast(1) * DAY_MS

    /** Null when the history is kept forever. */
    fun historyCutoff(now: Long, retentionDays: Int): Long? =
        if (retentionDays <= 0) null else now - retentionDays * DAY_MS

    fun tempCutoff(now: Long): Long = now - DAY_MS
}
