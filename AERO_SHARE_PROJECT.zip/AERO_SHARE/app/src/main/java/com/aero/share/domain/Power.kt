package com.aero.share.domain

import com.aero.share.transfer.engine.EngineConfig

/**
 * Maps the user's power mode (and thermal/battery state) to concrete tunables.
 * BALANCED is the default, PERFORMANCE uses larger buffers and a low-latency Wi-Fi lock but never bypasses
 * thermal management, ENERGY_SAVING lowers discovery frequency and background activity.
 */
interface PowerPolicy {
    /** Engine tunables for the current mode and the connection-timeout setting. */
    fun engineConfig(): EngineConfig

    /** How often nearby-device discovery is refreshed while the list is visible. */
    fun discoveryIntervalMs(): Long

    /** How often this device's presence beacon is repeated while it is visible. */
    fun beaconIntervalMs(): Long

    /** Whether a transfer should hold a low-latency Wi-Fi lock (performance mode on API 29+). */
    fun useLowLatencyWifiLock(): Boolean
}
