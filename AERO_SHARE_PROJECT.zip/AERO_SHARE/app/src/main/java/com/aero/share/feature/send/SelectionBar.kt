package com.aero.share.feature.send

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.aero.share.R
import com.aero.share.core.common.Formatters
import com.aero.share.core.common.labelRes
import com.aero.share.core.designsystem.AeroBadge
import com.aero.share.core.designsystem.AeroButton
import com.aero.share.core.designsystem.AeroButtonStyle
import com.aero.share.core.designsystem.AeroCategoryIcon
import com.aero.share.core.designsystem.AeroDivider
import com.aero.share.core.designsystem.AeroIcon
import com.aero.share.core.designsystem.AeroIconButton
import com.aero.share.core.designsystem.AeroText
import com.aero.share.core.designsystem.AeroTheme
import com.aero.share.core.designsystem.AeroTopBar
import com.aero.share.core.designsystem.aeroRowClickable
import com.aero.share.domain.AppItem
import com.aero.share.domain.FileItem
import com.aero.share.domain.FolderItem
import com.aero.share.domain.SelectionItem
import com.aero.share.transfer.model.FileCategory

/**
 * The bar at the bottom of the picker: how much is selected (the size says so when some sizes are unknown), a summary per
 * category, a tap target that opens the full list, and Clear / Next. Next stays disabled until something is selected.
 */
@Composable
internal fun SelectionBar(items: List<SelectionItem>, onReview: () -> Unit, onClear: () -> Unit, onNext: () -> Unit) {
    val colors = AeroTheme.colors
    val summary = remember(items) { SelectionMath.summarize(items) }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(colors.surfaceElevated)
            .padding(horizontal = AeroTheme.dimens.screenPadding, vertical = 12.dp),
    ) {
        if (summary.isEmpty) {
            AeroText(
                text = stringResource(R.string.send_bar_empty),
                modifier = Modifier.heightIn(min = 48.dp).padding(top = 12.dp),
                color = colors.textSecondary,
            )
        } else {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 48.dp)
                    .aeroRowClickable(role = Role.Button, onClick = onReview),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    AeroText(
                        text = pluralStringResource(R.plurals.send_bar_count, summary.entries, summary.entries),
                        style = AeroTheme.typography.bodyStrong,
                    )
                    AeroText(text = sizeLine(summary), style = AeroTheme.typography.caption, color = colors.textSecondary)
                }
                AeroText(
                    text = stringResource(R.string.send_bar_review),
                    style = AeroTheme.typography.label,
                    color = colors.accentText,
                )
            }
            CategoryChips(summary)
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            AeroButton(
                text = stringResource(R.string.send_bar_clear),
                onClick = onClear,
                style = AeroButtonStyle.Secondary,
                enabled = !summary.isEmpty,
            )
            AeroButton(
                text = stringResource(R.string.send_bar_next),
                onClick = onNext,
                modifier = Modifier.weight(1f),
                enabled = !summary.isEmpty,
            )
        }
    }
}

/** "24.5 MB · 120 files": the total size (flagged when some sizes are unknown) and, with folders, the number of files. */
@Composable
internal fun sizeLine(summary: SelectionSummary): String {
    val size = Formatters.bytes(summary.knownBytes)
    val sizeText = if (summary.sizeIsPartial) stringResource(R.string.send_bar_size_partial, size) else size
    if (summary.files == summary.entries) return sizeText
    return metaLine(listOf(sizeText, pluralStringResource(R.plurals.send_files_total, summary.files, summary.files)))
}

@Composable
internal fun CategoryChips(summary: SelectionSummary) {
    if (summary.categories.isEmpty() && summary.folders == 0) return
    Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(top = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        for ((category, count) in summary.categories) {
            AeroBadge(text = stringResource(R.string.send_chip_count, stringResource(category.labelRes()), count))
        }
        if (summary.folders > 0) {
            AeroBadge(text = pluralStringResource(R.plurals.send_chip_folders, summary.folders, summary.folders))
        }
    }
}

/**
 * Everything that is selected, in a full-screen list: each entry can be removed, and apps can show what the package is
 * (name, version, signer, warnings) before anything is sent.
 */
@Composable
internal fun SelectionReview(
    items: List<SelectionItem>,
    onRemove: (String) -> Unit,
    onClear: () -> Unit,
    onDismiss: () -> Unit,
) {
    val colors = AeroTheme.colors
    var expandedId by rememberSaveable { mutableStateOf<String?>(null) }
    LaunchedEffect(items.isEmpty()) { if (items.isEmpty()) onDismiss() }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(modifier = Modifier.fillMaxSize().background(colors.background).safeDrawingPadding()) {
            AeroTopBar(
                title = stringResource(R.string.send_review_title),
                onBack = onDismiss,
                actions = {
                    AeroButton(text = stringResource(R.string.send_review_clear), onClick = onClear, style = AeroButtonStyle.Ghost)
                },
            )
            LazyColumn(modifier = Modifier.weight(1f).fillMaxWidth()) {
                items(items, key = { item -> item.id }) { item ->
                    ReviewRow(
                        item = item,
                        expanded = expandedId == item.id,
                        onToggleDetails = { expandedId = if (expandedId == item.id) null else item.id },
                        onRemove = { onRemove(item.id) },
                    )
                    AeroDivider()
                }
            }
        }
    }
}

@Composable
private fun ReviewRow(item: SelectionItem, expanded: Boolean, onToggleDetails: () -> Unit, onRemove: () -> Unit) {
    val colors = AeroTheme.colors
    val hasDetails = item.category == FileCategory.APK
    Column(modifier = Modifier.fillMaxWidth().padding(horizontal = AeroTheme.dimens.screenPadding, vertical = 6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (item is FolderItem) {
                FolderTile()
            } else {
                AeroCategoryIcon(category = item.category)
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                AeroText(text = item.displayName, style = AeroTheme.typography.bodyStrong, maxLines = 2)
                AeroText(
                    text = itemMeta(item),
                    style = AeroTheme.typography.caption,
                    color = colors.textSecondary,
                    maxLines = 1,
                )
            }
            if (hasDetails) {
                AeroButton(
                    text = stringResource(if (expanded) R.string.send_review_hide else R.string.send_review_details),
                    onClick = onToggleDetails,
                    style = AeroButtonStyle.Ghost,
                )
            }
            AeroIconButton(
                icon = Icons.Rounded.Close,
                contentDescription = stringResource(R.string.send_review_remove, item.displayName),
                onClick = onRemove,
            )
        }
        if (expanded && hasDetails) {
            Spacer(Modifier.height(8.dp))
            when (item) {
                is FileItem -> ApkInspection(uri = item.uri)
                is AppItem -> InstalledAppDetails(item)
                is FolderItem -> Unit
            }
        }
    }
}

@Composable
private fun itemMeta(item: SelectionItem): String {
    val size = if (item.size >= 0L) Formatters.bytes(item.size) else ""
    return when (item) {
        is FileItem -> metaLine(listOf(stringResource(item.category.labelRes()), size))
        is FolderItem -> metaLine(listOf(pluralStringResource(R.plurals.send_files_total, item.fileCount, item.fileCount), size))
        is AppItem -> metaLine(listOf(item.versionName?.let { name -> stringResource(R.string.send_app_version, name) }.orEmpty(), size))
    }
}

@Composable
private fun InstalledAppDetails(app: AppItem) {
    val colors = AeroTheme.colors
    Column(modifier = Modifier.fillMaxWidth()) {
        AeroText(text = app.packageName, style = AeroTheme.typography.caption, color = colors.textSecondary)
        if (app.splitCount > 0) {
            AeroText(
                text = pluralStringResource(R.plurals.apkui_bundle, app.splitCount + 1, app.splitCount + 1),
                style = AeroTheme.typography.caption,
                color = colors.textSecondary,
            )
        }
    }
}

@Composable
private fun FolderTile() {
    val colors = AeroTheme.colors
    Box(
        modifier = Modifier
            .size(44.dp)
            .clip(RoundedCornerShape(AeroTheme.dimens.radiusSmall))
            .background(colors.accentContainer),
        contentAlignment = Alignment.Center,
    ) {
        AeroIcon(icon = Icons.Rounded.Folder, contentDescription = null, tint = colors.accentText, size = 24.dp)
    }
}
