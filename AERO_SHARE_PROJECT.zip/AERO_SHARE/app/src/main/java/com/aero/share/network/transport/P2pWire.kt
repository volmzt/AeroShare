package com.aero.share.network.transport

import com.aero.share.network.discovery.Beacon
import com.aero.share.network.discovery.NsdAdvert
import com.aero.share.transfer.security.Fingerprints
import java.nio.ByteBuffer

/**
 * The DNS-SD record AERO SHARE publishes over Wi-Fi Direct. It reuses the mDNS attributes of [NsdAdvert] and adds the
 * TLS port, because Wi-Fi Direct service discovery has no port field. The "id" attribute is left out of the record
 * (it is the first 32 characters of "fp") and rebuilt when parsing, which keeps the record small.
 *
 * Like every advertisement, the record is only a hint: the certificate fingerprint is verified by the TLS handshake.
 */
internal object P2pServiceRecord {
    /** Service type as WifiP2pDnsSdServiceInfo expects it (no trailing dot). */
    const val SERVICE_TYPE = "_aeroshare._tcp"
    const val PORT_KEY = "p"

    fun instanceName(deviceId: String): String = NsdAdvert.serviceName(deviceId)

    fun attributes(presence: Beacon.Presence): Map<String, String> {
        val map = LinkedHashMap<String, String>(NsdAdvert.attributes(presence))
        map.remove("id")
        map[PORT_KEY] = presence.port.toString()
        return map
    }

    /** True for the full domain name of an AERO SHARE service ("<instance>._aeroshare._tcp.local."). */
    fun isAeroService(fullDomainName: String): Boolean = fullDomainName.lowercase().contains(SERVICE_TYPE)

    /** Null when the record is not a valid AERO SHARE advertisement. */
    fun parse(record: Map<String, String>): Beacon.Presence? {
        val port = record[PORT_KEY]?.toIntOrNull() ?: return null
        val fingerprint = record["fp"] ?: return null
        if (!Fingerprints.isValid(fingerprint)) return null
        val bytes = HashMap<String, ByteArray?>()
        for ((key, value) in record) bytes[key] = value.toByteArray(Charsets.UTF_8)
        bytes["id"] = fingerprint.take(Beacon.DEVICE_ID_LENGTH).toByteArray(Charsets.UTF_8)
        return NsdAdvert.parse(bytes, port)
    }
}

/**
 * Datagram that a Wi-Fi Direct client sends to the group owner after the group has formed. When the sending phone
 * ends up as the group owner (the role negotiation is not fully under our control), this is the only way for it to
 * learn the IP address of the receiving client: the source address of the datagram. Layout:
 * "AEROP1" | fingerprint (32 raw bytes) | TLS port (u16, big endian). The content is public information; the identity is
 * still proven by the TLS handshake afterwards.
 */
internal object P2pHello {
    const val PORT = 47476
    const val SIZE = 40
    private const val FINGERPRINT_BYTES = 32
    private val MAGIC = byteArrayOf(0x41, 0x45, 0x52, 0x4F, 0x50, 0x31)

    data class Hello(val fingerprint: String, val port: Int)

    /** Null when [fingerprint] is not 64 lower-case hex characters or [port] is out of range. */
    fun encode(fingerprint: String, port: Int): ByteArray? {
        if (port !in 1..65535 || !Fingerprints.isValid(fingerprint)) return null
        val raw = Fingerprints.fromHex(fingerprint) ?: return null
        if (raw.size != FINGERPRINT_BYTES) return null
        val buffer = ByteBuffer.allocate(SIZE)
        buffer.put(MAGIC)
        buffer.put(raw)
        buffer.putShort(port.toShort())
        return buffer.array()
    }

    /** Strict: exact length and magic, non-zero port. */
    fun decode(data: ByteArray, length: Int): Hello? {
        if (length != SIZE || data.size < SIZE) return null
        for (i in MAGIC.indices) {
            if (data[i] != MAGIC[i]) return null
        }
        val raw = data.copyOfRange(MAGIC.size, MAGIC.size + FINGERPRINT_BYTES)
        val high = data[MAGIC.size + FINGERPRINT_BYTES].toInt() and 0xFF
        val low = data[MAGIC.size + FINGERPRINT_BYTES + 1].toInt() and 0xFF
        val port = (high shl 8) or low
        if (port == 0) return null
        return Hello(Fingerprints.toHex(raw), port)
    }
}
