package com.aero.share.di

import kotlinx.coroutines.flow.MutableStateFlow

/** One-shot requests coming from outside the UI (share sheet, pairing links). The UI consumes and clears them. */
class LaunchRequests {
    /** URI strings shared to AERO SHARE through ACTION_SEND / ACTION_SEND_MULTIPLE. */
    val sharedUris = MutableStateFlow<List<String>>(emptyList())

    /** An `aero://pair?...` link opened from a QR code scanned by another app. */
    val pairingLink = MutableStateFlow<String?>(null)
}
