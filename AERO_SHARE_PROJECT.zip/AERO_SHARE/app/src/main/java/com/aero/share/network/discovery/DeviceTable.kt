package com.aero.share.network.discovery

import com.aero.share.domain.LinkQuality
import com.aero.share.domain.NearbyDevice
import com.aero.share.transfer.model.DeviceKind
import com.aero.share.transfer.model.TransportKind

/** A device that should be probed for link quality. */
internal class ProbeTarget(val deviceId: String, val addresses: List<String>, val port: Int)

/**
 * Merges what mDNS and the multicast beacons report into one list, keyed by device id. Not thread-safe: the owner
 * serialises access. Times are milliseconds on any monotonic clock (the owner passes `elapsedRealtime`).
 *
 * - mDNS entries live until the service is reported lost; beacon addresses expire after a time-to-live.
 * - A device whose fingerprint differs from the one first seen under the same id is ignored.
 * - The published "last seen" moves in steps, so a steady beacon does not make the list change every few seconds.
 * - Devices without any usable on-link address are not listed (they could not be connected to).
 */
internal class DeviceTable(private val selfId: () -> String) {
    private class Entry(val fingerprint: String) {
        var name: String = ""
        var kind: DeviceKind = DeviceKind.OTHER
        var appVersion: String = ""
        var port: Int = 0
        var capabilities: Int = 0
        var nsdService: String? = null
        var nsdAddresses: List<String> = emptyList()
        val beacon = LinkedHashMap<String, Long>()
        var shownSeen: Long = 0
        var quality: LinkQuality = LinkQuality.UNKNOWN
    }

    private val entries = LinkedHashMap<String, Entry>()
    private var subnets: List<LocalSubnet> = emptyList()

    fun setSubnets(list: List<LocalSubnet>) {
        subnets = list
    }

    fun onNsd(serviceName: String, presence: Beacon.Presence, addresses: List<String>, now: Long) {
        if (presence.goodbye || presence.deviceId == selfId()) return
        val entry = touch(presence, now) ?: return
        entry.nsdService = serviceName
        entry.nsdAddresses = addresses
    }

    fun onNsdLost(serviceName: String) {
        val iterator = entries.values.iterator()
        while (iterator.hasNext()) {
            val entry = iterator.next()
            if (entry.nsdService != serviceName) continue
            entry.nsdService = null
            entry.nsdAddresses = emptyList()
            if (entry.beacon.isEmpty()) iterator.remove()
        }
    }

    /** [sourceAddress] is the address the datagram came from; addresses written inside a payload are never used. */
    fun onBeacon(presence: Beacon.Presence, sourceAddress: String, now: Long) {
        if (presence.deviceId == selfId()) return
        if (presence.goodbye) {
            goodbye(presence.deviceId, sourceAddress)
            return
        }
        val entry = touch(presence, now) ?: return
        entry.beacon[sourceAddress] = now
    }

    fun expire(now: Long, beaconTtlMs: Long) {
        val iterator = entries.values.iterator()
        while (iterator.hasNext()) {
            val entry = iterator.next()
            entry.beacon.values.removeAll { now - it > beaconTtlMs }
            if (entry.beacon.isEmpty() && entry.nsdService == null) iterator.remove()
        }
    }

    fun setQuality(deviceId: String, quality: LinkQuality) {
        entries[deviceId]?.quality = quality
    }

    fun clear() {
        entries.clear()
    }

    fun probeTargets(): List<ProbeTarget> {
        val out = ArrayList<ProbeTarget>()
        for ((id, entry) in entries) {
            val addresses = AddressRules.usable(entry.nsdAddresses + entry.beacon.keys, subnets)
            if (addresses.isNotEmpty() && entry.port > 0) out.add(ProbeTarget(id, addresses, entry.port))
        }
        return out
    }

    fun snapshot(): List<NearbyDevice> {
        val out = ArrayList<NearbyDevice>(entries.size)
        for ((id, entry) in entries) {
            val addresses = AddressRules.usable(entry.nsdAddresses + entry.beacon.keys, subnets)
            if (addresses.isEmpty()) continue
            out.add(
                NearbyDevice(
                    deviceId = id,
                    name = entry.name.ifBlank { id.take(FALLBACK_NAME_LENGTH) },
                    kind = entry.kind,
                    fingerprint = entry.fingerprint,
                    appVersion = entry.appVersion.ifEmpty { null },
                    addresses = addresses,
                    port = entry.port,
                    transports = setOf(TransportKind.LAN),
                    quality = entry.quality,
                    lastSeenElapsed = entry.shownSeen,
                    p2pAddress = null,
                    capabilities = entry.capabilities,
                ),
            )
        }
        out.sortWith(compareBy<NearbyDevice> { it.name.lowercase() }.thenBy { it.deviceId })
        return out
    }

    private fun goodbye(deviceId: String, sourceAddress: String) {
        val entry = entries[deviceId] ?: return
        if (entry.beacon.remove(sourceAddress) == null) return
        if (entry.beacon.isEmpty() && entry.nsdService == null) entries.remove(deviceId)
    }

    private fun touch(presence: Beacon.Presence, now: Long): Entry? {
        val id = presence.deviceId
        val existing = entries[id]
        if (existing != null && existing.fingerprint != presence.fingerprint) return null
        val entry = existing ?: Entry(presence.fingerprint).also {
            entries[id] = it
            it.shownSeen = now
        }
        entry.name = presence.name
        entry.kind = presence.kind
        entry.appVersion = presence.appVersion
        entry.port = presence.port
        entry.capabilities = presence.capabilities
        if (now - entry.shownSeen >= SEEN_STEP_MS) entry.shownSeen = now
        return entry
    }

    private companion object {
        const val SEEN_STEP_MS = 15_000L
        const val FALLBACK_NAME_LENGTH = 6
    }
}
