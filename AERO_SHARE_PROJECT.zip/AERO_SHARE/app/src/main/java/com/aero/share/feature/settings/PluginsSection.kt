package com.aero.share.feature.settings

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Extension
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.aero.share.R
import com.aero.share.core.designsystem.AeroEmptyState

/** There are no plugins in this version, and the page says so instead of listing anything that does not exist. */
@Composable
internal fun PluginsSection() {
    AeroEmptyState(
        icon = Icons.Rounded.Extension,
        title = stringResource(R.string.plug_title),
        message = stringResource(R.string.plug_text),
        modifier = Modifier.padding(top = 24.dp),
    )
}
