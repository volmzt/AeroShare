package com.aero.share.transfer.service

import com.aero.share.transfer.model.TransferDirection
import com.aero.share.transfer.model.TransferState

/** What the foreground notification says. */
internal enum class Phase { SENDING, RECEIVING, CONNECTING, AWAITING, PREPARING, PAUSED, VERIFYING, READY, QUEUED }

internal data class Presentation(
    val phase: Phase,
    /** The transfer the buttons act on; null when there is none. */
    val primaryId: String?,
    val showProgress: Boolean,
    val indeterminate: Boolean,
    val progress: Int,
    val transferred: Long,
    val total: Long,
    val bytesPerSecond: Long,
    val actions: List<ServiceAction>,
) {
    /** The "2.4 GB of 8.0 GB" line is only meaningful while bytes are moving or held. */
    val showsSizes: Boolean
        get() = total > 0L && (phase == Phase.SENDING || phase == Phase.RECEIVING || phase == Phase.PAUSED)
}

/** Decides, without any Android types, what the foreground notification shows for a [ServiceState]. */
internal object ForegroundPresentation {
    const val PROGRESS_MAX = 1000

    fun of(state: ServiceState): Presentation {
        val primary = state.active.firstOrNull { it.state == TransferState.TRANSFERRING }
            ?: state.active.firstOrNull { it.state == TransferState.VERIFYING }
            ?: state.active.firstOrNull { it.state == TransferState.PAUSED }
            ?: state.active.firstOrNull()
        if (primary == null) {
            return if (state.receiving) {
                Presentation(Phase.READY, null, false, false, 0, 0L, 0L, 0L, listOf(ServiceAction.STOP_RECEIVING))
            } else {
                Presentation(Phase.QUEUED, null, true, true, 0, 0L, 0L, 0L, emptyList())
            }
        }
        val phase = when (primary.state) {
            TransferState.TRANSFERRING ->
                if (primary.direction == TransferDirection.SEND) Phase.SENDING else Phase.RECEIVING
            TransferState.PAUSED -> Phase.PAUSED
            TransferState.VERIFYING -> Phase.VERIFYING
            TransferState.AWAITING_ACCEPTANCE -> Phase.AWAITING
            TransferState.CONNECTING -> Phase.CONNECTING
            else -> Phase.PREPARING
        }
        val measurable = primary.totalBytes > 0L &&
            (phase == Phase.SENDING || phase == Phase.RECEIVING || phase == Phase.PAUSED || phase == Phase.VERIFYING)
        val progress = if (measurable) {
            ((primary.transferredBytes.toDouble() / primary.totalBytes.toDouble()) * PROGRESS_MAX).toInt()
                .coerceIn(0, PROGRESS_MAX)
        } else {
            0
        }
        val actions = when (phase) {
            Phase.SENDING, Phase.RECEIVING -> listOf(ServiceAction.PAUSE, ServiceAction.CANCEL)
            Phase.PAUSED -> listOf(ServiceAction.RESUME, ServiceAction.CANCEL)
            else -> listOf(ServiceAction.CANCEL)
        }
        return Presentation(
            phase = phase,
            primaryId = primary.id,
            showProgress = true,
            indeterminate = !measurable,
            progress = progress,
            transferred = primary.transferredBytes,
            total = primary.totalBytes,
            bytesPerSecond = primary.bytesPerSecond,
            actions = actions,
        )
    }
}
