package com.aero.share.transfer

import android.content.Context
import android.os.Build
import android.os.PowerManager
import com.aero.share.domain.PowerPolicy
import com.aero.share.domain.SettingsRepository
import com.aero.share.transfer.engine.EngineConfig

/**
 * Maps the user's power mode to engine and discovery tunables (see [PowerProfiles]). The mode is read from the settings on
 * every call, so a change takes effect for the next transfer without a restart. When a [context] is given, battery saver and
 * severe thermal status cap the performance mode to the balanced values.
 */
class AppPowerPolicy(
    private val settings: SettingsRepository,
    context: Context? = null,
) : PowerPolicy {
    private val powerManager: PowerManager? =
        context?.applicationContext?.getSystemService(Context.POWER_SERVICE) as? PowerManager

    private fun profile(): PowerProfile = PowerProfiles.of(settings.settings.value.powerMode, constrained())

    private fun constrained(): Boolean {
        val manager = powerManager ?: return false
        if (manager.isPowerSaveMode) return true
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            return manager.currentThermalStatus >= PowerManager.THERMAL_STATUS_SEVERE
        }
        return false
    }

    override fun engineConfig(): EngineConfig =
        PowerProfiles.engineConfig(profile(), settings.settings.value.connectionTimeoutSec)

    override fun discoveryIntervalMs(): Long = profile().discoveryIntervalMs

    override fun beaconIntervalMs(): Long = profile().beaconIntervalMs

    override fun useLowLatencyWifiLock(): Boolean =
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && profile().lowLatencyWifi
}
