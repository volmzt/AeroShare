package com.aero.share.network.discovery

/** Text rules for everything that arrives from the network and may be shown to the user. */
internal object DiscoveryText {
    /** Removes control and direction-override characters, trims, and cuts to [maxBytes] of UTF-8 on a character boundary. */
    fun clean(raw: String, maxBytes: Int): String {
        val out = StringBuilder(raw.length)
        for (ch in raw) {
            if (Character.isISOControl(ch)) continue
            if (ch in '‪'..'‮' || ch in '⁦'..'⁩') continue
            out.append(ch)
        }
        return truncateUtf8(out.toString().trim(), maxBytes)
    }

    fun truncateUtf8(text: String, maxBytes: Int): String {
        var bytes = 0
        var index = 0
        while (index < text.length) {
            val codePoint = text.codePointAt(index)
            val size = if (codePoint < 0x80) 1 else if (codePoint < 0x800) 2 else if (codePoint < 0x10000) 3 else 4
            if (bytes + size > maxBytes) break
            bytes += size
            index += Character.charCount(codePoint)
        }
        return text.substring(0, index)
    }

    fun hasControlChars(text: String): Boolean = text.any { Character.isISOControl(it) }
}
