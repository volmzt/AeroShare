package com.aero.share.domain

import com.aero.share.transfer.model.DeviceKind
import com.aero.share.transfer.model.FileCategory
import com.aero.share.transfer.model.PeerTrust
import com.aero.share.transfer.model.TransferSnapshot
import com.aero.share.transfer.model.TransportKind
import com.aero.share.transfer.pairing.QrPayload
import kotlinx.coroutines.flow.StateFlow

/** What the user picked in the send flow (platform-neutral description; the app resolves it to streams). */
sealed interface SelectionItem {
    /** Stable unique key: the URI string, or the package name for apps. */
    val id: String
    val displayName: String
    /** Best-effort size in bytes, -1 when unknown. */
    val size: Long
    val category: FileCategory
}

data class FileItem(
    override val id: String,
    val uri: String,
    override val displayName: String,
    override val size: Long,
    override val category: FileCategory,
    val mimeType: String?,
    val lastModified: Long,
) : SelectionItem

/** A folder chosen through the system folder picker (SAF tree URI). */
data class FolderItem(
    override val id: String,
    val treeUri: String,
    override val displayName: String,
    override val size: Long,
    val fileCount: Int,
) : SelectionItem {
    override val category: FileCategory get() = FileCategory.OTHER
}

/** An installed app to be shared as APK (or split-APK bundle). */
data class AppItem(
    override val id: String,
    val packageName: String,
    override val displayName: String,
    val versionName: String?,
    override val size: Long,
    val splitCount: Int,
) : SelectionItem {
    override val category: FileCategory get() = FileCategory.APK
}

sealed interface Recipient {
    data class Nearby(val device: NearbyDevice) : Recipient
    data class Qr(val payload: QrPayload) : Recipient
    data class Manual(val host: String, val port: Int) : Recipient
}

/** One queued transfer is created per recipient (sequentially executed, never concurrent). */
data class SendJob(val items: List<SelectionItem>, val recipients: List<Recipient>)

enum class ReceiverStatus { OFF, STARTING, LISTENING, ERROR }

data class ReceiverState(
    val status: ReceiverStatus = ReceiverStatus.OFF,
    val port: Int? = null,
    /** Local IP addresses (for advanced manual connection). */
    val addresses: List<String> = emptyList(),
    val deviceName: String = "",
    val fingerprint: String? = null,
    val errorDetail: String? = null,
)

/** An incoming offer waiting for the user's decision. */
data class PendingIncoming(
    val transferId: String,
    val peerName: String,
    val peerKind: DeviceKind,
    val trust: PeerTrust,
    val authenticatedByQr: Boolean,
    val verificationCode: String?,
    val transport: TransportKind?,
    val title: String?,
    val fileCount: Int,
    val totalBytes: Long,
    val categories: Set<FileCategory>,
    val destinationLabel: String,
    val freeBytes: Long?,
    val isResume: Boolean,
    /** SystemClock.elapsedRealtime() when the request auto-declines. */
    val expiresAtElapsed: Long,
)

sealed interface PairingQrResult {
    data class Ready(val payload: QrPayload, val text: String, val expiresAt: Long, val hotspotIncluded: Boolean) : PairingQrResult
    data class Unavailable(val reason: String) : PairingQrResult
}

/**
 * Orchestrates the transfer engine, queue, foreground service, notifications, history and trust rules.
 * The UI only talks to this interface.
 */
interface TransferCoordinator {
    /** Queue and recent transfers of this process, newest first. */
    val transfers: StateFlow<List<TransferSnapshot>>

    val pendingIncoming: StateFlow<List<PendingIncoming>>
    val receiver: StateFlow<ReceiverState>

    /** Number of transfers currently active (connecting, awaiting, transferring, paused, verifying). */
    val activeCount: StateFlow<Int>

    /** Queues one transfer per recipient and returns their ids in order. */
    fun send(job: SendJob): List<String>

    fun startReceiving()
    fun stopReceiving()
    fun respond(transferId: String, accept: Boolean)

    fun pause(id: String)
    fun resume(id: String)
    fun cancel(id: String)

    /** Retries a failed/interrupted transfer (resumes from verified offsets where possible). */
    fun retry(id: String)

    /** Removes a finished transfer from the in-memory list (history is kept). */
    fun dismiss(id: String)

    /** Live snapshot of one transfer; emits null once dismissed. */
    fun observe(id: String): StateFlow<TransferSnapshot?>

    /** Creates a one-time pairing QR for this (listening) receiver. Starts the receiver if needed. */
    suspend fun createPairingQr(includeHotspot: Boolean): PairingQrResult
}
