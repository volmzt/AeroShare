package com.aero.share.feature.send

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.InsertDriveFile
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.compose.foundation.layout.Arrangement
import com.aero.share.R
import com.aero.share.core.common.SystemIntents
import com.aero.share.core.designsystem.AeroChip
import com.aero.share.core.designsystem.AeroScreen
import com.aero.share.core.designsystem.AeroTheme
import com.aero.share.core.designsystem.AeroTopBar
import com.aero.share.core.designsystem.LocalAeroToast
import com.aero.share.core.permissions.Permissions
import com.aero.share.di.LocalAppContainer
import com.aero.share.navigation.AeroNavigator

/**
 * Step one of sending: choose what to send. Photos, videos and audio come from the media library once access was explained
 * and allowed; documents, other files and folders open Android's own picker; installed apps are listed here. Everything
 * that is chosen stays selected while the person moves between tabs.
 */
@Composable
fun SendPickerScreen(navigator: AeroNavigator) {
    val container = LocalAppContainer.current
    val context = LocalContext.current
    val toast = LocalAeroToast.current
    val viewModel: PickerViewModel = viewModel(factory = viewModelFactory { initializer { PickerViewModel(container) } })
    val selection by viewModel.selection.collectAsStateWithLifecycle()
    val apps by viewModel.apps.collectAsStateWithLifecycle()
    val busy by viewModel.busy.collectAsStateWithLifecycle()
    val message by viewModel.message.collectAsStateWithLifecycle()
    var tabName by rememberSaveable { mutableStateOf(PickerTab.RECENT.name) }
    var query by rememberSaveable { mutableStateOf("") }
    var permissionDenied by rememberSaveable { mutableStateOf(false) }
    var reviewing by rememberSaveable { mutableStateOf(false) }
    val tab = PickerTab.values().firstOrNull { it.name == tabName } ?: PickerTab.RECENT
    val selectedIds = remember(selection) { SelectionMath.ids(selection) }

    val filesLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        viewModel.onFilesPicked(uris)
    }
    val folderLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        viewModel.onFolderPicked(uri)
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        permissionDenied = grants.values.any { granted -> !granted }
        viewModel.onPermissionResult()
    }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { viewModel.onResume() }
    LaunchedEffect(tab) { viewModel.onTabShown(tab) }

    val messageText = message?.let { notice -> stringResource(notice.textRes()) }
    LaunchedEffect(message) {
        if (messageText != null) {
            toast.show(messageText)
            viewModel.consumeMessage()
        }
    }

    AeroScreen {
        AeroTopBar(title = stringResource(R.string.send_picker_title), onBack = { navigator.back() })
        LazyRow(
            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
            contentPadding = PaddingValues(horizontal = AeroTheme.dimens.screenPadding),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(PickerTab.values().toList(), key = { entry -> entry.name }) { entry ->
                AeroChip(
                    text = stringResource(entry.labelRes()),
                    selected = entry == tab,
                    onClick = { tabName = entry.name },
                )
            }
        }
        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            when (tab) {
                PickerTab.RECENT, PickerTab.IMAGES, PickerTab.VIDEOS, PickerTab.AUDIO -> {
                    val mediaState by viewModel.media(tab).collectAsStateWithLifecycle()
                    MediaTab(
                        tab = tab,
                        state = mediaState,
                        selectedIds = selectedIds,
                        thumbnails = viewModel.thumbnails,
                        permissionDenied = permissionDenied,
                        onToggle = { entry -> viewModel.toggle(entry.item) },
                        onLoadMore = { viewModel.loadMore(tab) },
                        onRequest = { permissionLauncher.launch(MediaPermissions.request(tab)) },
                        onOpenSettings = { SystemIntents.openAppSettings(context) },
                        onRetry = { viewModel.retry(tab) },
                    )
                }
                PickerTab.DOCUMENTS -> SystemPickerPanel(
                    icon = Icons.Rounded.Description,
                    title = R.string.send_documents_title,
                    text = R.string.send_documents_text,
                    action = R.string.send_choose_documents,
                    onClick = { filesLauncher.launch(PickerLogic.DOCUMENT_MIME_TYPES) },
                )
                PickerTab.DOWNLOADS -> SystemPickerPanel(
                    icon = Icons.Rounded.Download,
                    title = R.string.send_downloads_title,
                    text = R.string.send_downloads_text,
                    action = R.string.send_choose_files,
                    onClick = { filesLauncher.launch(PickerLogic.ANY_MIME_TYPES) },
                )
                PickerTab.OTHER -> SystemPickerPanel(
                    icon = Icons.AutoMirrored.Rounded.InsertDriveFile,
                    title = R.string.send_other_title,
                    text = R.string.send_other_text,
                    action = R.string.send_choose_files,
                    onClick = { filesLauncher.launch(PickerLogic.ANY_MIME_TYPES) },
                )
                PickerTab.FOLDERS -> SystemPickerPanel(
                    icon = Icons.Rounded.Folder,
                    title = R.string.send_folders_title,
                    text = R.string.send_folders_text,
                    action = R.string.send_choose_folder,
                    onClick = { folderLauncher.launch(null) },
                    busy = busy,
                )
                PickerTab.APPS -> AppsTab(
                    state = apps,
                    query = query,
                    onQueryChange = { query = it },
                    selectedIds = selectedIds,
                    cachedIcon = { packageName -> viewModel.appIconCached(packageName) },
                    loadIcon = { packageName, sizePx -> viewModel.appIcon(packageName, sizePx) },
                    onToggle = { app -> viewModel.toggle(app) },
                    onChooseApk = { filesLauncher.launch(PickerLogic.APK_MIME_TYPES) },
                    onRetry = { viewModel.retryApps() },
                )
            }
        }
        SelectionBar(
            items = selection,
            onReview = { reviewing = true },
            onClear = { viewModel.clearSelection() },
            onNext = { navigator.openRecipients() },
        )
    }

    if (reviewing) {
        SelectionReview(
            items = selection,
            onRemove = { id -> viewModel.remove(id) },
            onClear = {
                viewModel.clearSelection()
                reviewing = false
            },
            onDismiss = { reviewing = false },
        )
    }
}
