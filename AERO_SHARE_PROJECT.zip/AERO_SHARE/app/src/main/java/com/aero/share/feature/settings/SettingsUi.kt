package com.aero.share.feature.settings

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.aero.share.core.designsystem.AeroScreen
import com.aero.share.core.designsystem.AeroText
import com.aero.share.core.designsystem.AeroTheme
import com.aero.share.core.designsystem.AeroTopBar

/** A settings page: the title bar and a scrolling column. [onBack] is null on the Settings tab itself. */
@Composable
internal fun SettingsPage(title: String, onBack: (() -> Unit)?, content: @Composable ColumnScope.() -> Unit) {
    AeroScreen {
        AeroTopBar(title = title, onBack = onBack)
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = AeroTheme.dimens.screenPadding)
                .padding(bottom = 24.dp),
            content = content,
        )
    }
}

/** A short explanation under a group of settings. */
@Composable
internal fun SettingsNote(text: String, modifier: Modifier = Modifier, color: Color = AeroTheme.colors.textSecondary) {
    AeroText(
        text = text,
        modifier = modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 8.dp),
        style = AeroTheme.typography.caption,
        color = color,
    )
}
