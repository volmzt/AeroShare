package com.aero.share.transfer

import com.aero.share.core.common.DiagnosticsLog
import com.aero.share.core.storage.source.ResolvedSelection
import com.aero.share.core.storage.source.SendSourceFactory
import com.aero.share.domain.ConnectionPlan
import com.aero.share.domain.DeviceRepository
import com.aero.share.domain.PlanResult
import com.aero.share.domain.PowerPolicy
import com.aero.share.domain.Recipient
import com.aero.share.domain.SelectionItem
import com.aero.share.domain.SettingsRepository
import com.aero.share.domain.TransportPlanner
import com.aero.share.transfer.engine.EngineLogger
import com.aero.share.transfer.engine.SendRequest
import com.aero.share.transfer.engine.SendTarget
import com.aero.share.transfer.engine.TransferResult
import com.aero.share.transfer.engine.TransferSender
import com.aero.share.transfer.model.LocalPeer
import com.aero.share.transfer.model.PeerInfo
import com.aero.share.transfer.model.TransferControl
import com.aero.share.transfer.model.TransferFailure
import com.aero.share.transfer.model.TransferState
import com.aero.share.transfer.model.TransferTracker
import com.aero.share.transfer.queue.QueuedJob
import com.aero.share.transfer.security.DeviceIdentity
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap

/** What one queued send needs: the user's selection and where it goes. */
internal class SendPayload(val items: List<SelectionItem>, val recipient: Recipient)

/**
 * Runs one queued send from start to finish: turns the selection into streams, asks the planner for a route, runs the engine
 * and always releases what was acquired on the way (temporary APK bundles, a Wi-Fi Direct group or a joined hotspot).
 * Cancelling from the UI works in every phase, including while a route is still being prepared.
 */
internal class SendFlow(
    private val identity: DeviceIdentity,
    private val localPeer: () -> LocalPeer,
    private val settings: SettingsRepository,
    private val power: PowerPolicy,
    private val planner: TransportPlanner,
    private val sources: SendSourceFactory,
    private val devices: DeviceRepository,
    private val diagnostics: DiagnosticsLog,
) {
    private val interrupted = ConcurrentHashMap.newKeySet<String>()
    private val running = ConcurrentHashMap<String, Deferred<TransferResult>>()

    /** Ends every running send as INTERRUPTED (it can be resumed later) instead of cancelling it. */
    fun interruptAll() {
        for ((id, job) in running) {
            interrupted.add(id)
            job.cancel()
        }
    }

    suspend fun execute(job: QueuedJob<SendPayload>): TransferResult {
        val tracker = job.tracker
        val control = job.control
        val payload = job.payload
        if (control.isCancelled) return cancelled(tracker)

        tracker.update { s ->
            s.copy(
                state = TransferState.PREPARING,
                startedAt = if (s.startedAt > 0L) s.startedAt else System.currentTimeMillis(),
            )
        }
        var resolved: ResolvedSelection? = null
        var plan: ConnectionPlan? = null
        try {
            val selection: ResolvedSelection = try {
                cancellable(control) { sources.resolve(payload.items) } ?: return cancelled(tracker)
            } catch (e: CancellationException) {
                throw e
            } catch (e: SecurityException) {
                return failed(tracker, TransferFailure.PERMISSION, null)
            } catch (e: IOException) {
                return failed(tracker, TransferFailure.SOURCE_UNREADABLE, e.message)
            } catch (e: Exception) {
                return failed(tracker, TransferFailure.INTERNAL, e.javaClass.simpleName)
            }
            resolved = selection
            if (selection.skipped > 0) {
                diagnostics.add("transfer", "skipped " + selection.skipped + " unreadable entries")
            }
            tracker.update { s ->
                s.copy(
                    state = TransferState.CONNECTING,
                    title = selection.title ?: s.title,
                    totalFiles = selection.files.size,
                    totalBytes = selection.files.sumOf { file -> file.size },
                )
            }

            val outcome: PlanResult = cancellable(control) { planFor(payload.recipient) } ?: return cancelled(tracker)
            val ready: ConnectionPlan = when (outcome) {
                is PlanResult.Failed -> return failed(tracker, outcome.failure, outcome.detail)
                is PlanResult.Ready -> outcome.plan
            }
            plan = ready
            if (control.isCancelled) return cancelled(tracker)

            val qr = (payload.recipient as? Recipient.Qr)?.payload
            val token: ByteArray? = qr?.tokenBytes()
            if (qr != null && token == null) return failed(tracker, TransferFailure.AUTH_FAILED, null)

            val sender = TransferSender(
                identity,
                localPeer(),
                power.engineConfig(),
                EngineLogger { line -> diagnostics.add("engine", line) },
            )
            val target = SendTarget(
                host = ready.host,
                port = ready.port,
                expectedFingerprint = ready.expectedFingerprint,
                pairToken = token,
                transport = ready.transport,
                connector = ready.connector,
            )
            val request = SendRequest(job.id, selection.files, selection.title, settings.settings.value.compression)
            val result: TransferResult = coroutineScope {
                val run = async { sender.send(target, request, control, tracker) }
                running[job.id] = run
                try {
                    run.await()
                } catch (e: CancellationException) {
                    if (interrupted.remove(job.id)) {
                        TransferResult.Failed(TransferFailure.INTERRUPTED, null, true)
                    } else {
                        throw e
                    }
                } finally {
                    running.remove(job.id)
                }
            }

            // The handshake authenticated the peer: remember it so it shows up as a known device.
            val peer = tracker.current.peer
            if (peer != null) {
                withContext(NonCancellable) { rememberPeer(peer, ready) }
            }
            return result
        } finally {
            val toRelease = plan
            if (toRelease != null) {
                withContext(NonCancellable) {
                    try {
                        planner.release(toRelease)
                    } catch (e: Exception) {
                        diagnostics.add("transfer", "route release failed: " + e.javaClass.simpleName)
                    }
                }
            }
            val temporary = resolved
            if (temporary != null) {
                try {
                    temporary.cleanup()
                } catch (e: Exception) {
                    diagnostics.add("transfer", "cleanup failed: " + e.javaClass.simpleName)
                }
            }
        }
    }

    private suspend fun planFor(recipient: Recipient): PlanResult = when (recipient) {
        is Recipient.Nearby -> planner.plan(recipient.device)
        is Recipient.Qr -> planner.planFromQr(recipient.payload)
        is Recipient.Manual -> try {
            PlanResult.Ready(planner.planManual(recipient.host, recipient.port))
        } catch (e: IllegalArgumentException) {
            PlanResult.Failed(TransferFailure.UNREACHABLE, "bad address")
        }
    }

    private suspend fun rememberPeer(peer: PeerInfo, plan: ConnectionPlan) {
        try {
            devices.upsertSeen(peer, plan.host, plan.transport)
        } catch (e: Exception) {
            diagnostics.add("devices", "could not remember a peer: " + e.javaClass.simpleName)
        }
    }

    /**
     * Runs [block] but gives up as soon as the user cancels. Returns null in that case. A failure inside [block] is thrown
     * to the caller unchanged.
     */
    private suspend fun <T : Any> cancellable(control: TransferControl, block: suspend () -> T): T? = coroutineScope {
        val work = async { block() }
        val watcher = launch {
            control.awaitCancelled()
            work.cancel()
        }
        try {
            work.await()
        } catch (e: CancellationException) {
            if (control.isCancelled) null else throw e
        } finally {
            watcher.cancel()
        }
    }

    private fun cancelled(tracker: TransferTracker): TransferResult {
        val now = System.currentTimeMillis()
        tracker.update { s ->
            s.copy(state = TransferState.CANCELLED, finishedAt = now, bytesPerSecond = 0L, etaMillis = null)
        }
        return TransferResult.Cancelled
    }

    private fun failed(tracker: TransferTracker, failure: TransferFailure, detail: String?): TransferResult {
        val now = System.currentTimeMillis()
        val shortDetail = detail?.take(MAX_DETAIL)
        tracker.update { s ->
            s.copy(
                state = TransferState.FAILED,
                failure = failure,
                failureDetail = shortDetail,
                resumable = false,
                finishedAt = now,
                bytesPerSecond = 0L,
                etaMillis = null,
            )
        }
        diagnostics.add("transfer", "send failed before the link was up: " + failure.name)
        return TransferResult.Failed(failure, shortDetail, false)
    }

    private companion object {
        const val MAX_DETAIL = 160
    }
}
