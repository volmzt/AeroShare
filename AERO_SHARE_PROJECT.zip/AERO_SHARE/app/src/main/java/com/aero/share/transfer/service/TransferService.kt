package com.aero.share.transfer.service

import android.annotation.SuppressLint
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.IBinder
import android.os.SystemClock
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Foreground service (type dataSync) that keeps transfers and the receiver alive while the app is in the background.
 * It owns no transfer logic: it renders the [ServiceState] published by the coordinator, holds the wake/Wi-Fi locks while a
 * transfer runs, forwards notification buttons and stops itself as soon as the coordinator reports that nothing is left.
 */
class TransferService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var locks: TransferLocks? = null
    private var lastStartId = 0
    private var started = false
    private var inForeground = false
    private var renderKey: String? = null
    private var lastRenderAt = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        locks = TransferLocks(this)
        scope.launch {
            TransferServiceBridge.state.collect { state -> onState(state) }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        lastStartId = startId
        started = true
        // startForeground has to happen within seconds of EVERY start request, whatever the state is.
        val state = TransferServiceBridge.state.value
        enterForeground(state)
        val name = intent?.getStringExtra(EXTRA_ACTION)
        if (name != null) {
            val action = ServiceAction.entries.firstOrNull { it.name == name }
            if (action != null) TransferServiceBridge.dispatch(action, intent.getStringExtra(EXTRA_TRANSFER_ID))
        }
        onState(state)
        return START_NOT_STICKY
    }

    /** Android 15+: the time budget of a data-sync foreground service is used up. Everything stops cleanly. */
    override fun onTimeout(startId: Int, fgsType: Int) {
        TransferServiceBridge.timeout()
        locks?.release()
        if (inForeground) {
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            inForeground = false
        }
        stopSelf()
    }

    override fun onDestroy() {
        locks?.release()
        scope.cancel()
        TransferServiceBridge.serviceStopped()
        super.onDestroy()
    }

    private fun enterForeground(state: ServiceState) {
        val notification = Notifications.foreground(this, state)
        try {
            ServiceCompat.startForeground(
                this,
                NotificationIds.FOREGROUND,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC,
            )
            inForeground = true
            renderKey = state.layoutKey()
            lastRenderAt = SystemClock.elapsedRealtime()
        } catch (e: RuntimeException) {
            // The system refused to promote the service (for example the app is not allowed to start one right now).
            // Nothing can run safely without it, so the service ends and the coordinator tries again later.
            inForeground = false
            stopSelf(lastStartId)
        }
    }

    private fun onState(state: ServiceState) {
        if (!started) return
        val held = locks
        if (state.idle) {
            held?.release()
            if (inForeground) {
                ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
                inForeground = false
            }
            stopSelf(lastStartId)
            return
        }
        held?.update(state.holdsLocks, state.lowLatencyWifi)
        if (inForeground) render(state)
    }

    /** Progress is shown at most once per second; a change of layout (new transfer, new state) is shown immediately. */
    @SuppressLint("MissingPermission")
    private fun render(state: ServiceState) {
        val now = SystemClock.elapsedRealtime()
        val key = state.layoutKey()
        if (key == renderKey && now - lastRenderAt < RENDER_INTERVAL_MS) return
        renderKey = key
        lastRenderAt = now
        try {
            NotificationManagerCompat.from(this).notify(NotificationIds.FOREGROUND, Notifications.foreground(this, state))
        } catch (e: SecurityException) {
            // The notification permission was revoked; the foreground notification stays visible in the task manager.
        }
    }

    companion object {
        const val EXTRA_ACTION = "com.aero.share.extra.ACTION"
        const val EXTRA_TRANSFER_ID = "com.aero.share.extra.TRANSFER_ID"
        private const val RENDER_INTERVAL_MS = 1_000L

        /**
         * Intent for a notification button. The action and the data URI make every button (and every transfer) a distinct
         * PendingIntent: extras alone are ignored when the system compares PendingIntents.
         */
        fun actionIntent(context: Context, action: ServiceAction, transferId: String?): Intent {
            val intent = Intent(context, TransferService::class.java)
                .setAction("com.aero.share.action." + action.name)
                .setData(Uri.parse("aero-action://" + action.name.lowercase() + "/" + Uri.encode(transferId ?: "-")))
                .putExtra(EXTRA_ACTION, action.name)
            if (transferId != null) intent.putExtra(EXTRA_TRANSFER_ID, transferId)
            return intent
        }
    }
}
