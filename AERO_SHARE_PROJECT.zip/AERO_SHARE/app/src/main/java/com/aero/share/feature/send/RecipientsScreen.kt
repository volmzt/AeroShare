package com.aero.share.feature.send

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.QrCodeScanner
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.aero.share.R
import com.aero.share.core.common.SystemIntents
import com.aero.share.core.designsystem.AeroButton
import com.aero.share.core.designsystem.AeroButtonStyle
import com.aero.share.core.designsystem.AeroCard
import com.aero.share.core.designsystem.AeroDialog
import com.aero.share.core.designsystem.AeroScreen
import com.aero.share.core.designsystem.AeroSectionHeader
import com.aero.share.core.designsystem.AeroText
import com.aero.share.core.designsystem.AeroTheme
import com.aero.share.core.designsystem.AeroTopBar
import com.aero.share.core.designsystem.LocalAeroToast
import com.aero.share.core.permissions.Permissions
import com.aero.share.di.LocalAppContainer
import com.aero.share.feature.home.NearbyEmpty
import com.aero.share.feature.home.NearbyHeader
import com.aero.share.navigation.AeroNavigator
import com.aero.share.network.pairing.QR_SCANNER_ERROR_CAMERA

/**
 * Step two of sending: choose who receives. Devices that are nearby are listed live; a QR code scanned from the other
 * device or an IP address (when the advanced setting is on) adds a recipient that discovery cannot see. Several recipients
 * can be chosen; whatever was chosen on Home is already checked.
 */
@Composable
fun RecipientsScreen(navigator: AeroNavigator) {
    val container = LocalAppContainer.current
    val context = LocalContext.current
    val toast = LocalAeroToast.current
    val viewModel: RecipientsViewModel = viewModel(factory = viewModelFactory { initializer { RecipientsViewModel(container) } })
    val ui by viewModel.state.collectAsStateWithLifecycle()
    val selection by container.sendSession.selection.collectAsStateWithLifecycle()
    var permissionDenied by rememberSaveable { mutableStateOf(false) }
    var scanning by rememberSaveable { mutableStateOf(false) }
    var explainCamera by rememberSaveable { mutableStateOf(false) }
    var manualOpen by rememberSaveable { mutableStateOf(false) }

    val deniedText = stringResource(R.string.perm_denied_hint)
    val cameraErrorText = stringResource(R.string.send_scan_camera_error)
    val invalidText = stringResource(R.string.nav_pairing_invalid)
    val expiredText = stringResource(R.string.nav_pairing_expired)
    val unknownName = stringResource(R.string.common_unknown_device)

    val nearbyLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        permissionDenied = grants.values.any { granted -> !granted }
        viewModel.onPermissionResult()
    }
    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        if (grants.values.all { granted -> granted }) scanning = true else toast.show(deniedText)
    }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { viewModel.onResume() }
    LifecycleEventEffect(Lifecycle.Event.ON_PAUSE) { viewModel.onPause() }
    BackHandler(enabled = scanning) { scanning = false }

    // After the process was recreated the session is empty: there is nothing left to send, so return to Home.
    if (selection.isEmpty()) {
        LaunchedEffect(Unit) { navigator.backToHome() }
        return
    }

    if (scanning) {
        ScannerPane(
            onScanned = { text ->
                when (val outcome = viewModel.onScanned(text)) {
                    is ScanOutcome.Added -> {
                        scanning = false
                        toast.show(context.getString(R.string.send_scan_added, outcome.name.ifBlank { unknownName }))
                    }
                    ScanOutcome.Invalid -> toast.show(invalidText)
                    ScanOutcome.Expired -> toast.show(expiredText)
                }
            },
            onError = { code ->
                scanning = false
                if (code == QR_SCANNER_ERROR_CAMERA) toast.show(cameraErrorText)
            },
            onClose = { scanning = false },
        )
        return
    }

    val summary = remember(selection) { SelectionMath.summarize(selection) }
    val sections = ui.sections
    AeroScreen {
        AeroTopBar(title = stringResource(R.string.send_recipients_title), onBack = { navigator.back() })
        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = AeroTheme.dimens.screenPadding, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(AeroTheme.dimens.gap),
        ) {
            item(key = "summary") {
                AeroCard {
                    AeroText(
                        text = pluralStringResource(R.plurals.send_bar_count, summary.entries, summary.entries),
                        style = AeroTheme.typography.bodyStrong,
                    )
                    AeroText(text = sizeLine(summary), style = AeroTheme.typography.caption, color = AeroTheme.colors.textSecondary)
                }
            }
            item(key = "actions") {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    AeroButton(
                        text = stringResource(R.string.send_recipients_scan),
                        onClick = {
                            if (Permissions.allGranted(context, Permissions.camera())) scanning = true else explainCamera = true
                        },
                        modifier = Modifier.weight(1f),
                        style = AeroButtonStyle.Secondary,
                        icon = Icons.Rounded.QrCodeScanner,
                    )
                    if (ui.advanced) {
                        AeroButton(
                            text = stringResource(R.string.send_recipients_manual),
                            onClick = { manualOpen = true },
                            modifier = Modifier.weight(1f),
                            style = AeroButtonStyle.Secondary,
                            icon = Icons.Rounded.Tune,
                        )
                    }
                }
            }
            item(key = "nearby-header") {
                NearbyHeader(count = sections.nearby.size, searching = ui.searching, onRefresh = { viewModel.searchNow() })
            }
            val empty = ui.empty
            if (sections.nearby.isEmpty() && empty != null) {
                item(key = "nearby-empty") {
                    NearbyEmpty(
                        kind = empty,
                        permissionDenied = permissionDenied,
                        onSearch = { viewModel.searchNow() },
                        onWifiSettings = { SystemIntents.openWifiSettings(context) },
                        onAllow = { nearbyLauncher.launch(Permissions.nearby()) },
                        onAppSettings = { SystemIntents.openAppSettings(context) },
                    )
                }
            } else {
                items(sections.nearby, key = { row -> row.key }) { row ->
                    RecipientCard(row = row, onToggle = { viewModel.toggle(row) })
                }
            }
            if (sections.added.isNotEmpty()) {
                item(key = "added-header") {
                    AeroSectionHeader(text = stringResource(R.string.send_recipients_added))
                }
                items(sections.added, key = { row -> row.key }) { row ->
                    RecipientCard(row = row, onToggle = { viewModel.toggle(row) })
                }
            }
            if (sections.offline.isNotEmpty()) {
                item(key = "offline-header") {
                    AeroSectionHeader(text = stringResource(R.string.send_recipients_offline))
                }
                item(key = "offline-note") {
                    AeroText(
                        text = stringResource(R.string.send_recipients_offline_note),
                        style = AeroTheme.typography.caption,
                        color = AeroTheme.colors.textSecondary,
                        modifier = Modifier.padding(bottom = 4.dp),
                    )
                }
                items(sections.offline, key = { row -> "offline-" + row.deviceId }) { row ->
                    OfflineCard(row)
                }
            }
        }
        RecipientsBottomBar(chosen = ui.chosenCount, onContinue = { navigator.openConfirm() })
    }

    if (explainCamera) {
        AeroDialog(
            title = stringResource(R.string.perm_camera_title),
            message = stringResource(R.string.perm_camera_message),
            confirmText = stringResource(R.string.common_allow),
            dismissText = stringResource(R.string.common_not_now),
            onConfirm = {
                explainCamera = false
                cameraLauncher.launch(Permissions.camera())
            },
            onDismiss = { explainCamera = false },
        )
    }
    if (manualOpen) {
        ManualAddressDialog(
            onDismiss = { manualOpen = false },
            onAdd = { host, port ->
                viewModel.addManual(host, port)
                manualOpen = false
            },
        )
    }
}
