package com.aero.share.core.storage.source

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import com.aero.share.core.storage.UriMetadata
import com.aero.share.transfer.engine.SendableFile
import com.aero.share.transfer.model.FileCategory
import java.util.ArrayDeque

/**
 * Walks a folder chosen through the system folder picker (breadth first) and creates one sendable file per document,
 * keeping the folder structure in the relative paths. Empty folders are not transferred; entries of unknown size and
 * unreadable entries are skipped and counted.
 */
internal object FolderEnumerator {
    const val MAX_FILES = 100_000

    /** Appends the files of the tree to [out]; returns how many entries were skipped. */
    fun enumerate(context: Context, treeUri: Uri, rootName: String, out: MutableList<SendableFile>, nextId: () -> Int): Int {
        val resolver = context.contentResolver
        val rootDocumentId = DocumentsContract.getTreeDocumentId(treeUri)
        val queue = ArrayDeque<Pair<String, String>>()
        queue.add(rootDocumentId to rootName.replace('/', '_'))
        var skipped = 0
        var added = 0
        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_SIZE,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED,
        )
        while (queue.isNotEmpty()) {
            val (documentId, directory) = queue.poll() ?: break
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, documentId)
            try {
                resolver.query(children, projection, null, null, null)?.use { c ->
                    while (c.moveToNext()) {
                        val childId = c.getString(0) ?: continue
                        val name = c.getString(1)?.replace('/', '_') ?: continue
                        val mime = c.getString(2)
                        if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                            queue.add(childId to "$directory/$name")
                            continue
                        }
                        val size = if (c.isNull(3)) -1L else c.getLong(3)
                        if (size < 0L || added >= MAX_FILES) {
                            skipped++
                            continue
                        }
                        val modified = if (c.isNull(4)) 0L else c.getLong(4)
                        val documentUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, childId)
                        out.add(
                            ContentUriSendable(
                                id = nextId(),
                                relativePath = "$directory/$name",
                                size = size,
                                lastModified = modified,
                                category = FileCategory.classify(name, mime),
                                mimeType = mime,
                                uri = documentUri,
                                resolver = resolver,
                                versionProbe = { UriMetadata.query(context, documentUri)?.let { m -> com.aero.share.transfer.engine.SourceVersion(m.size, m.lastModified) } },
                            ),
                        )
                        added++
                    }
                }
            } catch (e: SecurityException) {
                skipped++
            } catch (e: RuntimeException) {
                skipped++
            }
        }
        return skipped
    }
}
