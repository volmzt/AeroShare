package com.aero.share.core.common

import java.util.Locale

/** Human readable sizes, speeds, durations and percentages. Units are binary (1 KB = 1024 B). */
object Formatters {
    private val UNITS = arrayOf("B", "KB", "MB", "GB", "TB")

    /** "0 B", "1023 B", "1.0 KB", "2.4 GB" ... One decimal above 1023 bytes, using the current locale's decimal separator. */
    fun bytes(value: Long): String {
        if (value <= 0L) return "0 B"
        if (value < 1024L) return "$value B"
        var scaled = value.toDouble()
        var unit = 0
        while (scaled >= 1024.0 && unit < UNITS.size - 1) {
            scaled /= 1024.0
            unit++
        }
        // 1023.96 KB would print as "1024.0 KB": carry into the next unit instead.
        if (Math.round(scaled * 10.0) >= 10240L && unit < UNITS.size - 1) {
            scaled /= 1024.0
            unit++
        }
        return String.format(Locale.getDefault(), "%.1f %s", scaled, UNITS[unit])
    }

    /** "12.6 MB/s". */
    fun speed(bytesPerSecond: Long): String = bytes(bytesPerSecond) + "/s"

    /** "3:25" below one hour, "1:02:10" above. Negative values are shown as "0:00". */
    fun duration(millis: Long): String {
        val totalSeconds = if (millis <= 0L) 0L else millis / 1000L
        val hours = totalSeconds / 3600L
        val minutes = (totalSeconds % 3600L) / 60L
        val seconds = totalSeconds % 60L
        return if (hours > 0L) {
            String.format(Locale.ROOT, "%d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format(Locale.ROOT, "%d:%02d", minutes, seconds)
        }
    }

    /** "42%". Never rounds up to 100% before the transfer is really complete. */
    fun percent(fraction: Float): String {
        if (fraction.isNaN()) return "0%"
        val clamped = fraction.coerceIn(0f, 1f)
        return "${(clamped.toDouble() * 100.0 + 1e-4).toInt()}%"
    }
}
