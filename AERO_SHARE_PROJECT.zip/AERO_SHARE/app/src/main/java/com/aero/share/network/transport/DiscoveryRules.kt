package com.aero.share.network.transport

import com.aero.share.domain.CapabilityState
import com.aero.share.domain.DiscoveryProblem
import com.aero.share.domain.DiscoveryState
import com.aero.share.domain.DiscoveryStatus

internal data class RouteInputs(
    /** Some screen asked for the list of nearby devices. */
    val discoveryOwned: Boolean,
    /** The receiver's TLS port when some screen wants this device to be found; null otherwise. */
    val advertisePort: Int?,
    /** Visibility setting: false means HIDDEN. */
    val visible: Boolean,
    val lanEnabled: Boolean,
    val p2pEnabled: Boolean,
    val p2pCapability: CapabilityState,
)

/** Which mechanisms must run. Everything false means everything is stopped. */
internal data class RoutePlan(
    val lanDiscovery: Boolean,
    val lanAdvertising: Boolean,
    val p2pDiscovery: Boolean,
    val p2pAdvertising: Boolean,
) {
    val any: Boolean get() = lanDiscovery || lanAdvertising || p2pDiscovery || p2pAdvertising
    val lanWanted: Boolean get() = lanDiscovery || lanAdvertising
    val p2pWanted: Boolean get() = p2pDiscovery || p2pAdvertising

    companion object {
        val NONE = RoutePlan(lanDiscovery = false, lanAdvertising = false, p2pDiscovery = false, p2pAdvertising = false)
    }
}

internal data class StateInputs(
    val route: RoutePlan,
    val discoveryOwned: Boolean,
    val lanEnabled: Boolean,
    val p2pEnabled: Boolean,
    val lanProblem: DiscoveryProblem?,
    val lanMethods: Set<String>,
    val p2pRunning: Boolean,
    val p2pCapability: CapabilityState,
)

internal object DiscoveryRules {
    const val METHOD_WIFI_DIRECT = "wifi-direct"

    /**
     * The LAN mechanisms run whenever the setting allows them: they watch the network themselves and report "no network"
     * or "Wi-Fi off", and they start finding devices the moment a network appears. Wi-Fi Direct only runs when the device
     * can really use it (feature present, permission granted, Wi-Fi on), because it is the one that costs battery and
     * needs a permission prompt.
     */
    fun route(i: RouteInputs): RoutePlan {
        val advertise = i.advertisePort != null && i.visible
        val p2pUsable = i.p2pEnabled && i.p2pCapability == CapabilityState.AVAILABLE
        return RoutePlan(
            lanDiscovery = i.discoveryOwned && i.lanEnabled,
            lanAdvertising = advertise && i.lanEnabled,
            p2pDiscovery = i.discoveryOwned && p2pUsable,
            p2pAdvertising = advertise && p2pUsable,
        )
    }

    /** The state shown to the user. A problem is reported only when nothing works and nothing is still starting. */
    fun state(i: StateInputs): DiscoveryState {
        val route = i.route
        if (!route.any && !i.discoveryOwned) return DiscoveryState()
        val methods = LinkedHashSet<String>()
        if (route.lanWanted) methods.addAll(i.lanMethods)
        if (route.p2pWanted && i.p2pRunning) methods.add(METHOD_WIFI_DIRECT)
        val advertising = (route.lanAdvertising && i.lanMethods.isNotEmpty()) || (route.p2pAdvertising && i.p2pRunning)
        val status = if (i.discoveryOwned) DiscoveryStatus.SEARCHING else DiscoveryStatus.IDLE
        if (methods.isNotEmpty()) return DiscoveryState(status, null, advertising, methods)
        // Nothing works yet. Wi-Fi Direct that is allowed to run but not up yet, or LAN without a verdict yet, is "starting".
        val starting = route.p2pWanted || (route.lanWanted && i.lanProblem == null)
        if (starting) return DiscoveryState(status, null, false, emptySet())
        return DiscoveryState(DiscoveryStatus.PROBLEM, problem(i), false, emptySet())
    }

    private fun problem(i: StateInputs): DiscoveryProblem {
        if (i.route.lanWanted) return i.lanProblem ?: DiscoveryProblem.UNAVAILABLE
        if (!i.lanEnabled && i.p2pEnabled) {
            return when (i.p2pCapability) {
                CapabilityState.PERMISSION_MISSING -> DiscoveryProblem.PERMISSION_MISSING
                CapabilityState.RADIO_OFF -> DiscoveryProblem.WIFI_OFF
                CapabilityState.NO_NETWORK -> DiscoveryProblem.NO_NETWORK
                else -> DiscoveryProblem.UNAVAILABLE
            }
        }
        return DiscoveryProblem.UNAVAILABLE
    }
}
