package com.aero.share.feature.onboarding

/** Page arithmetic of the first-launch tour. No Android classes, so it is unit-tested. */
internal object OnboardingFlow {
    /** Welcome, local transfers, discovery, permissions, receiving safely + QR pairing, privacy + look and language. */
    const val COUNT = 6
    const val LAST = COUNT - 1

    /** Zero-based index of the page that lists the permissions and when each one is asked for. */
    const val PERMISSIONS = 3

    /** The next page when Next is pressed on [current], or null on the last page. */
    fun next(current: Int): Int? = if (current in 0 until LAST) current + 1 else null

    /** The page Back returns to from [current], or null on the first page (where Back leaves the app). */
    fun previous(current: Int): Int? = if (current in 1..LAST) current - 1 else null

    /** Skip is offered on every page except the last, where "Get started" takes its place. */
    fun showsSkip(current: Int): Boolean = current in 0 until LAST
}
