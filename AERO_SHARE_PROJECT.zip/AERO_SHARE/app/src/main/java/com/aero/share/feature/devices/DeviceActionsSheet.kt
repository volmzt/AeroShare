package com.aero.share.feature.devices

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.Block
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.aero.share.R
import com.aero.share.core.common.LocalDeviceModel
import com.aero.share.core.common.labelRes
import com.aero.share.core.designsystem.AeroBottomSheet
import com.aero.share.core.designsystem.AeroDeviceIcon
import com.aero.share.core.designsystem.AeroDialog
import com.aero.share.core.designsystem.AeroGroup
import com.aero.share.core.designsystem.AeroInputDialog
import com.aero.share.core.designsystem.AeroDivider
import com.aero.share.core.designsystem.AeroSettingsRow
import com.aero.share.core.designsystem.AeroText
import com.aero.share.core.designsystem.AeroTheme
import com.aero.share.domain.NearbyDevice
import com.aero.share.feature.send.metaLine
import com.aero.share.transfer.model.PeerTrust

/** Which secondary window is open above the sheet. */
private enum class SheetDialog { NONE, RENAME, TRUST, BLOCK, FORGET, INFO }

/**
 * What can be done with one device. Sending needs the device to be nearby; trust, block and rename need a stored record
 * (created by the first real connection). Every action closes the sheet except "View information".
 */
@Composable
internal fun DeviceActionsSheet(
    target: DeviceTarget,
    autoAcceptTrusted: Boolean,
    onDismiss: () -> Unit,
    onSend: (NearbyDevice) -> Unit,
    onRename: (String) -> Unit,
    onSetTrusted: (Boolean) -> Unit,
    onSetBlocked: (Boolean) -> Unit,
    onForget: () -> Unit,
) {
    var dialog by rememberSaveable { mutableStateOf(SheetDialog.NONE) }
    val colors = AeroTheme.colors
    val availability = DevicesLogic.availability(target.blocked, target.nearby)
    val name = target.name.ifBlank { stringResource(R.string.common_unknown_device) }
    val trust = when {
        target.record == null -> PeerTrust.UNKNOWN
        target.blocked -> PeerTrust.BLOCKED
        target.trusted -> PeerTrust.TRUSTED
        else -> PeerTrust.KNOWN
    }

    AeroBottomSheet(onDismiss = onDismiss) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AeroDeviceIcon(kind = target.kind)
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                AeroText(text = name, style = AeroTheme.typography.titleSmall, maxLines = 2)
                AeroText(
                    text = metaLine(listOf(stringResource(target.kind.labelRes()), stringResource(trust.labelRes()))),
                    style = AeroTheme.typography.caption,
                    color = colors.textSecondary,
                )
            }
        }
        Spacer(Modifier.height(16.dp))
        AeroGroup {
            AeroSettingsRow(
                title = stringResource(R.string.dev_action_send),
                subtitle = when (availability) {
                    SendAvailability.AVAILABLE -> null
                    SendAvailability.NOT_NEARBY -> stringResource(R.string.dev_send_not_nearby)
                    SendAvailability.BLOCKED -> stringResource(R.string.dev_send_blocked)
                },
                icon = Icons.AutoMirrored.Rounded.Send,
                enabled = availability == SendAvailability.AVAILABLE,
                onClick = {
                    val device = target.nearby
                    if (device != null) onSend(device)
                },
            )
            if (target.manageable) {
                AeroDivider()
                AeroSettingsRow(
                    title = stringResource(R.string.dev_action_rename),
                    icon = Icons.Rounded.Edit,
                    onClick = { dialog = SheetDialog.RENAME },
                )
                AeroDivider()
                AeroSettingsRow(
                    title = stringResource(if (target.trusted) R.string.dev_action_untrust else R.string.dev_action_trust),
                    subtitle = stringResource(if (target.trusted) R.string.dev_untrust_hint else R.string.dev_trust_hint),
                    icon = if (target.trusted) Icons.Rounded.Close else Icons.Rounded.VerifiedUser,
                    onClick = {
                        if (target.trusted) {
                            onSetTrusted(false)
                            onDismiss()
                        } else {
                            dialog = SheetDialog.TRUST
                        }
                    },
                )
                AeroDivider()
                AeroSettingsRow(
                    title = stringResource(if (target.blocked) R.string.dev_action_unblock else R.string.dev_action_block),
                    subtitle = stringResource(if (target.blocked) R.string.dev_unblock_hint else R.string.dev_block_hint),
                    icon = Icons.Rounded.Block,
                    onClick = {
                        if (target.blocked) {
                            onSetBlocked(false)
                            onDismiss()
                        } else {
                            dialog = SheetDialog.BLOCK
                        }
                    },
                )
            }
            AeroDivider()
            AeroSettingsRow(
                title = stringResource(R.string.dev_action_info),
                icon = Icons.Rounded.Info,
                onClick = { dialog = SheetDialog.INFO },
            )
            if (target.manageable) {
                AeroDivider()
                AeroSettingsRow(
                    title = stringResource(R.string.dev_action_forget),
                    icon = Icons.Rounded.Delete,
                    onClick = { dialog = SheetDialog.FORGET },
                )
            }
        }
        if (!target.manageable) {
            Spacer(Modifier.height(12.dp))
            AeroText(
                text = stringResource(R.string.dev_not_connected_yet),
                style = AeroTheme.typography.caption,
                color = colors.textSecondary,
            )
        }
        Spacer(Modifier.height(8.dp))
    }

    // Created after the sheet, so they are drawn above it.
    val record = target.record
    when (dialog) {
        SheetDialog.NONE -> Unit
        SheetDialog.RENAME -> AeroInputDialog(
            title = stringResource(R.string.dev_rename_title),
            initialValue = record?.alias.orEmpty(),
            confirmText = stringResource(R.string.common_save),
            dismissText = stringResource(R.string.common_cancel),
            onConfirm = { text ->
                dialog = SheetDialog.NONE
                onRename(text)
                onDismiss()
            },
            onDismiss = { dialog = SheetDialog.NONE },
            label = stringResource(R.string.dev_rename_label),
            placeholder = record?.name.orEmpty(),
            message = stringResource(R.string.dev_rename_message),
            maxLength = LocalDeviceModel.MAX_NAME_LENGTH,
        )
        SheetDialog.TRUST -> AeroDialog(
            title = stringResource(R.string.dev_trust_title),
            message = stringResource(if (autoAcceptTrusted) R.string.dev_trust_message_auto else R.string.dev_trust_message_manual),
            confirmText = stringResource(R.string.dev_trust_confirm),
            dismissText = stringResource(R.string.common_cancel),
            onConfirm = {
                dialog = SheetDialog.NONE
                onSetTrusted(true)
                onDismiss()
            },
            onDismiss = { dialog = SheetDialog.NONE },
        )
        SheetDialog.BLOCK -> AeroDialog(
            title = stringResource(R.string.dev_block_title),
            message = stringResource(R.string.dev_block_message),
            confirmText = stringResource(R.string.dev_block_confirm),
            dismissText = stringResource(R.string.common_cancel),
            danger = true,
            onConfirm = {
                dialog = SheetDialog.NONE
                onSetBlocked(true)
                onDismiss()
            },
            onDismiss = { dialog = SheetDialog.NONE },
        )
        SheetDialog.FORGET -> AeroDialog(
            title = stringResource(R.string.dev_forget_title),
            message = stringResource(R.string.dev_forget_message),
            confirmText = stringResource(R.string.dev_forget_confirm),
            dismissText = stringResource(R.string.common_cancel),
            danger = true,
            onConfirm = {
                dialog = SheetDialog.NONE
                onForget()
                onDismiss()
            },
            onDismiss = { dialog = SheetDialog.NONE },
        )
        SheetDialog.INFO -> DeviceInfoSheet(target = target, onDismiss = { dialog = SheetDialog.NONE })
    }
}
