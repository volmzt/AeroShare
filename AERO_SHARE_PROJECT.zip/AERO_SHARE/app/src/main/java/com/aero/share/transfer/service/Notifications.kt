package com.aero.share.transfer.service

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import androidx.annotation.StringRes
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.aero.share.MainActivity
import com.aero.share.R
import com.aero.share.core.common.Formatters
import com.aero.share.core.common.LocaleHelper
import com.aero.share.core.common.messageRes
import com.aero.share.domain.PendingIncoming
import com.aero.share.transfer.model.TransferDirection
import com.aero.share.transfer.model.TransferSnapshot
import com.aero.share.transfer.model.TransferState

/**
 * Notification channels and builders. Every text is read from a context wrapped with the in-app language, so a language chosen
 * in the settings (which can differ from the system language) is honoured. Notifications never contain file names.
 */
object Notifications {
    const val CHANNEL_TRANSFERS = "transfers"
    const val CHANNEL_INCOMING = "incoming"
    const val CHANNEL_RESULTS = "results"
    const val CHANNEL_RECEIVER = "receiver"

    private const val BRAND_COLOR = 0xFFFF7900.toInt()

    /** Creates (or updates the names of) the four channels. Safe to call repeatedly, e.g. after a language change. */
    fun createChannels(context: Context) {
        val ctx = LocaleHelper.wrap(context)
        val manager = ctx.getSystemService(NotificationManager::class.java) ?: return
        manager.createNotificationChannels(
            listOf(
                channel(ctx, CHANNEL_TRANSFERS, R.string.notif_channel_transfers, R.string.notif_channel_transfers_desc, NotificationManager.IMPORTANCE_LOW),
                channel(ctx, CHANNEL_INCOMING, R.string.notif_channel_incoming, R.string.notif_channel_incoming_desc, NotificationManager.IMPORTANCE_HIGH),
                channel(ctx, CHANNEL_RESULTS, R.string.notif_channel_results, R.string.notif_channel_results_desc, NotificationManager.IMPORTANCE_DEFAULT),
                channel(ctx, CHANNEL_RECEIVER, R.string.notif_channel_receiver, R.string.notif_channel_receiver_desc, NotificationManager.IMPORTANCE_LOW),
            ),
        )
    }

    private fun channel(
        ctx: Context,
        id: String,
        @StringRes name: Int,
        @StringRes description: Int,
        importance: Int,
    ): NotificationChannel {
        val channel = NotificationChannel(id, ctx.getString(name), importance)
        channel.description = ctx.getString(description)
        channel.setShowBadge(id == CHANNEL_INCOMING)
        return channel
    }

    // ---------------------------------------------------------------- foreground notification

    /** The notification of the foreground service. It is always shown while the service runs, whatever the settings say. */
    internal fun foreground(context: Context, state: ServiceState): Notification {
        val ctx = LocaleHelper.wrap(context)
        val presentation = ForegroundPresentation.of(state)
        val channelId = if (presentation.phase == Phase.READY) CHANNEL_RECEIVER else CHANNEL_TRANSFERS
        val builder = baseBuilder(ctx, channelId)
            .setContentTitle(ctx.getString(R.string.app_name))
            .setContentText(ctx.getString(textFor(presentation.phase)))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
        if (presentation.showProgress) {
            builder.setProgress(ForegroundPresentation.PROGRESS_MAX, presentation.progress, presentation.indeterminate)
        }
        if (presentation.showsSizes) {
            val done = Formatters.bytes(presentation.transferred)
            val total = Formatters.bytes(presentation.total)
            val sub = if (presentation.phase != Phase.PAUSED && presentation.bytesPerSecond > 0L) {
                ctx.getString(R.string.notif_progress_speed, done, total, Formatters.speed(presentation.bytesPerSecond))
            } else {
                ctx.getString(R.string.notif_progress_plain, done, total)
            }
            builder.setSubText(sub)
        }
        for (action in presentation.actions) {
            builder.addAction(0, ctx.getString(labelFor(action)), actionIntent(ctx, action, presentation.primaryId))
        }
        return builder.build()
    }

    @StringRes
    private fun textFor(phase: Phase): Int = when (phase) {
        Phase.SENDING -> R.string.notif_text_sending
        Phase.RECEIVING -> R.string.notif_text_receiving
        Phase.CONNECTING -> R.string.notif_text_connecting
        Phase.AWAITING -> R.string.notif_text_awaiting
        Phase.PREPARING -> R.string.notif_text_preparing
        Phase.PAUSED -> R.string.notif_text_paused
        Phase.VERIFYING -> R.string.notif_text_verifying
        Phase.READY -> R.string.notif_text_ready
        Phase.QUEUED -> R.string.notif_text_queued
    }

    @StringRes
    private fun labelFor(action: ServiceAction): Int = when (action) {
        ServiceAction.PAUSE -> R.string.notif_action_pause
        ServiceAction.RESUME -> R.string.notif_action_resume
        ServiceAction.CANCEL -> R.string.notif_action_cancel
        ServiceAction.ACCEPT -> R.string.notif_action_accept
        ServiceAction.DECLINE -> R.string.notif_action_decline
        ServiceAction.STOP_RECEIVING -> R.string.notif_action_stop
    }

    // ---------------------------------------------------------------- incoming request

    /**
     * Shows an incoming request. A first contact (which comes with a verification code) can only be declined from the
     * notification: the code has to be compared with the other device inside the app before accepting.
     */
    @SuppressLint("MissingPermission")
    internal fun postIncoming(context: Context, pending: PendingIncoming) {
        val manager = NotificationManagerCompat.from(context)
        if (!manager.areNotificationsEnabled()) return
        val ctx = LocaleHelper.wrap(context)
        val name = pending.peerName.ifBlank { ctx.getString(R.string.notif_unknown_device) }
        val title = if (pending.isResume) {
            ctx.getString(R.string.notif_incoming_title_resume, name)
        } else {
            ctx.getString(R.string.notif_incoming_title, name)
        }
        val code = pending.verificationCode
        val summary = filesSummary(ctx, pending.fileCount, pending.totalBytes)
        val body = StringBuilder(summary)
        if (code != null) {
            body.append('\n').append(ctx.getString(R.string.notif_incoming_code, code))
            body.append('\n').append(ctx.getString(R.string.notif_incoming_open_to_verify, ctx.getString(R.string.app_name)))
        }
        val remaining = pending.expiresAtElapsed - SystemClock.elapsedRealtime()
        val builder = baseBuilder(ctx, CHANNEL_INCOMING)
            .setContentTitle(title)
            .setContentText(summary)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body.toString()))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setAutoCancel(true)
            .setTimeoutAfter(remaining.coerceAtLeast(1_000L))
        if (code == null) {
            builder.addAction(0, ctx.getString(R.string.notif_action_accept), actionIntent(ctx, ServiceAction.ACCEPT, pending.transferId))
        }
        builder.addAction(0, ctx.getString(R.string.notif_action_decline), actionIntent(ctx, ServiceAction.DECLINE, pending.transferId))
        try {
            manager.notify(pending.transferId, NotificationIds.INCOMING, builder.build())
        } catch (e: SecurityException) {
            // The notification permission was revoked while the request was being posted: the in-app prompt still works.
        }
    }

    internal fun cancelIncoming(context: Context, transferId: String) {
        NotificationManagerCompat.from(context).cancel(transferId, NotificationIds.INCOMING)
    }

    // ---------------------------------------------------------------- results

    /** Completed, failed or interrupted transfers. A transfer the user cancelled does not produce a notification. */
    @SuppressLint("MissingPermission")
    internal fun postResult(context: Context, snapshot: TransferSnapshot) {
        val manager = NotificationManagerCompat.from(context)
        if (!manager.areNotificationsEnabled()) return
        val ctx = LocaleHelper.wrap(context)
        val name = snapshot.peerName
        val sending = snapshot.direction == TransferDirection.SEND
        val builder = baseBuilder(ctx, CHANNEL_RESULTS)
            .setAutoCancel(true)
            .setCategory(NotificationCompat.CATEGORY_STATUS)
        when (snapshot.state) {
            TransferState.COMPLETED -> {
                val title = when {
                    name.isBlank() -> ctx.getString(if (sending) R.string.notif_result_sent_plain else R.string.notif_result_received_plain)
                    else -> ctx.getString(if (sending) R.string.notif_result_sent_title else R.string.notif_result_received_title, name)
                }
                builder.setContentTitle(title)
                    .setContentText(filesSummary(ctx, snapshot.totalFiles, snapshot.totalBytes))
            }
            TransferState.FAILED -> {
                builder.setContentTitle(ctx.getString(R.string.notif_result_failed_title))
                val failure = snapshot.failure
                if (failure != null) builder.setContentText(ctx.getString(failure.messageRes()))
            }
            TransferState.INTERRUPTED -> {
                builder.setContentTitle(ctx.getString(R.string.notif_result_interrupted_title))
                    .setContentText(ctx.getString(R.string.notif_result_interrupted_text, ctx.getString(R.string.app_name)))
            }
            else -> return
        }
        try {
            manager.notify(snapshot.id, NotificationIds.RESULT, builder.build())
        } catch (e: SecurityException) {
            // Permission revoked while posting; the result is still in the history.
        }
    }

    // ---------------------------------------------------------------- helpers

    private fun filesSummary(ctx: Context, count: Int, bytes: Long): String {
        val shown = count.coerceAtLeast(1)
        return ctx.resources.getQuantityString(R.plurals.notif_files_summary, shown, shown, Formatters.bytes(bytes))
    }

    private fun baseBuilder(ctx: Context, channelId: String): NotificationCompat.Builder =
        NotificationCompat.Builder(ctx, channelId)
            .setSmallIcon(R.drawable.ic_notif_aero)
            .setColor(BRAND_COLOR)
            .setContentIntent(openAppIntent(ctx))
            .setShowWhen(false)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)

    private fun openAppIntent(ctx: Context): PendingIntent {
        val intent = Intent(ctx, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        return PendingIntent.getActivity(ctx, 0, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    /** Button intents go to the service, which forwards them to the coordinator. */
    private fun actionIntent(ctx: Context, action: ServiceAction, transferId: String?): PendingIntent {
        val intent = TransferService.actionIntent(ctx, action, transferId)
        val requestCode = action.ordinal * 100_003 + (transferId?.hashCode() ?: 0)
        return PendingIntent.getForegroundService(
            ctx,
            requestCode,
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
    }
}
