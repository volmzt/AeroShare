package com.aero.share.feature.send

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.aero.share.R
import com.aero.share.core.common.SystemIntents
import com.aero.share.core.designsystem.AeroButton
import com.aero.share.core.designsystem.AeroCard
import com.aero.share.core.designsystem.AeroDialog
import com.aero.share.core.designsystem.AeroDivider
import com.aero.share.core.designsystem.AeroScreen
import com.aero.share.core.designsystem.AeroSectionHeader
import com.aero.share.core.designsystem.AeroText
import com.aero.share.core.designsystem.AeroTheme
import com.aero.share.core.designsystem.AeroTopBar
import com.aero.share.core.permissions.PermissionPrompts
import com.aero.share.core.permissions.Permissions
import com.aero.share.di.LocalAppContainer
import com.aero.share.navigation.AeroNavigator

/**
 * Step three of sending: the last look before anything leaves the device. It shows what is sent, to whom and how the
 * connection will be made, lists the things worth knowing (a large transfer, Wi-Fi that is off, a device that must confirm
 * a code) and starts the transfers. The first time, the notification permission is explained and asked for here.
 */
@Composable
fun ConfirmScreen(navigator: AeroNavigator) {
    val container = LocalAppContainer.current
    val context = LocalContext.current
    val viewModel: ConfirmViewModel = viewModel(factory = viewModelFactory { initializer { ConfirmViewModel(container) } })
    val ui by viewModel.state.collectAsStateWithLifecycle()
    val selection by container.sendSession.selection.collectAsStateWithLifecycle()
    var reviewOpen by rememberSaveable { mutableStateOf(false) }
    var explainNotifications by rememberSaveable { mutableStateOf(false) }
    // Once the transfers exist the session is emptied on purpose; that must not be mistaken for a lost session below.
    var sent by remember { mutableStateOf(false) }

    val startSending: () -> Unit = {
        val first = viewModel.send()
        if (first != null) {
            sent = true
            navigator.openTransfer(first, replaceCurrent = true)
        }
    }
    val notificationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { _ ->
        // Allowed or not, the transfer goes ahead: notifications only add progress and answer buttons.
        startSending()
    }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { viewModel.refreshRadio() }

    // After the process was recreated the session is empty: there is nothing left to send, so return to Home.
    if (selection.isEmpty() && !sent) {
        LaunchedEffect(Unit) { navigator.backToHome() }
        return
    }

    val summary = ui.summary
    AeroScreen {
        AeroTopBar(title = stringResource(R.string.send_confirm_title), onBack = { navigator.back() })
        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = AeroTheme.dimens.screenPadding, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(AeroTheme.dimens.gap),
        ) {
            item(key = "what-header") { AeroSectionHeader(text = stringResource(R.string.send_confirm_what)) }
            item(key = "what") {
                AeroCard(onClick = { reviewOpen = true }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            AeroText(
                                text = pluralStringResource(R.plurals.send_bar_count, summary.entries, summary.entries),
                                style = AeroTheme.typography.bodyStrong,
                            )
                            AeroText(
                                text = sizeLine(summary),
                                style = AeroTheme.typography.caption,
                                color = AeroTheme.colors.textSecondary,
                            )
                        }
                        AeroText(
                            text = stringResource(R.string.send_bar_review),
                            style = AeroTheme.typography.label,
                            color = AeroTheme.colors.accentText,
                        )
                    }
                    CategoryChips(summary)
                }
            }
            item(key = "to-header") { AeroSectionHeader(text = stringResource(R.string.send_confirm_to)) }
            item(key = "to") {
                AeroCard {
                    val removable = ui.recipients.size > 1
                    ui.recipients.forEachIndexed { index, recipient ->
                        if (index > 0) AeroDivider()
                        ConfirmRecipientRow(
                            recipient = recipient,
                            canRemove = removable,
                            onRemove = { viewModel.removeRecipient(recipient.key) },
                        )
                    }
                }
            }
            items(ui.warnings, key = { warning -> warning.name }) { warning ->
                ConfirmWarningRow(
                    warning = warning,
                    summary = summary,
                    onWifiSettings = { SystemIntents.openWifiSettings(context) },
                )
            }
            if (ui.compression) {
                item(key = "compression") {
                    AeroText(
                        text = stringResource(R.string.send_confirm_compression),
                        style = AeroTheme.typography.caption,
                        color = AeroTheme.colors.textSecondary,
                    )
                }
            }
            item(key = "secure") {
                AeroText(
                    text = stringResource(R.string.send_confirm_secure),
                    style = AeroTheme.typography.caption,
                    color = AeroTheme.colors.textSecondary,
                )
            }
        }
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(AeroTheme.colors.surfaceElevated)
                .padding(horizontal = AeroTheme.dimens.screenPadding, vertical = 12.dp),
        ) {
            AeroText(
                text = stringResource(R.string.send_confirm_hint),
                style = AeroTheme.typography.caption,
                color = AeroTheme.colors.textSecondary,
            )
            Spacer(Modifier.height(10.dp))
            AeroButton(
                text = stringResource(R.string.send_confirm_send),
                onClick = {
                    val needsExplanation = !Permissions.allGranted(context, Permissions.notifications()) &&
                        !PermissionPrompts.wasShown(context, PermissionPrompts.NOTIFICATIONS)
                    if (needsExplanation) explainNotifications = true else startSending()
                },
                modifier = Modifier.fillMaxWidth(),
                icon = Icons.AutoMirrored.Rounded.Send,
                enabled = ui.canSend,
            )
        }
    }

    if (reviewOpen) {
        SelectionReview(
            items = selection,
            onRemove = { id -> viewModel.removeItem(id) },
            onClear = { viewModel.clearItems() },
            onDismiss = { reviewOpen = false },
        )
    }
    if (explainNotifications) {
        AeroDialog(
            title = stringResource(R.string.perm_notifications_title),
            message = stringResource(R.string.perm_notifications_message),
            confirmText = stringResource(R.string.common_allow),
            dismissText = stringResource(R.string.common_not_now),
            onConfirm = {
                explainNotifications = false
                PermissionPrompts.markShown(context, PermissionPrompts.NOTIFICATIONS)
                notificationLauncher.launch(Permissions.notifications())
            },
            onDismiss = {
                explainNotifications = false
                PermissionPrompts.markShown(context, PermissionPrompts.NOTIFICATIONS)
                startSending()
            },
        )
    }
}
