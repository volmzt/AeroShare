package com.aero.share.network.transport

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiManager
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.core.location.LocationManagerCompat
import com.aero.share.core.permissions.Permissions
import com.aero.share.domain.CapabilityProvider
import com.aero.share.domain.RadioStatus
import com.aero.share.domain.TransportCapability
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * What the device can honestly do right now, per transport. The states come from the actual radio, network, permission
 * and location state (see [CapabilityRules]); nothing is assumed. Changes of Wi-Fi, Bluetooth, location and networks are
 * observed with passive callbacks that live as long as the process and cost nothing while nothing changes. Permission
 * grants are not announced by Android, so the UI calls [refresh] after a permission result and when the app resumes.
 * Bluetooth is only reported for information: AERO SHARE does not use it in this version.
 */
class AppCapabilityProvider(
    context: Context,
    private val scope: CoroutineScope,
    private val p2p: WifiDirectManager,
) : CapabilityProvider {
    private val app = context.applicationContext
    private val wifi: WifiManager? = app.getSystemService(WifiManager::class.java)
    private val connectivity: ConnectivityManager? = app.getSystemService(ConnectivityManager::class.java)
    private val locations: LocationManager? = app.getSystemService(LocationManager::class.java)
    private val bluetooth: BluetoothManager? = app.getSystemService(BluetoothManager::class.java)
    private val hasWifiHardware = app.packageManager.hasSystemFeature(PackageManager.FEATURE_WIFI)
    private val hasBluetooth = app.packageManager.hasSystemFeature(PackageManager.FEATURE_BLUETOOTH)
    private val kick = Channel<Unit>(Channel.CONFLATED)

    private val initial = readFacts()
    private val capabilityState = MutableStateFlow(CapabilityRules.compute(initial))
    private val radioState = MutableStateFlow(CapabilityRules.radio(initial))

    override val capabilities: StateFlow<List<TransportCapability>> = capabilityState.asStateFlow()
    override val radio: StateFlow<RadioStatus> = radioState.asStateFlow()

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            kick.trySend(Unit)
        }
    }

    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            kick.trySend(Unit)
        }

        override fun onLost(network: Network) {
            kick.trySend(Unit)
        }

        override fun onLinkPropertiesChanged(network: Network, linkProperties: android.net.LinkProperties) {
            kick.trySend(Unit)
        }
    }

    init {
        register()
        scope.launch {
            for (ignored in kick) {
                delay(DEBOUNCE_MS)
                publish()
            }
        }
    }

    override fun refresh() {
        publish()
    }

    private fun publish() {
        val facts = readFacts()
        capabilityState.value = CapabilityRules.compute(facts)
        radioState.value = CapabilityRules.radio(facts)
    }

    private fun readFacts(): CapabilityFacts {
        val lan = LanNetworkFinder.find(app)
        return CapabilityFacts(
            sdkInt = Build.VERSION.SDK_INT,
            hasWifiHardware = hasWifiHardware,
            hasWifiDirect = p2p.available,
            wifiEnabled = readWifiEnabled(),
            lanConnected = lan != null,
            wifiConnected = lan?.isWifi == true,
            nearbyGranted = Permissions.allGranted(app, Permissions.nearby()),
            locationEnabled = readLocationEnabled(),
            bluetoothSupported = hasBluetooth,
            bluetoothEnabled = readBluetoothEnabled(),
        )
    }

    private fun readWifiEnabled(): Boolean = try {
        wifi?.isWifiEnabled == true
    } catch (e: SecurityException) {
        false
    }

    private fun readLocationEnabled(): Boolean = try {
        locations != null && LocationManagerCompat.isLocationEnabled(locations)
    } catch (e: RuntimeException) {
        false
    }

    /** Needs no permission on Android 12+; older versions may refuse without BLUETOOTH, which counts as "not known on". */
    private fun readBluetoothEnabled(): Boolean = try {
        bluetooth?.adapter?.isEnabled == true
    } catch (e: SecurityException) {
        false
    }

    private fun register() {
        val filter = IntentFilter()
        filter.addAction(WifiManager.WIFI_STATE_CHANGED_ACTION)
        filter.addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
        filter.addAction(LocationManager.PROVIDERS_CHANGED_ACTION)
        filter.addAction(LOCATION_MODE_CHANGED_ACTION)
        try {
            ContextCompat.registerReceiver(app, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        } catch (e: RuntimeException) {
            // capabilities are then refreshed on demand only
        }
        val request = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .addTransportType(NetworkCapabilities.TRANSPORT_ETHERNET)
            .build()
        try {
            connectivity?.registerNetworkCallback(request, networkCallback)
        } catch (e: RuntimeException) {
            // capabilities are then refreshed on demand only
        }
    }

    private companion object {
        const val DEBOUNCE_MS = 250L
        const val LOCATION_MODE_CHANGED_ACTION = "android.location.MODE_CHANGED"
    }
}
