package com.aero.share.transfer

import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.SocketException
import java.util.Collections

internal object Ipv4 {
    /**
     * "192.168.1.20" -> packed int; null for anything that is not a canonical dotted-quad IPv4 address. Leading zeros are
     * refused because some parsers read them as octal numbers.
     */
    fun parse(text: String): Int? {
        val parts = text.split('.')
        if (parts.size != 4) return null
        var value = 0
        for (part in parts) {
            if (part.isEmpty() || part.length > 3 || !part.all { it in '0'..'9' }) return null
            if (part.length > 1 && part[0] == '0') return null
            val octet = part.toInt()
            if (octet > 255) return null
            value = (value shl 8) or octet
        }
        return value
    }
}

/** An IPv4 network such as 192.168.43.0/24. Prefixes shorter than /8 are refused so that "everything" can never match. */
internal data class Ipv4Subnet(val network: Int, val prefixLength: Int) {
    fun contains(address: Int): Boolean {
        val mask = if (prefixLength >= 32) -1 else (-1 shl (32 - prefixLength))
        return (address and mask) == (network and mask)
    }

    companion object {
        fun of(host: String, prefixLength: Int): Ipv4Subnet? {
            val value = Ipv4.parse(host) ?: return null
            if (prefixLength !in 8..32) return null
            return Ipv4Subnet(value, prefixLength)
        }
    }
}

/** One private IPv4 address of this device together with the interface that owns it. */
internal data class LocalAddress(
    val interfaceName: String,
    val host: String,
    val value: Int,
    val prefixLength: Int,
) {
    val subnet: Ipv4Subnet? get() = Ipv4Subnet.of(host, prefixLength)
}

internal object LocalAddresses {
    private val NOT_A_LAN = listOf(
        "rmnet", "ccmni", "clat", "v4-", "tun", "ppp", "dummy", "ifb", "sit", "ip6tnl", "veth", "docker",
        "wwan", "pdp", "bt-pan", "bnep", "lo",
    )

    /** Cellular, tunnel, Bluetooth-PAN and virtual interfaces never carry a transfer peer. */
    fun isLanInterface(name: String): Boolean {
        val lower = name.lowercase()
        return NOT_A_LAN.none { lower.startsWith(it) }
    }

    /** Lower is better: Wi-Fi/Ethernet, then USB tethering, then hotspot/other, then Wi-Fi Direct. */
    fun priority(name: String): Int {
        val lower = name.lowercase()
        return when {
            lower.startsWith("wlan0") || lower.startsWith("eth") || lower.startsWith("en") -> 0
            lower.startsWith("rndis") || lower.startsWith("usb") -> 1
            lower.startsWith("p2p") -> 3
            else -> 2
        }
    }

    /** Every up, non-loopback interface address that is a private (RFC 1918) IPv4 address. */
    fun enumerate(): List<LocalAddress> {
        val out = ArrayList<LocalAddress>()
        val interfaces = try {
            NetworkInterface.getNetworkInterfaces()
        } catch (e: SocketException) {
            null
        } ?: return out
        for (ni in Collections.list(interfaces)) {
            try {
                if (!ni.isUp || ni.isLoopback) continue
                val name = ni.name ?: continue
                if (!isLanInterface(name)) continue
                for (ia in ni.interfaceAddresses) {
                    val address = ia.address as? Inet4Address ?: continue
                    if (!address.isSiteLocalAddress) continue
                    val host = address.hostAddress ?: continue
                    val value = Ipv4.parse(host) ?: continue
                    out.add(LocalAddress(name, host, value, ia.networkPrefixLength.toInt()))
                }
            } catch (e: SocketException) {
                continue
            }
        }
        return out
    }

    /** Addresses to show for manual connections, best first, without duplicates. */
    fun receiverAddresses(all: List<LocalAddress>): List<String> =
        all.sortedBy { priority(it.interfaceName) }.map { it.host }.distinct()

    /**
     * Hosts for a pairing QR code (at most [max], the format allows four). Addresses of a hotspot that was just started come
     * first: the scanning phone joins that hotspot and has no other way to find this device.
     */
    fun qrHosts(all: List<LocalAddress>, hotspotHosts: List<String>, max: Int = 4): List<String> {
        val result = ArrayList<String>()
        for (host in hotspotHosts) {
            if (result.size >= max) break
            if (host !in result) result.add(host)
        }
        for (address in all.sortedBy { priority(it.interfaceName) }) {
            if (result.size >= max) break
            if (address.host !in result) result.add(address.host)
        }
        return result
    }
}
