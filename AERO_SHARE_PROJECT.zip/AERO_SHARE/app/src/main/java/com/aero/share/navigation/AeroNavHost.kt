package com.aero.share.navigation

import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.navigation.NavBackStackEntry
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.aero.share.core.designsystem.AeroMotion
import com.aero.share.core.designsystem.AeroTheme
import com.aero.share.feature.devices.DevicesScreen
import com.aero.share.feature.history.HistoryScreen
import com.aero.share.feature.home.HomeScreen
import com.aero.share.feature.receive.ReceiveScreen
import com.aero.share.feature.send.ConfirmScreen
import com.aero.share.feature.send.RecipientsScreen
import com.aero.share.feature.send.SendPickerScreen
import com.aero.share.feature.settings.AboutScreen
import com.aero.share.feature.settings.DiagnosticsScreen
import com.aero.share.feature.settings.SettingsScreen
import com.aero.share.feature.settings.SettingsSectionScreen
import com.aero.share.feature.transfer.TransferScreen

/** All destinations of the app. Screens receive only the [AeroNavigator], never the controller. */
@Composable
internal fun AeroNavHost(
    navController: NavHostController,
    navigator: AeroNavigator,
    modifier: Modifier = Modifier,
) {
    val motion = AeroTheme.motion
    val slidePx = with(LocalDensity.current) { 12.dp.roundToPx() }

    NavHost(
        navController = navController,
        startDestination = Routes.HOME,
        modifier = modifier,
        enterTransition = {
            NavTransitions.enter(motion, slidePx, initialState.destination.route, targetState.destination.route, false)
        },
        exitTransition = {
            NavTransitions.exit(motion, slidePx, initialState.destination.route, targetState.destination.route, false)
        },
        popEnterTransition = {
            NavTransitions.enter(motion, slidePx, initialState.destination.route, targetState.destination.route, true)
        },
        popExitTransition = {
            NavTransitions.exit(motion, slidePx, initialState.destination.route, targetState.destination.route, true)
        },
    ) {
        composable(Routes.HOME) { HomeScreen(navigator) }
        composable(Routes.DEVICES) { DevicesScreen(navigator) }
        composable(Routes.SETTINGS) { SettingsScreen(navigator) }
        composable(
            route = Routes.SETTINGS_SECTION,
            arguments = listOf(navArgument(Routes.ARG_SECTION) { type = NavType.StringType }),
        ) { entry ->
            val section = Routes.sectionOf(entry.arguments?.getString(Routes.ARG_SECTION))
            if (section != null) {
                SettingsSectionScreen(section, navigator)
            } else {
                LaunchedEffect(Unit) { navigator.back() }
            }
        }
        composable(Routes.DIAGNOSTICS) { DiagnosticsScreen(navigator) }
        composable(Routes.ABOUT) { AboutScreen(navigator) }
        composable(Routes.HISTORY) { HistoryScreen(navigator) }
        composable(Routes.SEND_PICK) { SendPickerScreen(navigator) }
        composable(Routes.SEND_RECIPIENTS) { RecipientsScreen(navigator) }
        composable(Routes.SEND_CONFIRM) { ConfirmScreen(navigator) }
        composable(Routes.RECEIVE) { ReceiveScreen(navigator) }
        composable(
            route = Routes.TRANSFER,
            arguments = listOf(navArgument(Routes.ARG_ID) { type = NavType.StringType }),
        ) { entry ->
            val id = entry.arguments?.getString(Routes.ARG_ID)
            if (!id.isNullOrBlank()) {
                TransferScreen(id, navigator)
            } else {
                LaunchedEffect(Unit) { navigator.back() }
            }
        }
    }
}

/**
 * Light fade plus a 12 dp slide between screens; switching between bottom-bar tabs is a plain cross-fade. With motion off
 * (user setting, reduced motion or the system's animation scale) every transition is instant.
 */
internal object NavTransitions {
    fun enter(motion: AeroMotion, slidePx: Int, from: String?, to: String?, popping: Boolean): EnterTransition {
        if (!motion.enabled) return EnterTransition.None
        val fade = fadeIn(animationSpec = tween(motion.short))
        if (Routes.isTab(from) && Routes.isTab(to)) return fade
        val direction = if (popping) -1 else 1
        return fade + slideInHorizontally(animationSpec = tween(motion.medium)) { direction * slidePx }
    }

    fun exit(motion: AeroMotion, slidePx: Int, from: String?, to: String?, popping: Boolean): ExitTransition {
        if (!motion.enabled) return ExitTransition.None
        val fade = fadeOut(animationSpec = tween(motion.short))
        if (Routes.isTab(from) && Routes.isTab(to)) return fade
        val direction = if (popping) 1 else -1
        return fade + slideOutHorizontally(animationSpec = tween(motion.medium)) { direction * slidePx }
    }
}
