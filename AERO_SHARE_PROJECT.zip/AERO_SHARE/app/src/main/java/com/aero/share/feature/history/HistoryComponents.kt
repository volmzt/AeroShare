package com.aero.share.feature.history

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.Download
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.aero.share.R
import com.aero.share.core.common.Formatters
import com.aero.share.core.common.labelRes
import com.aero.share.core.designsystem.AeroBadge
import com.aero.share.core.designsystem.AeroCard
import com.aero.share.core.designsystem.AeroChip
import com.aero.share.core.designsystem.AeroIcon
import com.aero.share.core.designsystem.AeroText
import com.aero.share.core.designsystem.AeroTheme
import com.aero.share.domain.HistoryItem
import com.aero.share.domain.HistoryStatus
import com.aero.share.feature.send.metaLine
import com.aero.share.transfer.model.TransferDirection
import java.text.DateFormat
import java.util.Date

/** Two rows of chips: who sent it, and how it ended. Each row scrolls sideways when the labels do not fit. */
@Composable
internal fun HistoryFilterBar(
    filters: HistoryFilters,
    onDirection: (DirectionFilter) -> Unit,
    onStatus: (StatusFilter) -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            for (option in DirectionFilter.entries) {
                AeroChip(
                    text = stringResource(option.labelRes()),
                    selected = filters.direction == option,
                    onClick = { onDirection(option) },
                )
            }
        }
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            for (option in StatusFilter.entries) {
                AeroChip(
                    text = stringResource(option.labelRes()),
                    selected = filters.status == option,
                    onClick = { onStatus(option) },
                )
            }
        }
    }
}

private fun DirectionFilter.labelRes(): Int = when (this) {
    DirectionFilter.ALL -> R.string.hist_filter_all
    DirectionFilter.SENT -> R.string.hist_filter_sent
    DirectionFilter.RECEIVED -> R.string.hist_filter_received
}

private fun StatusFilter.labelRes(): Int = when (this) {
    StatusFilter.ALL -> R.string.hist_filter_all
    StatusFilter.COMPLETED -> R.string.state_completed
    StatusFilter.FAILED -> R.string.state_failed
    StatusFilter.CANCELLED -> R.string.state_cancelled
}

/** The heading of one day: "Today", "Yesterday" or the date. */
@Composable
internal fun dayHeaderText(group: HistoryGroup): String = when (group.bucket) {
    DayBucket.TODAY -> stringResource(R.string.hist_today)
    DayBucket.YESTERDAY -> stringResource(R.string.hist_yesterday)
    DayBucket.OTHER -> DateFormat.getDateInstance(DateFormat.LONG).format(Date(group.anchor))
}

internal fun timeOfDayText(millis: Long): String = DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(millis))

internal fun dateTimeText(millis: Long): String =
    DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(millis))

/** Colour of the status badge: the outcome is never conveyed by colour alone, the badge always carries a word. */
@Composable
internal fun statusColor(status: HistoryStatus): Color = when (status) {
    HistoryStatus.COMPLETED -> AeroTheme.colors.success
    HistoryStatus.FAILED -> AeroTheme.colors.danger
    HistoryStatus.CANCELLED -> AeroTheme.colors.textSecondary
}

/** Arrow-out for sent, arrow-down for received, on a soft tile like the other list icons. */
@Composable
internal fun DirectionTile(direction: TransferDirection) {
    val sent = direction == TransferDirection.SEND
    val tint = AeroTheme.colors.accentText
    Box(
        modifier = Modifier
            .size(44.dp)
            .clip(RoundedCornerShape(AeroTheme.dimens.radiusSmall))
            .background(tint.copy(alpha = 0.14f)),
        contentAlignment = Alignment.Center,
    ) {
        AeroIcon(
            icon = if (sent) Icons.AutoMirrored.Rounded.Send else Icons.Rounded.Download,
            contentDescription = stringResource(if (sent) R.string.hist_filter_sent else R.string.hist_filter_received),
            tint = tint,
            size = 24.dp,
        )
    }
}

/** "5 files · 12.0 MB · 0:42": only what is known is shown, and an unfinished record says how far it got. */
@Composable
internal fun historyMeta(item: HistoryItem): String {
    val files = if (HistoryLogic.filesPartial(item)) {
        pluralStringResource(R.plurals.xfer_files_progress, item.fileCount, item.completedFiles, item.fileCount)
    } else {
        pluralStringResource(R.plurals.send_files_total, item.fileCount, item.fileCount)
    }
    val size = when {
        HistoryLogic.bytesPartial(item) ->
            stringResource(R.string.xfer_progress_bytes, Formatters.bytes(item.transferredBytes), Formatters.bytes(item.totalBytes))
        item.totalBytes > 0L -> Formatters.bytes(item.totalBytes)
        else -> ""
    }
    val duration = if (item.durationMillis > 0L) Formatters.duration(item.durationMillis) else ""
    return metaLine(listOf(files, size, duration))
}

@Composable
internal fun HistoryRow(item: HistoryItem, onClick: () -> Unit) {
    val colors = AeroTheme.colors
    val name = item.peerName.ifBlank { stringResource(R.string.common_unknown_device) }
    AeroCard(onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            DirectionTile(item.direction)
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                AeroText(text = name, style = AeroTheme.typography.bodyStrong, maxLines = 1)
                AeroText(text = historyMeta(item), style = AeroTheme.typography.caption, color = colors.textSecondary, maxLines = 2)
                AeroText(text = timeOfDayText(item.timestamp), style = AeroTheme.typography.caption, color = colors.textSecondary)
            }
            Spacer(Modifier.width(8.dp))
            AeroBadge(text = stringResource(item.status.labelRes()), color = statusColor(item.status))
        }
    }
}
