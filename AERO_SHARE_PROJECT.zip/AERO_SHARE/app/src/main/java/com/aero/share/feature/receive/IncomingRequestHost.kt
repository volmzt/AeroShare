package com.aero.share.feature.receive

import android.os.SystemClock
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aero.share.R
import com.aero.share.core.common.Formatters
import com.aero.share.core.common.labelRes
import com.aero.share.core.designsystem.AeroBadge
import com.aero.share.core.designsystem.AeroButton
import com.aero.share.core.designsystem.AeroButtonStyle
import com.aero.share.core.designsystem.AeroDeviceIcon
import com.aero.share.core.designsystem.AeroDialogFrame
import com.aero.share.core.designsystem.AeroText
import com.aero.share.core.designsystem.AeroTheme
import com.aero.share.di.LocalAppContainer
import com.aero.share.domain.PendingIncoming
import com.aero.share.feature.send.metaLine
import com.aero.share.navigation.AeroNavigator
import com.aero.share.transfer.model.PeerTrust
import kotlinx.coroutines.delay

/**
 * Asks about the oldest request that is waiting, on top of whatever screen is open. The decision is always explicit:
 * Back and a tap outside do nothing, and a request that is not answered declines itself when its time is up.
 */
@Composable
fun IncomingRequestHost(navigator: AeroNavigator) {
    val container = LocalAppContainer.current
    val pending by container.coordinator.pendingIncoming.collectAsStateWithLifecycle()
    val request = pending.firstOrNull() ?: return
    key(request.transferId) {
        IncomingDialog(
            request = request,
            queued = pending.size - 1,
            onAccept = {
                container.coordinator.respond(request.transferId, true)
                navigator.openTransfer(request.transferId)
            },
            onDecline = { container.coordinator.respond(request.transferId, false) },
        )
    }
}

@Composable
private fun IncomingDialog(request: PendingIncoming, queued: Int, onAccept: () -> Unit, onDecline: () -> Unit) {
    val colors = AeroTheme.colors
    var now by remember { mutableLongStateOf(SystemClock.elapsedRealtime()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(500L)
            now = SystemClock.elapsedRealtime()
        }
    }
    val remaining = IncomingLogic.remainingSeconds(request.expiresAtElapsed, now)
    val name = request.peerName.ifBlank { stringResource(R.string.common_unknown_device) }
    val space = IncomingLogic.storage(request.freeBytes, request.totalBytes)

    AeroDialogFrame(onDismiss = {}) {
        SenderHeader(name = name, request = request)
        Spacer(Modifier.height(16.dp))
        AeroText(
            text = pluralStringResource(R.plurals.recv_incoming_headline, request.fileCount, name, request.fileCount),
            style = AeroTheme.typography.titleSmall,
        )
        val title = request.title
        if (!title.isNullOrBlank()) {
            Spacer(Modifier.height(4.dp))
            AeroText(text = title, style = AeroTheme.typography.bodyStrong, maxLines = 2)
        }
        Spacer(Modifier.height(4.dp))
        AeroText(
            text = metaLine(
                listOf(
                    pluralStringResource(R.plurals.recv_incoming_files, request.fileCount, request.fileCount),
                    Formatters.bytes(request.totalBytes),
                ),
            ),
            color = colors.textSecondary,
        )
        if (request.categories.isNotEmpty()) {
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(top = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                for (category in request.categories.sortedBy { it.ordinal }) {
                    AeroBadge(text = stringResource(category.labelRes()))
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        val transport = request.transport
        if (transport != null) {
            AeroText(
                text = stringResource(R.string.recv_incoming_via, stringResource(transport.labelRes())),
                style = AeroTheme.typography.caption,
                color = colors.textSecondary,
            )
        }
        AeroText(
            text = stringResource(R.string.recv_incoming_destination, request.destinationLabel),
            style = AeroTheme.typography.caption,
            color = colors.textSecondary,
        )
        if (space == StorageCheck.TOO_LITTLE) {
            Spacer(Modifier.height(8.dp))
            AeroText(
                text = stringResource(
                    R.string.recv_incoming_no_space,
                    Formatters.bytes(request.freeBytes ?: 0L),
                    Formatters.bytes(request.totalBytes),
                ),
                color = colors.danger,
            )
        }
        if (request.isResume) {
            Spacer(Modifier.height(8.dp))
            AeroText(text = stringResource(R.string.recv_incoming_resume), color = colors.textSecondary)
        }
        VerificationBlock(request = request)
        Spacer(Modifier.height(14.dp))
        AeroText(
            text = stringResource(R.string.recv_incoming_expires, QrLogic.clock(remaining)),
            style = AeroTheme.typography.caption,
            color = colors.textSecondary,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
        )
        if (queued > 0) {
            AeroText(
                text = pluralStringResource(R.plurals.recv_incoming_more, queued, queued),
                style = AeroTheme.typography.caption,
                color = colors.accentText,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(top = 2.dp),
            )
        }
        Spacer(Modifier.height(14.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            AeroButton(
                text = stringResource(R.string.recv_incoming_decline),
                onClick = onDecline,
                modifier = Modifier.weight(1f),
                style = AeroButtonStyle.Secondary,
            )
            AeroButton(
                text = stringResource(R.string.recv_incoming_accept),
                onClick = onAccept,
                modifier = Modifier.weight(1f),
            )
        }
    }
}

@Composable
private fun SenderHeader(name: String, request: PendingIncoming) {
    val colors = AeroTheme.colors
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(AeroTheme.dimens.radiusSmall))
                .background(colors.accentContainer),
            contentAlignment = Alignment.Center,
        ) {
            AeroDeviceIcon(kind = request.peerKind)
        }
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            AeroText(text = name, style = AeroTheme.typography.bodyStrong, maxLines = 2)
            Row(
                modifier = Modifier.padding(top = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                val trustColor = when (request.trust) {
                    PeerTrust.TRUSTED -> colors.success
                    PeerTrust.KNOWN -> colors.textSecondary
                    PeerTrust.UNKNOWN -> colors.warning
                    PeerTrust.BLOCKED -> colors.danger
                }
                AeroBadge(text = stringResource(request.trust.labelRes()), color = trustColor)
                if (request.authenticatedByQr) {
                    AeroBadge(text = stringResource(R.string.recv_incoming_badge_qr), color = colors.success)
                }
            }
        }
    }
}

/**
 * A device that scanned our QR code is authenticated by the code itself. Any other sender shows a short code on both
 * screens; only if they match is it the device the person expects.
 */
@Composable
private fun VerificationBlock(request: PendingIncoming) {
    val colors = AeroTheme.colors
    val code = IncomingLogic.groupCode(request.verificationCode)
    if (code.isNotEmpty()) {
        Spacer(Modifier.height(14.dp))
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(AeroTheme.dimens.radiusSmall))
                .background(colors.surfaceAlt)
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            AeroText(
                text = stringResource(R.string.recv_incoming_code_title),
                style = AeroTheme.typography.caption,
                color = colors.textSecondary,
            )
            AeroText(
                text = code,
                style = AeroTheme.typography.display,
                color = colors.accentText,
                maxLines = 1,
                textAlign = TextAlign.Center,
            )
            AeroText(
                text = stringResource(R.string.recv_incoming_code_text),
                style = AeroTheme.typography.caption,
                color = colors.textSecondary,
                textAlign = TextAlign.Center,
            )
        }
    } else if (request.authenticatedByQr) {
        Spacer(Modifier.height(10.dp))
        AeroText(text = stringResource(R.string.recv_incoming_qr_note), color = colors.textSecondary)
    }
}
