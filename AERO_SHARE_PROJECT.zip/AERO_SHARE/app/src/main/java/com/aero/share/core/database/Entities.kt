package com.aero.share.core.database

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.aero.share.domain.DeviceRecord
import com.aero.share.domain.HistoryFile
import com.aero.share.domain.HistoryItem
import com.aero.share.domain.HistoryStatus
import com.aero.share.transfer.model.DeviceKind
import com.aero.share.transfer.model.FileCategory
import com.aero.share.transfer.model.TransferDirection
import com.aero.share.transfer.model.TransferFailure
import com.aero.share.transfer.model.TransportKind
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

/** Enums are stored by name; unknown names (after a downgrade) fall back instead of crashing. */
private inline fun <reified E : Enum<E>> enumOrNull(name: String?): E? =
    if (name == null) null else enumValues<E>().firstOrNull { it.name == name }

@Entity(tableName = "devices")
data class DeviceEntity(
    @PrimaryKey val deviceId: String,
    val name: String,
    val alias: String?,
    val kind: String,
    val model: String?,
    val fingerprint: String,
    val firstSeen: Long,
    val lastSeen: Long,
    val trusted: Boolean,
    val blocked: Boolean,
    val capabilities: Int,
    val lastAddress: String?,
    val lastTransport: String?,
) {
    fun toRecord() = DeviceRecord(
        deviceId = deviceId,
        name = name,
        alias = alias,
        kind = enumOrNull<DeviceKind>(kind) ?: DeviceKind.OTHER,
        model = model,
        fingerprint = fingerprint,
        firstSeen = firstSeen,
        lastSeen = lastSeen,
        trusted = trusted,
        blocked = blocked,
        capabilities = capabilities,
        lastAddress = lastAddress,
        lastTransport = enumOrNull<TransportKind>(lastTransport),
    )

    companion object {
        fun from(r: DeviceRecord) = DeviceEntity(
            deviceId = r.deviceId,
            name = r.name,
            alias = r.alias,
            kind = r.kind.name,
            model = r.model,
            fingerprint = r.fingerprint,
            firstSeen = r.firstSeen,
            lastSeen = r.lastSeen,
            trusted = r.trusted,
            blocked = r.blocked,
            capabilities = r.capabilities,
            lastAddress = r.lastAddress,
            lastTransport = r.lastTransport?.name,
        )
    }
}

@Entity(tableName = "history")
data class HistoryEntity(
    @PrimaryKey val id: String,
    val direction: String,
    @ColumnInfo(index = true) val timestamp: Long,
    val peerName: String,
    val peerId: String?,
    val fileCount: Int,
    val completedFiles: Int,
    val totalBytes: Long,
    val transferredBytes: Long,
    val durationMillis: Long,
    val status: String,
    val failure: String?,
    val transport: String?,
    val filesJson: String,
) {
    fun toItem() = HistoryItem(
        id = id,
        direction = enumOrNull<TransferDirection>(direction) ?: TransferDirection.RECEIVE,
        timestamp = timestamp,
        peerName = peerName,
        peerId = peerId,
        fileCount = fileCount,
        completedFiles = completedFiles,
        totalBytes = totalBytes,
        transferredBytes = transferredBytes,
        durationMillis = durationMillis,
        status = enumOrNull<HistoryStatus>(status) ?: HistoryStatus.FAILED,
        failure = enumOrNull<TransferFailure>(failure),
        transport = enumOrNull<TransportKind>(transport),
        files = filesFromJson(filesJson),
    )

    companion object {
        const val MAX_FILES = 200

        fun from(i: HistoryItem) = HistoryEntity(
            id = i.id,
            direction = i.direction.name,
            timestamp = i.timestamp,
            peerName = i.peerName,
            peerId = i.peerId,
            fileCount = i.fileCount,
            completedFiles = i.completedFiles,
            totalBytes = i.totalBytes,
            transferredBytes = i.transferredBytes,
            durationMillis = i.durationMillis,
            status = i.status.name,
            failure = i.failure?.name,
            transport = i.transport?.name,
            filesJson = filesToJson(i.files),
        )

        internal fun filesToJson(files: List<HistoryFile>): String {
            val array = JSONArray()
            for (f in files.take(MAX_FILES)) {
                val o = JSONObject()
                o.put("n", f.name)
                o.put("s", f.size)
                if (f.uri != null) o.put("u", f.uri)
                if (f.mimeType != null) o.put("m", f.mimeType)
                o.put("c", f.category.code)
                array.put(o)
            }
            return array.toString()
        }

        internal fun filesFromJson(text: String): List<HistoryFile> {
            return try {
                val array = JSONArray(text)
                val out = ArrayList<HistoryFile>(array.length())
                for (index in 0 until array.length()) {
                    val o = array.optJSONObject(index) ?: continue
                    out.add(
                        HistoryFile(
                            name = o.optString("n"),
                            size = o.optLong("s"),
                            uri = if (o.has("u") && !o.isNull("u")) o.optString("u") else null,
                            mimeType = if (o.has("m") && !o.isNull("m")) o.optString("m") else null,
                            category = FileCategory.fromCode(o.optInt("c", FileCategory.OTHER.code)),
                        ),
                    )
                }
                out
            } catch (e: JSONException) {
                emptyList()
            }
        }
    }
}
