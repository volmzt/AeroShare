package com.aero.share.feature.send

import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import com.aero.share.domain.FileItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** One page of a media list. [failed] is true when the library could not be read (for example the permission was revoked). */
internal class MediaPage(val entries: List<MediaEntry>, val failed: Boolean)

/**
 * Lists photos, videos and audio from MediaStore, newest first, a page at a time so that a library of tens of thousands of
 * files never has to be loaded at once. Reading happens off the main thread. Only metadata is read here, never file contents.
 */
internal class MediaRepository(context: Context) {
    private val resolver: ContentResolver = context.applicationContext.contentResolver

    suspend fun page(kind: MediaKind, offset: Int, limit: Int): MediaPage = withContext(Dispatchers.IO) {
        read(kind, offset, limit)
    }

    /** The newest [limit] items over [kinds]; a page that fails counts as failed only when nothing at all could be read. */
    suspend fun recent(kinds: List<MediaKind>, limit: Int): MediaPage = withContext(Dispatchers.IO) {
        val pages = kinds.map { kind -> read(kind, 0, limit) }
        val failed = pages.isNotEmpty() && pages.all { it.failed }
        MediaPage(PickerLogic.mergeRecent(pages.map { it.entries }, limit), failed)
    }

    private fun collectionOf(kind: MediaKind): Uri = when (kind) {
        MediaKind.IMAGE -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        MediaKind.VIDEO -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        MediaKind.AUDIO -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
    }

    private fun durationColumn(kind: MediaKind): String? = when (kind) {
        MediaKind.IMAGE -> null
        MediaKind.VIDEO -> MediaStore.Video.VideoColumns.DURATION
        MediaKind.AUDIO -> MediaStore.Audio.AudioColumns.DURATION
    }

    private fun open(collection: Uri, projection: Array<String>, offset: Int, limit: Int): Cursor? =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val args = Bundle().apply {
                putInt(ContentResolver.QUERY_ARG_LIMIT, limit)
                putInt(ContentResolver.QUERY_ARG_OFFSET, offset)
                putStringArray(ContentResolver.QUERY_ARG_SORT_COLUMNS, arrayOf(MediaStore.MediaColumns.DATE_ADDED))
                putInt(ContentResolver.QUERY_ARG_SORT_DIRECTION, ContentResolver.QUERY_SORT_DIRECTION_DESCENDING)
            }
            resolver.query(collection, projection, args, null)
        } else {
            // Before Android 10 the provider only understands LIMIT and OFFSET as part of the sort order.
            val order = MediaStore.MediaColumns.DATE_ADDED + " DESC LIMIT " + limit + " OFFSET " + offset
            resolver.query(collection, projection, null, null, order)
        }

    private fun read(kind: MediaKind, offset: Int, limit: Int): MediaPage {
        val collection = collectionOf(kind)
        val durationName = durationColumn(kind)
        val columns = ArrayList<String>()
        columns.add(MediaStore.MediaColumns._ID)
        columns.add(MediaStore.MediaColumns.DISPLAY_NAME)
        columns.add(MediaStore.MediaColumns.SIZE)
        columns.add(MediaStore.MediaColumns.MIME_TYPE)
        columns.add(MediaStore.MediaColumns.DATE_ADDED)
        columns.add(MediaStore.MediaColumns.DATE_MODIFIED)
        if (durationName != null) columns.add(durationName)
        try {
            val cursor = open(collection, columns.toTypedArray(), offset, limit) ?: return MediaPage(emptyList(), true)
            val entries = ArrayList<MediaEntry>(minOf(limit, 256))
            cursor.use { c ->
                val idIndex = c.getColumnIndex(MediaStore.MediaColumns._ID)
                val nameIndex = c.getColumnIndex(MediaStore.MediaColumns.DISPLAY_NAME)
                val sizeIndex = c.getColumnIndex(MediaStore.MediaColumns.SIZE)
                val mimeIndex = c.getColumnIndex(MediaStore.MediaColumns.MIME_TYPE)
                val addedIndex = c.getColumnIndex(MediaStore.MediaColumns.DATE_ADDED)
                val modifiedIndex = c.getColumnIndex(MediaStore.MediaColumns.DATE_MODIFIED)
                val durationIndex = if (durationName == null) -1 else c.getColumnIndex(durationName)
                if (idIndex < 0) return MediaPage(emptyList(), true)
                while (c.moveToNext() && entries.size < limit) {
                    val id = c.getLong(idIndex)
                    val uri = ContentUris.withAppendedId(collection, id).toString()
                    val name = SharedUriRules.displayName(c.stringAt(nameIndex), null)
                    val mime = c.stringAt(mimeIndex)
                    val added = c.longAt(addedIndex, 0L) * 1000L
                    val modified = c.longAt(modifiedIndex, 0L) * 1000L
                    entries.add(
                        MediaEntry(
                            item = FileItem(
                                id = uri,
                                uri = uri,
                                displayName = name,
                                size = c.longAt(sizeIndex, -1L),
                                category = PickerLogic.categoryOf(kind),
                                mimeType = mime,
                                lastModified = if (modified > 0L) modified else added,
                            ),
                            kind = kind,
                            addedMillis = added,
                            durationMillis = c.longAt(durationIndex, 0L).coerceAtLeast(0L),
                        ),
                    )
                }
            }
            return MediaPage(entries, false)
        } catch (e: SecurityException) {
            return MediaPage(emptyList(), true)
        } catch (e: IllegalArgumentException) {
            return MediaPage(emptyList(), true)
        } catch (e: IllegalStateException) {
            return MediaPage(emptyList(), true)
        } catch (e: UnsupportedOperationException) {
            return MediaPage(emptyList(), true)
        }
    }

    private fun Cursor.stringAt(index: Int): String? = if (index < 0 || isNull(index)) null else getString(index)

    private fun Cursor.longAt(index: Int, fallback: Long): Long = if (index < 0 || isNull(index)) fallback else getLong(index)
}
