package com.aero.share.core.designsystem

import com.aero.share.domain.AccentColor

/** Every colour of the interface as packed 0xAARRGGBB values. Kept free of UI types so the contrast rules are testable. */
internal data class PaletteTokens(
    val background: Long,
    val surface: Long,
    val surfaceAlt: Long,
    val surfaceElevated: Long,
    val accent: Long,
    val accentSecondary: Long,
    /** Text/icon colour on top of [accent] (white or near-black, whichever reads better). */
    val onAccent: Long,
    /** The accent as text or icon colour on the surfaces: darkened in the light theme when needed to stay readable. */
    val accentText: Long,
    /** Soft accent wash for selected states. */
    val accentContainer: Long,
    val textPrimary: Long,
    val textSecondary: Long,
    val divider: Long,
    val success: Long,
    val warning: Long,
    val danger: Long,
    val onDanger: Long,
    val scrim: Long,
    val isDark: Boolean,
)

/**
 * The palette. Dark: #090909 background, #141414 / #1C1C1C / #222222 surfaces, white and #A3A3A3 text, #303030 dividers.
 * Light mirrors it. The accent comes from the user's choice; colours used as text are pushed to at least 4.5:1 contrast.
 */
internal object AeroPalette {
    private const val TEXT_RATIO = 4.5

    fun tokens(dark: Boolean, accent: AccentColor): PaletteTokens {
        val background = if (dark) 0xFF090909L else 0xFFF4F4F5L
        val surface = if (dark) 0xFF141414L else 0xFFFFFFFFL
        val surfaceAlt = if (dark) 0xFF1C1C1CL else 0xFFEDEDEFL
        val surfaceElevated = if (dark) 0xFF222222L else 0xFFFFFFFFL
        // The surface that is hardest to read on: lightest in the dark theme, darkest in the light theme.
        val hardest = if (dark) surfaceElevated else surfaceAlt
        val towards = if (dark) ColorMath.WHITE else ColorMath.BLACK

        val primary = accent.primary and 0xFFFFFFFFL
        val secondary = accent.secondary and 0xFFFFFFFFL
        val accentText = ColorMath.ensureContrast(primary, hardest, TEXT_RATIO, towards)

        val danger = ColorMath.ensureContrast(if (dark) 0xFFFF5A52L else 0xFFC62F28L, hardest, TEXT_RATIO, towards)
        return PaletteTokens(
            background = background,
            surface = surface,
            surfaceAlt = surfaceAlt,
            surfaceElevated = surfaceElevated,
            accent = primary,
            accentSecondary = secondary,
            onAccent = ColorMath.readableOn(primary),
            accentText = accentText,
            accentContainer = ColorMath.withAlpha(primary, if (dark) 0.16 else 0.14),
            textPrimary = if (dark) 0xFFFFFFFFL else 0xFF111111L,
            textSecondary = if (dark) 0xFFA3A3A3L else 0xFF5C5C63L,
            divider = if (dark) 0xFF303030L else 0xFFDADADFL,
            success = ColorMath.ensureContrast(if (dark) 0xFF3DD68CL else 0xFF12804AL, hardest, TEXT_RATIO, towards),
            warning = ColorMath.ensureContrast(if (dark) 0xFFFFB020L else 0xFF9A5B00L, hardest, TEXT_RATIO, towards),
            danger = danger,
            onDanger = ColorMath.readableOn(danger),
            scrim = ColorMath.BLACK,
            isDark = dark,
        )
    }
}
