package com.aero.share.network.transport

import android.content.Context
import com.aero.share.core.common.DiagnosticsLog
import com.aero.share.domain.CapabilityProvider
import com.aero.share.domain.DiscoveryController
import com.aero.share.domain.DiscoveryProblem
import com.aero.share.domain.NearbyDevice
import com.aero.share.domain.PowerPolicy
import com.aero.share.domain.SettingsRepository
import com.aero.share.network.discovery.LanDiscovery
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.StateFlow

/**
 * Nearby-device discovery over every mechanism: mDNS and multicast beacons on the LAN ([LanDiscovery]) and Wi-Fi Direct
 * ([WifiDirectManager]), merged into one list. The logic (reference-counted owners, settings and capability reactions,
 * periodic refresh only while somebody looks, advertising only when visible, problem reporting) lives in the
 * unit-tested [DiscoveryCoordinator]; this class only connects it to the Android implementations.
 */
class CompositeDiscovery(
    @Suppress("UNUSED_PARAMETER") context: Context,
    scope: CoroutineScope,
    lan: LanDiscovery,
    p2p: WifiDirectManager,
    capabilities: CapabilityProvider,
    settings: SettingsRepository,
    power: PowerPolicy,
    diagnostics: DiagnosticsLog,
) : DiscoveryController by DiscoveryCoordinator(
    scope = scope,
    lan = LanAdapter(lan),
    direct = DirectAdapter(p2p),
    capabilities = capabilities,
    settings = settings,
    power = power,
    log = { message -> diagnostics.add("discovery", message) },
)

private class LanAdapter(private val lan: LanDiscovery) : LanSource {
    override val devices: StateFlow<List<NearbyDevice>> get() = lan.devices
    override val problem: StateFlow<DiscoveryProblem?> get() = lan.problem
    override val methods: StateFlow<Set<String>> get() = lan.methods

    override fun start() = lan.start()
    override fun stop() = lan.stop()
    override fun refresh() = lan.refresh()
    override fun startAdvertising(port: Int) = lan.startAdvertising(port)
    override fun stopAdvertising() = lan.stopAdvertising()
}

private class DirectAdapter(private val p2p: WifiDirectManager) : DirectSource {
    override val peers: StateFlow<List<NearbyDevice>> get() = p2p.peers
    override val active: StateFlow<Boolean> get() = p2p.active

    override fun start() = p2p.start()
    override fun stop() = p2p.stop()
    override fun refresh() = p2p.refresh()
    override fun startAdvertising(port: Int) = p2p.startAdvertising(port)
    override fun stopAdvertising() = p2p.stopAdvertising()
}
