package com.aero.share.network.discovery

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Build
import java.util.ArrayDeque
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Finds other AERO SHARE devices through DNS-SD (`_aeroshare._tcp.`). Services are resolved one at a time, because
 * NsdManager rejects parallel resolves. Everything that fails validation is ignored. The manager is never stopped
 * twice and a failed start is retried a couple of times with a growing delay.
 */
internal class NsdBrowser(
    context: Context,
    private val scope: CoroutineScope,
    private val onResolved: (serviceName: String, presence: Beacon.Presence, addresses: List<String>) -> Unit,
    private val onLost: (serviceName: String) -> Unit,
    /** Called once when browsing has failed for good (all retries used), so that the owner can report the problem. */
    private val onChanged: () -> Unit,
    private val log: (String) -> Unit,
) {
    private val nsd: NsdManager? = context.applicationContext.getSystemService(NsdManager::class.java)
    private val sync = Any()
    private var listener: NsdManager.DiscoveryListener? = null
    private val queue = ArrayDeque<NsdServiceInfo>()
    private val pending = HashSet<String>()
    private val attempts = HashMap<String, Int>()
    private var resolving = false
    private var startRetries = 0
    private var generation = 0

    val isActive: Boolean get() = synchronized(sync) { listener != null }

    fun start(): Boolean {
        val manager = nsd ?: return false
        synchronized(sync) {
            if (listener != null) return true
            // After the retries are used up nothing is started again until stop() resets the counter.
            if (startRetries > MAX_START_RETRIES) return false
            generation += 1
            val gen = generation
            val discovery = object : NsdManager.DiscoveryListener {
                override fun onDiscoveryStarted(serviceType: String) {}

                override fun onDiscoveryStopped(serviceType: String) {}

                override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {
                    startFailed(gen, errorCode)
                }

                override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {}

                override fun onServiceFound(serviceInfo: NsdServiceInfo) {
                    enqueue(gen, serviceInfo)
                }

                override fun onServiceLost(serviceInfo: NsdServiceInfo) {
                    val name = serviceInfo.serviceName
                    if (name != null) onLost(name)
                }
            }
            try {
                manager.discoverServices(NsdAdvert.SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, discovery)
                listener = discovery
                return true
            } catch (e: RuntimeException) {
                log("mdns: browsing could not start (${e.javaClass.simpleName})")
                return false
            }
        }
    }

    fun stop() {
        var stale: NsdManager.DiscoveryListener? = null
        synchronized(sync) {
            generation += 1
            stale = listener
            listener = null
            queue.clear()
            pending.clear()
            attempts.clear()
            resolving = false
            startRetries = 0
        }
        val l = stale ?: return
        try {
            nsd?.stopServiceDiscovery(l)
        } catch (e: IllegalArgumentException) {
            // not registered (any more)
        } catch (e: RuntimeException) {
            // the framework is shutting the service down
        }
    }

    /** Stops and starts browsing again, so that every service on the link is reported once more. */
    fun restart() {
        stop()
        start()
    }

    private fun startFailed(gen: Int, errorCode: Int) {
        var retry = false
        synchronized(sync) {
            if (gen != generation) return
            listener = null
            startRetries += 1
            retry = startRetries <= MAX_START_RETRIES
        }
        log("mdns: browsing failed ($errorCode)")
        if (!retry) {
            onChanged()
            return
        }
        scope.launch(Dispatchers.IO) {
            delay(RETRY_DELAY_MS * startRetries)
            synchronized(sync) {
                if (gen != generation) return@launch
            }
            start()
        }
    }

    private fun enqueue(gen: Int, info: NsdServiceInfo) {
        synchronized(sync) {
            if (gen != generation) return
            val name = info.serviceName ?: return
            if (!pending.add(name)) return
            queue.addLast(info)
        }
        pump(gen)
    }

    private fun pump(gen: Int) {
        val manager = nsd ?: return
        var next: NsdServiceInfo? = null
        synchronized(sync) {
            if (gen != generation || resolving) return
            next = queue.pollFirst()
            if (next == null) return
            resolving = true
        }
        val target = next ?: return
        try {
            manager.resolveService(
                target,
                object : NsdManager.ResolveListener {
                    override fun onResolveFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {
                        resolved(gen, target, errorCode, null)
                    }

                    override fun onServiceResolved(serviceInfo: NsdServiceInfo) {
                        resolved(gen, target, 0, serviceInfo)
                    }
                },
            )
        } catch (e: RuntimeException) {
            resolved(gen, target, -1, null)
        }
    }

    private fun resolved(gen: Int, requested: NsdServiceInfo, errorCode: Int, result: NsdServiceInfo?) {
        val name = requested.serviceName.orEmpty()
        var retryLater = false
        synchronized(sync) {
            if (gen != generation) return
            resolving = false
            val tried = (attempts[name] ?: 0) + 1
            if (result == null && errorCode == NsdManager.FAILURE_ALREADY_ACTIVE && tried < MAX_RESOLVE_ATTEMPTS) {
                attempts[name] = tried
                queue.addLast(requested)
                retryLater = true
            } else {
                attempts.remove(name)
                pending.remove(name)
            }
        }
        if (result != null) deliver(name, result)
        if (retryLater) {
            scope.launch(Dispatchers.IO) {
                delay(RESOLVE_RETRY_MS)
                pump(gen)
            }
        } else {
            pump(gen)
        }
    }

    @Suppress("DEPRECATION") // NsdServiceInfo.host is replaced by hostAddresses on Android 14, which is used there
    private fun deliver(serviceName: String, info: NsdServiceInfo) {
        val presence = NsdAdvert.parse(info.attributes, info.port) ?: return
        val hosts: List<String> = if (Build.VERSION.SDK_INT >= 34) {
            info.hostAddresses.mapNotNull { it.hostAddress }
        } else {
            listOfNotNull(info.host?.hostAddress)
        }
        if (hosts.isEmpty()) return
        onResolved(serviceName, presence, hosts)
    }

    private companion object {
        const val MAX_START_RETRIES = 2
        const val RETRY_DELAY_MS = 2000L
        const val RESOLVE_RETRY_MS = 300L
        const val MAX_RESOLVE_ATTEMPTS = 4
    }
}

/** Publishes this device through DNS-SD. The service name is the start of the device id; the rest is in the TXT record. */
internal class NsdAdvertiser(
    context: Context,
    /** Called when the registration was rejected asynchronously. */
    private val onChanged: () -> Unit,
    private val log: (String) -> Unit,
) {
    private val nsd: NsdManager? = context.applicationContext.getSystemService(NsdManager::class.java)
    private val sync = Any()
    private var listener: NsdManager.RegistrationListener? = null

    val isActive: Boolean get() = synchronized(sync) { listener != null }

    fun register(presence: Beacon.Presence): Boolean {
        val manager = nsd ?: return false
        unregister()
        val info = NsdServiceInfo()
        try {
            info.serviceName = NsdAdvert.serviceName(presence.deviceId)
            info.serviceType = NsdAdvert.SERVICE_TYPE
            info.port = presence.port
            for ((key, value) in NsdAdvert.attributes(presence)) info.setAttribute(key, value)
        } catch (e: IllegalArgumentException) {
            log("mdns: advertisement is invalid")
            return false
        }
        val registration = object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(serviceInfo: NsdServiceInfo) {}

            override fun onRegistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {
                log("mdns: registration failed ($errorCode)")
                synchronized(sync) {
                    if (listener === this) listener = null
                }
                onChanged()
            }

            override fun onServiceUnregistered(serviceInfo: NsdServiceInfo) {}

            override fun onUnregistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {}
        }
        synchronized(sync) {
            try {
                manager.registerService(info, NsdManager.PROTOCOL_DNS_SD, registration)
                listener = registration
                return true
            } catch (e: RuntimeException) {
                log("mdns: could not register (${e.javaClass.simpleName})")
                return false
            }
        }
    }

    fun unregister() {
        var stale: NsdManager.RegistrationListener? = null
        synchronized(sync) {
            stale = listener
            listener = null
        }
        val l = stale ?: return
        try {
            nsd?.unregisterService(l)
        } catch (e: IllegalArgumentException) {
            // never registered or already gone
        } catch (e: RuntimeException) {
            // the framework is shutting the service down
        }
    }
}
