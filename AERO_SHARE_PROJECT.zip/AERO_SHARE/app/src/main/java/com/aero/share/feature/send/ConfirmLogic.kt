package com.aero.share.feature.send

import com.aero.share.domain.DeviceRecord
import com.aero.share.domain.RadioStatus
import com.aero.share.domain.Recipient
import com.aero.share.domain.TransportMode
import com.aero.share.transfer.model.CompressionMode
import com.aero.share.transfer.model.DeviceKind

/** Things worth knowing before pressing Send. Each has its own text; none of them blocks sending. */
internal enum class ConfirmWarning {
    /** The selection reaches the "large transfer" threshold from the settings. */
    LARGE_TRANSFER,

    /** Some entries have no known size, so the total is a lower bound. */
    UNKNOWN_SIZES,

    /** Wi-Fi is switched off. */
    WIFI_OFF,

    /** Wi-Fi is on but not joined to a network, so only Wi-Fi Direct or a hotspot can work. */
    WIFI_NOT_CONNECTED,

    /** A device the person has not trusted yet will have to confirm a code. */
    VERIFICATION_CODE,

    /** One transfer is queued per recipient and they run one after another. */
    QUEUED_ONE_BY_ONE,

    /** A recipient was blocked on this device. */
    BLOCKED_RECIPIENT,
}

/** How the connection to a recipient will be made, as far as is known before sending. */
internal enum class ConnectionMethod { AUTOMATIC, LAN_ONLY, WIFI_DIRECT_PREFERRED, QR_CODE, QR_HOTSPOT, MANUAL_ADDRESS }

internal data class ConfirmRecipient(
    val key: String,
    val name: String,
    val kind: DeviceKind,
    val trusted: Boolean,
    val blocked: Boolean,
    val source: RecipientSource,
    val address: String?,
    val method: ConnectionMethod,
)

internal object ConfirmLogic {
    fun recipients(chosen: List<Recipient>, known: List<DeviceRecord>, mode: TransportMode): List<ConfirmRecipient> {
        val recordById = HashMap<String, DeviceRecord>(known.size * 2)
        for (record in known) recordById[record.deviceId] = record
        return chosen.map { recipient ->
            when (recipient) {
                is Recipient.Nearby -> {
                    val record = recordById[recipient.device.deviceId]
                    ConfirmRecipient(
                        key = RecipientKeys.of(recipient),
                        name = record?.displayName ?: recipient.device.name,
                        kind = recipient.device.kind,
                        trusted = record?.trusted == true,
                        blocked = record?.blocked == true,
                        source = RecipientSource.NEARBY,
                        address = null,
                        method = methodFor(mode),
                    )
                }
                is Recipient.Qr -> {
                    val record = recordById[recipient.payload.deviceId]
                    ConfirmRecipient(
                        key = RecipientKeys.of(recipient),
                        name = record?.displayName ?: recipient.payload.name,
                        kind = recipient.payload.kind,
                        trusted = record?.trusted == true,
                        blocked = record?.blocked == true,
                        source = RecipientSource.QR,
                        address = null,
                        method = if (recipient.payload.hotspot != null) ConnectionMethod.QR_HOTSPOT else ConnectionMethod.QR_CODE,
                    )
                }
                is Recipient.Manual -> ConfirmRecipient(
                    key = RecipientKeys.of(recipient),
                    name = recipient.host,
                    kind = DeviceKind.OTHER,
                    trusted = false,
                    blocked = false,
                    source = RecipientSource.MANUAL,
                    address = "${recipient.host}:${recipient.port}",
                    method = ConnectionMethod.MANUAL_ADDRESS,
                )
            }
        }
    }

    private fun methodFor(mode: TransportMode): ConnectionMethod = when (mode) {
        TransportMode.AUTO -> ConnectionMethod.AUTOMATIC
        TransportMode.LAN_ONLY -> ConnectionMethod.LAN_ONLY
        TransportMode.WIFI_DIRECT_PREFERRED -> ConnectionMethod.WIFI_DIRECT_PREFERRED
    }

    /**
     * The warnings that apply, most important first. A recipient that scanned our QR code is authenticated by the code
     * itself, so only the others need the verification-code warning.
     */
    fun warnings(
        summary: SelectionSummary,
        recipients: List<ConfirmRecipient>,
        largeTransferBytes: Long,
        radio: RadioStatus,
    ): List<ConfirmWarning> {
        val result = ArrayList<ConfirmWarning>()
        if (recipients.any { it.blocked }) result.add(ConfirmWarning.BLOCKED_RECIPIENT)
        if (!radio.wifiEnabled) {
            result.add(ConfirmWarning.WIFI_OFF)
        } else if (!radio.wifiConnected) {
            result.add(ConfirmWarning.WIFI_NOT_CONNECTED)
        }
        if (largeTransferBytes > 0L && summary.knownBytes >= largeTransferBytes) result.add(ConfirmWarning.LARGE_TRANSFER)
        if (summary.sizeIsPartial) result.add(ConfirmWarning.UNKNOWN_SIZES)
        if (recipients.any { !it.trusted && it.source != RecipientSource.QR }) result.add(ConfirmWarning.VERIFICATION_CODE)
        if (recipients.size > 1) result.add(ConfirmWarning.QUEUED_ONE_BY_ONE)
        return result
    }

    /** The compression note is shown only when compression can actually change what is sent. */
    fun mentionsCompression(mode: CompressionMode, summary: SelectionSummary): Boolean =
        mode == CompressionMode.SMART && !summary.isEmpty

    /** Sending needs something to send and someone to send it to. */
    fun canSend(summary: SelectionSummary, recipients: List<ConfirmRecipient>): Boolean =
        !summary.isEmpty && recipients.isNotEmpty()
}
