package com.aero.share.feature.settings

/** One open-source component that ships inside the app. */
internal data class OpenSourceNotice(val name: String, val author: String, val license: String)

/**
 * The components the app is built with, as declared in the Gradle files (runtime libraries only; test tools are not part of
 * the app). All of them are distributed under the Apache License 2.0. Names are proper names and are not translated.
 */
internal object Licenses {
    const val APACHE_2 = "Apache License 2.0"

    val NOTICES: List<OpenSourceNotice> = listOf(
        OpenSourceNotice("Kotlin and kotlinx.coroutines", "JetBrains", APACHE_2),
        OpenSourceNotice("Jetpack Compose", "Google", APACHE_2),
        OpenSourceNotice("AndroidX Core, Activity, Lifecycle and Navigation", "Google", APACHE_2),
        OpenSourceNotice("AndroidX Room", "Google", APACHE_2),
        OpenSourceNotice("AndroidX DataStore", "Google", APACHE_2),
        OpenSourceNotice("AndroidX WorkManager", "Google", APACHE_2),
        OpenSourceNotice("AndroidX CameraX", "Google", APACHE_2),
        OpenSourceNotice("AndroidX DocumentFile", "Google", APACHE_2),
        OpenSourceNotice("ZXing core", "ZXing authors", APACHE_2),
    )
}
