package com.aero.share.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.LocalContext
import com.aero.share.R
import com.aero.share.core.designsystem.AeroToastState
import com.aero.share.di.AppContainer
import com.aero.share.domain.Recipient
import com.aero.share.feature.send.SharedUriResolver

/**
 * Turns requests that arrive from outside the UI into navigation:
 *  - files shared from another app (share sheet) start a fresh send at the recipient step;
 *  - an `aero://pair?...` link starts a send to that device at the picker step.
 * Each request is cleared before it is handled, so it can never run twice (rotation, language change, process restore).
 */
@Composable
internal fun ExternalRequestsEffect(container: AppContainer, navigator: AeroNavigator, toast: AeroToastState) {
    val context = LocalContext.current

    LaunchedEffect(container) {
        container.launch.sharedUris.collect { uris ->
            if (uris.isEmpty()) return@collect
            container.launch.sharedUris.value = emptyList()
            val items = SharedUriResolver.resolve(context, uris)
            if (items.isEmpty()) {
                toast.show(context.getString(R.string.nav_shared_unreadable))
            } else {
                // A share from another app is a new send, never a continuation of an abandoned selection.
                container.sendSession.clearAll()
                container.sendSession.add(items)
                navigator.openRecipients()
            }
        }
    }

    LaunchedEffect(container) {
        container.launch.pairingLink.collect { link ->
            if (link == null) return@collect
            container.launch.pairingLink.value = null
            when (val result = PairingLinks.evaluate(link, System.currentTimeMillis())) {
                is PairingLink.Usable -> {
                    container.sendSession.clearAll()
                    container.sendSession.setRecipients(listOf(Recipient.Qr(result.payload)))
                    navigator.openSendPicker()
                }
                PairingLink.Invalid -> toast.show(context.getString(R.string.nav_pairing_invalid))
                PairingLink.Expired -> toast.show(context.getString(R.string.nav_pairing_expired))
            }
        }
    }
}
