package com.aero.share.core.storage

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.annotation.RequiresApi
import com.aero.share.transfer.model.ConflictPolicy
import com.aero.share.transfer.model.FileCategory
import com.aero.share.transfer.model.ManifestEntry
import com.aero.share.transfer.model.SavedFile
import com.aero.share.transfer.path.PathSafety
import com.aero.share.transfer.storage.StagedIncomingStorage
import java.io.File
import java.io.FileInputStream
import java.io.IOException

/**
 * Receives into `Downloads/AERO SHARE/` through MediaStore (Android 10+): no storage permission is needed and the files show up
 * in the system Downloads app. Files stay `IS_PENDING` until fully copied, so other apps never see half-written data.
 */
@RequiresApi(Build.VERSION_CODES.Q)
class MediaStoreIncomingStorage(
    private val context: Context,
    partsDir: File,
    conflictPolicy: ConflictPolicy,
) : StagedIncomingStorage(partsDir, conflictPolicy) {
    private val resolver = context.contentResolver
    private val collection: Uri = MediaStore.Downloads.EXTERNAL_CONTENT_URI

    override fun destinationLabel(): String = LABEL

    override fun destinationFreeBytes(): Long? = StorageSpace.freeBytes(Environment.getExternalStorageDirectory())

    override fun publish(entry: ManifestEntry, staged: File, sha256: String): SavedFile {
        val rel = PathSafety.sanitizeRelativePath(entry.relativePath) ?: throw IOException("unsafe path")
        val dir = rel.substringBeforeLast('/', "")
        val wanted = rel.substringAfterLast('/')
        val relativePath = if (dir.isEmpty()) "$BASE_PATH/" else "$BASE_PATH/$dir/"

        var name = wanted
        val existing = findExisting(relativePath, wanted)
        if (existing != null) {
            when (conflictPolicy) {
                ConflictPolicy.SKIP -> return saved(existing, wanted, dir, entry, sha256)
                ConflictPolicy.KEEP_BOTH -> name = PathSafety.uniqueName(wanted) { findExisting(relativePath, it) != null }
                ConflictPolicy.REPLACE -> resolver.delete(existing, null, null)
            }
        }

        val mime = MimeTypes.fromName(name)
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = resolver.insert(collection, values) ?: throw IOException("cannot create file")
        try {
            val out = resolver.openOutputStream(uri, "w") ?: throw IOException("cannot open file")
            out.use { sink ->
                FileInputStream(staged).use { input -> input.copyTo(sink, COPY_BUFFER) }
                sink.flush()
            }
            val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
            resolver.update(uri, done, null, null)
        } catch (e: Exception) {
            try {
                resolver.delete(uri, null, null)
            } catch (ignored: Exception) {
                // best effort: the pending row is invisible to other apps and removed by the system later
            }
            throw if (e is IOException) e else IOException("cannot store file", e)
        }
        return saved(uri, name, dir, entry, sha256)
    }

    private fun findExisting(relativePath: String, displayName: String): Uri? {
        val selection = "${MediaStore.MediaColumns.RELATIVE_PATH} = ? AND ${MediaStore.MediaColumns.DISPLAY_NAME} = ?"
        resolver.query(collection, arrayOf(MediaStore.MediaColumns._ID), selection, arrayOf(relativePath, displayName), null)?.use { c ->
            if (c.moveToFirst()) return ContentUris.withAppendedId(collection, c.getLong(0))
        }
        return null
    }

    private fun saved(uri: Uri, requestedName: String, dir: String, entry: ManifestEntry, sha256: String): SavedFile {
        // The provider may still have adjusted the name (for instance when another app owns a file with the same name).
        val finalName = resolver.query(uri, arrayOf(MediaStore.MediaColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        } ?: requestedName
        val mime = MimeTypes.fromName(finalName)
        return SavedFile(
            uri = uri.toString(),
            displayName = finalName,
            relativePath = if (dir.isEmpty()) finalName else "$dir/$finalName",
            size = entry.size,
            mimeType = mime,
            category = FileCategory.classify(finalName, mime),
            sha256 = sha256,
        )
    }

    companion object {
        const val BASE_PATH = "Download/AERO SHARE"
        const val LABEL = "Downloads/AERO SHARE"
        private const val COPY_BUFFER = 256 * 1024
    }
}
