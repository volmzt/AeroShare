package com.aero.share.core.storage.source

import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import com.aero.share.core.storage.MimeTypes
import com.aero.share.core.storage.UriMetadata
import com.aero.share.core.storage.apk.ApkBundle
import com.aero.share.core.storage.apk.ApkBundleManifest
import com.aero.share.domain.AppItem
import com.aero.share.domain.FileItem
import com.aero.share.domain.FolderItem
import com.aero.share.domain.SelectionItem
import com.aero.share.transfer.engine.SendableFile
import com.aero.share.transfer.engine.SourceVersion
import com.aero.share.transfer.model.FileCategory
import java.io.File
import java.io.IOException
import java.util.UUID
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext

/**
 * Turns what the user selected (files, folders, installed apps) into streams the transfer engine can send.
 * Nothing is read into memory: files are opened lazily at the requested offset.
 */
class SendSourceFactory(private val context: Context) {

    /**
     * Throws [IOException] with a readable message when something that was selected cannot be read (vanished, size
     * unknown, app uninstalled, no room to prepare an APK bundle). The coordinator reports that as an unreadable source.
     */
    suspend fun resolve(items: List<SelectionItem>): ResolvedSelection = withContext(Dispatchers.IO) {
        val files = ArrayList<SendableFile>()
        val temp = ArrayList<File>()
        var skipped = 0
        var counter = 0
        val nextId: () -> Int = { counter++ }
        try {
            for (item in items) {
                currentCoroutineContext().ensureActive()
                when (item) {
                    is FileItem -> files.add(fileSendable(item, nextId()))
                    is FolderItem -> skipped += FolderEnumerator.enumerate(
                        context,
                        Uri.parse(item.treeUri),
                        item.displayName,
                        files,
                        nextId,
                    )
                    is AppItem -> files.add(appSendable(item, nextId(), temp))
                }
            }
            if (files.isEmpty()) throw IOException("There are no files to send in this selection")
        } catch (e: Throwable) {
            deleteAll(temp)
            throw e
        }
        val title = when (val only = items.singleOrNull()) {
            is FolderItem -> only.displayName
            is AppItem -> only.displayName
            else -> null
        }
        ResolvedSelection(files = files, title = title, cleanup = { deleteAll(temp) }, skipped = skipped)
    }

    private fun fileSendable(item: FileItem, id: Int): SendableFile {
        val uri = Uri.parse(item.uri)
        val meta = UriMetadata.query(context, uri) ?: throw IOException("Cannot read ${item.displayName}")
        val name = cleanName(meta.name ?: item.displayName)
        val mime = meta.mimeType ?: item.mimeType ?: MimeTypes.fromName(name)
        return ContentUriSendable(
            id = id,
            relativePath = name,
            size = meta.size,
            lastModified = meta.lastModified,
            category = FileCategory.classify(name, mime),
            mimeType = mime,
            uri = uri,
            resolver = context.contentResolver,
            versionProbe = { UriMetadata.query(context, uri)?.let { SourceVersion(it.size, it.lastModified) } },
        )
    }

    /** One APK as it is, or, when the app has split APKs, an `.aeroapks` bundle built in the cache (removed by cleanup). */
    private fun appSendable(item: AppItem, id: Int, temp: MutableList<File>): SendableFile {
        val pm = context.packageManager
        val info: PackageInfo
        try {
            info = pm.getPackageInfo(item.packageName, 0)
        } catch (e: PackageManager.NameNotFoundException) {
            throw IOException("${item.displayName} is no longer installed")
        }
        val app = info.applicationInfo ?: throw IOException("${item.displayName} has no package information")
        val base = File(app.sourceDir ?: throw IOException("${item.displayName} has no readable package"))
        if (!base.isFile || !base.canRead()) throw IOException("The package of ${item.displayName} is not readable")
        val splitDirs: Array<String> = app.splitSourceDirs ?: emptyArray()
        val stem = stemOf(item.displayName, item.versionName)
        if (splitDirs.isEmpty()) return FileSendable(id, "$stem.apk", base, FileCategory.APK, APK_MIME)

        if (splitDirs.size > ApkBundle.MAX_SPLITS) throw IOException("${item.displayName} has too many split packages")
        val used = HashSet<String>()
        val named = ArrayList<Pair<String, File>>()
        splitDirs.forEachIndexed { index, path ->
            val file = File(path)
            var name = file.name
            if (!ApkBundle.isApkEntry(name) || name == ApkBundle.BASE_ENTRY || !used.add(name)) {
                name = "split_$index.apk"
                used.add(name)
            }
            named.add(name to file)
        }
        for ((_, file) in named) {
            if (!file.isFile || !file.canRead()) throw IOException("A split package of ${item.displayName} is not readable")
        }
        val dir = File(File(context.cacheDir, "bundles"), UUID.randomUUID().toString())
        if (!dir.mkdirs()) throw IOException("Cannot prepare the bundle folder")
        val target = File(dir, "$stem.${ApkBundle.EXTENSION}")
        // Delete order matters: the file first, then its folder.
        temp.add(target)
        temp.add(dir)
        val needed = base.length() + named.sumOf { it.second.length() }
        if (dir.usableSpace < needed + SAFETY_BYTES) throw IOException("Not enough free space to prepare ${item.displayName}")
        val manifest = ApkBundleManifest(item.packageName, item.versionName, versionCodeOf(info), item.displayName, named.map { it.first })
        try {
            ApkBundle.build(target, manifest.toJson(), base, named)
        } catch (e: IllegalArgumentException) {
            throw IOException("Cannot build the bundle for ${item.displayName}", e)
        }
        return FileSendable(id, target.name, target, FileCategory.APK, MimeTypes.OCTET_STREAM)
    }

    @Suppress("DEPRECATION")
    private fun versionCodeOf(info: PackageInfo): Long =
        if (Build.VERSION.SDK_INT >= 28) info.longVersionCode else info.versionCode.toLong()

    private fun cleanName(raw: String): String {
        val cleaned = raw.replace('/', '_').replace('\\', '_').trim()
        return if (cleaned.isEmpty() || cleaned == "." || cleaned == "..") "file" else cleaned
    }

    private fun stemOf(label: String, version: String?): String {
        val raw = if (version.isNullOrBlank()) label else "${label}_$version"
        val cleaned = raw.map { c -> if (c.isLetterOrDigit() || c in " ._()+-") c else '_' }.joinToString("").trim().take(80)
        return cleaned.ifEmpty { "app" }
    }

    private fun deleteAll(files: List<File>) {
        for (file in files) file.delete()
    }

    private companion object {
        const val APK_MIME = "application/vnd.android.package-archive"
        const val SAFETY_BYTES = 32L * 1024 * 1024
    }
}
