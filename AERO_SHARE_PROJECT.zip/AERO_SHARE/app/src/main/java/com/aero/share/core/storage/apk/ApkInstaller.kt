package com.aero.share.core.storage.apk

import androidx.compose.ui.graphics.ImageBitmap
import kotlinx.coroutines.flow.SharedFlow

enum class ApkWarning {
    /** An app with this package is installed and was signed by a different certificate: install would fail or be a fake. */
    SIGNER_MISMATCH,
    /** Older version than the installed one. */
    DOWNGRADE,
    /** Requires a newer Android than this device runs. */
    MIN_SDK_TOO_HIGH,
    /** Archive is incomplete or not a valid APK. */
    INVALID,
    /** Split bundle is missing parts required for this device. */
    INCOMPLETE_SPLITS,
}

/** Metadata inspection only. This is NOT malware scanning and must never be described as such. */
data class ApkInfo(
    val uri: String,
    val fileName: String,
    val appName: String?,
    val packageName: String?,
    val versionName: String?,
    val versionCode: Long?,
    val sizeBytes: Long,
    val icon: ImageBitmap?,
    /** SHA-256 of the file (computed by streaming). */
    val sha256: String?,
    /** SHA-256 fingerprints of the signing certificates, lower-case hex. */
    val signerSha256: List<String>,
    val isBundle: Boolean,
    val splitCount: Int,
    val installedVersionName: String?,
    val warnings: List<ApkWarning>,
)

sealed interface InstallEvent {
    /** The system installer UI was shown (user must confirm there). */
    data class Started(val uri: String) : InstallEvent
    data class Success(val packageName: String?) : InstallEvent
    data class Failure(val message: String) : InstallEvent
    data object Cancelled : InstallEvent
}

/** Installation always goes through Android's PackageInstaller with user confirmation. Nothing is installed silently. */
interface ApkInstaller {
    /** Reads metadata of an APK or AERO split bundle (.aeroapks). Returns null if unreadable. */
    suspend fun inspect(uri: String): ApkInfo?

    /** Whether the user has allowed this app to request package installs. */
    fun canRequestInstall(): Boolean

    /** Opens the system settings page where the user can allow installing from AERO SHARE. */
    fun openInstallPermissionSettings()

    /** Starts the system install flow. Result is reported through [events]. */
    suspend fun install(uri: String)

    val events: SharedFlow<InstallEvent>
}
