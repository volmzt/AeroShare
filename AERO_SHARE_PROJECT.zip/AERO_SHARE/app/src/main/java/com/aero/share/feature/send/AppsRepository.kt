package com.aero.share.feature.send

import android.content.Context
import android.content.Intent
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.graphics.Bitmap
import android.os.Build
import android.util.LruCache
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import com.aero.share.domain.AppItem
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Lists the apps that have a launcher icon (this app excluded) so they can be shared as APK files. The size is the base
 * package plus all split packages, which is exactly what a transfer of that app sends. Icons are loaded one by one, when a
 * row is drawn, and kept in a small memory cache.
 */
internal class AppsRepository(context: Context) {
    private val appContext: Context = context.applicationContext
    private val icons = object : LruCache<String, Bitmap>(ICON_CACHE_KILOBYTES) {
        override fun sizeOf(key: String, value: Bitmap): Int = (value.byteCount / 1024).coerceAtLeast(1)
    }

    suspend fun load(): List<AppItem> = withContext(Dispatchers.IO) {
        val manager = appContext.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val seen = HashSet<String>()
        val items = ArrayList<AppItem>()
        for (info in queryLauncher(manager, launcher)) {
            val activity = info.activityInfo ?: continue
            val packageName: String = activity.packageName ?: continue
            if (packageName == appContext.packageName || !seen.add(packageName)) continue
            val applicationInfo = activity.applicationInfo ?: continue
            val sourceDir: String = applicationInfo.sourceDir ?: continue
            val splitDirs: Array<String> = applicationInfo.splitSourceDirs ?: emptyArray<String>()
            var size = File(sourceDir).length()
            for (path in splitDirs) size += File(path).length()
            val label = info.loadLabel(manager).toString().trim().ifEmpty { packageName }
            items.add(
                AppItem(
                    id = packageName,
                    packageName = packageName,
                    displayName = label,
                    versionName = packageInfo(manager, packageName)?.versionName,
                    size = size,
                    splitCount = splitDirs.size,
                ),
            )
        }
        items.sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { app -> app.displayName })
    }

    fun cachedIcon(packageName: String): ImageBitmap? = icons.get(packageName)?.asImageBitmap()

    suspend fun icon(packageName: String, sizePx: Int): ImageBitmap? {
        cachedIcon(packageName)?.let { return it }
        val bitmap = withContext(Dispatchers.IO) {
            try {
                appContext.packageManager.getApplicationIcon(packageName).toBitmap(sizePx, sizePx)
            } catch (e: PackageManager.NameNotFoundException) {
                null
            } catch (e: RuntimeException) {
                null
            }
        } ?: return null
        icons.put(packageName, bitmap)
        return bitmap.asImageBitmap()
    }

    @Suppress("DEPRECATION")
    private fun queryLauncher(manager: PackageManager, intent: Intent): List<ResolveInfo> =
        if (Build.VERSION.SDK_INT >= 33) {
            manager.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0L))
        } else {
            manager.queryIntentActivities(intent, 0)
        }

    @Suppress("DEPRECATION")
    private fun packageInfo(manager: PackageManager, packageName: String): PackageInfo? =
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                manager.getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(0L))
            } else {
                manager.getPackageInfo(packageName, 0)
            }
        } catch (e: PackageManager.NameNotFoundException) {
            null
        }

    private companion object {
        const val ICON_CACHE_KILOBYTES = 4 * 1024
    }
}
