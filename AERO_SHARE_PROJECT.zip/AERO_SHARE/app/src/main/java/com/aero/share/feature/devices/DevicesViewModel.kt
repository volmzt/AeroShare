package com.aero.share.feature.devices

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aero.share.di.AppContainer
import com.aero.share.domain.DiscoveryState
import com.aero.share.domain.NearbyDevice
import com.aero.share.domain.Recipient
import com.aero.share.domain.Visibility
import com.aero.share.feature.home.HomeDevice
import com.aero.share.feature.home.HomeLogic
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** Everything the Devices tab draws. [loaded] stays false until the stored devices were read, so no empty state flashes. */
internal data class DevicesUi(
    val loaded: Boolean = false,
    val nearby: List<HomeDevice> = emptyList(),
    val known: List<KnownRow> = emptyList(),
    val hidden: Boolean = false,
    val discovery: DiscoveryState = DiscoveryState(),
    val longSearch: Boolean = false,
) {
    /** The device with this id as it is right now, or null when it is neither nearby nor stored any more. */
    fun target(deviceId: String): DeviceTarget? {
        val live = nearby.firstOrNull { row -> row.device.deviceId == deviceId }?.device
        val record = known.firstOrNull { row -> row.record.deviceId == deviceId }?.record
        return if (live == null && record == null) null else DeviceTarget(deviceId, record, live)
    }
}

/**
 * Owns the discovery session of the Devices tab (it searches only while the tab is visible) and passes the decisions about
 * stored devices to the repository. Trust, block and alias live in the repository; nothing is cached here.
 */
internal class DevicesViewModel(private val container: AppContainer) : ViewModel() {
    private val longSearch = MutableStateFlow(false)
    private var resumed = false
    private var started = false
    private var timer: Job? = null

    val state: StateFlow<DevicesUi> = combine(
        container.discovery.devices,
        container.devices.devices,
        container.settings.settings,
        container.discovery.state,
        longSearch,
    ) { nearby, records, settings, discovery, long ->
        DevicesUi(
            loaded = true,
            nearby = HomeLogic.devices(nearby, records),
            known = DevicesLogic.known(records, nearby),
            hidden = settings.visibility == Visibility.HIDDEN,
            discovery = discovery,
            longSearch = long,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), DevicesUi())

    fun onResume() {
        resumed = true
        container.capabilities.refresh()
        beginSearch()
    }

    fun onPause() {
        resumed = false
        endSearch()
    }

    /** The refresh button and the "search again" actions. */
    fun searchNow() {
        if (!resumed) return
        if (started) {
            restartTimer()
            container.discovery.refresh()
        } else {
            beginSearch()
        }
    }

    /** The system permission dialog was closed; whatever the answer, look at the situation again. */
    fun onPermissionResult() {
        container.capabilities.refresh()
        searchNow()
    }

    fun setVisible(visible: Boolean) {
        viewModelScope.launch {
            container.settings.update { settings ->
                settings.copy(visibility = if (visible) Visibility.VISIBLE else Visibility.HIDDEN)
            }
        }
    }

    fun rename(deviceId: String, input: String) {
        val alias = DevicesLogic.aliasOf(input)
        viewModelScope.launch { container.devices.rename(deviceId, alias) }
    }

    fun setTrusted(deviceId: String, trusted: Boolean) {
        viewModelScope.launch { container.devices.setTrusted(deviceId, trusted) }
    }

    fun setBlocked(deviceId: String, blocked: Boolean) {
        viewModelScope.launch { container.devices.setBlocked(deviceId, blocked) }
    }

    fun forget(deviceId: String) {
        viewModelScope.launch { container.devices.forget(deviceId) }
    }

    /** Starts a fresh selection addressed to [device]; the caller then opens the file picker. */
    fun prepareSend(device: NearbyDevice) {
        container.sendSession.clearAll()
        container.sendSession.setRecipients(listOf(Recipient.Nearby(device)))
    }

    private fun beginSearch() {
        if (!started) {
            started = true
            container.discovery.startDiscovery(OWNER)
        }
        restartTimer()
    }

    private fun endSearch() {
        if (started) {
            started = false
            container.discovery.stopDiscovery(OWNER)
        }
        timer?.cancel()
        timer = null
        longSearch.value = false
    }

    private fun restartTimer() {
        timer?.cancel()
        longSearch.value = false
        timer = viewModelScope.launch {
            delay(HomeLogic.NONE_FOUND_AFTER_MS)
            longSearch.value = true
        }
    }

    override fun onCleared() {
        endSearch()
    }

    private companion object {
        const val OWNER = "devices"
    }
}
