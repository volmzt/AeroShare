package com.aero.share.feature.history

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aero.share.di.AppContainer
import com.aero.share.domain.HistoryItem
import java.util.TimeZone
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * What the History screen draws. [loaded] stays false until the stored records were read, so the empty state does not
 * flash. [all] is the unfiltered list, so an open detail sheet survives a change of the filters.
 */
internal data class HistoryUi(
    val loaded: Boolean = false,
    val all: List<HistoryItem> = emptyList(),
    val filters: HistoryFilters = HistoryFilters(),
    val groups: List<HistoryGroup> = emptyList(),
) {
    fun find(id: String): HistoryItem? = all.firstOrNull { item -> item.id == id }
}

/** Reads the history and the two filters; deleting records never touches the received files themselves. */
internal class HistoryViewModel(private val container: AppContainer) : ViewModel() {
    private val filters = MutableStateFlow(HistoryFilters())

    val state: StateFlow<HistoryUi> = combine(container.history.items, filters) { items, current ->
        HistoryUi(
            loaded = true,
            all = items,
            filters = current,
            groups = HistoryLogic.group(HistoryLogic.filter(items, current), System.currentTimeMillis(), TimeZone.getDefault()),
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HistoryUi())

    fun setDirection(direction: DirectionFilter) {
        filters.value = filters.value.copy(direction = direction)
    }

    fun setStatus(status: StatusFilter) {
        filters.value = filters.value.copy(status = status)
    }

    fun resetFilters() {
        filters.value = HistoryFilters()
    }

    fun delete(id: String) {
        viewModelScope.launch { container.history.delete(id) }
    }

    /** Removes the records only; files that were received stay where they are. */
    fun clear() {
        viewModelScope.launch { container.history.clear() }
    }
}
