package com.aero.share.feature.send

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.aero.share.R
import com.aero.share.core.common.Formatters
import com.aero.share.core.designsystem.AeroBadge
import com.aero.share.core.designsystem.AeroButton
import com.aero.share.core.designsystem.AeroButtonStyle
import com.aero.share.core.designsystem.AeroCard
import com.aero.share.core.designsystem.AeroDeviceIcon
import com.aero.share.core.designsystem.AeroIcon
import com.aero.share.core.designsystem.AeroIconButton
import com.aero.share.core.designsystem.AeroText
import com.aero.share.core.designsystem.AeroTheme

internal fun ConnectionMethod.textRes(): Int = when (this) {
    ConnectionMethod.AUTOMATIC -> R.string.send_confirm_method_auto
    ConnectionMethod.LAN_ONLY -> R.string.send_confirm_method_lan
    ConnectionMethod.WIFI_DIRECT_PREFERRED -> R.string.send_confirm_method_direct
    ConnectionMethod.QR_CODE -> R.string.send_confirm_method_qr
    ConnectionMethod.QR_HOTSPOT -> R.string.send_confirm_method_qr_hotspot
    ConnectionMethod.MANUAL_ADDRESS -> R.string.send_confirm_method_manual
}

/** One recipient: icon, name, how the connection will be made and its badges. With several recipients each can be removed. */
@Composable
internal fun ConfirmRecipientRow(recipient: ConfirmRecipient, canRemove: Boolean, onRemove: () -> Unit) {
    val colors = AeroTheme.colors
    val title = recipient.address ?: recipient.name.ifBlank { stringResource(R.string.common_unknown_device) }
    Row(
        modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp).padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(AeroTheme.dimens.radiusSmall))
                .background(colors.accentContainer),
            contentAlignment = Alignment.Center,
        ) {
            AeroDeviceIcon(kind = recipient.kind)
        }
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            AeroText(text = title, style = AeroTheme.typography.bodyStrong, maxLines = 1)
            AeroText(
                text = stringResource(recipient.method.textRes()),
                style = AeroTheme.typography.caption,
                color = colors.textSecondary,
            )
        }
        if (recipient.trusted) {
            AeroBadge(text = stringResource(R.string.common_trust_trusted), color = colors.success)
        }
        if (recipient.blocked) {
            AeroBadge(text = stringResource(R.string.common_trust_blocked), modifier = Modifier.padding(start = 6.dp), color = colors.danger)
        }
        if (canRemove) {
            AeroIconButton(
                icon = Icons.Rounded.Close,
                contentDescription = stringResource(R.string.send_confirm_remove_recipient, title),
                onClick = onRemove,
            )
        }
    }
}

private class WarningStyle(val icon: ImageVector, val tint: Color)

@Composable
private fun warningStyle(warning: ConfirmWarning): WarningStyle {
    val colors = AeroTheme.colors
    return when (warning) {
        ConfirmWarning.WIFI_OFF -> WarningStyle(Icons.Rounded.Warning, colors.danger)
        ConfirmWarning.WIFI_NOT_CONNECTED,
        ConfirmWarning.LARGE_TRANSFER,
        ConfirmWarning.UNKNOWN_SIZES,
        ConfirmWarning.BLOCKED_RECIPIENT,
        -> WarningStyle(Icons.Rounded.Warning, colors.warning)
        ConfirmWarning.VERIFICATION_CODE,
        ConfirmWarning.QUEUED_ONE_BY_ONE,
        -> WarningStyle(Icons.Rounded.Info, colors.accentText)
    }
}

@Composable
private fun warningText(warning: ConfirmWarning, summary: SelectionSummary): String = when (warning) {
    ConfirmWarning.LARGE_TRANSFER -> stringResource(R.string.send_confirm_warn_large, Formatters.bytes(summary.knownBytes))
    ConfirmWarning.UNKNOWN_SIZES -> stringResource(R.string.send_confirm_warn_unknown_sizes)
    ConfirmWarning.WIFI_OFF -> stringResource(R.string.send_confirm_warn_wifi_off)
    ConfirmWarning.WIFI_NOT_CONNECTED -> stringResource(R.string.send_confirm_warn_wifi_not_connected)
    ConfirmWarning.VERIFICATION_CODE -> stringResource(R.string.send_confirm_warn_code)
    ConfirmWarning.QUEUED_ONE_BY_ONE -> stringResource(R.string.send_confirm_warn_queue)
    ConfirmWarning.BLOCKED_RECIPIENT -> stringResource(R.string.send_confirm_warn_blocked)
}

/** A note that applies to this send. The Wi-Fi ones offer a shortcut to the system settings. */
@Composable
internal fun ConfirmWarningRow(warning: ConfirmWarning, summary: SelectionSummary, onWifiSettings: () -> Unit) {
    val style = warningStyle(warning)
    val wifiRelated = warning == ConfirmWarning.WIFI_OFF || warning == ConfirmWarning.WIFI_NOT_CONNECTED
    AeroCard {
        Row(verticalAlignment = Alignment.Top) {
            AeroIcon(icon = style.icon, contentDescription = null, tint = style.tint, modifier = Modifier.padding(top = 2.dp))
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                AeroText(text = warningText(warning, summary))
                if (wifiRelated) {
                    Box(modifier = Modifier.padding(top = 10.dp)) {
                        AeroButton(
                            text = stringResource(R.string.home_action_wifi_settings),
                            onClick = onWifiSettings,
                            style = AeroButtonStyle.Secondary,
                        )
                    }
                }
            }
        }
    }
}
