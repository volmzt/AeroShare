package com.aero.share.core.common

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings

/**
 * Shortcuts to system settings pages. Each returns false (instead of crashing) when the device has no screen for it, so the
 * caller can fall back to a toast. Nothing here needs a permission.
 */
object SystemIntents {
    fun openWifiSettings(context: Context): Boolean = start(context, Intent(Settings.ACTION_WIFI_SETTINGS))

    /** The "App info" page of AERO SHARE, where permissions can be switched on again after they were denied. */
    fun openAppSettings(context: Context): Boolean = start(
        context,
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.packageName, null)),
    )

    /** The notification page of AERO SHARE (channels), available from Android 8 which is the app's minimum. */
    fun openNotificationSettings(context: Context): Boolean = start(
        context,
        Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName),
    )

    private fun start(context: Context, intent: Intent): Boolean {
        if (context !is Activity) intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(intent)
            true
        } catch (e: ActivityNotFoundException) {
            false
        } catch (e: SecurityException) {
            false
        }
    }
}
