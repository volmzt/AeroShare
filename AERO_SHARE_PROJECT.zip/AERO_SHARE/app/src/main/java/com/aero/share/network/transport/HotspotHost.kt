package com.aero.share.network.transport

import android.annotation.SuppressLint
import android.content.Context
import android.net.wifi.SoftApConfiguration
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import com.aero.share.core.permissions.Permissions
import com.aero.share.transfer.pairing.HotspotCredentials
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withTimeoutOrNull

/**
 * A local-only hotspot (WifiManager.startLocalOnlyHotspot) used for QR pairing when the two phones share no network.
 * The platform picks the name and the passphrase; they are shown in the QR code for this one session only. The hotspot
 * has no internet access and lives exactly as long as the reservation is held, so [stop] must always be called.
 *
 * Limits: it may fail when tethering is active or the radio cannot run an access point next to the current Wi-Fi
 * connection; some phones disconnect the current Wi-Fi while it runs. A WPA3-only hotspot is rejected, because the QR
 * format carries no security type and the joining side requests WPA2.
 */
internal class HotspotHost(context: Context, private val log: (String) -> Unit) {
    private val app = context.applicationContext
    private val wifi: WifiManager? = app.getSystemService(WifiManager::class.java)
    private val lock = Any()
    private var reservation: WifiManager.LocalOnlyHotspotReservation? = null
    private var credentials: HotspotCredentials? = null

    @SuppressLint("MissingPermission")
    suspend fun start(): HotspotCredentials? {
        synchronized(lock) {
            val existing = credentials
            if (existing != null && reservation != null) return existing
        }
        val manager = wifi ?: return null
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return null
        if (!Permissions.allGranted(app, Permissions.nearby())) {
            log("the hotspot needs the nearby-devices permission")
            return null
        }
        val started = CompletableDeferred<WifiManager.LocalOnlyHotspotReservation?>()
        val callback = object : WifiManager.LocalOnlyHotspotCallback() {
            override fun onStarted(reservation: WifiManager.LocalOnlyHotspotReservation?) {
                if (reservation == null) {
                    started.complete(null)
                } else if (!started.complete(reservation)) {
                    // Nobody is waiting any more (timeout): give the hotspot back.
                    reservation.close()
                }
            }

            override fun onStopped() {
                synchronized(lock) {
                    reservation = null
                    credentials = null
                }
            }

            override fun onFailed(reason: Int) {
                log("the hotspot could not start (" + reasonName(reason) + ")")
                started.complete(null)
            }
        }
        try {
            manager.startLocalOnlyHotspot(callback, Handler(Looper.getMainLooper()))
        } catch (e: SecurityException) {
            log("the hotspot was denied")
            return null
        } catch (e: RuntimeException) {
            log("starting the hotspot threw " + e.javaClass.simpleName)
            return null
        }
        val got = withTimeoutOrNull(START_TIMEOUT_MS) { started.await() }
        if (got == null) {
            started.cancel()
            return null
        }
        val creds = credentialsOf(got)
        if (creds == null) {
            got.close()
            log("the hotspot configuration cannot be used for pairing")
            return null
        }
        synchronized(lock) {
            reservation = got
            credentials = creds
        }
        return creds
    }

    fun stop() {
        val held = synchronized(lock) {
            val current = reservation
            reservation = null
            credentials = null
            current
        }
        try {
            held?.close()
        } catch (e: RuntimeException) {
            log("stopping the hotspot threw " + e.javaClass.simpleName)
        }
    }

    @Suppress("DEPRECATION")
    private fun credentialsOf(held: WifiManager.LocalOnlyHotspotReservation): HotspotCredentials? {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val config = held.softApConfiguration
            if (config.securityType == SoftApConfiguration.SECURITY_TYPE_WPA3_SAE) return null
            return HotspotRules.build(config.ssid, config.passphrase)
        }
        val legacy = held.wifiConfiguration ?: return null
        return HotspotRules.build(legacy.SSID, legacy.preSharedKey)
    }

    private fun reasonName(reason: Int): String = when (reason) {
        WifiManager.LocalOnlyHotspotCallback.ERROR_NO_CHANNEL -> "no channel"
        WifiManager.LocalOnlyHotspotCallback.ERROR_INCOMPATIBLE_MODE -> "incompatible mode"
        WifiManager.LocalOnlyHotspotCallback.ERROR_TETHERING_DISALLOWED -> "tethering disallowed"
        else -> "code-$reason"
    }

    private companion object {
        const val START_TIMEOUT_MS = 15_000L
    }
}
