package com.aero.share.feature.send

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aero.share.di.AppContainer
import com.aero.share.domain.AppSettings
import com.aero.share.domain.DeviceRecord
import com.aero.share.domain.RadioStatus
import com.aero.share.domain.Recipient
import com.aero.share.domain.SelectionItem
import com.aero.share.domain.SendJob
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

internal data class ConfirmUi(
    val summary: SelectionSummary,
    val recipients: List<ConfirmRecipient>,
    val warnings: List<ConfirmWarning>,
    val compression: Boolean,
    val canSend: Boolean,
)

/** Everything the confirmation shows, derived from the send session, the known devices, the settings and the radios. */
internal class ConfirmViewModel(private val container: AppContainer) : ViewModel() {
    private fun build(
        selection: List<SelectionItem>,
        chosen: List<Recipient>,
        known: List<DeviceRecord>,
        settings: AppSettings,
        radio: RadioStatus,
    ): ConfirmUi {
        val summary = SelectionMath.summarize(selection)
        val recipients = ConfirmLogic.recipients(chosen, known, settings.transportMode)
        return ConfirmUi(
            summary = summary,
            recipients = recipients,
            warnings = ConfirmLogic.warnings(summary, recipients, settings.largeTransferWarnBytes, radio),
            compression = ConfirmLogic.mentionsCompression(settings.compression, summary),
            canSend = ConfirmLogic.canSend(summary, recipients),
        )
    }

    val state: StateFlow<ConfirmUi> = combine(
        container.sendSession.selection,
        container.sendSession.recipients,
        container.devices.devices,
        container.settings.settings,
        container.capabilities.radio,
    ) { selection, chosen, known, settings, radio ->
        build(selection, chosen, known, settings, radio)
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5_000),
        build(
            container.sendSession.selection.value,
            container.sendSession.recipients.value,
            emptyList(),
            container.settings.settings.value,
            container.capabilities.radio.value,
        ),
    )

    /** The radio state may have changed while another screen (the system Wi-Fi settings, say) was in front. */
    fun refreshRadio() = container.capabilities.refresh()

    fun removeRecipient(key: String) = container.sendSession.removeRecipient(key)

    fun removeItem(id: String) = container.sendSession.remove(id)

    fun clearItems() = container.sendSession.clearSelection()

    /**
     * Queues one transfer per recipient and empties the session, so the same selection cannot be sent twice by accident.
     * Returns the id of the first transfer, or null when there was nothing to send.
     */
    fun send(): String? {
        val items = container.sendSession.selection.value
        val recipients = container.sendSession.recipients.value
        if (items.isEmpty() || recipients.isEmpty()) return null
        val ids = container.coordinator.send(SendJob(items = items, recipients = recipients))
        val first = ids.firstOrNull() ?: return null
        container.sendSession.clearAll()
        return first
    }
}
