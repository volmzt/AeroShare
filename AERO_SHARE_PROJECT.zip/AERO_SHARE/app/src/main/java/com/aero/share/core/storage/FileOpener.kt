package com.aero.share.core.storage

/** Opens, shares and locates received files using normal Android intents. Never executes files. */
interface FileOpener {
    /** Opens [uri] with an app that handles [mimeType]. Returns false when no app can open it. */
    fun open(uri: String, mimeType: String?): Boolean

    /** Shares the given files through the system share sheet. */
    fun share(uris: List<String>, mimeTypes: List<String?>): Boolean

    /** Opens the receive folder (Downloads/AERO SHARE or the user-chosen folder) in a file manager. */
    fun openReceiveFolder(): Boolean
}
