package com.aero.share.transfer

import com.aero.share.core.common.DiagnosticsLog
import com.aero.share.domain.LocalDeviceProvider
import com.aero.share.domain.PairingQrResult
import com.aero.share.domain.ReceiverStatus
import com.aero.share.domain.SettingsRepository
import com.aero.share.domain.TransportPlanner
import com.aero.share.transfer.pairing.HotspotCredentials
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/** Short stable reasons returned in [PairingQrResult.Unavailable]; the UI maps them to localized text. */
object PairingReasons {
    const val NO_NETWORK = "no-network"
    const val RECEIVER_ERROR = "receiver-error"
    const val QR_TOO_LONG = "qr-too-long"
}

/** Subnets of the local-only hotspot while this device runs one for QR pairing. */
internal class HotspotState {
    @Volatile
    var subnets: List<Ipv4Subnet> = emptyList()
}

/**
 * Creates pairing QR codes: makes sure the receiver listens, issues a one-time token, optionally starts a local-only hotspot
 * (so two phones without any router can still connect) and puts every reachable address into the code. The hotspot is
 * stopped again once the code has expired and no transfer is running.
 */
internal class PairingQr(
    private val scope: CoroutineScope,
    private val receiver: ReceiverController,
    private val localDevice: LocalDeviceProvider,
    private val settings: SettingsRepository,
    private val planner: TransportPlanner,
    private val hotspot: HotspotState,
    private val activeCount: StateFlow<Int>,
    private val diagnostics: DiagnosticsLog,
) {
    private val lock = Any()
    private var stopJob: Job? = null
    private var hotspotRunning = false
    private var hotspotAddresses: List<LocalAddress> = emptyList()

    suspend fun create(includeHotspot: Boolean): PairingQrResult {
        val state = receiver.request(true).await()
        val port = state.port
        if (state.status != ReceiverStatus.LISTENING || port == null) {
            return PairingQrResult.Unavailable(PairingReasons.RECEIVER_ERROR)
        }
        val current = settings.settings.value
        val ttlMs = current.qrTtlSeconds.coerceIn(MIN_TTL_SEC, MAX_TTL_SEC) * 1000L
        val before = LocalAddresses.enumerate()

        var credentials: HotspotCredentials? = null
        var hotspotHosts: List<String> = emptyList()
        if (includeHotspot) {
            credentials = startHotspot()
            if (credentials != null) {
                val found = awaitHotspotAddresses(before)
                if (found.isEmpty()) {
                    diagnostics.add("pairing", "hotspot started but no address appeared")
                    stopHotspotNow()
                    credentials = null
                } else {
                    synchronized(lock) { hotspotAddresses = found }
                    hotspot.subnets = found.mapNotNull { it.subnet }
                    hotspotHosts = found.map { it.host }
                    scheduleHotspotStop(ttlMs)
                }
            }
        }

        val hosts = LocalAddresses.qrHosts(LocalAddresses.enumerate(), hotspotHosts)
        if (hosts.isEmpty()) {
            if (credentials != null) stopHotspotNow()
            return PairingQrResult.Unavailable(PairingReasons.NO_NETWORK)
        }
        val info = localDevice.info.value
        val token = receiver.tokens.issue(ttlMs, if (current.qrSingleUse) 1 else MULTI_USE)
        val payload = QrBuilder.build(info.deviceId, info.name, info.kind, hosts, port, info.fingerprint, token, credentials)
            ?: return PairingQrResult.Unavailable(PairingReasons.QR_TOO_LONG)
        return PairingQrResult.Ready(payload, payload.encode(), token.expiresAt, credentials != null)
    }

    /** Called when receiving stops: the hotspot only exists to serve a QR code. */
    fun shutdown() {
        val job = synchronized(lock) {
            val pending = stopJob
            stopJob = null
            pending
        }
        job?.cancel()
        stopHotspotNow()
    }

    private suspend fun startHotspot(): HotspotCredentials? {
        return try {
            val credentials = planner.startHotspot()
            if (credentials != null) synchronized(lock) { hotspotRunning = true }
            credentials
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            diagnostics.add("pairing", "hotspot failed: " + e.javaClass.simpleName)
            null
        }
    }

    /**
     * The hotspot interface appears a moment after the system reports it as started, so addresses that were not there
     * before are awaited for a few seconds. A hotspot that was already running for an earlier QR code keeps its addresses.
     */
    private suspend fun awaitHotspotAddresses(before: List<LocalAddress>): List<LocalAddress> {
        val known = before.map { it.interfaceName + "|" + it.host }.toSet()
        repeat(ADDRESS_POLLS) {
            val now = LocalAddresses.enumerate()
            val added = now.filter { (it.interfaceName + "|" + it.host) !in known }
            if (added.isNotEmpty()) return added
            val remembered = synchronized(lock) { hotspotAddresses }
            if (remembered.isNotEmpty() && remembered.all { old -> now.any { it.host == old.host } }) return remembered
            delay(ADDRESS_POLL_MS)
        }
        return emptyList()
    }

    private fun scheduleHotspotStop(ttlMs: Long) {
        val job = scope.launch {
            delay(ttlMs + HOTSPOT_GRACE_MS)
            activeCount.first { it == 0 }
            stopHotspotNow()
        }
        val previous = synchronized(lock) {
            val old = stopJob
            stopJob = job
            old
        }
        previous?.cancel()
    }

    private fun stopHotspotNow() {
        val wasRunning = synchronized(lock) {
            val running = hotspotRunning
            hotspotRunning = false
            hotspotAddresses = emptyList()
            running
        }
        hotspot.subnets = emptyList()
        if (wasRunning) planner.stopHotspot()
    }

    private companion object {
        const val MIN_TTL_SEC = 30
        const val MAX_TTL_SEC = 600
        const val MULTI_USE = 3
        const val HOTSPOT_GRACE_MS = 15_000L
        const val ADDRESS_POLLS = 10
        const val ADDRESS_POLL_MS = 250L
    }
}
