package com.aero.share.core.storage

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import com.aero.share.transfer.model.ConflictPolicy
import com.aero.share.transfer.model.FileCategory
import com.aero.share.transfer.model.ManifestEntry
import com.aero.share.transfer.model.SavedFile
import com.aero.share.transfer.path.PathSafety
import com.aero.share.transfer.storage.StagedIncomingStorage
import java.io.File
import java.io.FileInputStream
import java.io.IOException

/** Receives into a folder the user picked with the system folder picker (Storage Access Framework tree). */
class SafTreeIncomingStorage(
    private val context: Context,
    private val treeUri: Uri,
    partsDir: File,
    conflictPolicy: ConflictPolicy,
    private val label: String,
) : StagedIncomingStorage(partsDir, conflictPolicy) {

    override fun destinationLabel(): String = label

    /** The Storage Access Framework does not expose free space. */
    override fun destinationFreeBytes(): Long? = null

    override fun publish(entry: ManifestEntry, staged: File, sha256: String): SavedFile {
        val rel = PathSafety.sanitizeRelativePath(entry.relativePath) ?: throw IOException("unsafe path")
        val root = DocumentFile.fromTreeUri(context, treeUri) ?: throw IOException("folder unavailable")
        if (!root.canWrite()) throw IOException("folder is not writable")

        val segments = rel.split('/')
        var dir: DocumentFile = root
        for (segment in segments.dropLast(1)) {
            val found = dir.findFile(segment)
            dir = if (found != null && found.isDirectory) found else dir.createDirectory(segment) ?: throw IOException("cannot create folder")
        }
        val wanted = segments.last()
        var name = wanted
        val existing = dir.findFile(wanted)
        if (existing != null) {
            when (conflictPolicy) {
                ConflictPolicy.SKIP -> return saved(existing, wanted, rel, entry, sha256)
                ConflictPolicy.KEEP_BOTH -> name = PathSafety.uniqueName(wanted) { dir.findFile(it) != null }
                ConflictPolicy.REPLACE -> if (!existing.delete()) throw IOException("cannot replace existing file")
            }
        }

        val mime = MimeTypes.fromName(name)
        val created = dir.createFile(mime, name) ?: throw IOException("cannot create file")
        try {
            val out = context.contentResolver.openOutputStream(created.uri, "w") ?: throw IOException("cannot open file")
            out.use { sink ->
                FileInputStream(staged).use { input -> input.copyTo(sink, COPY_BUFFER) }
                sink.flush()
            }
        } catch (e: Exception) {
            created.delete()
            throw if (e is IOException) e else IOException("cannot store file", e)
        }
        return saved(created, name, rel, entry, sha256)
    }

    private fun saved(doc: DocumentFile, requestedName: String, rel: String, entry: ManifestEntry, sha256: String): SavedFile {
        val finalName = doc.name ?: requestedName
        val dir = rel.substringBeforeLast('/', "")
        val mime = doc.type ?: MimeTypes.fromName(finalName)
        return SavedFile(
            uri = doc.uri.toString(),
            displayName = finalName,
            relativePath = if (dir.isEmpty()) finalName else "$dir/$finalName",
            size = entry.size,
            mimeType = mime,
            category = FileCategory.classify(finalName, mime),
            sha256 = sha256,
        )
    }

    private companion object {
        const val COPY_BUFFER = 256 * 1024
    }
}
