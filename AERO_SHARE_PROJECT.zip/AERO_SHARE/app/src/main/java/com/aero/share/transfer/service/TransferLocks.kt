package com.aero.share.transfer.service

import android.content.Context
import android.net.wifi.WifiManager
import android.os.Build
import android.os.PowerManager

/**
 * Keeps the CPU and the Wi-Fi radio awake while a transfer really runs and lets go as soon as nothing is active.
 * The wake lock has a hard timeout so a bug can never keep the phone awake forever. No battery-optimisation exemption is
 * ever requested.
 */
internal class TransferLocks(context: Context) {
    private val appContext = context.applicationContext
    private var wake: PowerManager.WakeLock? = null
    private var wifi: WifiManager.WifiLock? = null

    @Synchronized
    fun update(hold: Boolean, lowLatency: Boolean) {
        if (hold) acquire(lowLatency) else release()
    }

    @Synchronized
    fun release() {
        val wakeLock = wake
        if (wakeLock != null && wakeLock.isHeld) wakeLock.release()
        val wifiLock = wifi
        if (wifiLock != null && wifiLock.isHeld) wifiLock.release()
        // The Wi-Fi lock mode depends on the power mode at the time, so it is created again for the next transfer.
        wifi = null
    }

    private fun acquire(lowLatency: Boolean) {
        var wakeLock = wake
        if (wakeLock == null) {
            val manager = appContext.getSystemService(Context.POWER_SERVICE) as? PowerManager
            wakeLock = manager?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, WAKE_TAG)
            wakeLock?.setReferenceCounted(false)
            wake = wakeLock
        }
        if (wakeLock != null && !wakeLock.isHeld) wakeLock.acquire(MAX_HOLD_MS)

        var wifiLock = wifi
        if (wifiLock == null) {
            val manager = appContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            wifiLock = manager?.createWifiLock(wifiMode(lowLatency), WIFI_TAG)
            wifiLock?.setReferenceCounted(false)
            wifi = wifiLock
        }
        if (wifiLock != null && !wifiLock.isHeld) wifiLock.acquire()
    }

    @Suppress("DEPRECATION")
    private fun wifiMode(lowLatency: Boolean): Int =
        if (lowLatency && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            WifiManager.WIFI_MODE_FULL_LOW_LATENCY
        } else {
            WifiManager.WIFI_MODE_FULL
        }

    private companion object {
        const val WAKE_TAG = "AeroShare:transfer"
        const val WIFI_TAG = "AeroShare:transfer"
        const val MAX_HOLD_MS = 6L * 60L * 60L * 1000L
    }
}
