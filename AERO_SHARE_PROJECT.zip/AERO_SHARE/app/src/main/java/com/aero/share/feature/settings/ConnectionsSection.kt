package com.aero.share.feature.settings

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.QrCodeScanner
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aero.share.R
import com.aero.share.core.common.SystemIntents
import com.aero.share.core.common.labelRes
import com.aero.share.core.designsystem.AeroChoiceRow
import com.aero.share.core.designsystem.AeroDivider
import com.aero.share.core.designsystem.AeroGroup
import com.aero.share.core.designsystem.AeroSectionHeader
import com.aero.share.core.designsystem.AeroSettingsRow
import com.aero.share.core.designsystem.AeroSwitchRow
import com.aero.share.domain.AppSettings
import com.aero.share.domain.CapabilityState
import com.aero.share.domain.TransportCapability
import com.aero.share.navigation.AeroNavigator
import com.aero.share.navigation.SettingsSection

/**
 * How devices find and reach each other. Everything here changes what discovery and the transfer planner do, and the list
 * at the bottom shows what this device can really use right now.
 */
@Composable
internal fun ConnectionsSection(settings: AppSettings, viewModel: SettingsViewModel, navigator: AeroNavigator) {
    val capabilities by viewModel.capabilities.collectAsStateWithLifecycle()
    val wifiDirect = SettingsLogic.wifiDirectSupported(capabilities)
    val mode = SettingsLogic.effectiveTransportMode(settings.transportMode, wifiDirect)

    // The radios may have been switched in the system settings.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { viewModel.refreshCapabilities() }

    AeroGroup {
        AeroChoiceRow(
            title = stringResource(R.string.set_transport_title),
            subtitle = stringResource(R.string.set_transport_text),
            options = SettingsLogic.transportModes(wifiDirect).map { option -> option to stringResource(option.labelRes()) },
            selected = mode,
            onSelected = { option -> viewModel.update { current -> current.copy(transportMode = option) } },
        )
        AeroDivider()
        AeroSwitchRow(
            title = stringResource(R.string.set_lan_title),
            subtitle = stringResource(R.string.set_lan_text),
            checked = settings.lanDiscoveryEnabled,
            onCheckedChange = { on -> viewModel.update { current -> current.copy(lanDiscoveryEnabled = on) } },
        )
        if (wifiDirect) {
            AeroDivider()
            AeroSwitchRow(
                title = stringResource(R.string.set_wifidirect_title),
                subtitle = stringResource(R.string.set_wifidirect_text),
                checked = settings.wifiDirectEnabled,
                onCheckedChange = { on -> viewModel.update { current -> current.copy(wifiDirectEnabled = on) } },
            )
        }
        AeroDivider()
        VisibilityRow(settings = settings, viewModel = viewModel)
    }
    SettingsNote(text = stringResource(R.string.set_visibility_note))

    AeroSectionHeader(text = stringResource(R.string.set_connection_header))
    AeroGroup {
        AeroSwitchRow(
            title = stringResource(R.string.set_advanced_title),
            subtitle = stringResource(R.string.set_advanced_text),
            checked = settings.advancedConnectionEnabled,
            onCheckedChange = { on -> viewModel.update { current -> current.copy(advancedConnectionEnabled = on) } },
        )
        AeroDivider()
        AeroChoiceRow(
            title = stringResource(R.string.set_timeout_title),
            subtitle = stringResource(R.string.set_timeout_text),
            options = SettingsLogic.CONNECTION_TIMEOUTS.map { seconds -> seconds to secondsText(seconds) },
            selected = SettingsLogic.nearestInt(SettingsLogic.CONNECTION_TIMEOUTS, settings.connectionTimeoutSec),
            onSelected = { seconds -> viewModel.update { current -> current.copy(connectionTimeoutSec = seconds) } },
        )
    }

    AeroSectionHeader(text = stringResource(R.string.set_related_header))
    AeroGroup {
        AeroSettingsRow(
            title = stringResource(R.string.set_related_qr_title),
            subtitle = stringResource(R.string.set_related_qr_text),
            icon = Icons.Rounded.QrCodeScanner,
            onClick = { navigator.openSettingsSection(SettingsSection.SECURITY) },
        )
        AeroDivider()
        AeroSettingsRow(
            title = stringResource(R.string.set_related_trust_title),
            subtitle = stringResource(R.string.set_related_trust_text),
            icon = Icons.Rounded.VerifiedUser,
            onClick = { navigator.openSettingsSection(SettingsSection.SECURITY) },
        )
    }

    if (capabilities.isNotEmpty()) {
        AeroSectionHeader(text = stringResource(R.string.set_capabilities_title))
        AeroGroup { CapabilityRows(capabilities) }
    }
    SettingsNote(text = stringResource(R.string.set_bluetooth_note))
}

/** One row per way of connecting, with what is stopping it if it is not available; some rows open the right system page. */
@Composable
private fun CapabilityRows(capabilities: List<TransportCapability>) {
    val context = LocalContext.current
    val openWifi: () -> Unit = { SystemIntents.openWifiSettings(context) }
    val openApp: () -> Unit = { SystemIntents.openAppSettings(context) }
    SettingsLogic.orderedTransports(capabilities).forEachIndexed { index, capability ->
        if (index > 0) AeroDivider()
        val action: (() -> Unit)? = when (capability.state) {
            CapabilityState.RADIO_OFF -> openWifi
            CapabilityState.PERMISSION_MISSING -> openApp
            else -> null
        }
        AeroSettingsRow(
            title = stringResource(capability.kind.labelRes()),
            subtitle = stringResource(capability.state.labelRes()),
            icon = if (capability.state == CapabilityState.AVAILABLE) Icons.Rounded.Check else Icons.Rounded.Warning,
            onClick = action,
        )
    }
}
