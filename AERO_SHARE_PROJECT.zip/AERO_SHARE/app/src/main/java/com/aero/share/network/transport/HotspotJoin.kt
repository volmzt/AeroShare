package com.aero.share.network.transport

import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiNetworkSpecifier
import android.os.Build
import androidx.annotation.RequiresApi
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Joins a hotspot shown in a pairing QR code (WifiNetworkSpecifier, Android 10+). The system asks its user to confirm;
 * the connection is private to this app, exists only while the callback is registered and has no internet access.
 * Android below 10 has no such API: the caller reports [PlanDetail.HOTSPOT_MANUAL_JOIN] and the UI tells the user to
 * join the Wi-Fi network by hand. Phones without a second Wi-Fi station may drop their normal Wi-Fi meanwhile.
 */
@RequiresApi(Build.VERSION_CODES.Q)
internal class HotspotJoin(
    private val connectivity: ConnectivityManager,
    private val log: (String) -> Unit,
) {
    class Joined(val network: Network, val release: () -> Unit)

    /** Null when the user declined, the network was not found or the request timed out. */
    suspend fun join(ssid: String, passphrase: String, timeoutMs: Int): Joined? {
        val specifier = try {
            WifiNetworkSpecifier.Builder().setSsid(ssid).setWpa2Passphrase(passphrase).build()
        } catch (e: IllegalArgumentException) {
            log("the hotspot name or passphrase was rejected")
            return null
        }
        val request = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .setNetworkSpecifier(specifier)
            .build()
        val result = CompletableDeferred<Network?>()
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                result.complete(network)
            }

            override fun onUnavailable() {
                result.complete(null)
            }
        }
        var joined = false
        try {
            try {
                connectivity.requestNetwork(request, callback, timeoutMs)
            } catch (e: RuntimeException) {
                log("joining the hotspot threw " + e.javaClass.simpleName)
                return null
            }
            val network = withTimeoutOrNull(timeoutMs + GRACE_MS) { result.await() } ?: return null
            joined = true
            return Joined(network) { unregister(callback) }
        } finally {
            if (!joined) unregister(callback)
        }
    }

    private fun unregister(callback: ConnectivityManager.NetworkCallback) {
        try {
            connectivity.unregisterNetworkCallback(callback)
        } catch (e: IllegalArgumentException) {
            // already unregistered
        }
    }

    private companion object {
        const val GRACE_MS = 2_000L
    }
}
