package com.aero.share.core.storage.apk

import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow

/**
 * Process-wide bus for the results of the system installer. [InstallResultReceiver] and [ApkInstallerImpl] publish here;
 * the UI collects [flow] from a scope that outlives the screen (a ViewModel), because the system installer window is
 * shown on top of the app and the screen may be stopped while the result arrives.
 */
object InstallEvents {
    private val bus = MutableSharedFlow<InstallEvent>(
        replay = 0,
        extraBufferCapacity = 16,
        onBufferOverflow = BufferOverflow.DROP_OLDEST,
    )

    val flow: SharedFlow<InstallEvent> = bus.asSharedFlow()

    fun emit(event: InstallEvent) {
        bus.tryEmit(event)
    }
}
