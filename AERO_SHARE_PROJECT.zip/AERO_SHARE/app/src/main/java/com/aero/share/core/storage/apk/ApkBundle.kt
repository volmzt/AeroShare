package com.aero.share.core.storage.apk

import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * The AERO split-APK bundle (`.aeroapks`): a plain ZIP written without compression. Entry order is fixed:
 * `aero-app.json`, `base.apk`, then the `split_*.apk` files. Format description: docs/APK_BUNDLE_FORMAT.md.
 * Pure Java I/O (no Android types), so it is unit tested on the JVM.
 */
object ApkBundle {
    const val EXTENSION = "aeroapks"
    const val MANIFEST_ENTRY = "aero-app.json"
    const val BASE_ENTRY = "base.apk"
    const val MAX_SPLITS = 128
    const val MAX_MANIFEST_BYTES = 64 * 1024
    private const val BUFFER = 128 * 1024
    private const val ABI_PREFIX = "split_config."
    private const val APK_SUFFIX = ".apk"

    private val splitEntry = Regex("split_[A-Za-z0-9._-]{1,100}\\.apk")

    private val abiNames = mapOf(
        "arm64_v8a" to "arm64-v8a",
        "armeabi_v7a" to "armeabi-v7a",
        "armeabi" to "armeabi",
        "x86_64" to "x86_64",
        "x86" to "x86",
        "mips64" to "mips64",
        "mips" to "mips",
        "riscv64" to "riscv64",
    )

    fun isBundleName(fileName: String): Boolean = fileName.endsWith(".$EXTENSION", ignoreCase = true)

    /** Entry names that may be written into an install session. They are never used as file paths. */
    fun isApkEntry(name: String): Boolean = name == BASE_ENTRY || splitEntry.matches(name)

    /** The ABI a split such as `split_config.arm64_v8a.apk` is for, or null (density, language and feature splits). */
    fun abiOf(entryName: String): String? {
        if (entryName.length < ABI_PREFIX.length + APK_SUFFIX.length) return null
        if (!entryName.startsWith(ABI_PREFIX) || !entryName.endsWith(APK_SUFFIX)) return null
        return abiNames[entryName.substring(ABI_PREFIX.length, entryName.length - APK_SUFFIX.length)]
    }

    /** Calls [action] for the manifest and for every valid APK entry, in file order. Everything else is skipped. */
    inline fun forEachEntry(zip: ZipInputStream, action: (name: String) -> Unit) {
        while (true) {
            val entry = zip.nextEntry ?: break
            val name = entry.name
            if (!entry.isDirectory && (name == MANIFEST_ENTRY || isApkEntry(name))) action(name)
            zip.closeEntry()
        }
    }

    /**
     * Writes the bundle to [target]. [splits] are (entry name, file) pairs whose names pass [isApkEntry], are not
     * `base.apk` and are unique. A partly written target is deleted when writing fails.
     */
    fun build(target: File, manifestJson: String, base: File, splits: List<Pair<String, File>>) {
        require(splits.size <= MAX_SPLITS) { "too many splits" }
        require(splits.all { isApkEntry(it.first) && it.first != BASE_ENTRY }) { "bad split name" }
        require(splits.map { it.first }.toSet().size == splits.size) { "duplicate split name" }
        target.parentFile?.mkdirs()
        try {
            ZipOutputStream(target.outputStream().buffered(BUFFER)).use { zip ->
                zip.setLevel(Deflater.NO_COMPRESSION)
                zip.putNextEntry(ZipEntry(MANIFEST_ENTRY))
                zip.write(manifestJson.toByteArray(Charsets.UTF_8))
                zip.closeEntry()
                writeEntry(zip, BASE_ENTRY, base)
                for ((name, file) in splits) writeEntry(zip, name, file)
            }
        } catch (e: IOException) {
            target.delete()
            throw e
        }
    }

    private fun writeEntry(zip: ZipOutputStream, name: String, file: File) {
        zip.putNextEntry(ZipEntry(name))
        FileInputStream(file).use { it.copyTo(zip, BUFFER) }
        zip.closeEntry()
    }
}
