package com.aero.share.feature.settings

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.res.stringResource
import com.aero.share.R
import com.aero.share.core.designsystem.AeroChoiceRow
import com.aero.share.core.designsystem.AeroDialog
import com.aero.share.core.designsystem.AeroSwitchRow
import com.aero.share.domain.AppSettings
import com.aero.share.domain.ThemeMode
import com.aero.share.domain.Visibility

// Rows that more than one settings page offers. Each page shows the same stored value, so changing it in one place is
// seen in the other.

/** Follow the system, dark or light. */
@Composable
internal fun ThemeRow(settings: AppSettings, viewModel: SettingsViewModel) {
    AeroChoiceRow(
        title = stringResource(R.string.set_theme_title),
        options = listOf(
            ThemeMode.SYSTEM to stringResource(R.string.common_theme_system),
            ThemeMode.DARK to stringResource(R.string.common_theme_dark),
            ThemeMode.LIGHT to stringResource(R.string.common_theme_light),
        ),
        selected = settings.themeMode,
        onSelected = { mode -> viewModel.update { current -> current.copy(themeMode = mode) } },
    )
}

/** Whether this device announces itself to nearby devices. Hidden is not a security boundary, and the pages say so. */
@Composable
internal fun VisibilityRow(settings: AppSettings, viewModel: SettingsViewModel) {
    AeroSwitchRow(
        title = stringResource(R.string.set_visibility_title),
        subtitle = stringResource(R.string.set_visibility_text),
        checked = settings.visibility == Visibility.VISIBLE,
        onCheckedChange = { visible ->
            viewModel.update { current ->
                current.copy(visibility = if (visible) Visibility.VISIBLE else Visibility.HIDDEN)
            }
        },
    )
}

/** Automatic acceptance from trusted devices. Turning it on asks first, because it lowers the protection explicit approval gives. */
@Composable
internal fun AutoAcceptRow(settings: AppSettings, viewModel: SettingsViewModel) {
    var confirm by rememberSaveable { mutableStateOf(false) }
    AeroSwitchRow(
        title = stringResource(R.string.set_auto_title),
        subtitle = stringResource(R.string.set_auto_text),
        checked = settings.autoAcceptTrusted,
        onCheckedChange = { on ->
            if (on) {
                confirm = true
            } else {
                viewModel.update { current -> current.copy(autoAcceptTrusted = false) }
            }
        },
    )
    if (confirm) {
        AeroDialog(
            title = stringResource(R.string.set_auto_confirm_title),
            message = stringResource(R.string.set_auto_confirm_message),
            confirmText = stringResource(R.string.set_auto_confirm),
            dismissText = stringResource(R.string.common_cancel),
            danger = true,
            onConfirm = {
                confirm = false
                viewModel.update { current -> current.copy(autoAcceptTrusted = true) }
            },
            onDismiss = { confirm = false },
        )
    }
}
