package com.aero.share.feature.transfer

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.aero.share.R
import com.aero.share.core.common.Formatters
import com.aero.share.core.common.hintRes
import com.aero.share.core.common.labelRes
import com.aero.share.core.common.messageRes
import com.aero.share.core.designsystem.AeroCard
import com.aero.share.core.designsystem.AeroDeviceIcon
import com.aero.share.core.designsystem.AeroIcon
import com.aero.share.core.designsystem.AeroProgressBar
import com.aero.share.core.designsystem.AeroText
import com.aero.share.core.designsystem.AeroTheme
import com.aero.share.feature.receive.IncomingLogic
import com.aero.share.feature.send.metaLine
import com.aero.share.transfer.model.DeviceKind
import com.aero.share.transfer.model.TransferDirection
import com.aero.share.transfer.model.TransferSnapshot
import com.aero.share.transfer.model.TransferState

/** The name to show for the other device: what the coordinator resolved, then what the peer announced. */
@Composable
internal fun peerDisplayName(snapshot: TransferSnapshot): String {
    val fallback = stringResource(R.string.common_unknown_device)
    return snapshot.peerName.ifBlank { snapshot.peer?.name.orEmpty() }.ifBlank { fallback }
}

@Composable
private fun headlineText(headline: Headline, name: String): String = when (headline) {
    Headline.SENDING -> stringResource(R.string.xfer_head_sending, name)
    Headline.RECEIVING -> stringResource(R.string.xfer_head_receiving, name)
    Headline.SENT -> stringResource(R.string.xfer_head_sent, name)
    Headline.RECEIVED -> stringResource(R.string.xfer_head_received, name)
    Headline.SEND_FAILED -> stringResource(R.string.xfer_head_send_failed, name)
    Headline.RECEIVE_FAILED -> stringResource(R.string.xfer_head_receive_failed, name)
    Headline.CANCELLED -> stringResource(R.string.xfer_head_cancelled, name)
}

/** Who it is with, what is happening (in the right direction and tense) and the exact state. */
@Composable
internal fun TransferHero(snapshot: TransferSnapshot) {
    val colors = AeroTheme.colors
    val name = peerDisplayName(snapshot)
    val headline = TransferLogic.headline(snapshot.direction, snapshot.state)
    val stateColor = when (snapshot.state) {
        TransferState.COMPLETED -> colors.success
        TransferState.FAILED -> colors.danger
        TransferState.CANCELLED,
        TransferState.INTERRUPTED,
        TransferState.PAUSED,
        -> colors.warning
        TransferState.WAITING,
        TransferState.PREPARING,
        TransferState.CONNECTING,
        TransferState.AWAITING_ACCEPTANCE,
        TransferState.TRANSFERRING,
        TransferState.VERIFYING,
        -> colors.textSecondary
    }
    AeroCard(elevated = true) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(RoundedCornerShape(AeroTheme.dimens.radiusSmall))
                    .background(colors.accentContainer),
                contentAlignment = Alignment.Center,
            ) {
                when (snapshot.state) {
                    TransferState.COMPLETED -> AeroIcon(Icons.Rounded.Check, contentDescription = null, tint = colors.success, size = 30.dp)
                    TransferState.FAILED -> AeroIcon(Icons.Rounded.Warning, contentDescription = null, tint = colors.danger, size = 30.dp)
                    TransferState.CANCELLED -> AeroIcon(Icons.Rounded.Close, contentDescription = null, tint = colors.warning, size = 30.dp)
                    else -> AeroDeviceIcon(kind = snapshot.peer?.kind ?: DeviceKind.OTHER)
                }
            }
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                AeroText(text = headlineText(headline, name), style = AeroTheme.typography.titleSmall, maxLines = 3)
                AeroText(text = stringResource(snapshot.state.labelRes()), color = stateColor)
            }
        }
        val title = snapshot.title
        if (!title.isNullOrBlank()) {
            Spacer(Modifier.height(10.dp))
            AeroText(text = title, style = AeroTheme.typography.caption, color = colors.textSecondary, maxLines = 2)
        }
        if (snapshot.state == TransferState.PAUSED && snapshot.pausedByPeer) {
            Spacer(Modifier.height(10.dp))
            AeroText(text = stringResource(R.string.xfer_paused_by_peer), color = colors.warning)
        }
    }
}

@Composable
private fun etaText(eta: Eta): String? = when (eta.kind) {
    EtaKind.HIDDEN -> null
    EtaKind.LESS_THAN_MINUTE -> stringResource(R.string.xfer_eta_less_than_minute)
    EtaKind.MINUTES -> pluralStringResource(R.plurals.xfer_eta_minutes, eta.value, eta.value)
    EtaKind.HOURS -> pluralStringResource(R.plurals.xfer_eta_hours, eta.value, eta.value)
}

/**
 * The bar and the numbers behind it. Only real values are shown: no bar while nothing has been sent, no speed while the
 * transfer is paused, and the time left only as a rounded estimate.
 */
@Composable
internal fun TransferProgressCard(snapshot: TransferSnapshot) {
    val style = TransferLogic.progressStyle(snapshot.state, snapshot.transferredBytes)
    if (style == ProgressStyle.NONE) return
    val colors = AeroTheme.colors
    AeroCard {
        AeroProgressBar(progress = snapshot.fraction, indeterminate = style == ProgressStyle.INDETERMINATE)
        if (style == ProgressStyle.DETERMINATE) {
            Spacer(Modifier.height(10.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                AeroText(
                    text = stringResource(
                        R.string.xfer_progress_bytes,
                        Formatters.bytes(snapshot.transferredBytes),
                        Formatters.bytes(snapshot.totalBytes),
                    ),
                    style = AeroTheme.typography.bodyStrong,
                )
                AeroText(text = Formatters.percent(snapshot.fraction), style = AeroTheme.typography.bodyStrong, color = colors.accentText)
            }
        }
        if (TransferLogic.showsLiveDetails(snapshot.state)) {
            val fileName = snapshot.currentFileName
            if (!fileName.isNullOrBlank()) {
                Spacer(Modifier.height(10.dp))
                AeroText(text = fileName, maxLines = 1)
            }
            val number = TransferLogic.fileNumber(snapshot.currentFileIndex, snapshot.totalFiles)
            val eta = TransferLogic.eta(snapshot.state, snapshot.etaMillis, snapshot.bytesPerSecond)
            val details = metaLine(
                listOf(
                    if (number != null) stringResource(R.string.xfer_file_of, number, snapshot.totalFiles) else "",
                    if (TransferLogic.showsSpeed(snapshot.state, snapshot.bytesPerSecond)) Formatters.speed(snapshot.bytesPerSecond) else "",
                    etaText(eta).orEmpty(),
                ),
            )
            if (details.isNotEmpty()) {
                AeroText(text = details, style = AeroTheme.typography.caption, color = colors.textSecondary)
            }
            if (snapshot.elapsedMillis > 0L) {
                AeroText(
                    text = stringResource(R.string.xfer_elapsed, Formatters.duration(snapshot.elapsedMillis)),
                    style = AeroTheme.typography.caption,
                    color = colors.textSecondary,
                )
            }
        }
    }
}

/** While the other device has not answered: the code both screens show, so the person can check who is on the other end. */
@Composable
internal fun SenderCodeCard(code: String) {
    val colors = AeroTheme.colors
    AeroCard {
        Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            AeroText(text = stringResource(R.string.xfer_code_title), style = AeroTheme.typography.caption, color = colors.textSecondary)
            AeroText(
                text = IncomingLogic.groupCode(code),
                style = AeroTheme.typography.display,
                color = colors.accentText,
                maxLines = 1,
                textAlign = TextAlign.Center,
            )
            AeroText(
                text = stringResource(R.string.xfer_code_text),
                style = AeroTheme.typography.caption,
                color = colors.textSecondary,
                textAlign = TextAlign.Center,
            )
        }
    }
}

/** How it travels: the connection that was used, and what is known about the data. */
@Composable
internal fun TransferDetailsCard(snapshot: TransferSnapshot) {
    val colors = AeroTheme.colors
    val transport = snapshot.transport
    AeroCard {
        if (transport != null) {
            DetailLine(label = stringResource(R.string.xfer_detail_connection), value = stringResource(transport.labelRes()))
        }
        DetailLine(
            label = stringResource(R.string.xfer_detail_files),
            value = pluralStringResource(R.plurals.xfer_files_progress, snapshot.totalFiles, snapshot.completedFiles, snapshot.totalFiles),
        )
        DetailLine(label = stringResource(R.string.xfer_detail_size), value = Formatters.bytes(snapshot.totalBytes))
        if (snapshot.compressed) {
            DetailLine(label = stringResource(R.string.xfer_detail_compression), value = stringResource(R.string.xfer_detail_compression_value))
        }
        DetailLine(label = stringResource(R.string.xfer_detail_security), value = stringResource(R.string.xfer_detail_security_value))
        if (snapshot.state.isTerminal && snapshot.elapsedMillis > 0L) {
            DetailLine(label = stringResource(R.string.xfer_detail_duration), value = Formatters.duration(snapshot.elapsedMillis))
        }
        if (snapshot.state == TransferState.INTERRUPTED && snapshot.resumable) {
            Spacer(Modifier.height(6.dp))
            AeroText(text = stringResource(R.string.xfer_resumable_note), style = AeroTheme.typography.caption, color = colors.textSecondary)
        }
    }
}

@Composable
private fun DetailLine(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Top,
    ) {
        AeroText(text = label, color = AeroTheme.colors.textSecondary, modifier = Modifier.weight(1f))
        Spacer(Modifier.width(12.dp))
        AeroText(text = value, modifier = Modifier.weight(1.4f), textAlign = TextAlign.End)
    }
}

/** What went wrong in plain words, and what can be done about it. */
@Composable
internal fun FailureCard(snapshot: TransferSnapshot) {
    val colors = AeroTheme.colors
    val failure = snapshot.failure ?: return
    AeroCard {
        Row(verticalAlignment = Alignment.Top) {
            AeroIcon(Icons.Rounded.Warning, contentDescription = null, tint = colors.danger, modifier = Modifier.padding(top = 2.dp))
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                AeroText(text = stringResource(failure.messageRes()), style = AeroTheme.typography.bodyStrong)
                Spacer(Modifier.height(4.dp))
                AeroText(text = stringResource(failure.hintRes()), color = colors.textSecondary)
                if (snapshot.direction == TransferDirection.RECEIVE && snapshot.state == TransferState.FAILED) {
                    Spacer(Modifier.height(8.dp))
                    AeroText(
                        text = stringResource(R.string.xfer_receive_retry_hint),
                        style = AeroTheme.typography.caption,
                        color = colors.textSecondary,
                    )
                }
            }
        }
    }
}
