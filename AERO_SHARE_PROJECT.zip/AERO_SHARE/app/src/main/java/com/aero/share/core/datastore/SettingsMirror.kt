package com.aero.share.core.datastore

import android.content.Context

/**
 * Tiny synchronous copy of the two settings that must be known before DataStore can be read (the language is
 * needed in `attachBaseContext`). Written on every settings change by [DataStoreSettingsRepository].
 */
object SettingsMirror {
    private const val FILE = "aero_mirror"
    private const val KEY_LANGUAGE = "language"
    private const val KEY_THEME = "theme"

    /** BCP-47 tag chosen by the user, or null when the system language is used. */
    fun language(context: Context): String? =
        try {
            context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString(KEY_LANGUAGE, null)?.takeIf { it.isNotEmpty() }
        } catch (e: RuntimeException) {
            null
        }

    fun theme(context: Context): String? =
        try {
            context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString(KEY_THEME, null)?.takeIf { it.isNotEmpty() }
        } catch (e: RuntimeException) {
            null
        }

    fun write(context: Context, languageTag: String?, theme: String) {
        try {
            context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
                .putString(KEY_LANGUAGE, languageTag.orEmpty())
                .putString(KEY_THEME, theme)
                .commit()
        } catch (e: RuntimeException) {
            // The mirror is only an optimisation for early start-up; DataStore stays the source of truth.
        }
    }
}
