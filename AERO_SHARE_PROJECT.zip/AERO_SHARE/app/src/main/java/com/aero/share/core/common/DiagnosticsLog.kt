package com.aero.share.core.common

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class DiagnosticEntry(val timestamp: Long, val category: String, val message: String)

/**
 * In-memory ring buffer of recent NON-SENSITIVE events and errors for the diagnostics page and exported reports.
 * Callers must never add file names, tokens, keys, IP addresses of other people or file contents.
 */
class DiagnosticsLog(private val capacity: Int = 200, private val clock: () -> Long = { System.currentTimeMillis() }) {
    private val _entries = MutableStateFlow<List<DiagnosticEntry>>(emptyList())
    val entries: StateFlow<List<DiagnosticEntry>> get() = _entries.asStateFlow()

    fun add(category: String, message: String) {
        val entry = DiagnosticEntry(clock(), category.take(24), message.take(300))
        _entries.update { (it + entry).takeLast(capacity) }
    }

    fun clear() {
        _entries.value = emptyList()
    }
}
