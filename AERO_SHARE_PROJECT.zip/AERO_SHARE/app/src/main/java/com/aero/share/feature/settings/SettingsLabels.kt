package com.aero.share.feature.settings

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Extension
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.SwapVert
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.WifiTethering
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import com.aero.share.R
import com.aero.share.core.common.Formatters
import com.aero.share.domain.AccentColor
import com.aero.share.domain.CapabilityState
import com.aero.share.domain.PowerMode
import com.aero.share.domain.TransportMode
import com.aero.share.navigation.SettingsSection
import com.aero.share.transfer.model.CompressionMode
import com.aero.share.transfer.model.ConflictPolicy

internal fun SettingsSection.titleRes(): Int = when (this) {
    SettingsSection.GENERAL -> R.string.set_general_title
    SettingsSection.CONNECTIONS -> R.string.set_connections_title
    SettingsSection.TRANSFERS -> R.string.set_transfers_title
    SettingsSection.POWER -> R.string.set_power_title
    SettingsSection.CUSTOMIZATION -> R.string.set_custom_title
    SettingsSection.SECURITY -> R.string.set_security_title
    SettingsSection.PLUGINS -> R.string.set_plugins_title
}

internal fun SettingsSection.summaryRes(): Int = when (this) {
    SettingsSection.GENERAL -> R.string.set_general_summary
    SettingsSection.CONNECTIONS -> R.string.set_connections_summary
    SettingsSection.TRANSFERS -> R.string.set_transfers_summary
    SettingsSection.POWER -> R.string.set_power_summary
    SettingsSection.CUSTOMIZATION -> R.string.set_custom_summary
    SettingsSection.SECURITY -> R.string.set_security_summary
    SettingsSection.PLUGINS -> R.string.set_plugins_summary
}

internal fun SettingsSection.icon(): ImageVector = when (this) {
    SettingsSection.GENERAL -> Icons.Rounded.Tune
    SettingsSection.CONNECTIONS -> Icons.Rounded.WifiTethering
    SettingsSection.TRANSFERS -> Icons.Rounded.SwapVert
    SettingsSection.POWER -> Icons.Rounded.Speed
    SettingsSection.CUSTOMIZATION -> Icons.Rounded.Palette
    SettingsSection.SECURITY -> Icons.Rounded.Shield
    SettingsSection.PLUGINS -> Icons.Rounded.Extension
}

internal fun TransportMode.labelRes(): Int = when (this) {
    TransportMode.AUTO -> R.string.set_mode_auto
    TransportMode.LAN_ONLY -> R.string.set_mode_lan
    TransportMode.WIFI_DIRECT_PREFERRED -> R.string.set_mode_direct
}

internal fun CompressionMode.labelRes(): Int = when (this) {
    CompressionMode.OFF -> R.string.set_compression_off
    CompressionMode.SMART -> R.string.set_compression_smart
}

internal fun ConflictPolicy.labelRes(): Int = when (this) {
    ConflictPolicy.KEEP_BOTH -> R.string.set_conflict_keep
    ConflictPolicy.REPLACE -> R.string.set_conflict_replace
    ConflictPolicy.SKIP -> R.string.set_conflict_skip
}

internal fun AccentColor.labelRes(): Int = when (this) {
    AccentColor.ORANGE -> R.string.set_accent_orange
    AccentColor.BLUE -> R.string.set_accent_blue
    AccentColor.GREEN -> R.string.set_accent_green
    AccentColor.PURPLE -> R.string.set_accent_purple
    AccentColor.PINK -> R.string.set_accent_pink
    AccentColor.TEAL -> R.string.set_accent_teal
}

internal fun CapabilityState.labelRes(): Int = when (this) {
    CapabilityState.AVAILABLE -> R.string.set_cap_available
    CapabilityState.RADIO_OFF -> R.string.set_cap_radio_off
    CapabilityState.PERMISSION_MISSING -> R.string.set_cap_permission
    CapabilityState.UNSUPPORTED -> R.string.set_cap_unsupported
    CapabilityState.NO_NETWORK -> R.string.set_cap_no_network
}

internal fun PowerMode.titleRes(): Int = when (this) {
    PowerMode.BALANCED -> R.string.set_power_balanced
    PowerMode.PERFORMANCE -> R.string.set_power_performance
    PowerMode.ENERGY_SAVING -> R.string.set_power_saving
}

internal fun PowerMode.descriptionRes(): Int = when (this) {
    PowerMode.BALANCED -> R.string.set_power_balanced_text
    PowerMode.PERFORMANCE -> R.string.set_power_performance_text
    PowerMode.ENERGY_SAVING -> R.string.set_power_saving_text
}

/** "10 seconds", "1 minute", "5 minutes": whole minutes are shown as minutes. */
@Composable
internal fun secondsText(seconds: Int): String =
    if (seconds >= 60 && seconds % 60 == 0) {
        pluralStringResource(R.plurals.set_minutes, seconds / 60, seconds / 60)
    } else {
        pluralStringResource(R.plurals.set_seconds, seconds, seconds)
    }

@Composable
internal fun daysText(days: Int): String = pluralStringResource(R.plurals.set_days, days, days)

/** The size above which sending asks first; 0 is "never ask". */
@Composable
internal fun warnBytesText(bytes: Long): String =
    if (bytes <= 0L) stringResource(R.string.set_warn_never) else Formatters.bytes(bytes)

/** Days of history to keep; 0 is "keep everything". */
@Composable
internal fun historyDaysText(days: Int): String =
    if (days <= 0) stringResource(R.string.set_history_forever) else daysText(days)
