package com.aero.share.network.transport

import com.aero.share.domain.LinkQuality
import com.aero.share.domain.NearbyDevice
import com.aero.share.network.discovery.Beacon
import com.aero.share.transfer.model.TransportKind

/**
 * AERO SHARE devices found through Wi-Fi Direct service discovery, keyed by their p2p MAC address. Not thread-safe:
 * the owner serializes access. Entries expire when their advertisement is not seen again within the TTL; nothing is
 * invented, so link quality always stays UNKNOWN (there is no cheap, honest measurement before a group exists).
 */
internal class P2pPeerTable(private val selfId: () -> String) {
    private class Entry(val mac: String, var presence: Beacon.Presence, var lastSeen: Long, var shownSeen: Long)

    private val entries = LinkedHashMap<String, Entry>()

    /** Records an advertisement seen at [now] (monotonic milliseconds). Returns true when the visible list changed. */
    fun onService(mac: String, presence: Beacon.Presence, now: Long): Boolean {
        val key = normalizeMac(mac) ?: return false
        if (presence.goodbye) return remove(key)
        if (presence.deviceId == selfId()) return false
        val existing = entries[key]
        if (existing == null) {
            entries[key] = Entry(key, presence, now, now)
            return true
        }
        val changed = existing.presence != presence
        existing.presence = presence
        existing.lastSeen = now
        val refreshShown = now - existing.shownSeen >= SEEN_STEP_MS
        if (refreshShown) existing.shownSeen = now
        return changed || refreshShown
    }

    fun remove(mac: String): Boolean {
        val key = normalizeMac(mac) ?: return false
        return entries.remove(key) != null
    }

    /** Drops entries not seen for more than [ttlMs]. Returns true when something was removed. */
    fun expire(now: Long, ttlMs: Long): Boolean {
        var changed = false
        val iterator = entries.values.iterator()
        while (iterator.hasNext()) {
            if (now - iterator.next().lastSeen > ttlMs) {
                iterator.remove()
                changed = true
            }
        }
        return changed
    }

    fun clear(): Boolean {
        if (entries.isEmpty()) return false
        entries.clear()
        return true
    }

    val size: Int get() = entries.size

    /** Sorted by name; when one device shows up under two addresses, the most recently seen entry wins. */
    fun snapshot(): List<NearbyDevice> {
        val byId = LinkedHashMap<String, Entry>()
        for (entry in entries.values) {
            val id = entry.presence.deviceId
            val other = byId[id]
            if (other == null || entry.lastSeen > other.lastSeen) byId[id] = entry
        }
        val out = ArrayList<NearbyDevice>(byId.size)
        for (entry in byId.values) {
            val presence = entry.presence
            out.add(
                NearbyDevice(
                    deviceId = presence.deviceId,
                    name = presence.name.ifBlank { presence.deviceId.take(FALLBACK_NAME_LENGTH) },
                    kind = presence.kind,
                    fingerprint = presence.fingerprint,
                    appVersion = presence.appVersion.takeIf { it.isNotEmpty() },
                    addresses = emptyList(),
                    port = presence.port,
                    transports = setOf(TransportKind.WIFI_DIRECT),
                    quality = LinkQuality.UNKNOWN,
                    lastSeenElapsed = entry.shownSeen,
                    p2pAddress = entry.mac,
                    capabilities = presence.capabilities,
                ),
            )
        }
        out.sortWith(compareBy<NearbyDevice> { it.name.lowercase() }.thenBy { it.deviceId })
        return out
    }

    companion object {
        const val SEEN_STEP_MS = 15_000L
        const val FALLBACK_NAME_LENGTH = 6
        private val MAC = Regex("^[0-9a-f]{2}(:[0-9a-f]{2}){5}$")

        /** Lower-case "aa:bb:cc:dd:ee:ff", or null when [raw] is not a MAC address. */
        fun normalizeMac(raw: String): String? {
            val value = raw.trim().lowercase()
            return if (MAC.matches(value)) value else null
        }
    }
}
