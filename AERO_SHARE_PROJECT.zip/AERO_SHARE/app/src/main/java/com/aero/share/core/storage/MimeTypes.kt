package com.aero.share.core.storage

import android.webkit.MimeTypeMap
import java.util.Locale

/** MIME type derived from the file extension; used when a backend needs a type that is consistent with the file name. */
internal object MimeTypes {
    const val OCTET_STREAM = "application/octet-stream"

    fun fromName(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
        if (ext.isEmpty()) return OCTET_STREAM
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: OCTET_STREAM
    }
}
