package com.aero.share.core.storage

import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Environment
import com.aero.share.core.permissions.Permissions
import com.aero.share.transfer.model.ConflictPolicy
import com.aero.share.transfer.storage.FileIncomingStorage
import com.aero.share.transfer.storage.IncomingStorage
import java.io.File

/**
 * Android 8-9 (API 26-28): plain files. With WRITE_EXTERNAL_STORAGE the public `Download/AERO SHARE` folder is used (and
 * announced to the media scanner); without it the app-specific external folder, which needs no permission.
 */
object LegacyIncomingStorage {
    fun hasPublicAccess(context: Context): Boolean = Permissions.allGranted(context, Permissions.legacyWrite()) &&
        Environment.getExternalStorageState() == Environment.MEDIA_MOUNTED

    fun create(context: Context, partsDir: File, policy: ConflictPolicy): IncomingStorage {
        val appContext = context.applicationContext
        @Suppress("DEPRECATION") // getExternalStoragePublicDirectory is the only public-Downloads API before Android 10
        val publicDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "AERO SHARE")
        val usePublic = hasPublicAccess(appContext)
        val dir = if (usePublic) publicDir else File(appContext.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: appContext.filesDir, "AERO SHARE")
        return FileIncomingStorage(
            destinationDir = dir,
            partsDir = partsDir,
            conflictPolicy = policy,
            label = label(appContext, usePublic),
            uriOf = { file ->
                if (usePublic) MediaScannerConnection.scanFile(appContext, arrayOf(file.path), null, null)
                Uri.fromFile(file).toString()
            },
        )
    }

    fun label(context: Context, publicAccess: Boolean): String =
        if (publicAccess) "Download/AERO SHARE" else "Android/data/${context.packageName}/files/Download/AERO SHARE"
}
