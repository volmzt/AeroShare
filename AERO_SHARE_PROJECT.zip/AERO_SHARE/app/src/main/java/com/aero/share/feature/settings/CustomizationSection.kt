package com.aero.share.feature.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.aero.share.R
import com.aero.share.core.designsystem.AeroDivider
import com.aero.share.core.designsystem.AeroGroup
import com.aero.share.core.designsystem.AeroIcon
import com.aero.share.core.designsystem.AeroSectionHeader
import com.aero.share.core.designsystem.AeroSwitchRow
import com.aero.share.core.designsystem.AeroText
import com.aero.share.core.designsystem.AeroTheme
import com.aero.share.core.designsystem.LocalFeedback
import com.aero.share.domain.AccentColor
import com.aero.share.domain.AppSettings

/** Theme, accent colour, motion, feedback and density. These are read by the design system, so they change the app at once. */
@Composable
internal fun CustomizationSection(settings: AppSettings, viewModel: SettingsViewModel) {
    AeroGroup {
        ThemeRow(settings = settings, viewModel = viewModel)
        AeroDivider()
        AccentPicker(
            selected = settings.accent,
            onSelected = { accent -> viewModel.update { current -> current.copy(accent = accent) } },
        )
    }

    AeroSectionHeader(text = stringResource(R.string.set_look_header))
    AeroGroup {
        AeroSwitchRow(
            title = stringResource(R.string.set_glass_title),
            subtitle = stringResource(R.string.set_glass_text),
            checked = settings.glassEffects,
            onCheckedChange = { on -> viewModel.update { current -> current.copy(glassEffects = on) } },
        )
        AeroDivider()
        AeroSwitchRow(
            title = stringResource(R.string.set_compact_title),
            subtitle = stringResource(R.string.set_compact_text),
            checked = settings.compactLists,
            onCheckedChange = { on -> viewModel.update { current -> current.copy(compactLists = on) } },
        )
    }

    AeroSectionHeader(text = stringResource(R.string.set_motion_header))
    AeroGroup {
        AeroSwitchRow(
            title = stringResource(R.string.set_animations_title),
            subtitle = stringResource(R.string.set_animations_text),
            checked = settings.animationsEnabled,
            onCheckedChange = { on -> viewModel.update { current -> current.copy(animationsEnabled = on) } },
        )
        AeroDivider()
        AeroSwitchRow(
            title = stringResource(R.string.set_reduced_title),
            subtitle = stringResource(R.string.set_reduced_text),
            checked = settings.reducedMotion,
            onCheckedChange = { on -> viewModel.update { current -> current.copy(reducedMotion = on) } },
        )
        AeroDivider()
        AeroSwitchRow(
            title = stringResource(R.string.set_haptics_title),
            subtitle = stringResource(R.string.set_haptics_text),
            checked = settings.hapticsEnabled,
            onCheckedChange = { on -> viewModel.update { current -> current.copy(hapticsEnabled = on) } },
        )
        AeroDivider()
        AeroSwitchRow(
            title = stringResource(R.string.set_sounds_title),
            subtitle = stringResource(R.string.set_sounds_text),
            checked = settings.soundsEnabled,
            onCheckedChange = { on -> viewModel.update { current -> current.copy(soundsEnabled = on) } },
        )
    }
    SettingsNote(text = stringResource(R.string.set_motion_note))
}

/** Six round swatches. The chosen one has a thick ring and a check mark, and every swatch is announced by its colour name. */
@Composable
private fun AccentPicker(selected: AccentColor, onSelected: (AccentColor) -> Unit) {
    val colors = AeroTheme.colors
    Column(modifier = Modifier.fillMaxWidth().padding(horizontal = AeroTheme.dimens.cardPadding, vertical = 12.dp)) {
        AeroText(text = stringResource(R.string.set_accent_title), style = AeroTheme.typography.bodyStrong)
        AeroText(
            text = stringResource(R.string.set_accent_text),
            style = AeroTheme.typography.caption,
            color = colors.textSecondary,
        )
        Spacer(Modifier.height(10.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            AccentColor.entries.forEach { option ->
                AccentSwatch(option = option, selected = option == selected, onClick = { onSelected(option) })
            }
        }
    }
}

@Composable
private fun AccentSwatch(option: AccentColor, selected: Boolean, onClick: () -> Unit) {
    val colors = AeroTheme.colors
    val feedback = LocalFeedback.current
    val label = stringResource(option.labelRes())
    val fill = Color(option.primary)
    val checkTint = if (fill.luminance() > 0.35f) Color(0xFF111111) else Color.White
    Box(
        modifier = Modifier
            .size(48.dp)
            .selectable(
                selected = selected,
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                role = Role.RadioButton,
                onClick = {
                    feedback.tap()
                    onClick()
                },
            )
            .semantics { contentDescription = label },
        contentAlignment = Alignment.Center,
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(fill, CircleShape)
                .border(
                    width = if (selected) 3.dp else 1.dp,
                    color = if (selected) colors.textPrimary else colors.divider,
                    shape = CircleShape,
                ),
            contentAlignment = Alignment.Center,
        ) {
            if (selected) {
                AeroIcon(icon = Icons.Rounded.Check, contentDescription = null, tint = checkTint, size = 20.dp)
            }
        }
    }
}
