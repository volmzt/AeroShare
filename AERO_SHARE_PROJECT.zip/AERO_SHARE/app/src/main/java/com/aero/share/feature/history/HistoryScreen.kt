package com.aero.share.feature.history

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Search
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.aero.share.R
import com.aero.share.core.designsystem.AeroDialog
import com.aero.share.core.designsystem.AeroEmptyState
import com.aero.share.core.designsystem.AeroIconButton
import com.aero.share.core.designsystem.AeroScreen
import com.aero.share.core.designsystem.AeroSectionHeader
import com.aero.share.core.designsystem.AeroTheme
import com.aero.share.core.designsystem.AeroTopBar
import com.aero.share.di.LocalAppContainer
import com.aero.share.navigation.AeroNavigator

/**
 * Every transfer that ended, newest first, grouped by day. History lives only on this device; deleting records here never
 * deletes the files that were received.
 */
@Composable
fun HistoryScreen(navigator: AeroNavigator) {
    val container = LocalAppContainer.current
    val viewModel: HistoryViewModel = viewModel(factory = viewModelFactory { initializer { HistoryViewModel(container) } })
    val ui by viewModel.state.collectAsStateWithLifecycle()
    var selected by rememberSaveable { mutableStateOf<String?>(null) }
    var confirmClear by rememberSaveable { mutableStateOf(false) }

    val chosen = selected
    val item = if (chosen != null) ui.find(chosen) else null

    // The record was deleted (here or by the retention rule): close its sheet.
    LaunchedEffect(chosen, item == null, ui.loaded) {
        if (chosen != null && item == null && ui.loaded) selected = null
    }

    AeroScreen {
        AeroTopBar(
            title = stringResource(R.string.hist_title),
            onBack = { navigator.back() },
            actions = {
                AeroIconButton(
                    icon = Icons.Rounded.Delete,
                    contentDescription = stringResource(R.string.hist_clear),
                    onClick = { confirmClear = true },
                    enabled = ui.all.isNotEmpty(),
                )
            },
        )
        if (ui.loaded && ui.all.isEmpty()) {
            AeroEmptyState(
                icon = Icons.Rounded.History,
                title = stringResource(R.string.hist_empty_title),
                message = stringResource(R.string.hist_empty_text),
                modifier = Modifier.padding(top = 32.dp),
            )
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = AeroTheme.dimens.screenPadding, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(AeroTheme.dimens.gap),
            ) {
                item(key = "filters") {
                    HistoryFilterBar(
                        filters = ui.filters,
                        onDirection = { option -> viewModel.setDirection(option) },
                        onStatus = { option -> viewModel.setStatus(option) },
                    )
                }
                if (ui.loaded && ui.groups.isEmpty()) {
                    item(key = "no-match") {
                        AeroEmptyState(
                            icon = Icons.Rounded.Search,
                            title = stringResource(R.string.hist_nomatch_title),
                            message = stringResource(R.string.hist_nomatch_text),
                            actionText = stringResource(R.string.hist_reset_filters),
                            onAction = { viewModel.resetFilters() },
                        )
                    }
                }
                for (group in ui.groups) {
                    item(key = "day:" + group.day) {
                        AeroSectionHeader(text = dayHeaderText(group))
                    }
                    items(group.items, key = { entry -> entry.id }) { entry ->
                        HistoryRow(item = entry, onClick = { selected = entry.id })
                    }
                }
            }
        }
    }

    if (item != null) {
        HistoryDetailSheet(
            item = item,
            onDismiss = { selected = null },
            onDelete = {
                selected = null
                viewModel.delete(item.id)
            },
        )
    }

    if (confirmClear) {
        AeroDialog(
            title = stringResource(R.string.hist_clear_title),
            message = stringResource(R.string.hist_clear_message),
            confirmText = stringResource(R.string.hist_clear_confirm),
            dismissText = stringResource(R.string.common_cancel),
            danger = true,
            onConfirm = {
                confirmClear = false
                selected = null
                viewModel.clear()
            },
            onDismiss = { confirmClear = false },
        )
    }
}
