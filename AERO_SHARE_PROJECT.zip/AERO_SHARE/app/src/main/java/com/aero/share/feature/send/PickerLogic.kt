package com.aero.share.feature.send

import com.aero.share.domain.AppItem
import com.aero.share.domain.FileItem
import com.aero.share.transfer.model.FileCategory

/** The sections of the file picker, in the order they are shown. */
internal enum class PickerTab { RECENT, IMAGES, VIDEOS, AUDIO, DOCUMENTS, DOWNLOADS, APPS, OTHER, FOLDERS }

/** The three MediaStore collections that can be listed once the person has allowed access to them. */
internal enum class MediaKind { IMAGE, VIDEO, AUDIO }

/** How much of the media library this app may see: all of it, only what the person picked (Android 14+), or nothing yet. */
internal enum class MediaAccess { FULL, PARTIAL, NONE }

/** One row of a media list: the file as it will be selected, plus what the list needs to draw it. */
internal data class MediaEntry(
    val item: FileItem,
    val kind: MediaKind,
    /** When the file was added to the library, in epoch milliseconds (used for ordering and the date shown). */
    val addedMillis: Long,
    /** Length of a video or audio file; 0 when unknown or for images. */
    val durationMillis: Long,
)

/** The pure decisions behind the picker, kept apart from Android classes so they can be tested on the JVM. */
internal object PickerLogic {
    const val PAGE_SIZE = 200
    const val RECENT_LIMIT = 200

    /** The next page is requested when the last visible item is this close to the end of what is loaded. */
    const val LOAD_AHEAD = 36
    const val GRID_COLUMNS = 3
    const val APK_MIME = "application/vnd.android.package-archive"

    /** What the "Documents" picker offers: PDF, Office and OpenDocument files, rich text and plain text. */
    val DOCUMENT_MIME_TYPES: Array<String> = arrayOf(
        "application/pdf",
        "application/msword",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "application/vnd.ms-excel",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "application/vnd.ms-powerpoint",
        "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        "application/vnd.oasis.opendocument.text",
        "application/vnd.oasis.opendocument.spreadsheet",
        "application/vnd.oasis.opendocument.presentation",
        "application/rtf",
        "text/*",
    )

    val ANY_MIME_TYPES: Array<String> = arrayOf("*/*")
    val APK_MIME_TYPES: Array<String> = arrayOf(APK_MIME)

    fun isMediaTab(tab: PickerTab): Boolean = kindsOf(tab).isNotEmpty()

    /** The collections a tab lists; empty for the tabs that go through the system picker or list apps. */
    fun kindsOf(tab: PickerTab): List<MediaKind> = when (tab) {
        PickerTab.RECENT -> MediaKind.values().toList()
        PickerTab.IMAGES -> listOf(MediaKind.IMAGE)
        PickerTab.VIDEOS -> listOf(MediaKind.VIDEO)
        PickerTab.AUDIO -> listOf(MediaKind.AUDIO)
        PickerTab.DOCUMENTS, PickerTab.DOWNLOADS, PickerTab.APPS, PickerTab.OTHER, PickerTab.FOLDERS -> emptyList()
    }

    fun categoryOf(kind: MediaKind): FileCategory = when (kind) {
        MediaKind.IMAGE -> FileCategory.IMAGE
        MediaKind.VIDEO -> FileCategory.VIDEO
        MediaKind.AUDIO -> FileCategory.AUDIO
    }

    fun categoriesOf(kinds: List<MediaKind>): Set<FileCategory> = kinds.map { categoryOf(it) }.toSet()

    /**
     * Access to one collection. [fullGranted] is the permission for exactly that collection (or the old storage permission
     * before Android 13); [visualSelectedGranted] is the Android 14 "selected photos and videos" permission.
     */
    fun accessOf(sdkInt: Int, kind: MediaKind, fullGranted: Boolean, visualSelectedGranted: Boolean): MediaAccess = when {
        fullGranted -> MediaAccess.FULL
        sdkInt >= 34 && kind != MediaKind.AUDIO && visualSelectedGranted -> MediaAccess.PARTIAL
        else -> MediaAccess.NONE
    }

    /** Access of a whole tab: FULL only when every collection is fully open, NONE when none can be read. */
    fun tabAccess(accesses: List<MediaAccess>): MediaAccess = when {
        accesses.isEmpty() -> MediaAccess.NONE
        accesses.all { it == MediaAccess.FULL } -> MediaAccess.FULL
        accesses.all { it == MediaAccess.NONE } -> MediaAccess.NONE
        else -> MediaAccess.PARTIAL
    }

    /** Appends a page to what is loaded; an entry that is already there (the library changed meanwhile) is not added twice. */
    fun append(existing: List<MediaEntry>, page: List<MediaEntry>): List<MediaEntry> {
        if (page.isEmpty()) return existing
        val known = HashSet<String>(existing.size + page.size)
        for (entry in existing) known.add(entry.item.id)
        val fresh = page.filter { entry -> known.add(entry.item.id) }
        return if (fresh.isEmpty()) existing else existing + fresh
    }

    /** The newest [limit] entries over several lists, newest first. */
    fun mergeRecent(lists: List<List<MediaEntry>>, limit: Int): List<MediaEntry> =
        lists.flatten().sortedByDescending { it.addedMillis }.take(limit)

    /** Largest power of two by which an image can be shrunk while both sides stay at least [target] pixels long. */
    fun sampleSizeFor(width: Int, height: Int, target: Int): Int {
        if (width <= 0 || height <= 0 || target <= 0) return 1
        var sample = 1
        while (width / (sample * 2) >= target && height / (sample * 2) >= target) sample *= 2
        return sample
    }

    /** Apps whose name or package contains [query] (ignoring case); everything when the query is blank. */
    fun filterApps(apps: List<AppItem>, query: String): List<AppItem> {
        val needle = query.trim().lowercase()
        if (needle.isEmpty()) return apps
        return apps.filter { app ->
            app.displayName.lowercase().contains(needle) || app.packageName.lowercase().contains(needle)
        }
    }
}
