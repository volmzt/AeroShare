package com.aero.share.feature.send

import androidx.annotation.StringRes
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.aero.share.R
import com.aero.share.core.common.Formatters
import com.aero.share.core.designsystem.AeroBadge
import com.aero.share.core.designsystem.AeroCategoryIcon
import com.aero.share.core.designsystem.AeroIcon
import com.aero.share.core.designsystem.AeroText
import com.aero.share.core.designsystem.AeroTheme
import com.aero.share.core.designsystem.aeroRowClickable
import com.aero.share.domain.AppItem
import com.aero.share.transfer.model.FileCategory
import java.text.DateFormat
import java.util.Date

private const val THUMBNAIL_PX = 256
private const val APP_ICON_PX = 96

/** The round mark that shows whether a row or cell is part of the selection: an accent disc with a check, or an empty ring. */
@Composable
internal fun SelectionIndicator(selected: Boolean, modifier: Modifier = Modifier) {
    val colors = AeroTheme.colors
    val base = modifier.size(24.dp).clip(CircleShape)
    if (selected) {
        Box(modifier = base.background(colors.accent, CircleShape), contentAlignment = Alignment.Center) {
            AeroIcon(icon = Icons.Rounded.Check, contentDescription = null, tint = colors.onAccent, size = 16.dp)
        }
    } else {
        Box(
            modifier = base
                .background(colors.background.copy(alpha = 0.55f), CircleShape)
                .border(2.dp, colors.textSecondary, CircleShape),
        )
    }
}

/** Joins the non-empty parts as "a · b · c" with the app's own separator text. */
@Composable
internal fun metaLine(parts: List<String>): String {
    var line = ""
    for (part in parts) {
        if (part.isEmpty()) continue
        line = if (line.isEmpty()) part else stringResource(R.string.common_pair, line, part)
    }
    return line
}

internal fun dateText(millis: Long): String =
    if (millis <= 0L) "" else DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(millis))

/** A square preview of a photo, video or (as an icon with its name) audio file, in the picker grid. */
@Composable
internal fun MediaCell(
    entry: MediaEntry,
    selected: Boolean,
    thumbnails: ThumbnailLoader,
    onToggle: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = AeroTheme.colors
    val uri = entry.item.uri
    val preview by produceState<ImageBitmap?>(initialValue = thumbnails.cached(uri), uri) {
        if (value == null && entry.kind != MediaKind.AUDIO) value = thumbnails.load(uri, entry.kind, THUMBNAIL_PX)
    }
    val shape = RoundedCornerShape(8.dp)
    Box(
        modifier = modifier
            .aspectRatio(1f)
            .clip(shape)
            .background(colors.surfaceAlt, shape)
            .semantics { this.selected = selected }
            .aeroRowClickable(role = Role.Checkbox, onClick = onToggle),
    ) {
        val image = preview
        if (image != null) {
            Image(
                bitmap = image,
                contentDescription = entry.item.displayName,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        } else {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                AeroCategoryIcon(category = entry.item.category)
            }
        }
        if (entry.kind == MediaKind.AUDIO) {
            AeroText(
                text = entry.item.displayName,
                modifier = Modifier.align(Alignment.BottomStart).padding(6.dp),
                style = AeroTheme.typography.caption,
                maxLines = 2,
            )
        }
        if (entry.kind == MediaKind.VIDEO && entry.durationMillis > 0L) {
            AeroText(
                text = Formatters.duration(entry.durationMillis),
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(4.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color.Black.copy(alpha = 0.6f))
                    .padding(horizontal = 4.dp, vertical = 1.dp),
                style = AeroTheme.typography.caption,
                color = Color.White,
                maxLines = 1,
            )
        }
        if (selected) Box(modifier = Modifier.fillMaxSize().background(colors.accent.copy(alpha = 0.28f)))
        SelectionIndicator(selected = selected, modifier = Modifier.align(Alignment.TopEnd).padding(6.dp))
    }
}

/** A media file as a list row: type icon, name, length · size · date, and the selection mark. */
@Composable
internal fun MediaRow(entry: MediaEntry, selected: Boolean, onToggle: () -> Unit) {
    val item = entry.item
    val parts = listOf(
        if (entry.durationMillis > 0L) Formatters.duration(entry.durationMillis) else "",
        if (item.size >= 0L) Formatters.bytes(item.size) else "",
        dateText(entry.addedMillis),
    )
    SelectableRow(
        selected = selected,
        onToggle = onToggle,
        leading = { AeroCategoryIcon(category = item.category) },
        title = item.displayName,
        subtitle = metaLine(parts),
    )
}

/** An installed app as a list row: its icon (loaded when the row is drawn), name, version · size and the selection mark. */
@Composable
internal fun AppRow(
    app: AppItem,
    selected: Boolean,
    cachedIcon: (String) -> ImageBitmap?,
    loadIcon: suspend (String, Int) -> ImageBitmap?,
    onToggle: () -> Unit,
) {
    val icon by produceState<ImageBitmap?>(initialValue = cachedIcon(app.packageName), app.packageName) {
        if (value == null) value = loadIcon(app.packageName, APP_ICON_PX)
    }
    val version = app.versionName?.let { name -> stringResource(R.string.send_app_version, name) }.orEmpty()
    val parts = listOf(version, if (app.size >= 0L) Formatters.bytes(app.size) else "")
    SelectableRow(
        selected = selected,
        onToggle = onToggle,
        leading = {
            val image = icon
            if (image != null) {
                Image(
                    bitmap = image,
                    contentDescription = null,
                    modifier = Modifier.size(44.dp).clip(RoundedCornerShape(10.dp)),
                )
            } else {
                AeroCategoryIcon(category = FileCategory.APK)
            }
        },
        title = app.displayName,
        subtitle = metaLine(parts),
        badge = if (app.splitCount > 0) stringResource(R.string.send_app_split_badge) else null,
    )
}

@Composable
private fun SelectableRow(
    selected: Boolean,
    onToggle: () -> Unit,
    leading: @Composable () -> Unit,
    title: String,
    subtitle: String,
    badge: String? = null,
) {
    val colors = AeroTheme.colors
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 64.dp)
            .semantics { this.selected = selected }
            .aeroRowClickable(role = Role.Checkbox, onClick = onToggle)
            .background(if (selected) colors.accentContainer else Color.Transparent)
            .padding(horizontal = AeroTheme.dimens.screenPadding, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        leading()
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            AeroText(text = title, style = AeroTheme.typography.bodyStrong, maxLines = 1)
            if (subtitle.isNotEmpty()) {
                AeroText(text = subtitle, style = AeroTheme.typography.caption, color = colors.textSecondary, maxLines = 1)
            }
        }
        if (badge != null) {
            AeroBadge(text = badge)
            Spacer(Modifier.width(8.dp))
        }
        SelectionIndicator(selected = selected)
    }
}

/** Centres a message that may be taller than a small screen with large text: it scrolls instead of being cut off. */
@Composable
internal fun CenteredScroll(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = AeroTheme.dimens.screenPadding, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        content = content,
    )
}

/** The tab title as a resource, for the chip row. */
@StringRes
internal fun PickerTab.labelRes(): Int = when (this) {
    PickerTab.RECENT -> R.string.send_tab_recent
    PickerTab.IMAGES -> R.string.send_tab_images
    PickerTab.VIDEOS -> R.string.send_tab_videos
    PickerTab.AUDIO -> R.string.send_tab_audio
    PickerTab.DOCUMENTS -> R.string.send_tab_documents
    PickerTab.DOWNLOADS -> R.string.send_tab_downloads
    PickerTab.APPS -> R.string.send_tab_apps
    PickerTab.OTHER -> R.string.send_tab_other
    PickerTab.FOLDERS -> R.string.send_tab_folders
}

@StringRes
internal fun PickerMessage.textRes(): Int = when (this) {
    PickerMessage.NOTHING_READABLE -> R.string.send_msg_nothing_readable
    PickerMessage.SOME_UNREADABLE -> R.string.send_msg_some_unreadable
    PickerMessage.EMPTY_FOLDER -> R.string.send_msg_empty_folder
    PickerMessage.FOLDER_PARTIAL -> R.string.send_msg_folder_partial
}
