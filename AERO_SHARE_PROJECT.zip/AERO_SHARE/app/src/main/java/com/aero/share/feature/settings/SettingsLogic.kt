package com.aero.share.feature.settings

import com.aero.share.core.common.LocalDeviceModel
import com.aero.share.domain.CapabilityState
import com.aero.share.domain.TransportCapability
import com.aero.share.domain.TransportMode
import com.aero.share.transfer.model.TransportKind

/** Where received files go, as far as the settings page can tell. */
internal sealed interface ReceiveFolder {
    /** Downloads/AERO SHARE, the default. */
    data object Default : ReceiveFolder

    /** A folder the person chose, which can still be written to. [name] may be empty when the provider gives none. */
    data class Custom(val name: String) : ReceiveFolder

    /** A folder was chosen once but its access was revoked or the folder is gone; receiving falls back to the default. */
    data object Unavailable : ReceiveFolder
}

/** Decisions of the settings pages that do not need Android, kept apart so they can be unit-tested. */
internal object SettingsLogic {
    private const val GIB = 1024L * 1024L * 1024L

    /** Seconds to wait for the other device before giving up. */
    val CONNECTION_TIMEOUTS: List<Int> = listOf(10, 15, 30, 60)

    /** Seconds a pairing QR code stays valid. */
    val QR_LIFETIMES: List<Int> = listOf(60, 120, 300)

    /** Ask before sending more than this many bytes; 0 means never ask. */
    val LARGE_TRANSFER_WARN_BYTES: List<Long> = listOf(0L, 1L * GIB, 2L * GIB, 5L * GIB, 10L * GIB)

    /** Days after which unfinished received data is cleaned up. */
    val PARTIAL_RETENTION_DAYS: List<Int> = listOf(1, 3, 7, 14, 30)

    /** Days after which history records are removed; 0 means keep them. */
    val HISTORY_RETENTION_DAYS: List<Int> = listOf(0, 30, 90, 365)

    /** The option nearest to [value], so a stored value that is not offered any more still shows a sensible choice. */
    fun nearestInt(options: List<Int>, value: Int): Int {
        var best = options.first()
        for (option in options) {
            if (Math.abs(option.toLong() - value) < Math.abs(best.toLong() - value)) best = option
        }
        return best
    }

    fun nearestLong(options: List<Long>, value: Long): Long {
        // Clamping first keeps the subtraction below from overflowing for extreme stored values.
        val clamped = value.coerceIn(options.min(), options.max())
        var best = options.first()
        for (option in options) {
            if (Math.abs(option - clamped) < Math.abs(best - clamped)) best = option
        }
        return best
    }

    /** The name to store for what was typed: trimmed, at most 40 characters; null (use the model name) when empty. */
    fun customNameOf(input: String): String? {
        val clean = input.trim().take(LocalDeviceModel.MAX_NAME_LENGTH).trimEnd()
        return if (clean.isEmpty()) null else clean
    }

    /** Wi-Fi Direct is only offered as a preference on devices that have it. */
    fun transportModes(wifiDirectSupported: Boolean): List<TransportMode> =
        if (wifiDirectSupported) {
            listOf(TransportMode.AUTO, TransportMode.LAN_ONLY, TransportMode.WIFI_DIRECT_PREFERRED)
        } else {
            listOf(TransportMode.AUTO, TransportMode.LAN_ONLY)
        }

    /** If Wi-Fi Direct is not available the preference for it counts as Automatic, so a choice is always shown. */
    fun effectiveTransportMode(mode: TransportMode, wifiDirectSupported: Boolean): TransportMode =
        if (mode == TransportMode.WIFI_DIRECT_PREFERRED && !wifiDirectSupported) TransportMode.AUTO else mode

    /** Every way of connecting in a fixed order; the ones this device cannot do stay in the list and say so. */
    fun orderedTransports(capabilities: List<TransportCapability>): List<TransportCapability> =
        capabilities.sortedBy { capability -> capability.kind.ordinal }

    fun wifiDirectSupported(capabilities: List<TransportCapability>): Boolean =
        capabilities.any { capability ->
            capability.kind == TransportKind.WIFI_DIRECT && capability.state != CapabilityState.UNSUPPORTED
        }

    /** Notification channels only matter while notifications are on at all. */
    fun notificationDetailsEnabled(notificationsEnabled: Boolean): Boolean = notificationsEnabled

    /** Turning notifications on needs the system permission from Android 13 on. */
    fun needsNotificationPermission(sdkInt: Int, granted: Boolean): Boolean = sdkInt >= 33 && !granted

    /** What the folder row says, from facts the Android layer collects (kept apart so the rules can be tested). */
    fun folderState(rawUri: String?, persisted: Boolean, canWrite: Boolean, name: String?): ReceiveFolder = when {
        rawUri.isNullOrBlank() -> ReceiveFolder.Default
        !persisted || !canWrite -> ReceiveFolder.Unavailable
        else -> ReceiveFolder.Custom(name.orEmpty().trim())
    }
}
