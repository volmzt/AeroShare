package com.aero.share.network.discovery

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiManager
import androidx.core.content.ContextCompat
import java.net.Inet4Address
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** The network used for LAN discovery and transfers: a Wi-Fi or Ethernet network that has an IPv4 address. */
data class LanNetwork(
    val network: Network,
    val interfaceName: String?,
    val isWifi: Boolean,
    /** The addresses of this device on the network, with prefix lengths. */
    val subnets: List<LocalSubnet>,
)

/**
 * Follows the Wi-Fi / Ethernet networks of the device. Networks are only watched between [start] and [stop]; nothing
 * runs in the background otherwise. A Wi-Fi network without internet access still counts (that is the usual LAN case).
 * When both exist, Wi-Fi wins over Ethernet.
 */
class NetworkWatcher(context: Context, private val log: (String) -> Unit = {}) {
    private val manager: ConnectivityManager? = context.applicationContext.getSystemService(ConnectivityManager::class.java)
    private val lock = Any()
    private val networks = LinkedHashSet<Network>()
    private val state = MutableStateFlow<LanNetwork?>(null)
    private var callback: ConnectivityManager.NetworkCallback? = null

    val current: StateFlow<LanNetwork?> = state.asStateFlow()

    fun start() {
        val cm = manager ?: return
        synchronized(lock) {
            if (callback != null) return
            val request = NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .addTransportType(NetworkCapabilities.TRANSPORT_ETHERNET)
                .build()
            val watcher = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    changed(network, true)
                }

                override fun onLost(network: Network) {
                    changed(network, false)
                }

                override fun onLinkPropertiesChanged(network: Network, linkProperties: android.net.LinkProperties) {
                    changed(network, true)
                }

                override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) {
                    changed(network, true)
                }
            }
            try {
                cm.registerNetworkCallback(request, watcher)
                callback = watcher
            } catch (e: RuntimeException) {
                log("network watch failed: ${e.javaClass.simpleName}")
            }
        }
    }

    fun stop() {
        val cm = manager ?: return
        synchronized(lock) {
            val watcher = callback ?: return
            callback = null
            try {
                cm.unregisterNetworkCallback(watcher)
            } catch (e: IllegalArgumentException) {
                // already unregistered
            }
            networks.clear()
            state.value = null
        }
    }

    private fun changed(network: Network, present: Boolean) {
        synchronized(lock) {
            if (callback == null) return
            if (present) networks.add(network) else networks.remove(network)
            var wifi: LanNetwork? = null
            var wired: LanNetwork? = null
            for (candidate in networks) {
                val lan = describe(candidate) ?: continue
                if (lan.isWifi) wifi = lan else wired = lan
            }
            state.value = wifi ?: wired
        }
    }

    private fun describe(network: Network): LanNetwork? {
        val cm = manager ?: return null
        val link = cm.getLinkProperties(network) ?: return null
        val subnets = ArrayList<LocalSubnet>()
        for (linkAddress in link.linkAddresses) {
            val address = linkAddress.address
            if (address is Inet4Address) {
                val text = address.hostAddress ?: continue
                subnets.add(LocalSubnet(text, linkAddress.prefixLength))
            }
        }
        if (subnets.isEmpty()) return null
        val wifi = cm.getNetworkCapabilities(network)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        return LanNetwork(network, link.interfaceName, wifi, subnets)
    }
}

/** Whether the Wi-Fi radio is on. Devices without Wi-Fi hardware report true, so that "no network" is not shown as "Wi-Fi off". */
class WifiState(context: Context) {
    private val app = context.applicationContext
    private val wifi: WifiManager? = app.getSystemService(WifiManager::class.java)
    private val state = MutableStateFlow(read())
    private var receiver: BroadcastReceiver? = null

    val enabled: StateFlow<Boolean> = state.asStateFlow()

    fun start() {
        if (receiver != null) return
        state.value = read()
        val listener = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                state.value = read()
            }
        }
        ContextCompat.registerReceiver(
            app,
            listener,
            IntentFilter(WifiManager.WIFI_STATE_CHANGED_ACTION),
            ContextCompat.RECEIVER_NOT_EXPORTED,
        )
        receiver = listener
    }

    fun stop() {
        val listener = receiver ?: return
        receiver = null
        try {
            app.unregisterReceiver(listener)
        } catch (e: IllegalArgumentException) {
            // already unregistered
        }
    }

    private fun read(): Boolean = wifi?.isWifiEnabled ?: true
}
