package com.aero.share.network.transport

import com.aero.share.domain.NearbyDevice

/** Merges devices found on the LAN with devices found over Wi-Fi Direct into one list, one entry per device. */
internal object DeviceMerge {
    /** Best link first, then by name; the device id keeps the order stable. */
    val ORDER: Comparator<NearbyDevice> = compareByDescending<NearbyDevice> { it.quality.ordinal }
        .thenBy { it.name.lowercase() }
        .thenBy { it.deviceId }

    fun merge(lan: List<NearbyDevice>, direct: List<NearbyDevice>): List<NearbyDevice> {
        if (direct.isEmpty()) return lan.sortedWith(ORDER)
        val byId = LinkedHashMap<String, NearbyDevice>()
        for (device in lan) byId[device.deviceId] = device
        for (device in direct) {
            val existing = byId[device.deviceId]
            byId[device.deviceId] = if (existing == null) device else combine(existing, device)
        }
        return byId.values.sortedWith(ORDER)
    }

    /** [primary] (LAN) wins where the two disagree; the union of transports and addresses is kept. */
    private fun combine(primary: NearbyDevice, other: NearbyDevice): NearbyDevice {
        val quality = if (other.quality.ordinal > primary.quality.ordinal) other.quality else primary.quality
        return primary.copy(
            name = primary.name.ifBlank { other.name },
            fingerprint = primary.fingerprint ?: other.fingerprint,
            appVersion = primary.appVersion ?: other.appVersion,
            addresses = (primary.addresses + other.addresses).distinct(),
            transports = primary.transports + other.transports,
            quality = quality,
            lastSeenElapsed = maxOf(primary.lastSeenElapsed, other.lastSeenElapsed),
            p2pAddress = primary.p2pAddress ?: other.p2pAddress,
            capabilities = if (primary.capabilities != 0) primary.capabilities else other.capabilities,
        )
    }
}
