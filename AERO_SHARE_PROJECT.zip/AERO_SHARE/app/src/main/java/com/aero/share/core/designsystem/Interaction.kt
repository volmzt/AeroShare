package com.aero.share.core.designsystem

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.ProvidableCompositionLocal
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp

/** Haptic and sound feedback of the current app; provided once at the root of the UI. */
val LocalFeedback: ProvidableCompositionLocal<FeedbackManager> =
    staticCompositionLocalOf { error("FeedbackManager not provided") }

/** Scales to 97 % and dims slightly while [pressed]; instant when motion is off. */
fun Modifier.pressScale(pressed: Boolean, enabled: Boolean = true): Modifier = composed {
    val motion = AeroTheme.motion
    val active = pressed && enabled
    val scale by animateFloatAsState(
        targetValue = if (active) 0.97f else 1f,
        animationSpec = tween(durationMillis = if (motion.enabled) 90 else 0),
        label = "press-scale",
    )
    graphicsLayer {
        scaleX = scale
        scaleY = scale
        alpha = if (active) 0.92f else 1f
    }
}

/**
 * Click handling with the app's own press feedback (no ripple): a small scale/alpha change, plus a haptic tick and the
 * system click sound when the user's settings allow them.
 */
fun Modifier.aeroClickable(enabled: Boolean = true, role: Role? = null, onClick: () -> Unit): Modifier = composed {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val feedback = LocalFeedback.current
    this.pressScale(pressed, enabled).clickable(
        interactionSource = source,
        indication = null,
        enabled = enabled,
        role = role,
        onClick = {
            feedback.tap()
            onClick()
        },
    )
}

/** For rows inside lists and cards: no scaling, only a soft highlight while pressed. */
fun Modifier.aeroRowClickable(enabled: Boolean = true, role: Role? = null, onClick: () -> Unit): Modifier = composed {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val feedback = LocalFeedback.current
    val highlight = AeroTheme.colors.textPrimary.copy(alpha = 0.07f)
    this.background(if (pressed && enabled) highlight else Color.Transparent).clickable(
        interactionSource = source,
        indication = null,
        enabled = enabled,
        role = role,
        onClick = {
            feedback.tap()
            onClick()
        },
    )
}

/**
 * Card surface. With "glass effects" on it is translucent with a hairline highlight (cheap: no blur, no off-screen
 * layers); otherwise it is the plain surface colour with the divider as border.
 */
fun Modifier.aeroGlass(): Modifier = composed {
    val colors = AeroTheme.colors
    val shape = RoundedCornerShape(AeroTheme.dimens.radius)
    if (LocalAeroGlass.current) {
        this.clip(shape)
            .background(colors.surface.copy(alpha = if (colors.isDark) 0.62f else 0.72f), shape)
            .border(1.dp, colors.textPrimary.copy(alpha = 0.10f), shape)
    } else {
        this.clip(shape)
            .background(colors.surface, shape)
            .border(1.dp, colors.divider, shape)
    }
}

/** Two soft accent glows behind the screen; only drawn with glass effects so the translucent cards have something to show. */
internal fun Modifier.glassBackdrop(): Modifier = composed {
    if (!LocalAeroGlass.current) {
        this
    } else {
        val accent = AeroTheme.colors.accent
        this.drawBehind {
            drawRect(
                brush = Brush.radialGradient(
                    colors = listOf(accent.copy(alpha = 0.22f), Color.Transparent),
                    center = Offset(size.width * 0.85f, size.height * 0.08f),
                    radius = size.minDimension * 0.9f,
                ),
            )
            drawRect(
                brush = Brush.radialGradient(
                    colors = listOf(accent.copy(alpha = 0.10f), Color.Transparent),
                    center = Offset(size.width * 0.05f, size.height * 0.75f),
                    radius = size.minDimension * 0.8f,
                ),
            )
        }
    }
}
