package com.aero.share.core.database

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Dao
interface DeviceDao {
    @Query("SELECT * FROM devices ORDER BY trusted DESC, lastSeen DESC")
    fun observeAll(): Flow<List<DeviceEntity>>

    @Query("SELECT * FROM devices WHERE deviceId = :id LIMIT 1")
    suspend fun find(id: String): DeviceEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: DeviceEntity)

    @Query("UPDATE devices SET alias = :alias WHERE deviceId = :id")
    suspend fun setAlias(id: String, alias: String?)

    @Query("UPDATE devices SET trusted = :trusted WHERE deviceId = :id")
    suspend fun setTrusted(id: String, trusted: Boolean)

    @Query("UPDATE devices SET blocked = :blocked WHERE deviceId = :id")
    suspend fun setBlocked(id: String, blocked: Boolean)

    @Query("DELETE FROM devices WHERE deviceId = :id")
    suspend fun delete(id: String)
}

@Dao
interface HistoryDao {
    @Query("SELECT * FROM history ORDER BY timestamp DESC")
    fun observeAll(): Flow<List<HistoryEntity>>

    @Query("SELECT * FROM history WHERE id = :id LIMIT 1")
    suspend fun find(id: String): HistoryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: HistoryEntity)

    @Query("DELETE FROM history WHERE id = :id")
    suspend fun delete(id: String)

    @Query("DELETE FROM history")
    suspend fun clear()

    @Query("DELETE FROM history WHERE timestamp < :timestamp")
    suspend fun deleteOlderThan(timestamp: Long)
}

/** Local database: known devices (trust, alias) and transfer history. Version 1; schema changes need a real migration. */
@Database(entities = [DeviceEntity::class, HistoryEntity::class], version = 1, exportSchema = false)
abstract class AeroDatabase : RoomDatabase() {
    abstract fun devices(): DeviceDao
    abstract fun history(): HistoryDao

    companion object {
        fun create(context: Context): AeroDatabase =
            Room.databaseBuilder(context.applicationContext, AeroDatabase::class.java, "aero.db").build()
    }
}
