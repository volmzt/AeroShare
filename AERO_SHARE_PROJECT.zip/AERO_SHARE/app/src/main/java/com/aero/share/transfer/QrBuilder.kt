package com.aero.share.transfer

import com.aero.share.transfer.model.DeviceKind
import com.aero.share.transfer.pairing.HotspotCredentials
import com.aero.share.transfer.pairing.PairToken
import com.aero.share.transfer.pairing.QrPayload

/**
 * Builds the pairing payload and makes sure the encoded text is something the scanner will accept: the parser refuses
 * names longer than 60 characters and the whole text may not exceed 1000 characters. When it does not fit, the device name
 * is shortened first and extra addresses are dropped last.
 */
internal object QrBuilder {
    const val MAX_LENGTH = 1000
    const val FALLBACK_NAME = "AERO SHARE"

    fun build(
        deviceId: String,
        name: String,
        kind: DeviceKind,
        hosts: List<String>,
        port: Int,
        fingerprint: String,
        token: PairToken,
        hotspot: HotspotCredentials?,
    ): QrPayload? {
        val clean = DisplayText.clean(name).ifEmpty { FALLBACK_NAME }
        val names = listOf(clean, clean.take(24).trimEnd(), FALLBACK_NAME).filter { it.isNotEmpty() }.distinct()
        val hostSets = listOf(hosts.take(4), hosts.take(2), hosts.take(1)).filter { it.isNotEmpty() }.distinct()
        for (candidateName in names) {
            for (candidateHosts in hostSets) {
                val payload = QrPayload(
                    version = 1,
                    deviceId = deviceId,
                    name = candidateName,
                    kind = kind,
                    hosts = candidateHosts,
                    port = port,
                    fingerprint = fingerprint,
                    token = token.encoded,
                    expiresAt = token.expiresAt,
                    hotspot = hotspot,
                )
                val text = payload.encode()
                if (text.length <= MAX_LENGTH && QrPayload.parse(text) != null) return payload
            }
        }
        return null
    }
}
