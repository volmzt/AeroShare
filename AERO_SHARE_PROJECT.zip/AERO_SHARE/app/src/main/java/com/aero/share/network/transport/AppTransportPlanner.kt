package com.aero.share.network.transport

import android.content.Context
import android.net.ConnectivityManager
import android.os.Build
import com.aero.share.core.common.DiagnosticsLog
import com.aero.share.domain.CapabilityProvider
import com.aero.share.domain.CapabilityState
import com.aero.share.domain.ConnectionPlan
import com.aero.share.domain.NearbyDevice
import com.aero.share.domain.PlanResult
import com.aero.share.domain.SettingsRepository
import com.aero.share.domain.TransportPlanner
import com.aero.share.transfer.engine.SocketConnector
import com.aero.share.transfer.model.TransferFailure
import com.aero.share.transfer.model.TransportKind
import com.aero.share.transfer.pairing.HotspotCredentials
import com.aero.share.transfer.pairing.QrPayload
import java.util.IdentityHashMap
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope

/**
 * Chooses and prepares the transport for one transfer. The choice follows the transport mode setting (AUTO prefers the
 * LAN and falls back to Wi-Fi Direct; LAN_ONLY never leaves the LAN; WIFI_DIRECT_PREFERRED tries Wi-Fi Direct first),
 * but every route is verified with a real TCP connection before it is reported as ready. A failed plan carries the most
 * useful [TransferFailure] and a stable [PlanDetail]; no addresses or names are ever put into diagnostics.
 *
 * Whatever a plan created (a Wi-Fi Direct group, a joined hotspot) is torn down by [release], which is idempotent.
 */
class AppTransportPlanner(
    context: Context,
    scope: CoroutineScope,
    private val p2p: WifiDirectManager,
    private val capabilities: CapabilityProvider,
    private val settings: SettingsRepository,
    private val diagnostics: DiagnosticsLog,
) : TransportPlanner {
    private val app = context.applicationContext
    private val connectivity: ConnectivityManager? = app.getSystemService(ConnectivityManager::class.java)
    private val probe = HostProbe(scope)
    private val hotspot = HotspotHost(app) { message -> log(message) }
    private val resourcesLock = Any()
    private val resources = IdentityHashMap<ConnectionPlan, suspend () -> Unit>()

    override suspend fun plan(device: NearbyDevice): PlanResult {
        val current = settings.settings.value
        val timeoutMs = timeoutMs(current.connectionTimeoutSec)
        val p2pCapability = capabilities.capabilities.value.stateOf(TransportKind.WIFI_DIRECT)
        val p2pUsable = current.wifiDirectEnabled && p2pCapability == CapabilityState.AVAILABLE
        val routes = PlanRules.routes(
            mode = current.transportMode,
            hasAddresses = device.addresses.isNotEmpty(),
            hasP2pAddress = device.p2pAddress != null,
            p2pUsable = p2pUsable,
        )
        if (routes.isEmpty()) {
            return PlanRules.noRoute(current.transportMode, device.p2pAddress != null, current.wifiDirectEnabled, p2pCapability)
        }
        var failure: PlanResult.Failed? = null
        for (route in routes) {
            val result = when (route) {
                Route.LAN -> planLan(device, timeoutMs)
                Route.WIFI_DIRECT -> planDirect(device, timeoutMs)
            }
            when (result) {
                is PlanResult.Ready -> return result
                is PlanResult.Failed -> failure = PlanRules.moreSpecific(failure, result)
            }
        }
        return failure ?: PlanResult.Failed(TransferFailure.UNREACHABLE, PlanDetail.NO_ROUTE)
    }

    override suspend fun planFromQr(payload: QrPayload): PlanResult {
        if (PlanRules.isExpired(payload.expiresAt, System.currentTimeMillis())) {
            return PlanResult.Failed(TransferFailure.AUTH_FAILED, PlanDetail.QR_EXPIRED)
        }
        val timeoutMs = timeoutMs(settings.settings.value.connectionTimeoutSec)
        val connector = lanConnector()
        val credentials = payload.hotspot
        // With a hotspot as the alternative, a quick look at the current network is enough.
        val firstTimeoutMs = if (credentials != null) minOf(timeoutMs, QR_FIRST_PROBE_MS) else timeoutMs
        val direct = probe.probeAny(payload.hosts, payload.port, firstTimeoutMs, connector)
        val host = direct.host
        if (host != null) {
            return PlanResult.Ready(ConnectionPlan(host, payload.port, TransportKind.LAN, payload.fingerprint, connector))
        }
        if (credentials == null) return PlanRules.failureFromProbes(direct.outcomes, discovered = false)
        return joinHotspot(payload, credentials, timeoutMs)
    }

    override fun planManual(host: String, port: Int): ConnectionPlan =
        ConnectionPlan(host, port, TransportKind.MANUAL, null, lanConnector())

    override suspend fun release(plan: ConnectionPlan) {
        val cleanup = takeCleanup(plan) ?: return
        try {
            cleanup()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            log("releasing a transport threw " + e.javaClass.simpleName)
        }
    }

    override suspend fun startHotspot(): HotspotCredentials? = hotspot.start()

    override fun stopHotspot() {
        hotspot.stop()
    }

    // ---- routes

    private suspend fun planLan(device: NearbyDevice, timeoutMs: Int): PlanResult {
        val connector = lanConnector()
        val summary = probe.probeAny(device.addresses, device.port, timeoutMs, connector)
        val host = summary.host
        if (host != null) {
            return PlanResult.Ready(ConnectionPlan(host, device.port, TransportKind.LAN, device.fingerprint, connector))
        }
        log("no LAN address of the device accepted a connection")
        return PlanRules.failureFromProbes(summary.outcomes, discovered = true)
    }

    private suspend fun planDirect(device: NearbyDevice, timeoutMs: Int): PlanResult {
        val group = p2p.connect(device).getOrElse { error ->
            val reason = (error as? P2pException)?.reason ?: P2pFailure.FAILED
            log("Wi-Fi Direct connection failed (" + reason.name + ")")
            return PlanRules.directFailure(reason)
        }
        val host = group.peerAddress
        if (host == null) {
            p2p.disconnectAwait()
            return PlanRules.directFailure(P2pFailure.PEER_ADDRESS_UNKNOWN)
        }
        // The group has just formed: the link and the other phone's server may need a moment.
        val summary = probe.probeWithRetry(
            hosts = listOf(host),
            port = device.port,
            timeoutMs = minOf(timeoutMs, DIRECT_PROBE_MS),
            connector = SocketConnector.DEFAULT,
            attempts = DIRECT_PROBE_ATTEMPTS,
            pauseMs = DIRECT_PROBE_PAUSE_MS,
        )
        if (summary.host == null) {
            p2p.disconnectAwait()
            return PlanRules.directProbeFailure(summary.outcomes)
        }
        val plan = ConnectionPlan(host, device.port, TransportKind.WIFI_DIRECT, device.fingerprint, SocketConnector.DEFAULT)
        remember(plan) { p2p.disconnectAwait() }
        return PlanResult.Ready(plan)
    }

    /** Joins the hotspot of the QR code (Android 10+) and connects through that network. */
    private suspend fun joinHotspot(payload: QrPayload, credentials: HotspotCredentials, timeoutMs: Int): PlanResult {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            return PlanResult.Failed(TransferFailure.UNREACHABLE, PlanDetail.HOTSPOT_MANUAL_JOIN)
        }
        val manager = connectivity ?: return PlanResult.Failed(TransferFailure.UNREACHABLE, PlanDetail.NO_ROUTE)
        val joined = HotspotJoin(manager) { message -> log(message) }
            .join(credentials.ssid, credentials.passphrase, maxOf(timeoutMs, JOIN_MIN_MS))
            ?: return PlanResult.Failed(TransferFailure.UNREACHABLE, PlanDetail.HOTSPOT_JOIN_FAILED)
        val connector = NetworkBoundConnector(joined.network)
        val summary = probe.probeWithRetry(
            hosts = payload.hosts,
            port = payload.port,
            timeoutMs = minOf(timeoutMs, HOTSPOT_PROBE_MS),
            connector = connector,
            attempts = HOTSPOT_PROBE_ATTEMPTS,
            pauseMs = HOTSPOT_PROBE_PAUSE_MS,
        )
        val host = summary.host
        if (host == null) {
            joined.release()
            return PlanRules.failureFromProbes(summary.outcomes, discovered = false)
        }
        val plan = ConnectionPlan(host, payload.port, TransportKind.HOTSPOT, payload.fingerprint, connector)
        remember(plan) { joined.release() }
        return PlanResult.Ready(plan)
    }

    // ---- helpers

    /** Sockets go through the Wi-Fi/Ethernet network itself: the default network may be mobile data. */
    private fun lanConnector(): SocketConnector {
        val lan = LanNetworkFinder.find(app) ?: return SocketConnector.DEFAULT
        return NetworkBoundConnector(lan.network)
    }

    private fun timeoutMs(seconds: Int): Int = seconds.coerceIn(MIN_TIMEOUT_SEC, MAX_TIMEOUT_SEC) * 1000

    private fun remember(plan: ConnectionPlan, cleanup: suspend () -> Unit) {
        synchronized(resourcesLock) { resources[plan] = cleanup }
    }

    private fun takeCleanup(plan: ConnectionPlan): (suspend () -> Unit)? = synchronized(resourcesLock) {
        val key = resources.keys.firstOrNull { it === plan } ?: resources.keys.firstOrNull { it == plan }
        if (key == null) null else resources.remove(key)
    }

    private fun log(message: String) {
        diagnostics.add("transport", message)
    }

    private companion object {
        const val MIN_TIMEOUT_SEC = 3
        const val MAX_TIMEOUT_SEC = 120
        const val QR_FIRST_PROBE_MS = 4_000
        const val DIRECT_PROBE_MS = 3_000
        const val DIRECT_PROBE_ATTEMPTS = 4
        const val DIRECT_PROBE_PAUSE_MS = 700L
        const val HOTSPOT_PROBE_MS = 5_000
        const val HOTSPOT_PROBE_ATTEMPTS = 3
        const val HOTSPOT_PROBE_PAUSE_MS = 700L
        const val JOIN_MIN_MS = 30_000
    }
}
