package com.aero.share.feature.devices

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import com.aero.share.R
import com.aero.share.core.common.labelRes
import com.aero.share.core.designsystem.AeroBottomSheet
import com.aero.share.core.designsystem.AeroButton
import com.aero.share.core.designsystem.AeroButtonStyle
import com.aero.share.core.designsystem.AeroText
import com.aero.share.core.designsystem.AeroTheme
import com.aero.share.feature.send.metaLine
import java.text.DateFormat
import java.util.Date

/**
 * Everything known about a device, for people who want to compare certificate fingerprints. A fingerprint is shown only
 * for stored devices: the one a nearby device announces has not been checked yet and is never presented as verified.
 */
@Composable
internal fun DeviceInfoSheet(target: DeviceTarget, onDismiss: () -> Unit) {
    val record = target.record
    val nearby = target.nearby
    val kindText = stringResource(target.kind.labelRes())
    AeroBottomSheet(onDismiss = onDismiss) {
        AeroText(text = stringResource(R.string.dev_info_title), style = AeroTheme.typography.titleSmall)
        Spacer(Modifier.height(8.dp))
        InfoLine(
            label = stringResource(R.string.dev_info_name),
            value = target.name.ifBlank { stringResource(R.string.common_unknown_device) },
        )
        if (record != null && !record.alias.isNullOrBlank() && record.alias != record.name) {
            InfoLine(label = stringResource(R.string.dev_info_original_name), value = record.name)
        }
        InfoLine(
            label = stringResource(R.string.dev_info_type),
            value = metaLine(listOf(kindText, record?.model.orEmpty())),
        )
        InfoLine(label = stringResource(R.string.dev_info_id), value = DevicesLogic.shortId(target.deviceId), style = AeroTheme.typography.mono)
        if (record != null) {
            InfoLine(
                label = stringResource(R.string.dev_info_fingerprint),
                value = DevicesLogic.groupFingerprint(record.fingerprint),
                style = AeroTheme.typography.mono,
            )
            InfoLine(label = stringResource(R.string.dev_info_first_seen), value = dateTimeText(record.firstSeen))
            InfoLine(label = stringResource(R.string.dev_info_last_seen), value = dateTimeText(record.lastSeen))
            val transport = record.lastTransport
            if (transport != null) {
                InfoLine(label = stringResource(R.string.dev_info_transport), value = stringResource(transport.labelRes()))
            }
            val features = DevicesLogic.features(record.capabilities)
            InfoLine(
                label = stringResource(R.string.dev_info_features),
                value = if (features.isEmpty()) {
                    stringResource(R.string.dev_info_features_none)
                } else {
                    features.map { feature -> stringResource(feature.labelRes()) }.joinToString(", ")
                },
            )
        } else {
            InfoLine(
                label = stringResource(R.string.dev_info_fingerprint),
                value = stringResource(R.string.dev_info_fingerprint_pending),
            )
        }
        val version = nearby?.appVersion
        if (!version.isNullOrBlank()) {
            InfoLine(label = stringResource(R.string.dev_info_app_version), value = version)
        }
        Spacer(Modifier.height(16.dp))
        AeroButton(
            text = stringResource(R.string.common_close),
            onClick = onDismiss,
            modifier = Modifier.fillMaxWidth(),
            style = AeroButtonStyle.Secondary,
        )
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun InfoLine(label: String, value: String, style: TextStyle = AeroTheme.typography.body) {
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        AeroText(text = label, style = AeroTheme.typography.caption, color = AeroTheme.colors.textSecondary)
        AeroText(text = value, style = style)
    }
}

private fun dateTimeText(millis: Long): String =
    if (millis <= 0L) "" else DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(millis))

private fun DeviceFeature.labelRes(): Int = when (this) {
    DeviceFeature.COMPRESSION -> R.string.dev_feature_compression
    DeviceFeature.RESUME -> R.string.dev_feature_resume
    DeviceFeature.FOLDERS -> R.string.dev_feature_folders
    DeviceFeature.WIFI_DIRECT -> R.string.dev_feature_wifi_direct
    DeviceFeature.APK_BUNDLE -> R.string.dev_feature_apk_bundle
}
