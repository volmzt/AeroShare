package com.aero.share.network.discovery

import com.aero.share.transfer.model.DeviceKind
import com.aero.share.transfer.security.Fingerprints
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.CodingErrorAction

/** A decoded datagram of the AERO presence protocol. */
sealed interface Beacon {
    /** "Who is there?" Visible devices answer with a unicast [Presence] to the sender. */
    data object Query : Beacon

    /**
     * "I am here" ([goodbye] = false) or "I am leaving" ([goodbye] = true). The device id is the first 32 characters of
     * the certificate fingerprint (as everywhere in AERO SHARE), so it is not sent separately and cannot disagree with it.
     * Nothing in a beacon is authenticated; the TLS handshake with the pinned fingerprint is what proves identity.
     */
    data class Presence(
        val goodbye: Boolean,
        val fingerprint: String,
        val name: String,
        val kind: DeviceKind,
        val port: Int,
        val appVersion: String,
        val capabilities: Int,
    ) : Beacon {
        val deviceId: String get() = fingerprint.take(DEVICE_ID_LENGTH)
    }

    companion object {
        const val DEVICE_ID_LENGTH = 32
    }
}

/**
 * Wire format of the multicast beacon (UDP, group 239.255.42.99, port 47475), all numbers big-endian:
 *
 *     "AEROB1" | type u8 (1 announce, 2 query, 3 goodbye)
 *     announce / goodbye only: fingerprint[32] | nameLen u8 | name (UTF-8) | kind u8 | port u16 | versionLen u8 | version | capabilities u32
 *
 * Parsing is strict: any malformed, truncated, oversized or over-long datagram yields null. Pure Kotlin, unit tested.
 */
object BeaconCodec {
    const val GROUP = "239.255.42.99"
    const val PORT = 47475
    const val MAX_DATAGRAM = 512
    const val MAX_NAME_BYTES = 60
    const val MAX_VERSION_BYTES = 32
    const val TYPE_ANNOUNCE = 1
    const val TYPE_QUERY = 2
    const val TYPE_GOODBYE = 3
    private const val FINGERPRINT_BYTES = 32
    private val magic = "AEROB1".toByteArray(Charsets.US_ASCII)

    fun encodeQuery(): ByteArray = magic + byteArrayOf(TYPE_QUERY.toByte())

    fun encode(presence: Beacon.Presence): ByteArray {
        val fingerprint = Fingerprints.fromHex(presence.fingerprint)
        require(Fingerprints.isValid(presence.fingerprint) && fingerprint != null && fingerprint.size == FINGERPRINT_BYTES) { "bad fingerprint" }
        require(presence.port in 1..65535) { "bad port" }
        val name = DiscoveryText.clean(presence.name, MAX_NAME_BYTES).toByteArray(Charsets.UTF_8)
        val version = DiscoveryText.clean(presence.appVersion, MAX_VERSION_BYTES).toByteArray(Charsets.UTF_8)
        val out = ByteArrayOutputStream(160)
        out.write(magic)
        out.write(if (presence.goodbye) TYPE_GOODBYE else TYPE_ANNOUNCE)
        out.write(fingerprint)
        out.write(name.size)
        out.write(name)
        out.write(presence.kind.code and 0xFF)
        out.write(presence.port ushr 8)
        out.write(presence.port)
        out.write(version.size)
        out.write(version)
        out.write(presence.capabilities ushr 24)
        out.write(presence.capabilities ushr 16)
        out.write(presence.capabilities ushr 8)
        out.write(presence.capabilities)
        return out.toByteArray()
    }

    /** Decodes the first [length] bytes of [data]. Returns null for anything that is not a well-formed beacon. */
    fun decode(data: ByteArray, length: Int = data.size): Beacon? {
        if (length < magic.size + 1 || length > MAX_DATAGRAM || length > data.size) return null
        for (index in magic.indices) {
            if (data[index] != magic[index]) return null
        }
        val type = data[magic.size].toInt() and 0xFF
        var pos = magic.size + 1
        when (type) {
            TYPE_QUERY -> return if (pos == length) Beacon.Query else null
            TYPE_ANNOUNCE, TYPE_GOODBYE -> Unit
            else -> return null
        }

        if (pos + FINGERPRINT_BYTES > length) return null
        val fingerprint = Fingerprints.toHex(data.copyOfRange(pos, pos + FINGERPRINT_BYTES))
        pos += FINGERPRINT_BYTES

        if (pos >= length) return null
        val nameLength = data[pos].toInt() and 0xFF
        pos += 1
        if (nameLength > MAX_NAME_BYTES || pos + nameLength > length) return null
        val name = decodeText(data, pos, nameLength) ?: return null
        pos += nameLength

        if (pos >= length) return null
        val kind = DeviceKind.fromCode(data[pos].toInt() and 0xFF)
        pos += 1

        if (pos + 2 > length) return null
        val port = ((data[pos].toInt() and 0xFF) shl 8) or (data[pos + 1].toInt() and 0xFF)
        pos += 2
        if (port == 0) return null

        if (pos >= length) return null
        val versionLength = data[pos].toInt() and 0xFF
        pos += 1
        if (versionLength > MAX_VERSION_BYTES || pos + versionLength > length) return null
        val version = decodeText(data, pos, versionLength) ?: return null
        pos += versionLength

        if (pos + 4 != length) return null
        val capabilities = ((data[pos].toInt() and 0xFF) shl 24) or
            ((data[pos + 1].toInt() and 0xFF) shl 16) or
            ((data[pos + 2].toInt() and 0xFF) shl 8) or
            (data[pos + 3].toInt() and 0xFF)

        return Beacon.Presence(
            goodbye = type == TYPE_GOODBYE,
            fingerprint = fingerprint,
            name = name,
            kind = kind,
            port = port,
            appVersion = version,
            capabilities = capabilities,
        )
    }

    private fun decodeText(data: ByteArray, offset: Int, length: Int): String? =
        try {
            val text = Charsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(data, offset, length))
                .toString()
            if (DiscoveryText.hasControlChars(text)) null else text
        } catch (e: CharacterCodingException) {
            null
        }
}
