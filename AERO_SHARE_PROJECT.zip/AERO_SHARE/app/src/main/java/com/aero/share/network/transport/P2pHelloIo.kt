package com.aero.share.network.transport

import java.io.Closeable
import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.SocketAddress
import java.net.SocketException
import java.net.SocketTimeoutException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext

/** Receives [P2pHello] datagrams. Opened before a Wi-Fi Direct connection is requested and closed when it is done. */
internal class P2pHelloListener private constructor(private val socket: DatagramSocket) : Closeable {
    val localPort: Int get() = socket.localPort

    /** Waits for a valid hello accepted by [accept]; returns the address it came from, or null after [timeoutMs]. */
    suspend fun await(timeoutMs: Long, accept: (P2pHello.Hello) -> Boolean): InetAddress? = withContext(Dispatchers.IO) {
        val deadline = System.nanoTime() + timeoutMs * 1_000_000L
        val buffer = ByteArray(128)
        val packet = DatagramPacket(buffer, buffer.size)
        var result: InetAddress? = null
        while (result == null && isActive) {
            val remainingMs = (deadline - System.nanoTime()) / 1_000_000L
            if (remainingMs <= 0L) break
            try {
                socket.soTimeout = minOf(remainingMs, SLICE_MS).toInt().coerceAtLeast(1)
                packet.length = buffer.size
                socket.receive(packet)
            } catch (e: SocketTimeoutException) {
                continue
            } catch (e: SocketException) {
                break
            } catch (e: IOException) {
                break
            }
            val hello = P2pHello.decode(buffer, packet.length)
            if (hello != null && accept(hello)) result = packet.address
        }
        result
    }

    override fun close() {
        try {
            socket.close()
        } catch (e: RuntimeException) {
            // already closed
        }
    }

    companion object {
        private const val SLICE_MS = 500L

        /** Null when the port cannot be bound (for example another app uses it). */
        fun open(port: Int = P2pHello.PORT): P2pHelloListener? {
            return try {
                val socket = DatagramSocket(null as SocketAddress?)
                try {
                    socket.reuseAddress = true
                    socket.bind(InetSocketAddress(port))
                } catch (e: IOException) {
                    socket.close()
                    return null
                }
                P2pHelloListener(socket)
            } catch (e: IOException) {
                null
            } catch (e: SecurityException) {
                null
            }
        }
    }
}

internal object P2pHelloSender {
    /**
     * Blocking: sends [repeat] datagrams [intervalMs] apart (UDP may lose the first ones while the link comes up).
     * Returns false when nothing could be sent.
     */
    fun send(host: String, port: Int, fingerprint: String, tlsPort: Int, repeat: Int = 3, intervalMs: Long = 600L): Boolean {
        val payload = P2pHello.encode(fingerprint, tlsPort) ?: return false
        var sent = false
        try {
            DatagramSocket().use { socket ->
                val target = InetSocketAddress(InetAddress.getByName(host), port)
                for (i in 0 until repeat) {
                    try {
                        socket.send(DatagramPacket(payload, payload.size, target))
                        sent = true
                    } catch (e: IOException) {
                        // try again with the next datagram
                    }
                    if (i < repeat - 1) Thread.sleep(intervalMs)
                }
            }
        } catch (e: IOException) {
            return sent
        } catch (e: InterruptedException) {
            Thread.currentThread().interrupt()
        }
        return sent
    }
}
