package com.aero.share.feature.send

import androidx.annotation.StringRes
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Android
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.aero.share.R
import com.aero.share.core.designsystem.AeroCard
import com.aero.share.core.designsystem.AeroEmptyState
import com.aero.share.core.designsystem.AeroIcon
import com.aero.share.core.designsystem.AeroProgressBar
import com.aero.share.core.designsystem.AeroSectionHeader
import com.aero.share.core.designsystem.AeroText
import com.aero.share.core.designsystem.AeroTextField
import com.aero.share.core.designsystem.AeroTheme
import com.aero.share.domain.AppItem

/**
 * The tabs whose files Android only lets an app reach through its own file picker (documents, downloads, other files,
 * folders): a short explanation and the button that opens that picker. While a chosen folder is counted it shows progress.
 */
@Composable
internal fun SystemPickerPanel(
    icon: ImageVector,
    @StringRes title: Int,
    @StringRes text: Int,
    @StringRes action: Int,
    onClick: () -> Unit,
    busy: Boolean = false,
) {
    CenteredScroll {
        if (busy) {
            AeroEmptyState(
                icon = icon,
                title = stringResource(R.string.send_folder_counting_title),
                message = stringResource(R.string.send_folder_counting_text),
            )
            Spacer(Modifier.height(12.dp))
            AeroProgressBar(progress = 0f, modifier = Modifier.width(160.dp), indeterminate = true)
        } else {
            AeroEmptyState(
                icon = icon,
                title = stringResource(title),
                message = stringResource(text),
                actionText = stringResource(action),
                onAction = onClick,
            )
        }
    }
}

/** Installed apps with a search field, plus a card for APK files stored on the device. */
@Composable
internal fun AppsTab(
    state: AppsState,
    query: String,
    onQueryChange: (String) -> Unit,
    selectedIds: Set<String>,
    cachedIcon: (String) -> ImageBitmap?,
    loadIcon: suspend (String, Int) -> ImageBitmap?,
    onToggle: (AppItem) -> Unit,
    onChooseApk: () -> Unit,
    onRetry: () -> Unit,
) {
    val colors = AeroTheme.colors
    val padding = AeroTheme.dimens.screenPadding
    val filtered = remember(state.apps, query) { PickerLogic.filterApps(state.apps, query) }
    LazyColumn(modifier = Modifier.fillMaxSize()) {
        item(key = "search") {
            AeroTextField(
                value = query,
                onValueChange = onQueryChange,
                modifier = Modifier.fillMaxWidth().padding(horizontal = padding, vertical = 8.dp),
                placeholder = stringResource(R.string.send_apps_search),
            )
        }
        item(key = "apk-files") {
            AeroCard(modifier = Modifier.padding(horizontal = padding, vertical = 4.dp), onClick = onChooseApk) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        AeroText(text = stringResource(R.string.send_apps_apk_title), style = AeroTheme.typography.bodyStrong)
                        AeroText(
                            text = stringResource(R.string.send_apps_apk_text),
                            style = AeroTheme.typography.caption,
                            color = colors.textSecondary,
                        )
                    }
                    Spacer(Modifier.width(12.dp))
                    AeroIcon(icon = Icons.Rounded.Android, contentDescription = null, tint = colors.accentText, size = 28.dp)
                }
            }
        }
        item(key = "installed-header") {
            AeroSectionHeader(text = stringResource(R.string.send_apps_installed), modifier = Modifier.padding(horizontal = padding))
        }
        when {
            state.failed -> item(key = "apps-error") {
                AeroEmptyState(
                    icon = Icons.Rounded.Warning,
                    title = stringResource(R.string.send_apps_error_title),
                    message = stringResource(R.string.send_apps_error_text),
                    modifier = Modifier.padding(horizontal = padding),
                    actionText = stringResource(R.string.common_retry),
                    onAction = onRetry,
                )
            }
            !state.loaded -> item(key = "apps-loading") {
                Box(modifier = Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                    AeroProgressBar(progress = 0f, modifier = Modifier.width(160.dp), indeterminate = true)
                }
            }
            filtered.isEmpty() -> item(key = "apps-empty") {
                AeroEmptyState(
                    icon = Icons.Rounded.Search,
                    title = stringResource(R.string.send_apps_empty_title),
                    message = stringResource(R.string.send_apps_empty_text),
                    modifier = Modifier.padding(horizontal = padding),
                )
            }
            else -> items(filtered, key = { app -> app.id }, contentType = { "app" }) { app ->
                AppRow(
                    app = app,
                    selected = app.id in selectedIds,
                    cachedIcon = cachedIcon,
                    loadIcon = loadIcon,
                    onToggle = { onToggle(app) },
                )
            }
        }
    }
}
