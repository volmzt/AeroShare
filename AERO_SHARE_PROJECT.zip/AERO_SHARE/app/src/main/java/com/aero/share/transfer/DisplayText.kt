package com.aero.share.transfer

/**
 * Cleans text that came from another device before it is shown to the user or put into a notification: control characters
 * and invisible/bidirectional formatting characters (which can be used to spoof a name) are replaced by spaces, runs of
 * whitespace are collapsed and the length is limited.
 */
internal object DisplayText {
    const val MAX_NAME = 60

    private val manySpaces = Regex("\\s{2,}")

    fun clean(raw: String, max: Int = MAX_NAME): String {
        val builder = StringBuilder(raw.length)
        for (ch in raw) {
            val code = ch.code
            val unsafe = code < 0x20 || code == 0x7F || code in 0x80..0x9F ||
                code in 0x200B..0x200F || code in 0x202A..0x202E || code in 0x2066..0x2069 || code == 0xFEFF
            builder.append(if (unsafe) ' ' else ch)
        }
        val collapsed = manySpaces.replace(builder.toString().trim(), " ")
        if (collapsed.length <= max) return collapsed
        val cut = collapsed.substring(0, max)
        val safe = if (cut.isNotEmpty() && cut.last().isHighSurrogate()) cut.dropLast(1) else cut
        return safe.trimEnd()
    }
}
