package com.aero.share.network.transport

import com.aero.share.transfer.pairing.HotspotCredentials

/** Turns what the platform reports about a local-only hotspot into credentials that fit into a pairing QR code. */
internal object HotspotRules {
    const val MAX_SSID_CHARS = 32
    const val MIN_PASSPHRASE_CHARS = 8
    const val MAX_PASSPHRASE_CHARS = 63

    /** Null when the values cannot be put into a QR code (the same limits as [com.aero.share.transfer.pairing.QrPayload]). */
    fun build(ssid: String?, passphrase: String?): HotspotCredentials? {
        val name = unquote(ssid) ?: return null
        val secret = unquote(passphrase) ?: return null
        if (name.length !in 1..MAX_SSID_CHARS) return null
        if (secret.length !in MIN_PASSPHRASE_CHARS..MAX_PASSPHRASE_CHARS) return null
        if (name.any { it.code < 0x20 } || secret.any { it.code < 0x20 }) return null
        return HotspotCredentials(name, secret)
    }

    /** Older platform versions report some values wrapped in double quotes. */
    private fun unquote(value: String?): String? {
        if (value == null) return null
        return if (value.length >= 2 && value.startsWith("\"") && value.endsWith("\"")) {
            value.substring(1, value.length - 1)
        } else {
            value
        }
    }
}
