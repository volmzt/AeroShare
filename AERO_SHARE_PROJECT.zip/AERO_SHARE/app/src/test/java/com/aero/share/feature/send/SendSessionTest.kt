package com.aero.share.feature.send

import com.aero.share.domain.AppItem
import com.aero.share.domain.FileItem
import com.aero.share.domain.FolderItem
import com.aero.share.domain.LinkQuality
import com.aero.share.domain.NearbyDevice
import com.aero.share.domain.Recipient
import com.aero.share.transfer.model.DeviceKind
import com.aero.share.transfer.model.FileCategory
import com.aero.share.transfer.model.TransportKind
import com.aero.share.transfer.pairing.QrPayload
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test

class SendSessionTest {
    private fun file(id: String, size: Long = 10L, category: FileCategory = FileCategory.DOCUMENT) = FileItem(
        id = id,
        uri = id,
        displayName = id.substringAfterLast('/'),
        size = size,
        category = category,
        mimeType = null,
        lastModified = 0L,
    )

    private fun device(id: String) = NearbyDevice(
        deviceId = id,
        name = "Device $id",
        kind = DeviceKind.PHONE,
        fingerprint = null,
        appVersion = null,
        addresses = listOf("10.0.0.2"),
        port = 47474,
        transports = setOf(TransportKind.LAN),
        quality = LinkQuality.UNKNOWN,
        lastSeenElapsed = 0L,
    )

    private fun qr(deviceId: String) = QrPayload(
        version = 1,
        deviceId = deviceId,
        name = "Scanned",
        kind = DeviceKind.PHONE,
        hosts = listOf("10.0.0.3"),
        port = 47474,
        fingerprint = "a".repeat(64),
        token = "token",
        expiresAt = 10_000L,
    )

    @Test
    fun addKeepsOrderAndIgnoresDuplicates() {
        val session = SendSession()
        session.add(listOf(file("content://a/1"), file("content://a/2")))
        session.add(listOf(file("content://a/2"), file("content://a/3")))
        assertEquals(listOf("content://a/1", "content://a/2", "content://a/3"), session.selection.value.map { it.id })
    }

    @Test
    fun addingOnlyKnownItemsKeepsTheSameList() {
        val session = SendSession()
        session.add(listOf(file("content://a/1")))
        val before = session.selection.value
        session.add(listOf(file("content://a/1")))
        assertSame(before, session.selection.value)
    }

    @Test
    fun duplicatesInsideOneBatchAreDropped() {
        val session = SendSession()
        session.add(listOf(file("x"), file("x"), file("y")))
        assertEquals(listOf("x", "y"), session.selection.value.map { it.id })
    }

    @Test
    fun toggleAddsAndRemoves() {
        val session = SendSession()
        val item = file("content://a/1")
        session.toggle(item)
        assertEquals(1, session.selection.value.size)
        session.toggle(item)
        assertTrue(session.selection.value.isEmpty())
    }

    @Test
    fun removeAndClearSelection() {
        val session = SendSession()
        session.add(listOf(file("1"), file("2"), file("3")))
        session.remove("2")
        assertEquals(listOf("1", "3"), session.selection.value.map { it.id })
        session.remove("missing")
        assertEquals(2, session.selection.value.size)
        session.clearSelection()
        assertTrue(session.selection.value.isEmpty())
    }

    @Test
    fun differentKindsOfItemsShareOneSelection() {
        val session = SendSession()
        val folder = FolderItem(id = "tree", treeUri = "tree", displayName = "Photos", size = 100L, fileCount = 3)
        val app = AppItem(id = "com.example", packageName = "com.example", displayName = "Example", versionName = "1", size = 5L, splitCount = 0)
        session.add(listOf(file("1"), folder, app))
        assertEquals(3, session.selection.value.size)
    }

    @Test
    fun recipientsAreDeduplicatedByDevice() {
        val session = SendSession()
        session.setRecipients(listOf(Recipient.Nearby(device("d1")), Recipient.Qr(qr("d1")), Recipient.Nearby(device("d2"))))
        assertEquals(2, session.recipients.value.size)
        assertTrue(session.recipients.value[0] is Recipient.Nearby)
    }

    @Test
    fun manualRecipientsAreIdentifiedByAddress() {
        assertEquals(
            RecipientKeys.of(Recipient.Manual("192.168.1.9", 47474)),
            RecipientKeys.of(Recipient.Manual(" 192.168.1.9 ", 47474)),
        )
        assertNotEquals(
            RecipientKeys.of(Recipient.Manual("192.168.1.9", 47474)),
            RecipientKeys.of(Recipient.Manual("192.168.1.9", 47475)),
        )
    }

    @Test
    fun toggleRecipientAddsAndRemoves() {
        val session = SendSession()
        val nearby = Recipient.Nearby(device("d1"))
        session.toggleRecipient(nearby)
        assertEquals(1, session.recipients.value.size)
        session.toggleRecipient(nearby)
        assertTrue(session.recipients.value.isEmpty())
    }

    @Test
    fun upsertReplacesTheSameDeviceInPlace() {
        val session = SendSession()
        session.setRecipients(listOf(Recipient.Nearby(device("d1")), Recipient.Nearby(device("d2"))))
        session.upsertRecipient(Recipient.Qr(qr("d1")))
        assertEquals(2, session.recipients.value.size)
        assertTrue(session.recipients.value[0] is Recipient.Qr)
        assertTrue(session.recipients.value[1] is Recipient.Nearby)
        session.upsertRecipient(Recipient.Manual("10.0.0.9", 47474))
        assertEquals(3, session.recipients.value.size)
    }

    @Test
    fun removeRecipientByKey() {
        val session = SendSession()
        session.setRecipients(listOf(Recipient.Nearby(device("d1")), Recipient.Nearby(device("d2"))))
        session.removeRecipient(RecipientKeys.of(Recipient.Nearby(device("d1"))))
        assertEquals(listOf("d2"), session.recipients.value.map { (it as Recipient.Nearby).device.deviceId })
    }

    @Test
    fun clearAllEmptiesBoth() {
        val session = SendSession()
        session.add(listOf(file("1")))
        session.setRecipients(listOf(Recipient.Nearby(device("d1"))))
        session.clearAll()
        assertTrue(session.selection.value.isEmpty())
        assertTrue(session.recipients.value.isEmpty())
    }
}
