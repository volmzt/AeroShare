package com.aero.share.core.storage.apk

import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.file.Files
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ApkBundleTest {

    @Test
    fun entryNamesAreValidatedStrictly() {
        assertTrue(ApkBundle.isApkEntry("base.apk"))
        assertTrue(ApkBundle.isApkEntry("split_config.arm64_v8a.apk"))
        assertTrue(ApkBundle.isApkEntry("split_config.xxhdpi.apk"))
        assertTrue(ApkBundle.isApkEntry("split_0.apk"))
        assertFalse(ApkBundle.isApkEntry("../base.apk"))
        assertFalse(ApkBundle.isApkEntry("dir/base.apk"))
        assertFalse(ApkBundle.isApkEntry("split_.apk"))
        assertFalse(ApkBundle.isApkEntry("split_a/b.apk"))
        assertFalse(ApkBundle.isApkEntry("split_a\\b.apk"))
        assertFalse(ApkBundle.isApkEntry("evil.apk"))
        assertFalse(ApkBundle.isApkEntry("aero-app.json"))
        assertFalse(ApkBundle.isApkEntry("split_" + "a".repeat(101) + ".apk"))
    }

    @Test
    fun bundleNamesAreRecognisedByExtension() {
        assertTrue(ApkBundle.isBundleName("Maps_1.2.aeroapks"))
        assertTrue(ApkBundle.isBundleName("MAPS.AEROAPKS"))
        assertFalse(ApkBundle.isBundleName("Maps.apk"))
        assertFalse(ApkBundle.isBundleName("aeroapks"))
    }

    @Test
    fun abiIsReadFromSplitNames() {
        assertEquals("arm64-v8a", ApkBundle.abiOf("split_config.arm64_v8a.apk"))
        assertEquals("armeabi-v7a", ApkBundle.abiOf("split_config.armeabi_v7a.apk"))
        assertEquals("x86_64", ApkBundle.abiOf("split_config.x86_64.apk"))
        assertEquals("x86", ApkBundle.abiOf("split_config.x86.apk"))
        assertNull(ApkBundle.abiOf("split_config.xxhdpi.apk"))
        assertNull(ApkBundle.abiOf("split_config.en.apk"))
        assertNull(ApkBundle.abiOf("split_config.apk"))
        assertNull(ApkBundle.abiOf("split_config..apk"))
        assertNull(ApkBundle.abiOf("base.apk"))
        assertNull(ApkBundle.abiOf(""))
    }

    @Test
    fun buildThenReadKeepsOrderAndContent() {
        val dir = Files.createTempDirectory("aero-bundle").toFile()
        try {
            val base = File(dir, "b.apk").also { it.writeBytes(ByteArray(300_000) { i -> (i % 251).toByte() }) }
            val s1 = File(dir, "s1").also { it.writeBytes("ARM".toByteArray()) }
            val s2 = File(dir, "s2").also { it.writeBytes(ByteArray(0)) }
            val target = File(dir, "out/app.aeroapks")
            ApkBundle.build(
                target,
                """{"format":1}""",
                base,
                listOf("split_config.arm64_v8a.apk" to s1, "split_config.xxhdpi.apk" to s2),
            )

            val names = ArrayList<String>()
            val contents = HashMap<String, ByteArray>()
            ZipInputStream(FileInputStream(target)).use { zip ->
                ApkBundle.forEachEntry(zip) { name ->
                    names.add(name)
                    contents[name] = zip.readBytes()
                }
            }
            assertEquals(listOf("aero-app.json", "base.apk", "split_config.arm64_v8a.apk", "split_config.xxhdpi.apk"), names)
            assertEquals("""{"format":1}""", String(contents.getValue("aero-app.json"), Charsets.UTF_8))
            assertTrue(base.readBytes().contentEquals(contents.getValue("base.apk")))
            assertEquals("ARM", String(contents.getValue("split_config.arm64_v8a.apk"), Charsets.UTF_8))
            assertEquals(0, contents.getValue("split_config.xxhdpi.apk").size)
        } finally {
            dir.deleteRecursively()
        }
    }

    @Test
    fun foreignAndNestedEntriesAreSkipped() {
        val dir = Files.createTempDirectory("aero-bundle").toFile()
        try {
            val file = File(dir, "x.aeroapks")
            ZipOutputStream(FileOutputStream(file)).use { zip ->
                for (name in listOf("../evil.apk", "lib/arm64/libx.so", "readme.txt", "base.apk", "dir/", "split_ok.apk")) {
                    zip.putNextEntry(ZipEntry(name))
                    if (!name.endsWith("/")) zip.write(name.toByteArray())
                    zip.closeEntry()
                }
            }
            val seen = ArrayList<String>()
            ZipInputStream(FileInputStream(file)).use { zip ->
                ApkBundle.forEachEntry(zip) { name -> seen.add(name) }
            }
            assertEquals(listOf("base.apk", "split_ok.apk"), seen)
        } finally {
            dir.deleteRecursively()
        }
    }

    @Test
    fun invalidSplitListsAreRejectedBeforeAnythingIsWritten() {
        val dir = Files.createTempDirectory("aero-bundle").toFile()
        try {
            val base = File(dir, "b.apk").also { it.writeBytes(byteArrayOf(1)) }
            val s = File(dir, "s").also { it.writeBytes(byteArrayOf(2)) }
            val target = File(dir, "t.aeroapks")
            assertThrowsIllegal { ApkBundle.build(target, "{}", base, listOf("../x.apk" to s)) }
            assertThrowsIllegal { ApkBundle.build(target, "{}", base, listOf("base.apk" to s)) }
            assertThrowsIllegal { ApkBundle.build(target, "{}", base, listOf("split_a.apk" to s, "split_a.apk" to s)) }
            assertFalse(target.exists())
        } finally {
            dir.deleteRecursively()
        }
    }

    private fun assertThrowsIllegal(block: () -> Unit) {
        try {
            block()
        } catch (e: IllegalArgumentException) {
            return
        }
        throw AssertionError("IllegalArgumentException expected")
    }
}
