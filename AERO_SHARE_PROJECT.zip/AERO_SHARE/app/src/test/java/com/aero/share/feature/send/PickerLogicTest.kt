package com.aero.share.feature.send

import com.aero.share.domain.AppItem
import com.aero.share.domain.FileItem
import com.aero.share.transfer.model.FileCategory
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test

class PickerLogicTest {
    private fun entry(id: String, added: Long, kind: MediaKind = MediaKind.IMAGE) = MediaEntry(
        item = FileItem(
            id = id,
            uri = id,
            displayName = id,
            size = 1L,
            category = PickerLogic.categoryOf(kind),
            mimeType = null,
            lastModified = added,
        ),
        kind = kind,
        addedMillis = added,
        durationMillis = 0L,
    )

    private fun app(name: String, pkg: String) =
        AppItem(id = pkg, packageName = pkg, displayName = name, versionName = null, size = 1L, splitCount = 0)

    @Test
    fun mediaTabsListTheirCollections() {
        assertEquals(listOf(MediaKind.IMAGE, MediaKind.VIDEO, MediaKind.AUDIO), PickerLogic.kindsOf(PickerTab.RECENT))
        assertEquals(listOf(MediaKind.IMAGE), PickerLogic.kindsOf(PickerTab.IMAGES))
        assertEquals(listOf(MediaKind.VIDEO), PickerLogic.kindsOf(PickerTab.VIDEOS))
        assertEquals(listOf(MediaKind.AUDIO), PickerLogic.kindsOf(PickerTab.AUDIO))
    }

    @Test
    fun otherTabsAreNotMediaTabs() {
        for (tab in listOf(PickerTab.DOCUMENTS, PickerTab.DOWNLOADS, PickerTab.APPS, PickerTab.OTHER, PickerTab.FOLDERS)) {
            assertFalse(tab.name, PickerLogic.isMediaTab(tab))
        }
        assertTrue(PickerLogic.isMediaTab(PickerTab.RECENT))
    }

    @Test
    fun everyTabIsListedOnce() {
        assertEquals(PickerTab.values().size, PickerTab.values().toSet().size)
        assertEquals(9, PickerTab.values().size)
    }

    @Test
    fun categoriesFollowKinds() {
        assertEquals(
            setOf(FileCategory.IMAGE, FileCategory.VIDEO, FileCategory.AUDIO),
            PickerLogic.categoriesOf(PickerLogic.kindsOf(PickerTab.RECENT)),
        )
        assertEquals(setOf(FileCategory.AUDIO), PickerLogic.categoriesOf(listOf(MediaKind.AUDIO)))
    }

    @Test
    fun fullPermissionGivesFullAccess() {
        assertEquals(MediaAccess.FULL, PickerLogic.accessOf(34, MediaKind.IMAGE, true, false))
        assertEquals(MediaAccess.FULL, PickerLogic.accessOf(30, MediaKind.AUDIO, true, false))
    }

    @Test
    fun selectedPhotosGivePartialAccessOnAndroid14() {
        assertEquals(MediaAccess.PARTIAL, PickerLogic.accessOf(34, MediaKind.IMAGE, false, true))
        assertEquals(MediaAccess.PARTIAL, PickerLogic.accessOf(35, MediaKind.VIDEO, false, true))
    }

    @Test
    fun audioHasNoPartialAccess() {
        assertEquals(MediaAccess.NONE, PickerLogic.accessOf(34, MediaKind.AUDIO, false, true))
    }

    @Test
    fun partialAccessDoesNotExistBeforeAndroid14() {
        assertEquals(MediaAccess.NONE, PickerLogic.accessOf(33, MediaKind.IMAGE, false, true))
        assertEquals(MediaAccess.NONE, PickerLogic.accessOf(29, MediaKind.IMAGE, false, false))
    }

    @Test
    fun tabAccessCombinesCollections() {
        assertEquals(MediaAccess.NONE, PickerLogic.tabAccess(emptyList()))
        assertEquals(MediaAccess.FULL, PickerLogic.tabAccess(listOf(MediaAccess.FULL, MediaAccess.FULL)))
        assertEquals(MediaAccess.NONE, PickerLogic.tabAccess(listOf(MediaAccess.NONE, MediaAccess.NONE)))
        assertEquals(MediaAccess.PARTIAL, PickerLogic.tabAccess(listOf(MediaAccess.FULL, MediaAccess.NONE)))
        assertEquals(MediaAccess.PARTIAL, PickerLogic.tabAccess(listOf(MediaAccess.PARTIAL, MediaAccess.FULL)))
        assertEquals(MediaAccess.PARTIAL, PickerLogic.tabAccess(listOf(MediaAccess.PARTIAL)))
    }

    @Test
    fun appendSkipsEntriesThatAreAlreadyLoaded() {
        val first = listOf(entry("a", 3L), entry("b", 2L))
        val merged = PickerLogic.append(first, listOf(entry("b", 2L), entry("c", 1L)))
        assertEquals(listOf("a", "b", "c"), merged.map { it.item.id })
    }

    @Test
    fun appendOfNothingKeepsTheList() {
        val first = listOf(entry("a", 3L))
        assertSame(first, PickerLogic.append(first, emptyList()))
        assertSame(first, PickerLogic.append(first, listOf(entry("a", 3L))))
    }

    @Test
    fun recentIsNewestFirstAndLimited() {
        val images = listOf(entry("i1", 100L), entry("i2", 50L))
        val videos = listOf(entry("v1", 80L, MediaKind.VIDEO))
        val audio = listOf(entry("a1", 120L, MediaKind.AUDIO))
        val merged = PickerLogic.mergeRecent(listOf(images, videos, audio), 3)
        assertEquals(listOf("a1", "i1", "v1"), merged.map { it.item.id })
    }

    @Test
    fun sampleSizeKeepsBothSidesAtLeastTheTarget() {
        assertEquals(1, PickerLogic.sampleSizeFor(200, 200, 256))
        assertEquals(1, PickerLogic.sampleSizeFor(500, 500, 256))
        assertEquals(2, PickerLogic.sampleSizeFor(512, 512, 256))
        assertEquals(8, PickerLogic.sampleSizeFor(4000, 3000, 256))
        assertEquals(4, PickerLogic.sampleSizeFor(4000, 1200, 256))
    }

    @Test
    fun sampleSizeOfNonsenseIsOne() {
        assertEquals(1, PickerLogic.sampleSizeFor(0, 100, 256))
        assertEquals(1, PickerLogic.sampleSizeFor(100, 100, 0))
    }

    @Test
    fun appFilterMatchesNameAndPackage() {
        val apps = listOf(app("Camera", "com.vendor.cam"), app("Notes", "org.notes.app"), app("Calc", "com.vendor.calc"))
        assertEquals(3, PickerLogic.filterApps(apps, "  ").size)
        assertEquals(listOf("Camera"), PickerLogic.filterApps(apps, "camera").map { it.displayName })
        assertEquals(listOf("Camera", "Calc"), PickerLogic.filterApps(apps, "VENDOR").map { it.displayName })
        assertTrue(PickerLogic.filterApps(apps, "zzz").isEmpty())
    }
}
