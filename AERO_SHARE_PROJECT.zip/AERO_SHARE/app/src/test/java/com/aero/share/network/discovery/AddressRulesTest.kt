package com.aero.share.network.discovery

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class AddressRulesTest {
    private val lan = listOf(LocalSubnet("192.168.1.20", 24))

    @Test
    fun ipv4ParsingIsStrict() {
        assertEquals(0xC0A80105.toInt(), AddressRules.ipv4ToInt("192.168.1.5"))
        for (bad in listOf("", "1.2.3", "1.2.3.4.5", "256.1.1.1", "1.2.3.-4", "a.b.c.d", "1..2.3", "1.2.3.4444", " 1.2.3.4", "1.2.3.4 ")) {
            assertNull("'$bad'", AddressRules.ipv4ToInt(bad))
        }
    }

    @Test
    fun addressesOutsideTheLocalSubnetAreDropped() {
        assertEquals(listOf("192.168.1.7"), AddressRules.usable(listOf("10.1.2.3", "192.168.1.7", "192.168.2.7"), lan))
    }

    @Test
    fun everythingIsKeptWhenTheSubnetsAreUnknown() {
        assertEquals(listOf("10.1.2.3", "192.168.1.7"), AddressRules.usable(listOf("10.1.2.3", "192.168.1.7"), emptyList()))
    }

    @Test
    fun widerPrefixesAreHonoured() {
        val wide = listOf(LocalSubnet("10.20.30.40", 16))
        assertEquals(listOf("10.20.99.1"), AddressRules.usable(listOf("10.20.99.1", "10.21.0.1"), wide))
    }

    @Test
    fun loopbackWildcardMulticastAndReservedAreDropped() {
        val input = listOf("127.0.0.1", "0.0.0.0", "224.0.0.251", "239.255.42.99", "240.0.0.1", "255.255.255.255")
        assertEquals(emptyList<String>(), AddressRules.usable(input, emptyList()))
    }

    @Test
    fun ipv4ComesFirstAndDuplicatesAreRemoved() {
        val input = listOf("2001:db8::5", "192.168.1.9", "192.168.1.9", "/192.168.1.8", "fd00::7")
        assertEquals(listOf("192.168.1.9", "192.168.1.8", "2001:db8::5", "fd00::7"), AddressRules.usable(input, lan))
    }

    @Test
    fun linkLocalLoopbackAndMulticastIpv6AreDropped() {
        val input = listOf("fe80::1", "FE80::2", "feb0::3", "fe80::1%wlan0", "::1", "::", "ff02::fb", "not-an-address", "::ffff:1.2.3.4")
        assertEquals(emptyList<String>(), AddressRules.usable(input, lan))
    }

    @Test
    fun ipv4LinkLocalIsAllowedForAdHocNetworks() {
        assertEquals(listOf("169.254.10.2"), AddressRules.usable(listOf("169.254.10.2"), listOf(LocalSubnet("169.254.10.1", 16))))
    }
}
