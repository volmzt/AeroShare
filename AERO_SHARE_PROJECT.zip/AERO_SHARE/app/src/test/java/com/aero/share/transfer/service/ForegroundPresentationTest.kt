package com.aero.share.transfer.service

import com.aero.share.transfer.model.TransferDirection
import com.aero.share.transfer.model.TransferState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ForegroundPresentationTest {
    private fun transfer(
        id: String = "t1",
        direction: TransferDirection = TransferDirection.SEND,
        state: TransferState = TransferState.TRANSFERRING,
        done: Long = 250L,
        total: Long = 1_000L,
        speed: Long = 100L,
    ) = ServiceTransfer(id, direction, state, done, total, speed)

    private fun stateOf(vararg transfers: ServiceTransfer, waiting: Int = 0, receiving: Boolean = false) =
        ServiceState(active = transfers.toList(), waiting = waiting, receiving = receiving)

    @Test
    fun aSendingTransferShowsMeasuredProgressWithPauseAndCancel() {
        val p = ForegroundPresentation.of(stateOf(transfer()))
        assertEquals(Phase.SENDING, p.phase)
        assertEquals("t1", p.primaryId)
        assertTrue(p.showProgress)
        assertFalse(p.indeterminate)
        assertEquals(250, p.progress)
        assertEquals(listOf(ServiceAction.PAUSE, ServiceAction.CANCEL), p.actions)
        assertTrue(p.showsSizes)
        assertEquals(100L, p.bytesPerSecond)
    }

    @Test
    fun aReceivingTransferIsToldApart() {
        val p = ForegroundPresentation.of(stateOf(transfer(direction = TransferDirection.RECEIVE)))
        assertEquals(Phase.RECEIVING, p.phase)
    }

    @Test
    fun aPausedTransferOffersResume() {
        val p = ForegroundPresentation.of(stateOf(transfer(state = TransferState.PAUSED)))
        assertEquals(Phase.PAUSED, p.phase)
        assertEquals(listOf(ServiceAction.RESUME, ServiceAction.CANCEL), p.actions)
        assertTrue(p.showsSizes)
        assertEquals(250, p.progress)
    }

    @Test
    fun connectingHasAnUnmeasuredBarAndOnlyCancel() {
        val p = ForegroundPresentation.of(stateOf(transfer(state = TransferState.CONNECTING, done = 0L, total = 0L)))
        assertEquals(Phase.CONNECTING, p.phase)
        assertTrue(p.indeterminate)
        assertEquals(0, p.progress)
        assertEquals(listOf(ServiceAction.CANCEL), p.actions)
        assertFalse(p.showsSizes)
    }

    @Test
    fun waitingForTheOtherUserAndPreparingAreRecognised() {
        assertEquals(Phase.AWAITING, ForegroundPresentation.of(stateOf(transfer(state = TransferState.AWAITING_ACCEPTANCE))).phase)
        assertEquals(Phase.PREPARING, ForegroundPresentation.of(stateOf(transfer(state = TransferState.PREPARING))).phase)
        assertEquals(Phase.PREPARING, ForegroundPresentation.of(stateOf(transfer(state = TransferState.WAITING))).phase)
    }

    @Test
    fun verifyingIsMeasuredButCannotBePaused() {
        val p = ForegroundPresentation.of(stateOf(transfer(state = TransferState.VERIFYING, done = 1_000L)))
        assertEquals(Phase.VERIFYING, p.phase)
        assertEquals(ForegroundPresentation.PROGRESS_MAX, p.progress)
        assertEquals(listOf(ServiceAction.CANCEL), p.actions)
        assertFalse(p.showsSizes)
    }

    @Test
    fun anUnknownTotalNeverShowsAFakePercentage() {
        val p = ForegroundPresentation.of(stateOf(transfer(done = 500L, total = 0L)))
        assertTrue(p.indeterminate)
        assertEquals(0, p.progress)
        assertFalse(p.showsSizes)
    }

    @Test
    fun progressIsClampedToTheBarRange() {
        assertEquals(ForegroundPresentation.PROGRESS_MAX, ForegroundPresentation.of(stateOf(transfer(done = 5_000L, total = 1_000L))).progress)
        assertEquals(0, ForegroundPresentation.of(stateOf(transfer(done = -5L, total = 1_000L))).progress)
    }

    @Test
    fun hugeTransfersAreMeasuredWithoutOverflow() {
        val twentyGiB = 20L * 1024 * 1024 * 1024
        val p = ForegroundPresentation.of(stateOf(transfer(done = twentyGiB / 2, total = twentyGiB)))
        assertEquals(500, p.progress)
    }

    @Test
    fun theRunningTransferIsPreferredAsThePrimaryOne() {
        val p = ForegroundPresentation.of(
            stateOf(
                transfer(id = "queued", state = TransferState.CONNECTING),
                transfer(id = "paused", state = TransferState.PAUSED),
                transfer(id = "running", state = TransferState.TRANSFERRING),
            ),
        )
        assertEquals("running", p.primaryId)
        val noRunning = ForegroundPresentation.of(
            stateOf(transfer(id = "connecting", state = TransferState.CONNECTING), transfer(id = "verifying", state = TransferState.VERIFYING)),
        )
        assertEquals("verifying", noRunning.primaryId)
        val onlyPaused = ForegroundPresentation.of(
            stateOf(transfer(id = "connecting", state = TransferState.CONNECTING), transfer(id = "paused", state = TransferState.PAUSED)),
        )
        assertEquals("paused", onlyPaused.primaryId)
        val first = ForegroundPresentation.of(
            stateOf(transfer(id = "one", state = TransferState.CONNECTING), transfer(id = "two", state = TransferState.PREPARING)),
        )
        assertEquals("one", first.primaryId)
    }

    @Test
    fun aReceiverThatIsJustListeningOffersToStop() {
        val p = ForegroundPresentation.of(stateOf(receiving = true))
        assertEquals(Phase.READY, p.phase)
        assertNull(p.primaryId)
        assertFalse(p.showProgress)
        assertEquals(listOf(ServiceAction.STOP_RECEIVING), p.actions)
    }

    @Test
    fun queuedWorkWithNothingRunningYetShowsAnUnmeasuredBar() {
        val p = ForegroundPresentation.of(stateOf(waiting = 2))
        assertEquals(Phase.QUEUED, p.phase)
        assertNull(p.primaryId)
        assertTrue(p.showProgress)
        assertTrue(p.indeterminate)
        assertTrue(p.actions.isEmpty())
    }
}
