package com.aero.share.transfer

import com.aero.share.domain.PowerMode
import org.junit.Assert.assertEquals
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test

class PowerProfilesTest {
    @Test
    fun balancedIsUsedForTheBalancedMode() {
        assertSame(PowerProfiles.BALANCED, PowerProfiles.of(PowerMode.BALANCED, constrained = false))
        assertSame(PowerProfiles.BALANCED, PowerProfiles.of(PowerMode.BALANCED, constrained = true))
    }

    @Test
    fun performanceUsesBiggerBuffersAndFasterDiscovery() {
        val performance = PowerProfiles.of(PowerMode.PERFORMANCE, constrained = false)
        assertTrue(performance.chunkSize > PowerProfiles.BALANCED.chunkSize)
        assertTrue(performance.discoveryIntervalMs < PowerProfiles.BALANCED.discoveryIntervalMs)
        assertTrue(performance.lowLatencyWifi)
    }

    @Test
    fun performanceNeverOverridesAHotOrBatterySavingDevice() {
        assertSame(PowerProfiles.BALANCED, PowerProfiles.of(PowerMode.PERFORMANCE, constrained = true))
    }

    @Test
    fun energySavingDiscoversLessOftenAndUsesSmallBuffers() {
        val saving = PowerProfiles.of(PowerMode.ENERGY_SAVING, constrained = false)
        assertTrue(saving.chunkSize < PowerProfiles.BALANCED.chunkSize)
        assertTrue(saving.discoveryIntervalMs > PowerProfiles.BALANCED.discoveryIntervalMs)
        assertEquals(false, saving.lowLatencyWifi)
    }

    @Test
    fun beaconsAreNeverSlowerThanTenSecondsInAnyMode() {
        for (profile in listOf(PowerProfiles.BALANCED, PowerProfiles.PERFORMANCE, PowerProfiles.ENERGY_SAVING)) {
            assertTrue(profile.beaconIntervalMs <= 10_000L)
        }
    }

    @Test
    fun chunkSizesStayInsideWhatTheEngineAccepts() {
        for (profile in listOf(PowerProfiles.BALANCED, PowerProfiles.PERFORMANCE, PowerProfiles.ENERGY_SAVING)) {
            assertTrue(profile.chunkSize in (16 * 1024)..(1024 * 1024))
        }
    }

    @Test
    fun connectionTimeoutFromTheSettingsIsClampedAndDrivesTheIdleTimeout() {
        val normal = PowerProfiles.engineConfig(PowerProfiles.BALANCED, 15)
        assertEquals(15_000, normal.connectTimeoutMs)
        assertEquals(45_000, normal.idleTimeoutMs)

        val tiny = PowerProfiles.engineConfig(PowerProfiles.BALANCED, 1)
        assertEquals(5_000, tiny.connectTimeoutMs)
        assertEquals(30_000, tiny.idleTimeoutMs)

        val huge = PowerProfiles.engineConfig(PowerProfiles.BALANCED, 100_000)
        assertEquals(120_000, huge.connectTimeoutMs)
        assertEquals(360_000, huge.idleTimeoutMs)
    }

    @Test
    fun chunkSizeOfTheProfileReachesTheEngineConfig() {
        assertEquals(PowerProfiles.PERFORMANCE.chunkSize, PowerProfiles.engineConfig(PowerProfiles.PERFORMANCE, 15).chunkSize)
    }
}
