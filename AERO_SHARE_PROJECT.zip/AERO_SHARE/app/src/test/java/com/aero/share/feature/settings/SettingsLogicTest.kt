package com.aero.share.feature.settings

import com.aero.share.domain.AppSettings
import com.aero.share.domain.CapabilityState
import com.aero.share.domain.TransportCapability
import com.aero.share.domain.TransportMode
import com.aero.share.transfer.model.TransportKind
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SettingsLogicTest {
    private val defaults = AppSettings()

    // ---- the offered choices must contain what the app starts with, and be sorted

    @Test
    fun everyDefaultIsOneOfTheOfferedChoices() {
        assertTrue(defaults.connectionTimeoutSec in SettingsLogic.CONNECTION_TIMEOUTS)
        assertTrue(defaults.qrTtlSeconds in SettingsLogic.QR_LIFETIMES)
        assertTrue(defaults.largeTransferWarnBytes in SettingsLogic.LARGE_TRANSFER_WARN_BYTES)
        assertTrue(defaults.partialRetentionDays in SettingsLogic.PARTIAL_RETENTION_DAYS)
        assertTrue(defaults.historyRetentionDays in SettingsLogic.HISTORY_RETENTION_DAYS)
    }

    @Test
    fun choicesAreSortedAndWithoutDuplicates() {
        assertEquals(SettingsLogic.CONNECTION_TIMEOUTS.sorted().distinct(), SettingsLogic.CONNECTION_TIMEOUTS)
        assertEquals(SettingsLogic.QR_LIFETIMES.sorted().distinct(), SettingsLogic.QR_LIFETIMES)
        assertEquals(SettingsLogic.LARGE_TRANSFER_WARN_BYTES.sorted().distinct(), SettingsLogic.LARGE_TRANSFER_WARN_BYTES)
        assertEquals(SettingsLogic.PARTIAL_RETENTION_DAYS.sorted().distinct(), SettingsLogic.PARTIAL_RETENTION_DAYS)
        assertEquals(SettingsLogic.HISTORY_RETENTION_DAYS.sorted().distinct(), SettingsLogic.HISTORY_RETENTION_DAYS)
    }

    @Test
    fun noChoiceIsNegativeOrUnreasonablyShort() {
        assertTrue(SettingsLogic.CONNECTION_TIMEOUTS.all { it >= 5 })
        assertTrue(SettingsLogic.QR_LIFETIMES.all { it >= 30 })
        assertTrue(SettingsLogic.LARGE_TRANSFER_WARN_BYTES.all { it >= 0L })
        assertTrue(SettingsLogic.PARTIAL_RETENTION_DAYS.all { it >= 1 })
        assertTrue(SettingsLogic.HISTORY_RETENTION_DAYS.all { it >= 0 })
    }

    @Test
    fun largeTransferChoicesAreWholeGibibytes() {
        for (bytes in SettingsLogic.LARGE_TRANSFER_WARN_BYTES) assertEquals(0L, bytes % (1024L * 1024L * 1024L))
        assertEquals(0L, SettingsLogic.LARGE_TRANSFER_WARN_BYTES.first())
    }

    // ---- nearest

    @Test
    fun nearestKeepsAnOfferedValue() {
        for (option in SettingsLogic.CONNECTION_TIMEOUTS) assertEquals(option, SettingsLogic.nearestInt(SettingsLogic.CONNECTION_TIMEOUTS, option))
        for (option in SettingsLogic.LARGE_TRANSFER_WARN_BYTES) {
            assertEquals(option, SettingsLogic.nearestLong(SettingsLogic.LARGE_TRANSFER_WARN_BYTES, option))
        }
    }

    @Test
    fun nearestPicksTheClosestOption() {
        assertEquals(15, SettingsLogic.nearestInt(SettingsLogic.CONNECTION_TIMEOUTS, 17))
        assertEquals(30, SettingsLogic.nearestInt(SettingsLogic.CONNECTION_TIMEOUTS, 25))
        assertEquals(60, SettingsLogic.nearestInt(SettingsLogic.CONNECTION_TIMEOUTS, 500))
        assertEquals(10, SettingsLogic.nearestInt(SettingsLogic.CONNECTION_TIMEOUTS, -3))
        assertEquals(1, SettingsLogic.nearestInt(SettingsLogic.PARTIAL_RETENTION_DAYS, 0))
    }

    @Test
    fun nearestPrefersTheEarlierOptionOnATie() {
        assertEquals(10, SettingsLogic.nearestInt(listOf(10, 20), 15))
    }

    @Test
    fun nearestLongHandlesHugeValues() {
        val gib = 1024L * 1024L * 1024L
        assertEquals(10 * gib, SettingsLogic.nearestLong(SettingsLogic.LARGE_TRANSFER_WARN_BYTES, Long.MAX_VALUE))
        assertEquals(0L, SettingsLogic.nearestLong(SettingsLogic.LARGE_TRANSFER_WARN_BYTES, Long.MIN_VALUE + 1))
    }

    // ---- device name

    @Test
    fun customNameIsTrimmedAndLimited() {
        assertEquals("My phone", SettingsLogic.customNameOf("  My phone "))
        assertNull(SettingsLogic.customNameOf(""))
        assertNull(SettingsLogic.customNameOf("   "))
        assertEquals(40, SettingsLogic.customNameOf("n".repeat(200))?.length)
        assertFalse(SettingsLogic.customNameOf("a".repeat(39) + " zzz").orEmpty().endsWith(" "))
    }

    // ---- transports

    private fun cap(kind: TransportKind, state: CapabilityState) = TransportCapability(kind, state)

    @Test
    fun wifiDirectIsOnlyOfferedWhereItExists() {
        assertEquals(
            listOf(TransportMode.AUTO, TransportMode.LAN_ONLY, TransportMode.WIFI_DIRECT_PREFERRED),
            SettingsLogic.transportModes(true),
        )
        assertEquals(listOf(TransportMode.AUTO, TransportMode.LAN_ONLY), SettingsLogic.transportModes(false))
    }

    @Test
    fun aStoredWifiDirectPreferenceFallsBackToAutomaticWhereItIsMissing() {
        assertEquals(TransportMode.AUTO, SettingsLogic.effectiveTransportMode(TransportMode.WIFI_DIRECT_PREFERRED, false))
        assertEquals(TransportMode.WIFI_DIRECT_PREFERRED, SettingsLogic.effectiveTransportMode(TransportMode.WIFI_DIRECT_PREFERRED, true))
        assertEquals(TransportMode.LAN_ONLY, SettingsLogic.effectiveTransportMode(TransportMode.LAN_ONLY, false))
        for (mode in TransportMode.values()) {
            assertTrue(SettingsLogic.effectiveTransportMode(mode, false) in SettingsLogic.transportModes(false))
        }
    }

    @Test
    fun transportsAreListedInAFixedOrderAndUnsupportedOnesStayVisible() {
        val all = listOf(
            cap(TransportKind.HOTSPOT, CapabilityState.RADIO_OFF),
            cap(TransportKind.WIFI_DIRECT, CapabilityState.UNSUPPORTED),
            cap(TransportKind.LAN, CapabilityState.AVAILABLE),
            cap(TransportKind.MANUAL, CapabilityState.NO_NETWORK),
        )
        val listed = SettingsLogic.orderedTransports(all)
        assertEquals(
            listOf(TransportKind.LAN, TransportKind.WIFI_DIRECT, TransportKind.HOTSPOT, TransportKind.MANUAL),
            listed.map { it.kind },
        )
        assertEquals(CapabilityState.UNSUPPORTED, listed[1].state)
    }

    @Test
    fun wifiDirectCountsAsSupportedUnlessTheDeviceSaysItIsNot() {
        val unsupported = listOf(cap(TransportKind.WIFI_DIRECT, CapabilityState.UNSUPPORTED), cap(TransportKind.LAN, CapabilityState.AVAILABLE))
        assertFalse(SettingsLogic.wifiDirectSupported(unsupported))
        for (state in listOf(CapabilityState.AVAILABLE, CapabilityState.RADIO_OFF, CapabilityState.PERMISSION_MISSING, CapabilityState.NO_NETWORK)) {
            assertTrue(SettingsLogic.wifiDirectSupported(listOf(cap(TransportKind.WIFI_DIRECT, state))))
        }
    }

    @Test
    fun noCapabilitiesMeansNothingIsListedAndNoWifiDirect() {
        assertTrue(SettingsLogic.orderedTransports(emptyList()).isEmpty())
        assertFalse(SettingsLogic.wifiDirectSupported(emptyList()))
    }

    // ---- notifications

    @Test
    fun notificationPermissionIsOnlyNeededFromAndroid13() {
        assertFalse(SettingsLogic.needsNotificationPermission(32, false))
        assertTrue(SettingsLogic.needsNotificationPermission(33, false))
        assertTrue(SettingsLogic.needsNotificationPermission(35, false))
        assertFalse(SettingsLogic.needsNotificationPermission(35, true))
    }

    // ---- receive folder

    @Test
    fun theDefaultFolderNeedsNoPermission() {
        assertEquals(ReceiveFolder.Default, SettingsLogic.folderState(null, false, false, null))
        assertEquals(ReceiveFolder.Default, SettingsLogic.folderState("  ", true, true, "x"))
    }

    @Test
    fun aChosenFolderNeedsPersistedAccessAndWriting() {
        assertEquals(ReceiveFolder.Custom("Camera"), SettingsLogic.folderState("content://x", true, true, " Camera "))
        assertEquals(ReceiveFolder.Custom(""), SettingsLogic.folderState("content://x", true, true, null))
        assertEquals(ReceiveFolder.Unavailable, SettingsLogic.folderState("content://x", false, true, "Camera"))
        assertEquals(ReceiveFolder.Unavailable, SettingsLogic.folderState("content://x", true, false, "Camera"))
    }
}
