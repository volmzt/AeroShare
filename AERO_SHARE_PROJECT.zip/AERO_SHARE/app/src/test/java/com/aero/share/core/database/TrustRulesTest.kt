package com.aero.share.core.database

import com.aero.share.domain.DeviceRecord
import com.aero.share.transfer.model.DeviceKind
import com.aero.share.transfer.model.PeerTrust
import org.junit.Assert.assertEquals
import org.junit.Test

class TrustRulesTest {
    private fun record(id: String, fp: String, trusted: Boolean = false, blocked: Boolean = false) = DeviceRecord(
        deviceId = id, name = "n", alias = null, kind = DeviceKind.PHONE, model = null, fingerprint = fp,
        firstSeen = 0, lastSeen = 0, trusted = trusted, blocked = blocked, capabilities = 0, lastAddress = null, lastTransport = null,
    )

    private fun snap(vararg r: DeviceRecord) = r.associateBy { it.deviceId }

    @Test
    fun unknownWhenNothingIsStored() {
        assertEquals(PeerTrust.UNKNOWN, TrustRules.trustOf(emptyMap(), "a", "fa"))
    }

    @Test
    fun knownTrustedAndBlockedByMatchingFingerprint() {
        val s = snap(record("k", "fk"), record("t", "ft", trusted = true), record("b", "fb", blocked = true), record("bt", "fbt", trusted = true, blocked = true))
        assertEquals(PeerTrust.KNOWN, TrustRules.trustOf(s, "k", "fk"))
        assertEquals(PeerTrust.TRUSTED, TrustRules.trustOf(s, "t", "ft"))
        assertEquals(PeerTrust.BLOCKED, TrustRules.trustOf(s, "b", "fb"))
        assertEquals(PeerTrust.BLOCKED, TrustRules.trustOf(s, "bt", "fbt")) // block wins over trust
    }

    @Test
    fun aChangedKeyIsNeverTrusted() {
        val s = snap(record("t", "ft", trusted = true), record("b", "fb", blocked = true))
        assertEquals(PeerTrust.UNKNOWN, TrustRules.trustOf(s, "t", "other"))
        assertEquals(PeerTrust.BLOCKED, TrustRules.trustOf(s, "b", "other"))
    }

    @Test
    fun aBlockedFingerprintStaysBlockedUnderAnotherId() {
        val s = snap(record("b", "fb", blocked = true))
        assertEquals(PeerTrust.BLOCKED, TrustRules.trustOf(s, "x", "fb"))
        assertEquals(PeerTrust.UNKNOWN, TrustRules.trustOf(s, "x", "fx"))
    }
}
