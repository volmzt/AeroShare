package com.aero.share.feature.settings

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LicensesTest {
    @Test
    fun everyNoticeIsComplete() {
        for (notice in Licenses.NOTICES) {
            assertTrue(notice.name.isNotBlank())
            assertTrue(notice.author.isNotBlank())
            assertTrue(notice.license.isNotBlank())
        }
    }

    @Test
    fun namesAreUnique() {
        assertEquals(Licenses.NOTICES.size, Licenses.NOTICES.map { it.name }.distinct().size)
    }

    @Test
    fun everyRuntimeLibraryFamilyOfTheAppIsListed() {
        val names = Licenses.NOTICES.joinToString(" | ") { it.name }
        for (family in listOf("Kotlin", "coroutines", "Compose", "Navigation", "Lifecycle", "Activity", "Room", "DataStore", "WorkManager", "CameraX", "DocumentFile", "ZXing")) {
            assertTrue("missing $family", names.contains(family))
        }
    }
}
