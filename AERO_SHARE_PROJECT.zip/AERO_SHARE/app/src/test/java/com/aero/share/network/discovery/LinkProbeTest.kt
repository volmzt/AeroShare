package com.aero.share.network.discovery

import com.aero.share.domain.LinkQuality
import java.net.ServerSocket
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class LinkProbeTest {
    @Test
    fun qualityThresholdsAreExactlyThirtyAndOneHundredTwentyMilliseconds() {
        assertEquals(LinkQuality.STRONG, LinkProbe.classify(0))
        assertEquals(LinkQuality.STRONG, LinkProbe.classify(29))
        assertEquals(LinkQuality.FAIR, LinkProbe.classify(30))
        assertEquals(LinkQuality.FAIR, LinkProbe.classify(119))
        assertEquals(LinkQuality.WEAK, LinkProbe.classify(120))
        assertEquals(LinkQuality.WEAK, LinkProbe.classify(5_000))
    }

    @Test
    fun anOpenPortIsMeasured() {
        ServerSocket(0).use { server ->
            val millis = LinkProbe.measure("127.0.0.1", server.localPort, 1000)
            assertNotNull(millis)
            assertTrue(millis!! in 0..1000)
        }
    }

    @Test
    fun aClosedPortGivesNoMeasurement() {
        val port = ServerSocket(0).use { it.localPort }
        assertNull(LinkProbe.measure("127.0.0.1", port, 500))
    }

    @Test
    fun anInvalidPortOrHostGivesNoMeasurement() {
        assertNull(LinkProbe.measure("127.0.0.1", 70000, 300))
        assertNull(LinkProbe.measure("999.999.999.999", 80, 300))
    }

    @Test
    fun theSocketBinderIsCalledBeforeConnecting() {
        var bound = false
        ServerSocket(0).use { server ->
            LinkProbe.measure("127.0.0.1", server.localPort, 1000) { bound = true }
        }
        assertTrue(bound)
    }
}
