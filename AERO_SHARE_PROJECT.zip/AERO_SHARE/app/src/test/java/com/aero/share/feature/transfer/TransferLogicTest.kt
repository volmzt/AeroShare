package com.aero.share.feature.transfer

import com.aero.share.transfer.model.TransferDirection
import com.aero.share.transfer.model.TransferFailure
import com.aero.share.transfer.model.TransferState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TransferLogicTest {
    private val send = TransferDirection.SEND
    private val receive = TransferDirection.RECEIVE

    // ---- headline

    @Test
    fun runningTransfersAreNamedByDirection() {
        val running = listOf(
            TransferState.WAITING, TransferState.PREPARING, TransferState.CONNECTING, TransferState.AWAITING_ACCEPTANCE,
            TransferState.TRANSFERRING, TransferState.PAUSED, TransferState.INTERRUPTED, TransferState.VERIFYING,
        )
        for (state in running) {
            assertEquals(state.name, Headline.SENDING, TransferLogic.headline(send, state))
            assertEquals(state.name, Headline.RECEIVING, TransferLogic.headline(receive, state))
        }
    }

    @Test
    fun finishedTransfersAreNamedByOutcome() {
        assertEquals(Headline.SENT, TransferLogic.headline(send, TransferState.COMPLETED))
        assertEquals(Headline.RECEIVED, TransferLogic.headline(receive, TransferState.COMPLETED))
        assertEquals(Headline.SEND_FAILED, TransferLogic.headline(send, TransferState.FAILED))
        assertEquals(Headline.RECEIVE_FAILED, TransferLogic.headline(receive, TransferState.FAILED))
        assertEquals(Headline.CANCELLED, TransferLogic.headline(send, TransferState.CANCELLED))
        assertEquals(Headline.CANCELLED, TransferLogic.headline(receive, TransferState.CANCELLED))
    }

    // ---- progress bar

    @Test
    fun barIsIndeterminateOnlyWhileSomethingIsBeingSetUp() {
        assertEquals(ProgressStyle.NONE, TransferLogic.progressStyle(TransferState.WAITING, 0))
        for (state in listOf(TransferState.PREPARING, TransferState.CONNECTING, TransferState.AWAITING_ACCEPTANCE)) {
            assertEquals(state.name, ProgressStyle.INDETERMINATE, TransferLogic.progressStyle(state, 0))
        }
    }

    @Test
    fun barIsRealWhileDataMoves() {
        for (state in listOf(TransferState.TRANSFERRING, TransferState.PAUSED, TransferState.VERIFYING, TransferState.INTERRUPTED)) {
            assertEquals(state.name, ProgressStyle.DETERMINATE, TransferLogic.progressStyle(state, 0))
        }
    }

    @Test
    fun finishedTransfersShowAnOutcomeBarOnlyIfDataMoved() {
        assertEquals(ProgressStyle.NONE, TransferLogic.progressStyle(TransferState.COMPLETED, 100))
        assertEquals(ProgressStyle.DETERMINATE, TransferLogic.progressStyle(TransferState.FAILED, 100))
        assertEquals(ProgressStyle.NONE, TransferLogic.progressStyle(TransferState.FAILED, 0))
        assertEquals(ProgressStyle.DETERMINATE, TransferLogic.progressStyle(TransferState.CANCELLED, 1))
        assertEquals(ProgressStyle.NONE, TransferLogic.progressStyle(TransferState.CANCELLED, 0))
    }

    // ---- controls

    private fun controls(
        state: TransferState,
        direction: TransferDirection = send,
        failure: TransferFailure? = null,
        pausedByPeer: Boolean = false,
    ) = TransferLogic.controls(state, direction, failure, pausedByPeer)

    @Test
    fun activeTransferCanBePausedAndCancelled() {
        val c = controls(TransferState.TRANSFERRING)
        assertTrue(c.pause)
        assertTrue(c.cancel)
        assertFalse(c.resume)
        assertFalse(c.retry)
    }

    @Test
    fun setupStatesOnlyOfferCancel() {
        for (state in listOf(TransferState.WAITING, TransferState.PREPARING, TransferState.CONNECTING, TransferState.AWAITING_ACCEPTANCE)) {
            val c = controls(state)
            assertEquals(state.name, Controls(pause = false, resume = false, cancel = true, retry = false), c)
        }
    }

    @Test
    fun pausedTransferCanBeResumedUnlessTheOtherDevicePausedIt() {
        assertTrue(controls(TransferState.PAUSED).resume)
        val byPeer = controls(TransferState.PAUSED, pausedByPeer = true)
        assertFalse(byPeer.resume)
        assertTrue(byPeer.cancel)
    }

    @Test
    fun interruptedSendCanBeRetriedButAReceiveCannot() {
        assertTrue(controls(TransferState.INTERRUPTED, send).retry)
        assertFalse(controls(TransferState.INTERRUPTED, receive).retry)
        assertTrue(controls(TransferState.INTERRUPTED, receive).cancel)
    }

    @Test
    fun failedSendOffersRetryOnlyWhenItCanHelp() {
        assertTrue(controls(TransferState.FAILED, send, TransferFailure.UNREACHABLE).retry)
        assertTrue(controls(TransferState.FAILED, send, null).retry)
        assertFalse(controls(TransferState.FAILED, send, TransferFailure.UNSUPPORTED_VERSION).retry)
        assertFalse(controls(TransferState.FAILED, send, TransferFailure.BLOCKED).retry)
        assertFalse(controls(TransferState.FAILED, send, TransferFailure.AUTH_FAILED).retry)
        assertFalse(controls(TransferState.FAILED, send, TransferFailure.SOURCE_UNREADABLE).retry)
        assertFalse(controls(TransferState.FAILED, receive, TransferFailure.UNREACHABLE).retry)
    }

    @Test
    fun finishedTransfersOfferNoControls() {
        assertFalse(controls(TransferState.COMPLETED).any)
        assertFalse(controls(TransferState.CANCELLED).any)
    }

    @Test
    fun everyTemporaryFailureIsRetryable() {
        val notRetryable = setOf(
            TransferFailure.BLOCKED, TransferFailure.AUTH_FAILED,
            TransferFailure.UNSUPPORTED_VERSION, TransferFailure.SOURCE_UNREADABLE,
        )
        for (failure in TransferFailure.values()) {
            assertEquals(failure.name, failure !in notRetryable, TransferLogic.retryable(failure))
        }
    }

    // ---- estimate

    private fun eta(millis: Long?, state: TransferState = TransferState.TRANSFERRING, speed: Long = 1_000L) =
        TransferLogic.eta(state, millis, speed)

    @Test
    fun etaIsHiddenWhenThereIsNothingToEstimate() {
        assertEquals(EtaKind.HIDDEN, eta(null).kind)
        assertEquals(EtaKind.HIDDEN, eta(60_000L, state = TransferState.PAUSED).kind)
        assertEquals(EtaKind.HIDDEN, eta(60_000L, state = TransferState.CONNECTING).kind)
        assertEquals(EtaKind.HIDDEN, eta(60_000L, speed = 0L).kind)
        assertEquals(EtaKind.HIDDEN, eta(-1L).kind)
    }

    @Test
    fun shortEtaSaysLessThanAMinute() {
        assertEquals(Eta(EtaKind.LESS_THAN_MINUTE), eta(0L))
        assertEquals(Eta(EtaKind.LESS_THAN_MINUTE), eta(44_999L))
    }

    @Test
    fun etaInMinutesIsRounded() {
        assertEquals(Eta(EtaKind.MINUTES, 1), eta(45_000L))
        assertEquals(Eta(EtaKind.MINUTES, 2), eta(90_000L))
        assertEquals(Eta(EtaKind.MINUTES, 7), eta(7 * 60_000L + 10_000L))
        assertEquals(Eta(EtaKind.MINUTES, 89), eta(89 * 60_000L))
    }

    @Test
    fun longEtaIsInHours() {
        assertEquals(Eta(EtaKind.HOURS, 2), eta(90L * 60_000L))
        assertEquals(Eta(EtaKind.HOURS, 2), eta(100L * 60_000L))
        assertEquals(Eta(EtaKind.HOURS, 3), eta(150L * 60_000L))
        assertEquals(Eta(EtaKind.HOURS, 10), eta(10L * 3_600_000L))
    }

    @Test
    fun absurdEtaIsHidden() {
        assertEquals(EtaKind.HIDDEN, eta(200L * 3_600_000L).kind)
        assertEquals(Eta(EtaKind.HOURS, 99), eta(99L * 3_600_000L))
    }

    // ---- file line

    @Test
    fun fileNumberIsOneBasedAndBounded() {
        assertEquals(3, TransferLogic.fileNumber(3, 12))
        assertEquals(12, TransferLogic.fileNumber(12, 12))
        assertNull(TransferLogic.fileNumber(0, 12))
        assertNull(TransferLogic.fileNumber(13, 12))
        assertNull(TransferLogic.fileNumber(1, 0))
    }

    // ---- what is shown when

    @Test
    fun liveDetailsOnlyWhileDataIsInvolved() {
        assertTrue(TransferLogic.showsLiveDetails(TransferState.TRANSFERRING))
        assertTrue(TransferLogic.showsLiveDetails(TransferState.PAUSED))
        assertFalse(TransferLogic.showsLiveDetails(TransferState.CONNECTING))
        assertFalse(TransferLogic.showsLiveDetails(TransferState.COMPLETED))
    }

    @Test
    fun speedIsShownOnlyWhileDataFlows() {
        assertTrue(TransferLogic.showsSpeed(TransferState.TRANSFERRING, 1))
        assertFalse(TransferLogic.showsSpeed(TransferState.TRANSFERRING, 0))
        assertFalse(TransferLogic.showsSpeed(TransferState.PAUSED, 1_000))
    }

    @Test
    fun verificationCodeIsShownWhileWaitingForAnswer() {
        assertTrue(TransferLogic.showsVerificationCode(TransferState.AWAITING_ACCEPTANCE, "482 913"))
        assertFalse(TransferLogic.showsVerificationCode(TransferState.AWAITING_ACCEPTANCE, null))
        assertFalse(TransferLogic.showsVerificationCode(TransferState.AWAITING_ACCEPTANCE, " "))
        assertFalse(TransferLogic.showsVerificationCode(TransferState.TRANSFERRING, "482 913"))
    }

    @Test
    fun onlyTerminalStatesAreFinished() {
        for (state in TransferState.values()) {
            assertEquals(state.name, state == TransferState.COMPLETED || state == TransferState.FAILED || state == TransferState.CANCELLED, TransferLogic.isFinished(state))
        }
    }
}
