package com.aero.share.network.transport

import com.aero.share.domain.AppSettings
import com.aero.share.domain.CapabilityProvider
import com.aero.share.domain.CapabilityState
import com.aero.share.domain.DiscoveryProblem
import com.aero.share.domain.DiscoveryStatus
import com.aero.share.domain.LinkQuality
import com.aero.share.domain.NearbyDevice
import com.aero.share.domain.PowerPolicy
import com.aero.share.domain.RadioStatus
import com.aero.share.domain.SettingsRepository
import com.aero.share.domain.TransportCapability
import com.aero.share.domain.Visibility
import com.aero.share.transfer.engine.EngineConfig
import com.aero.share.transfer.model.DeviceKind
import com.aero.share.transfer.model.TransportKind
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DiscoveryCoordinatorTest {
    private class FakeLan : LanSource {
        override val devices = MutableStateFlow<List<NearbyDevice>>(emptyList())
        override val problem = MutableStateFlow<DiscoveryProblem?>(null)
        override val methods = MutableStateFlow<Set<String>>(emptySet())
        val starts = AtomicInteger()
        val stops = AtomicInteger()
        val refreshes = AtomicInteger()
        val advert = CopyOnWriteArrayList<Int?>()
        override fun start() { starts.incrementAndGet() }
        override fun stop() { stops.incrementAndGet() }
        override fun refresh() { refreshes.incrementAndGet() }
        override fun startAdvertising(port: Int) { advert.add(port) }
        override fun stopAdvertising() { advert.add(null) }
    }

    private class FakeDirect : DirectSource {
        override val peers = MutableStateFlow<List<NearbyDevice>>(emptyList())
        override val active = MutableStateFlow(false)
        val starts = AtomicInteger()
        val stops = AtomicInteger()
        val refreshes = AtomicInteger()
        val advert = CopyOnWriteArrayList<Int?>()
        override fun start() { starts.incrementAndGet() }
        override fun stop() { stops.incrementAndGet() }
        override fun refresh() { refreshes.incrementAndGet() }
        override fun startAdvertising(port: Int) { advert.add(port) }
        override fun stopAdvertising() { advert.add(null) }
    }

    private class FakeCapabilities : CapabilityProvider {
        override val capabilities = MutableStateFlow(all(CapabilityState.AVAILABLE))
        override val radio = MutableStateFlow(RadioStatus(true, true, false, false, true, 34))
        val refreshes = AtomicInteger()
        override fun refresh() { refreshes.incrementAndGet() }

        companion object {
            fun all(direct: CapabilityState) = listOf(
                TransportCapability(TransportKind.LAN, CapabilityState.AVAILABLE),
                TransportCapability(TransportKind.WIFI_DIRECT, direct),
                TransportCapability(TransportKind.HOTSPOT, CapabilityState.AVAILABLE),
                TransportCapability(TransportKind.MANUAL, CapabilityState.AVAILABLE),
            )
        }
    }

    private class FakeSettings : SettingsRepository {
        override val settings = MutableStateFlow(AppSettings())
        override suspend fun update(transform: (AppSettings) -> AppSettings) {
            settings.value = transform(settings.value)
        }
    }

    private class FakePower(private val discoveryMs: Long) : PowerPolicy {
        override fun engineConfig() = EngineConfig()
        override fun discoveryIntervalMs() = discoveryMs
        override fun beaconIntervalMs() = 5_000L
        override fun useLowLatencyWifiLock() = false
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val lan = FakeLan()
    private val direct = FakeDirect()
    private val caps = FakeCapabilities()
    private val settings = FakeSettings()

    private fun coordinator(discoveryMs: Long = 600_000L) = DiscoveryCoordinator(
        scope, lan, direct, caps, settings, FakePower(discoveryMs), {},
        minRefreshMs = 20L, minDirectRefreshMs = 60L,
    )

    @After
    fun tearDown() {
        scope.cancel()
    }

    private fun waitUntil(what: String, timeoutMs: Long = 4_000, condition: () -> Boolean) {
        val deadline = System.nanoTime() + timeoutMs * 1_000_000
        while (!condition()) {
            if (System.nanoTime() > deadline) throw AssertionError("timed out waiting for: $what")
            Thread.sleep(10)
        }
    }

    private fun settle() = Thread.sleep(200)

    private fun device(id: String, name: String = id, transports: Set<TransportKind> = setOf(TransportKind.LAN), quality: LinkQuality = LinkQuality.UNKNOWN) =
        NearbyDevice(id, name, DeviceKind.PHONE, null, null, listOf("192.168.1.9"), 4000, transports, quality, 0)

    @Test
    fun nothingRunsWithoutOwners() {
        val c = coordinator()
        settle()
        assertEquals(0, lan.starts.get())
        assertEquals(0, direct.starts.get())
        assertEquals(DiscoveryStatus.IDLE, c.state.value.status)
        assertTrue(c.devices.value.isEmpty())
    }

    @Test
    fun ownersAreReferenceCounted() {
        val c = coordinator()
        c.startDiscovery("home")
        waitUntil("lan started") { lan.starts.get() == 1 }
        waitUntil("direct started") { direct.starts.get() == 1 }
        c.startDiscovery("devices")
        c.startDiscovery("devices")
        settle()
        assertEquals(1, lan.starts.get())
        c.stopDiscovery("home")
        settle()
        assertEquals(0, lan.stops.get())
        assertEquals(0, direct.stops.get())
        c.stopDiscovery("devices")
        waitUntil("both stopped") { lan.stops.get() == 1 && direct.stops.get() == 1 }
        c.stopDiscovery("devices")
        settle()
        assertEquals(1, lan.stops.get())
        assertEquals(DiscoveryStatus.IDLE, c.state.value.status)
    }

    @Test
    fun startingDiscoveryRefreshesCapabilities() {
        val c = coordinator()
        c.startDiscovery("home")
        waitUntil("capabilities refreshed") { caps.refreshes.get() >= 1 }
    }

    @Test
    fun turningLanOffStopsOnlyTheLan() {
        val c = coordinator()
        c.startDiscovery("home")
        waitUntil("started") { lan.starts.get() == 1 && direct.starts.get() == 1 }
        settings.settings.value = settings.settings.value.copy(lanDiscoveryEnabled = false)
        waitUntil("lan stopped") { lan.stops.get() == 1 }
        settle()
        assertEquals(0, direct.stops.get())
        settings.settings.value = settings.settings.value.copy(lanDiscoveryEnabled = true)
        waitUntil("lan restarted") { lan.starts.get() == 2 }
    }

    @Test
    fun wifiDirectWaitsForAUsableCapability() {
        caps.capabilities.value = FakeCapabilities.all(CapabilityState.PERMISSION_MISSING)
        val c = coordinator()
        c.startDiscovery("home")
        waitUntil("lan started") { lan.starts.get() == 1 }
        settle()
        assertEquals(0, direct.starts.get())
        caps.capabilities.value = FakeCapabilities.all(CapabilityState.AVAILABLE)
        waitUntil("direct started") { direct.starts.get() == 1 }
        caps.capabilities.value = FakeCapabilities.all(CapabilityState.RADIO_OFF)
        waitUntil("direct stopped") { direct.stops.get() == 1 }
    }

    @Test
    fun advertisingFollowsVisibilityAndOwners() {
        val c = coordinator()
        c.startAdvertising("receive", 4433)
        waitUntil("lan advertising") { lan.advert.toList() == listOf(4433) }
        waitUntil("direct advertising") { direct.advert.toList() == listOf(4433) }
        assertEquals(0, lan.starts.get())
        settings.settings.value = settings.settings.value.copy(visibility = Visibility.HIDDEN)
        waitUntil("hidden stops advertising") { lan.advert.toList() == listOf(4433, null) && direct.advert.toList() == listOf(4433, null) }
        settings.settings.value = settings.settings.value.copy(visibility = Visibility.VISIBLE)
        waitUntil("visible again") { lan.advert.toList() == listOf(4433, null, 4433) }
        c.stopAdvertising("receive")
        waitUntil("owner left") { lan.advert.toList() == listOf(4433, null, 4433, null) && direct.advert.toList().last() == null }
    }

    @Test
    fun hiddenDevicesNeverStartAdvertising() {
        settings.settings.value = settings.settings.value.copy(visibility = Visibility.HIDDEN)
        val c = coordinator()
        c.startAdvertising("receive", 4433)
        settle()
        assertTrue(lan.advert.isEmpty())
        assertTrue(direct.advert.isEmpty())
        assertEquals(DiscoveryStatus.IDLE, c.state.value.status)
    }

    @Test
    fun advertisingTwiceWithTheSamePortDoesNotRestartIt() {
        val c = coordinator()
        c.startAdvertising("a", 4433)
        waitUntil("advertising") { lan.advert.size == 1 }
        c.startAdvertising("b", 4433)
        settle()
        assertEquals(1, lan.advert.size)
        c.stopAdvertising("a")
        settle()
        assertEquals(1, lan.advert.size)
        c.stopAdvertising("b")
        waitUntil("stopped") { lan.advert.size == 2 }
    }

    @Test
    fun devicesFromBothSourcesAreMerged() {
        val c = coordinator()
        lan.devices.value = listOf(device("a", "Anna"), device("b", "Boris", quality = LinkQuality.STRONG))
        direct.peers.value = listOf(device("a", "Anna", setOf(TransportKind.WIFI_DIRECT)), device("c", "Carl", setOf(TransportKind.WIFI_DIRECT)))
        waitUntil("merged") { c.devices.value.size == 3 }
        assertEquals(listOf("Boris", "Anna", "Carl"), c.devices.value.map { it.name })
        assertEquals(setOf(TransportKind.LAN, TransportKind.WIFI_DIRECT), c.devices.value.first { it.deviceId == "a" }.transports)
        lan.devices.value = emptyList()
        waitUntil("only direct left") { c.devices.value.map { it.deviceId } == listOf("a", "c") }
    }

    @Test
    fun problemsAreReportedAndClearWhenTheNetworkReturns() {
        settings.settings.value = settings.settings.value.copy(wifiDirectEnabled = false)
        lan.problem.value = DiscoveryProblem.NO_NETWORK
        val c = coordinator()
        c.startDiscovery("home")
        waitUntil("problem shown") { c.state.value.status == DiscoveryStatus.PROBLEM }
        assertEquals(DiscoveryProblem.NO_NETWORK, c.state.value.problem)
        lan.problem.value = null
        lan.methods.value = setOf("multicast")
        waitUntil("searching") { c.state.value.status == DiscoveryStatus.SEARCHING }
        assertEquals(setOf("multicast"), c.state.value.activeMethods)
        assertEquals(null, c.state.value.problem)
    }

    @Test
    fun wifiDirectActivityIsVisibleInTheState() {
        val c = coordinator()
        c.startDiscovery("home")
        lan.methods.value = setOf("mdns")
        direct.active.value = true
        waitUntil("both methods") { c.state.value.activeMethods == setOf("mdns", DiscoveryRules.METHOD_WIFI_DIRECT) }
        assertFalse(c.state.value.advertising)
    }

    @Test
    fun advertisingFlagComesFromRunningMechanisms() {
        val c = coordinator()
        c.startAdvertising("receive", 4433)
        waitUntil("advertise requested") { lan.advert.size == 1 }
        assertFalse(c.state.value.advertising)
        lan.methods.value = setOf("mdns")
        waitUntil("advertising") { c.state.value.advertising }
        assertEquals(DiscoveryStatus.IDLE, c.state.value.status)
    }

    @Test
    fun periodicRefreshRunsOnlyWhileSomebodyLooks() {
        val c = coordinator(discoveryMs = 30L)
        c.startDiscovery("home")
        waitUntil("lan refreshed repeatedly") { lan.refreshes.get() >= 3 }
        waitUntil("direct refreshed less often") { direct.refreshes.get() >= 1 }
        assertTrue(direct.refreshes.get() < lan.refreshes.get())
        c.stopDiscovery("home")
        settle()
        val frozen = lan.refreshes.get()
        Thread.sleep(250)
        assertEquals(frozen, lan.refreshes.get())
    }

    @Test
    fun explicitRefreshQueriesAgainOnce() {
        val c = coordinator()
        c.startDiscovery("home")
        waitUntil("started") { lan.starts.get() == 1 && direct.starts.get() == 1 }
        val capabilityRefreshes = caps.refreshes.get()
        c.refresh()
        waitUntil("lan refreshed") { lan.refreshes.get() == 1 }
        waitUntil("direct refreshed") { direct.refreshes.get() == 1 }
        assertTrue(caps.refreshes.get() > capabilityRefreshes)
        settle()
        assertEquals(1, lan.refreshes.get())
    }

    @Test
    fun refreshWithoutOwnersOnlyRereadsCapabilities() {
        val c = coordinator()
        c.refresh()
        waitUntil("capabilities") { caps.refreshes.get() >= 1 }
        settle()
        assertEquals(0, lan.refreshes.get())
        assertEquals(0, direct.refreshes.get())
    }
}
