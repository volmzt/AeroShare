package com.aero.share.network.discovery

import com.aero.share.transfer.model.DeviceKind
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class NsdAdvertTest {
    private val fingerprint = "c3".repeat(32)
    private val presence = Beacon.Presence(false, fingerprint, "Living room tablet", DeviceKind.TABLET, 41000, "1.2.3", 29)

    private fun encoded(map: Map<String, String>): Map<String, ByteArray?> = map.mapValues { it.value.toByteArray(Charsets.UTF_8) }

    @Test
    fun attributesRoundTrip() {
        assertEquals(presence, NsdAdvert.parse(encoded(NsdAdvert.attributes(presence)), 41000))
    }

    @Test
    fun serviceNameIsThePrefixOfTheDeviceId() {
        assertEquals(fingerprint.take(20), NsdAdvert.serviceName(presence.deviceId))
    }

    @Test
    fun recordsWithAMismatchingIdAreRejected() {
        val map = NsdAdvert.attributes(presence).toMutableMap()
        map["id"] = "d4".repeat(16)
        assertNull(NsdAdvert.parse(encoded(map), 41000))
    }

    @Test
    fun invalidFingerprintsAreRejected() {
        for (bad in listOf("", "C3".repeat(32), "c3".repeat(31), "g3".repeat(32))) {
            val map = NsdAdvert.attributes(presence).toMutableMap()
            map["fp"] = bad
            assertNull("fp '$bad'", NsdAdvert.parse(encoded(map), 41000))
        }
    }

    @Test
    fun unsupportedProtocolVersionsAreRejected() {
        for (version in listOf("0", "2", "x", "")) {
            val map = NsdAdvert.attributes(presence).toMutableMap()
            map["v"] = version
            assertNull("v '$version'", NsdAdvert.parse(encoded(map), 41000))
        }
        val without = NsdAdvert.attributes(presence).toMutableMap().also { it.remove("v") }
        assertNull(NsdAdvert.parse(encoded(without), 41000))
    }

    @Test
    fun portsOutsideTheValidRangeAreRejected() {
        for (port in listOf(-1, 0, 65536, 100000)) {
            assertNull("port $port", NsdAdvert.parse(encoded(NsdAdvert.attributes(presence)), port))
        }
    }

    @Test
    fun missingRequiredKeysAreRejected() {
        for (key in listOf("fp", "id")) {
            val map = NsdAdvert.attributes(presence).toMutableMap().also { it.remove(key) }
            assertNull("without $key", NsdAdvert.parse(encoded(map), 41000))
        }
    }

    @Test
    fun optionalKeysFallBackToNeutralValues() {
        val map = mapOf("id" to fingerprint.take(32), "fp" to fingerprint, "v" to "1")
        val parsed = NsdAdvert.parse(encoded(map), 5000)!!
        assertEquals("", parsed.name)
        assertEquals(DeviceKind.OTHER, parsed.kind)
        assertEquals("", parsed.appVersion)
        assertEquals(0, parsed.capabilities)
    }

    @Test
    fun hostileNamesAreCleanedAndCapped() {
        val map = NsdAdvert.attributes(presence).toMutableMap()
        map["n"] = "‮evil\u0000" + "я".repeat(100)
        val parsed = NsdAdvert.parse(encoded(map), 41000)!!
        assertEquals("evil" + "я".repeat(28), parsed.name)
    }
}
