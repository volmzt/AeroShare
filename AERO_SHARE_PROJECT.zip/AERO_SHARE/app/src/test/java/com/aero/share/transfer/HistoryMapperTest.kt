package com.aero.share.transfer

import com.aero.share.domain.AppItem
import com.aero.share.domain.FileItem
import com.aero.share.domain.FolderItem
import com.aero.share.domain.HistoryStatus
import com.aero.share.domain.PendingIncoming
import com.aero.share.domain.SelectionItem
import com.aero.share.transfer.model.DeviceKind
import com.aero.share.transfer.model.FileCategory
import com.aero.share.transfer.model.PeerInfo
import com.aero.share.transfer.model.PeerTrust
import com.aero.share.transfer.model.SavedFile
import com.aero.share.transfer.model.TransferDirection
import com.aero.share.transfer.model.TransferFailure
import com.aero.share.transfer.model.TransferSnapshot
import com.aero.share.transfer.model.TransferState
import com.aero.share.transfer.model.TransportKind
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class HistoryMapperTest {
    private fun snapshot(
        state: TransferState,
        direction: TransferDirection = TransferDirection.SEND,
        startedAt: Long = 1_000L,
        finishedAt: Long? = 6_000L,
        failure: TransferFailure? = null,
    ) = TransferSnapshot(
        id = "t1",
        direction = direction,
        state = state,
        peerName = "Pixel",
        transport = TransportKind.LAN,
        totalFiles = 2,
        completedFiles = 1,
        totalBytes = 2_000L,
        transferredBytes = 1_500L,
        startedAt = startedAt,
        finishedAt = finishedAt,
        failure = failure,
    )

    private val peer = PeerInfo("device-1", "Galaxy", DeviceKind.PHONE, "1.0.0", "ab".repeat(32))

    @Test
    fun sentTransfersKeepTheirOwnId() {
        assertEquals("abc-123", HistoryMapper.idFor(TransferDirection.SEND, "abc-123"))
    }

    @Test
    fun receivedIdsAreReducedToSafeCharactersAndPrefixed() {
        assertEquals("in-abc-123", HistoryMapper.idFor(TransferDirection.RECEIVE, "abc-123"))
        assertEquals("in-etcpasswd", HistoryMapper.idFor(TransferDirection.RECEIVE, "../../etc/passwd"))
        assertEquals("in-x", HistoryMapper.idFor(TransferDirection.RECEIVE, ""))
        assertEquals("in-x", HistoryMapper.idFor(TransferDirection.RECEIVE, "/?&#"))
        assertEquals("in-" + "a".repeat(64), HistoryMapper.idFor(TransferDirection.RECEIVE, "a".repeat(300)))
    }

    @Test
    fun aReceivedIdNeverCollidesWithASentOne() {
        assertTrue(HistoryMapper.idFor(TransferDirection.RECEIVE, "same") != HistoryMapper.idFor(TransferDirection.SEND, "same"))
    }

    @Test
    fun runningOrNotYetStartedTransfersAreNotRecorded() {
        for (state in listOf(
            TransferState.WAITING, TransferState.PREPARING, TransferState.CONNECTING, TransferState.AWAITING_ACCEPTANCE,
            TransferState.TRANSFERRING, TransferState.PAUSED, TransferState.VERIFYING,
        )) {
            assertNull("$state must not be recorded", HistoryMapper.fromSnapshot(snapshot(state), emptyList(), 9_000L))
        }
    }

    @Test
    fun aCompletedTransferIsRecordedWithItsDuration() {
        val item = HistoryMapper.fromSnapshot(snapshot(TransferState.COMPLETED), emptyList(), 9_000L)
            ?: throw AssertionError("expected an item")
        assertEquals(HistoryStatus.COMPLETED, item.status)
        assertNull(item.failure)
        assertEquals(6_000L, item.timestamp)
        assertEquals(5_000L, item.durationMillis)
        assertEquals(2, item.fileCount)
        assertEquals(1, item.completedFiles)
        assertEquals(2_000L, item.totalBytes)
        assertEquals(1_500L, item.transferredBytes)
        assertEquals(TransportKind.LAN, item.transport)
        assertEquals("t1", item.id)
        assertEquals(TransferDirection.SEND, item.direction)
    }

    @Test
    fun cancellingBeforeAnythingStartedLeavesNoTrace() {
        assertNull(HistoryMapper.fromSnapshot(snapshot(TransferState.CANCELLED, startedAt = 0L, finishedAt = 500L), emptyList(), 9_000L))
    }

    @Test
    fun cancellingAfterTheStartIsRecordedAsCancelled() {
        val item = HistoryMapper.fromSnapshot(snapshot(TransferState.CANCELLED), emptyList(), 9_000L)
            ?: throw AssertionError("expected an item")
        assertEquals(HistoryStatus.CANCELLED, item.status)
        assertNull(item.failure)
    }

    @Test
    fun aFailureKeepsItsReasonAndDefaultsToInternal() {
        val explicit = HistoryMapper.fromSnapshot(snapshot(TransferState.FAILED, failure = TransferFailure.NO_SPACE), emptyList(), 0L)
            ?: throw AssertionError("expected an item")
        assertEquals(HistoryStatus.FAILED, explicit.status)
        assertEquals(TransferFailure.NO_SPACE, explicit.failure)
        val missing = HistoryMapper.fromSnapshot(snapshot(TransferState.FAILED), emptyList(), 0L)
            ?: throw AssertionError("expected an item")
        assertEquals(TransferFailure.INTERNAL, missing.failure)
    }

    @Test
    fun anInterruptedTransferIsRecordedAsFailedBecauseItNeverFinished() {
        val plain = HistoryMapper.fromSnapshot(snapshot(TransferState.INTERRUPTED), emptyList(), 0L)
            ?: throw AssertionError("expected an item")
        assertEquals(HistoryStatus.FAILED, plain.status)
        assertEquals(TransferFailure.INTERRUPTED, plain.failure)
        val explicit = HistoryMapper.fromSnapshot(snapshot(TransferState.INTERRUPTED, failure = TransferFailure.TIMEOUT), emptyList(), 0L)
            ?: throw AssertionError("expected an item")
        assertEquals(TransferFailure.TIMEOUT, explicit.failure)
    }

    @Test
    fun sentFilesAreListedFromTheSelection() {
        val items: List<SelectionItem> = listOf(
            FileItem("u1", "content://x/1", "photo.jpg", 1_024L, FileCategory.IMAGE, "image/jpeg", 5L),
            FileItem("u2", "content://x/2", "broken.bin", -1L, FileCategory.OTHER, null, 5L),
            FolderItem("f1", "content://tree/1", "Trip", 4_096L, 7),
            AppItem("com.example", "com.example", "Example", "1.2", 8_192L, 2),
        )
        val item = HistoryMapper.fromSnapshot(snapshot(TransferState.COMPLETED), items, 0L) ?: throw AssertionError("expected an item")
        assertEquals(4, item.files.size)
        assertEquals("photo.jpg", item.files[0].name)
        assertEquals(1_024L, item.files[0].size)
        assertEquals("image/jpeg", item.files[0].mimeType)
        assertEquals(FileCategory.IMAGE, item.files[0].category)
        assertNull("sent files have no uri to open", item.files[0].uri)
        assertEquals("an unknown size never becomes negative", 0L, item.files[1].size)
        assertEquals(FileCategory.OTHER, item.files[2].category)
        assertNull(item.files[2].mimeType)
        assertEquals(FileCategory.APK, item.files[3].category)
    }

    @Test
    fun aSentTransferWithoutASelectionHasNoFiles() {
        val item = HistoryMapper.fromSnapshot(snapshot(TransferState.COMPLETED), null, 0L) ?: throw AssertionError("expected an item")
        assertTrue(item.files.isEmpty())
    }

    @Test
    fun receivedFilesComeFromTheSavedFilesAndKeepTheirUri() {
        val saved = SavedFile("content://saved/1", "doc.pdf", "docs/doc.pdf", 900L, "application/pdf", FileCategory.DOCUMENT, "00".repeat(32))
        val source = snapshot(TransferState.COMPLETED, direction = TransferDirection.RECEIVE).copy(savedFiles = listOf(saved))
        val item = HistoryMapper.fromSnapshot(source, null, 0L) ?: throw AssertionError("expected an item")
        assertEquals("in-t1", item.id)
        assertEquals(1, item.files.size)
        assertEquals("doc.pdf", item.files[0].name)
        assertEquals("content://saved/1", item.files[0].uri)
        assertEquals("application/pdf", item.files[0].mimeType)
        assertEquals(FileCategory.DOCUMENT, item.files[0].category)
    }

    @Test
    fun thePeerNameIsCleanedAndFallsBackToTheAuthenticatedPeer() {
        val spoofed = snapshot(TransferState.COMPLETED).copy(peerName = "Evil‮gnp.exe", peer = peer)
        val cleaned = HistoryMapper.fromSnapshot(spoofed, null, 0L) ?: throw AssertionError("expected an item")
        assertFalse(cleaned.peerName.contains('‮'))
        assertEquals("device-1", cleaned.peerId)

        val unnamed = snapshot(TransferState.COMPLETED).copy(peerName = "", peer = peer)
        val fallback = HistoryMapper.fromSnapshot(unnamed, null, 0L) ?: throw AssertionError("expected an item")
        assertEquals("Galaxy", fallback.peerName)

        val noPeer = HistoryMapper.fromSnapshot(snapshot(TransferState.COMPLETED).copy(peerName = ""), null, 0L)
            ?: throw AssertionError("expected an item")
        assertEquals("", noPeer.peerName)
        assertNull(noPeer.peerId)
    }

    @Test
    fun missingTimesFallBackToWhatIsKnown() {
        val unfinished = snapshot(TransferState.FAILED, finishedAt = null).copy(elapsedMillis = 4_000L, startedAt = 0L)
        val item = HistoryMapper.fromSnapshot(unfinished, null, 9_000L) ?: throw AssertionError("expected an item")
        assertEquals(9_000L, item.timestamp)
        assertEquals(4_000L, item.durationMillis)
    }

    @Test
    fun aClockThatWentBackwardsNeverGivesANegativeDuration() {
        val odd = snapshot(TransferState.COMPLETED, startedAt = 8_000L, finishedAt = 2_000L)
        val item = HistoryMapper.fromSnapshot(odd, null, 0L) ?: throw AssertionError("expected an item")
        assertEquals(0L, item.durationMillis)
    }

    @Test
    fun aDeclinedRequestIsRecordedAsACancelledReceive() {
        val pending = PendingIncoming(
            transferId = "../weird id",
            peerName = "Pixel",
            peerKind = DeviceKind.PHONE,
            trust = PeerTrust.UNKNOWN,
            authenticatedByQr = false,
            verificationCode = "123 456",
            transport = TransportKind.WIFI_DIRECT,
            title = "Holiday",
            fileCount = 3,
            totalBytes = 12_345L,
            categories = setOf(FileCategory.IMAGE),
            destinationLabel = "Downloads",
            freeBytes = 1_000_000L,
            isResume = false,
            expiresAtElapsed = 99L,
        )
        val item = HistoryMapper.declined(pending, TransferFailure.DECLINED, "device-1", 7_000L)
        assertEquals("in-weirdid", item.id)
        assertEquals(TransferDirection.RECEIVE, item.direction)
        assertEquals(HistoryStatus.CANCELLED, item.status)
        assertEquals(TransferFailure.DECLINED, item.failure)
        assertEquals(7_000L, item.timestamp)
        assertEquals("device-1", item.peerId)
        assertEquals(3, item.fileCount)
        assertEquals(0, item.completedFiles)
        assertEquals(12_345L, item.totalBytes)
        assertEquals(0L, item.transferredBytes)
        assertEquals(TransportKind.WIFI_DIRECT, item.transport)
        assertTrue(item.files.isEmpty())
        assertNotNull(item.peerName)
        assertEquals(TransferFailure.TIMEOUT, HistoryMapper.declined(pending, TransferFailure.TIMEOUT, null, 0L).failure)
        assertNull(HistoryMapper.declined(pending, TransferFailure.TIMEOUT, null, 0L).peerId)
    }
}
