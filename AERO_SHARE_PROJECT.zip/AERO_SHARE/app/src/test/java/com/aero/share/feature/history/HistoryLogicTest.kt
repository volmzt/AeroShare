package com.aero.share.feature.history

import com.aero.share.domain.HistoryFile
import com.aero.share.domain.HistoryItem
import com.aero.share.domain.HistoryStatus
import com.aero.share.transfer.model.FileCategory
import com.aero.share.transfer.model.TransferDirection
import com.aero.share.transfer.model.TransferFailure
import java.util.TimeZone
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class HistoryLogicTest {
    private val utc = TimeZone.getTimeZone("UTC")
    private val hour = 3_600_000L
    private val day = 24 * hour

    private fun file(name: String, uri: String? = null) = HistoryFile(name, 10L, uri, null, FileCategory.OTHER)

    private fun item(
        id: String,
        timestamp: Long = 0L,
        direction: TransferDirection = TransferDirection.SEND,
        status: HistoryStatus = HistoryStatus.COMPLETED,
        failure: TransferFailure? = null,
        fileCount: Int = 1,
        completed: Int = 1,
        totalBytes: Long = 100L,
        transferred: Long = 100L,
        files: List<HistoryFile> = emptyList(),
    ) = HistoryItem(
        id = id,
        direction = direction,
        timestamp = timestamp,
        peerName = "Pixel",
        peerId = null,
        fileCount = fileCount,
        completedFiles = completed,
        totalBytes = totalBytes,
        transferredBytes = transferred,
        durationMillis = 1_000L,
        status = status,
        failure = failure,
        transport = null,
        files = files,
    )

    // ---- filters

    private val sample = listOf(
        item("a", direction = TransferDirection.SEND, status = HistoryStatus.COMPLETED),
        item("b", direction = TransferDirection.RECEIVE, status = HistoryStatus.COMPLETED),
        item("c", direction = TransferDirection.SEND, status = HistoryStatus.FAILED),
        item("d", direction = TransferDirection.RECEIVE, status = HistoryStatus.CANCELLED),
        item("e", direction = TransferDirection.RECEIVE, status = HistoryStatus.FAILED),
    )

    private fun ids(filters: HistoryFilters) = HistoryLogic.filter(sample, filters).map { it.id }

    @Test
    fun noFilterKeepsEverythingInOrder() {
        assertEquals(listOf("a", "b", "c", "d", "e"), ids(HistoryFilters()))
        assertFalse(HistoryFilters().active)
    }

    @Test
    fun directionFilter() {
        assertEquals(listOf("a", "c"), ids(HistoryFilters(direction = DirectionFilter.SENT)))
        assertEquals(listOf("b", "d", "e"), ids(HistoryFilters(direction = DirectionFilter.RECEIVED)))
    }

    @Test
    fun statusFilter() {
        assertEquals(listOf("a", "b"), ids(HistoryFilters(status = StatusFilter.COMPLETED)))
        assertEquals(listOf("c", "e"), ids(HistoryFilters(status = StatusFilter.FAILED)))
        assertEquals(listOf("d"), ids(HistoryFilters(status = StatusFilter.CANCELLED)))
    }

    @Test
    fun filtersCombine() {
        val filters = HistoryFilters(DirectionFilter.RECEIVED, StatusFilter.FAILED)
        assertTrue(filters.active)
        assertEquals(listOf("e"), ids(filters))
        assertTrue(ids(HistoryFilters(DirectionFilter.SENT, StatusFilter.CANCELLED)).isEmpty())
    }

    // ---- days

    @Test
    fun epochDayFollowsTheLocalCalendar() {
        val kyiv = TimeZone.getTimeZone("Europe/Kyiv")
        // 2026-11-20 23:30 UTC is already 2026-11-21 01:30 in Kyiv (UTC+2 in winter).
        val millis = 1_795_217_400_000L
        assertEquals(HistoryLogic.epochDay(millis, utc) + 1L, HistoryLogic.epochDay(millis, kyiv))
    }

    @Test
    fun epochDayIsFloorForTimesBeforeTheEpoch() {
        assertEquals(-1L, HistoryLogic.epochDay(-1L, utc))
        assertEquals(0L, HistoryLogic.epochDay(0L, utc))
        assertEquals(0L, HistoryLogic.epochDay(day - 1L, utc))
        assertEquals(1L, HistoryLogic.epochDay(day, utc))
    }

    @Test
    fun bucketsAreTodayYesterdayAndOther() {
        val now = 100L * day + 10 * hour
        assertEquals(DayBucket.TODAY, HistoryLogic.bucket(now, 100L * day, utc))
        assertEquals(DayBucket.TODAY, HistoryLogic.bucket(now, now, utc))
        assertEquals(DayBucket.YESTERDAY, HistoryLogic.bucket(now, 99L * day + 23 * hour, utc))
        assertEquals(DayBucket.OTHER, HistoryLogic.bucket(now, 98L * day + 23 * hour, utc))
        // A record dated in the future (clock set back later) is neither today nor yesterday.
        assertEquals(DayBucket.OTHER, HistoryLogic.bucket(now, 101L * day, utc))
    }

    @Test
    fun groupingKeepsOrderAndSplitsAtMidnight() {
        val now = 100L * day + 12 * hour
        val items = listOf(
            item("1", 100L * day + 11 * hour),
            item("2", 100L * day + 1 * hour),
            item("3", 99L * day + 23 * hour),
            item("4", 99L * day + 2 * hour),
            item("5", 90L * day),
        )
        val groups = HistoryLogic.group(items, now, utc)
        assertEquals(listOf(DayBucket.TODAY, DayBucket.YESTERDAY, DayBucket.OTHER), groups.map { it.bucket })
        assertEquals(listOf(listOf("1", "2"), listOf("3", "4"), listOf("5")), groups.map { g -> g.items.map { it.id } })
        assertEquals(listOf(100L, 99L, 90L), groups.map { it.day })
        assertEquals(100L * day + 11 * hour, groups[0].anchor)
    }

    @Test
    fun groupingAnEmptyListGivesNoGroups() {
        assertTrue(HistoryLogic.group(emptyList(), 0L, utc).isEmpty())
    }

    @Test
    fun groupingASingleItem() {
        val groups = HistoryLogic.group(listOf(item("x", 5L * day)), 5L * day, utc)
        assertEquals(1, groups.size)
        assertEquals(DayBucket.TODAY, groups[0].bucket)
    }

    // ---- files

    @Test
    fun onlyTheFirstHundredFilesAreListed() {
        val many = item("m", files = (1..250).map { file("f$it") })
        assertEquals(100, HistoryLogic.listedFiles(many).size)
        assertEquals("f1", HistoryLogic.listedFiles(many).first().name)
        assertEquals(150, HistoryLogic.hiddenFileCount(many))
        val few = item("f", files = (1..3).map { file("f$it") })
        assertEquals(3, HistoryLogic.listedFiles(few).size)
        assertEquals(0, HistoryLogic.hiddenFileCount(few))
        val exact = item("e", files = (1..100).map { file("f$it") })
        assertEquals(0, HistoryLogic.hiddenFileCount(exact))
    }

    @Test
    fun onlyFilesWithAnUriCanBeOpened() {
        val mixed = item("x", files = listOf(file("a", "content://a"), file("b"), file("c", ""), file("d", "content://d")))
        assertEquals(listOf("a", "d"), HistoryLogic.openableFiles(mixed).map { it.name })
        assertTrue(HistoryLogic.canShare(mixed))
        assertFalse(HistoryLogic.canShare(item("sent", files = listOf(file("a")))))
        assertFalse(HistoryLogic.canShare(item("none")))
    }

    @Test
    fun shareIsLimitedToTheSameNumberAsOnTheTransferScreen() {
        val tooMany = item("t", files = (1..101).map { file("f$it", "content://f$it") })
        assertFalse(HistoryLogic.canShare(tooMany))
        val ok = item("o", files = (1..100).map { file("f$it", "content://f$it") })
        assertTrue(HistoryLogic.canShare(ok))
    }

    // ---- what a row says

    @Test
    fun partialFilesOnlyForUnfinishedRecords() {
        assertTrue(HistoryLogic.filesPartial(item("a", status = HistoryStatus.FAILED, fileCount = 5, completed = 2)))
        assertFalse(HistoryLogic.filesPartial(item("b", status = HistoryStatus.FAILED, fileCount = 5, completed = 5)))
        assertFalse(HistoryLogic.filesPartial(item("c", status = HistoryStatus.COMPLETED, fileCount = 5, completed = 2)))
        assertFalse(HistoryLogic.filesPartial(item("d", status = HistoryStatus.CANCELLED, fileCount = 0, completed = 0)))
    }

    @Test
    fun partialBytesNeedSomeButNotAllBytes() {
        assertTrue(HistoryLogic.bytesPartial(item("a", status = HistoryStatus.FAILED, totalBytes = 100, transferred = 40)))
        assertFalse(HistoryLogic.bytesPartial(item("b", status = HistoryStatus.FAILED, totalBytes = 100, transferred = 0)))
        assertFalse(HistoryLogic.bytesPartial(item("c", status = HistoryStatus.FAILED, totalBytes = 100, transferred = 100)))
        assertFalse(HistoryLogic.bytesPartial(item("d", status = HistoryStatus.COMPLETED, totalBytes = 100, transferred = 40)))
        assertFalse(HistoryLogic.bytesPartial(item("e", status = HistoryStatus.CANCELLED, totalBytes = 0, transferred = 0)))
    }

    @Test
    fun failureIsShownForUnfinishedRecordsThatKnowWhy() {
        assertTrue(HistoryLogic.showsFailure(item("a", status = HistoryStatus.FAILED, failure = TransferFailure.TIMEOUT)))
        assertTrue(HistoryLogic.showsFailure(item("b", status = HistoryStatus.CANCELLED, failure = TransferFailure.DECLINED)))
        assertFalse(HistoryLogic.showsFailure(item("c", status = HistoryStatus.CANCELLED)))
        assertFalse(HistoryLogic.showsFailure(item("d", status = HistoryStatus.COMPLETED, failure = TransferFailure.TIMEOUT)))
    }
}
