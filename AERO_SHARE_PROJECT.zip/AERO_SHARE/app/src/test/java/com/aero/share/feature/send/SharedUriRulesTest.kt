package com.aero.share.feature.send

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SharedUriRulesTest {
    @Test
    fun onlyContentUrisAreAccepted() {
        assertTrue(SharedUriRules.isAcceptable("content"))
        assertTrue(SharedUriRules.isAcceptable("CONTENT"))
        assertFalse(SharedUriRules.isAcceptable("file"))
        assertFalse(SharedUriRules.isAcceptable("http"))
        assertFalse(SharedUriRules.isAcceptable("android.resource"))
        assertFalse(SharedUriRules.isAcceptable(null))
        assertFalse(SharedUriRules.isAcceptable(""))
    }

    @Test
    fun reportedNameWins() {
        assertEquals("Holiday.jpg", SharedUriRules.displayName("Holiday.jpg", "42"))
    }

    @Test
    fun lastSegmentIsUsedWhenNothingWasReported() {
        assertEquals("report.pdf", SharedUriRules.displayName(null, "docs/report.pdf"))
        assertEquals("report.pdf", SharedUriRules.displayName("  ", "primary:Download/report.pdf"))
    }

    @Test
    fun separatorsNeverSurvive() {
        assertEquals("a_b", SharedUriRules.displayName("a/b", null))
        assertEquals("a_b", SharedUriRules.displayName("a\\b", null))
    }

    @Test
    fun dotNamesFallBack() {
        assertEquals(SharedUriRules.FALLBACK_NAME, SharedUriRules.displayName("..", null))
        assertEquals(SharedUriRules.FALLBACK_NAME, SharedUriRules.displayName(".", null))
        assertEquals(SharedUriRules.FALLBACK_NAME, SharedUriRules.displayName(null, null))
        assertEquals(SharedUriRules.FALLBACK_NAME, SharedUriRules.displayName("", ""))
    }

    @Test
    fun distinctDropsBlanksAndRepeatsInOrder() {
        assertEquals(listOf("a", "b", "c"), SharedUriRules.distinct(listOf("a", "", "b", "a", " ", "c", "b")))
    }

    @Test
    fun distinctIsCapped() {
        val many = (0 until SharedUriRules.MAX_SHARED + 50).map { "content://x/$it" }
        assertEquals(SharedUriRules.MAX_SHARED, SharedUriRules.distinct(many).size)
    }
}
