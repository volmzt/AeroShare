package com.aero.share.network.transport

import com.aero.share.domain.LinkQuality
import com.aero.share.domain.NearbyDevice
import com.aero.share.transfer.model.DeviceKind
import com.aero.share.transfer.model.TransportKind
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class DeviceMergeTest {
    private fun device(
        id: String,
        name: String = id,
        quality: LinkQuality = LinkQuality.UNKNOWN,
        transports: Set<TransportKind> = setOf(TransportKind.LAN),
        addresses: List<String> = listOf("192.168.1.5"),
        p2p: String? = null,
        fingerprint: String? = null,
        seen: Long = 0,
        capabilities: Int = 0,
    ) = NearbyDevice(id, name, DeviceKind.PHONE, fingerprint, "1.0", addresses, 4000, transports, quality, seen, p2p, capabilities)

    @Test
    fun lanOnlyIsSortedByQualityThenName() {
        val merged = DeviceMerge.merge(
            listOf(
                device("a", "beta", LinkQuality.FAIR),
                device("b", "alpha", LinkQuality.UNKNOWN),
                device("c", "gamma", LinkQuality.STRONG),
                device("d", "Alpha2", LinkQuality.FAIR),
            ),
            emptyList(),
        )
        assertEquals(listOf("gamma", "Alpha2", "beta", "alpha"), merged.map { it.name })
    }

    @Test
    fun directOnlyDevicesAreKept() {
        val direct = device("p", transports = setOf(TransportKind.WIFI_DIRECT), addresses = emptyList(), p2p = "aa:bb:cc:dd:ee:01")
        assertEquals(listOf(direct), DeviceMerge.merge(emptyList(), listOf(direct)))
    }

    @Test
    fun sameDeviceOnBothTransportsBecomesOneEntry() {
        val lan = device("x", "Phone", LinkQuality.STRONG, fingerprint = "fp1", seen = 10, capabilities = 7)
        val direct = device(
            "x", "Phone (p2p)", LinkQuality.UNKNOWN, setOf(TransportKind.WIFI_DIRECT), emptyList(),
            "aa:bb:cc:dd:ee:01", fingerprint = "fp2", seen = 20, capabilities = 3,
        )
        val merged = DeviceMerge.merge(listOf(lan), listOf(direct)).single()
        assertEquals("Phone", merged.name)
        assertEquals(setOf(TransportKind.LAN, TransportKind.WIFI_DIRECT), merged.transports)
        assertEquals(listOf("192.168.1.5"), merged.addresses)
        assertEquals("aa:bb:cc:dd:ee:01", merged.p2pAddress)
        assertEquals(LinkQuality.STRONG, merged.quality)
        assertEquals("fp1", merged.fingerprint)
        assertEquals(20L, merged.lastSeenElapsed)
        assertEquals(7, merged.capabilities)
    }

    @Test
    fun missingValuesAreTakenFromTheOtherSource() {
        val lan = device("x", name = "", fingerprint = null, capabilities = 0)
        val direct = device("x", name = "Name", transports = setOf(TransportKind.WIFI_DIRECT), fingerprint = "fp", capabilities = 5)
        val merged = DeviceMerge.merge(listOf(lan), listOf(direct)).single()
        assertEquals("Name", merged.name)
        assertEquals("fp", merged.fingerprint)
        assertEquals(5, merged.capabilities)
        assertNull(device("y").p2pAddress)
    }

    @Test
    fun addressesAreUnitedWithoutDuplicates() {
        val lan = device("x", addresses = listOf("192.168.1.5", "10.0.0.2"))
        val direct = device("x", addresses = listOf("10.0.0.2", "192.168.49.1"), transports = setOf(TransportKind.WIFI_DIRECT))
        val merged = DeviceMerge.merge(listOf(lan), listOf(direct)).single()
        assertEquals(listOf("192.168.1.5", "10.0.0.2", "192.168.49.1"), merged.addresses)
    }

    @Test
    fun betterQualityFromEitherSourceWins() {
        val lan = device("x", quality = LinkQuality.WEAK)
        val direct = device("x", quality = LinkQuality.FAIR, transports = setOf(TransportKind.WIFI_DIRECT))
        assertEquals(LinkQuality.FAIR, DeviceMerge.merge(listOf(lan), listOf(direct)).single().quality)
        assertTrue(DeviceMerge.merge(emptyList(), emptyList()).isEmpty())
    }
}
