package com.aero.share.feature.home

import com.aero.share.domain.DeviceRecord
import com.aero.share.domain.DiscoveryProblem
import com.aero.share.domain.DiscoveryState
import com.aero.share.domain.DiscoveryStatus
import com.aero.share.domain.LinkQuality
import com.aero.share.domain.NearbyDevice
import com.aero.share.transfer.model.DeviceKind
import com.aero.share.transfer.model.TransferDirection
import com.aero.share.transfer.model.TransferSnapshot
import com.aero.share.transfer.model.TransferState
import com.aero.share.transfer.model.TransportKind
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class HomeLogicTest {
    private fun nearby(id: String, name: String = "Device $id") = NearbyDevice(
        deviceId = id,
        name = name,
        kind = DeviceKind.PHONE,
        fingerprint = null,
        appVersion = "1.0.0",
        addresses = listOf("192.168.1.5"),
        port = 47474,
        transports = setOf(TransportKind.LAN),
        quality = LinkQuality.UNKNOWN,
        lastSeenElapsed = 1_000L,
    )

    private fun record(id: String, alias: String? = null, trusted: Boolean = false, blocked: Boolean = false) = DeviceRecord(
        deviceId = id,
        name = "stored $id",
        alias = alias,
        kind = DeviceKind.PHONE,
        model = null,
        fingerprint = "f".repeat(64),
        firstSeen = 1L,
        lastSeen = 2L,
        trusted = trusted,
        blocked = blocked,
        capabilities = 0,
        lastAddress = null,
        lastTransport = null,
    )

    private fun transfer(
        id: String,
        state: TransferState,
        direction: TransferDirection = TransferDirection.SEND,
        total: Long = 0L,
        done: Long = 0L,
    ) = TransferSnapshot(id = id, direction = direction, state = state, totalBytes = total, transferredBytes = done)

    private fun searching() = DiscoveryState(DiscoveryStatus.SEARCHING)

    private fun problem(p: DiscoveryProblem?) = DiscoveryState(DiscoveryStatus.PROBLEM, p)

    // ---------------------------------------------------------------- empty states

    @Test
    fun noEmptyStateWhileThereAreDevices() {
        for (state in listOf(DiscoveryState(), searching(), problem(DiscoveryProblem.WIFI_OFF))) {
            assertNull(HomeLogic.emptyState(1, state, searchedLongEnough = true, searchWanted = true))
        }
    }

    @Test
    fun everyDiscoveryProblemHasItsOwnEmptyState() {
        assertEquals(HomeEmpty.WIFI_OFF, HomeLogic.emptyState(0, problem(DiscoveryProblem.WIFI_OFF), false, true))
        assertEquals(HomeEmpty.NO_NETWORK, HomeLogic.emptyState(0, problem(DiscoveryProblem.NO_NETWORK), false, true))
        assertEquals(HomeEmpty.PERMISSION, HomeLogic.emptyState(0, problem(DiscoveryProblem.PERMISSION_MISSING), false, true))
        assertEquals(HomeEmpty.UNAVAILABLE, HomeLogic.emptyState(0, problem(DiscoveryProblem.UNAVAILABLE), false, true))
    }

    @Test
    fun aProblemWithoutAReasonIsReportedAsUnavailableNotHidden() {
        assertEquals(HomeEmpty.UNAVAILABLE, HomeLogic.emptyState(0, problem(null), false, true))
    }

    @Test
    fun searchingTurnsIntoNoneFoundOnlyAfterTheGracePeriod() {
        assertEquals(HomeEmpty.SEARCHING, HomeLogic.emptyState(0, searching(), searchedLongEnough = false, searchWanted = true))
        assertEquals(HomeEmpty.NONE_FOUND, HomeLogic.emptyState(0, searching(), searchedLongEnough = true, searchWanted = true))
    }

    @Test
    fun idleIsShownAsPausedOnlyWhenNobodyAskedForASearch() {
        assertEquals(HomeEmpty.IDLE, HomeLogic.emptyState(0, DiscoveryState(), false, searchWanted = false))
        assertEquals(HomeEmpty.SEARCHING, HomeLogic.emptyState(0, DiscoveryState(), false, searchWanted = true))
    }

    @Test
    fun theProblemIsNeverHiddenByTheSearchFlags() {
        assertEquals(HomeEmpty.WIFI_OFF, HomeLogic.emptyState(0, problem(DiscoveryProblem.WIFI_OFF), true, false))
    }

    // ---------------------------------------------------------------- device rows

    @Test
    fun anAliasReplacesTheAnnouncedName() {
        val rows = HomeLogic.devices(listOf(nearby("a", "Pixel")), listOf(record("a", alias = "Mum's phone")))
        assertEquals("Mum's phone", rows.single().displayName)
    }

    @Test
    fun aBlankAliasIsIgnored() {
        val rows = HomeLogic.devices(listOf(nearby("a", "Pixel")), listOf(record("a", alias = "   ")))
        assertEquals("Pixel", rows.single().displayName)
    }

    @Test
    fun aDeviceThatWasNeverSavedIsNeitherTrustedNorBlocked() {
        val row = HomeLogic.devices(listOf(nearby("new")), emptyList()).single()
        assertFalse(row.trusted)
        assertFalse(row.blocked)
    }

    @Test
    fun anAnnouncedNameIsTrimmedAndAMissingOneStaysBlank() {
        assertEquals("Pixel", HomeLogic.devices(listOf(nearby("a", "  Pixel \n")), emptyList()).single().displayName)
        assertEquals("", HomeLogic.devices(listOf(nearby("a", "   ")), emptyList()).single().displayName)
    }

    @Test
    fun trustedDevicesComeFirstAndBlockedOnesLast() {
        val rows = HomeLogic.devices(
            listOf(nearby("1", "Alpha"), nearby("2", "Bravo"), nearby("3", "Charlie"), nearby("4", "Delta")),
            listOf(record("2", trusted = true), record("3", blocked = true), record("4", trusted = true, blocked = true)),
        )
        assertEquals(listOf("2", "1", "4", "3"), rows.map { it.device.deviceId })
    }

    @Test
    fun devicesAreOrderedByNameIgnoringCaseWithTheIdAsTieBreak() {
        val rows = HomeLogic.devices(
            listOf(nearby("z", "bob"), nearby("y", "Alice"), nearby("x", "alice"), nearby("w", "Carol")),
            emptyList(),
        )
        assertEquals(listOf("x", "y", "z", "w"), rows.map { it.device.deviceId })
    }

    @Test
    fun theOrderDoesNotDependOnTheOrderDiscoveryReportedThem() {
        val a = listOf(nearby("1", "A"), nearby("2", "B"), nearby("3", "C"))
        assertEquals(HomeLogic.devices(a, emptyList()).map { it.device.deviceId }, HomeLogic.devices(a.reversed(), emptyList()).map { it.device.deviceId })
    }

    // ---------------------------------------------------------------- banner

    @Test
    fun noBannerWithoutRunningTransfers() {
        assertNull(HomeLogic.banner(emptyList()))
        val finished = listOf(
            transfer("1", TransferState.COMPLETED),
            transfer("2", TransferState.FAILED),
            transfer("3", TransferState.CANCELLED),
        )
        assertNull(HomeLogic.banner(finished))
    }

    @Test
    fun anActiveTransferWinsOverAnInterruptedOneEvenWhenItIsOlder() {
        val banner = HomeLogic.banner(
            listOf(transfer("new-but-interrupted", TransferState.INTERRUPTED), transfer("running", TransferState.TRANSFERRING)),
        )
        assertNotNull(banner)
        assertEquals("running", banner?.transfer?.id)
        assertEquals(1, banner?.additional)
    }

    @Test
    fun aQueuedTransferIsAnnouncedWhenNothingElseIsRunning() {
        val banner = HomeLogic.banner(listOf(transfer("queued", TransferState.WAITING), transfer("done", TransferState.COMPLETED)))
        assertEquals("queued", banner?.transfer?.id)
        assertEquals(0, banner?.additional)
    }

    @Test
    fun theCountOfAdditionalTransfersCoversEveryRelevantOne() {
        val banner = HomeLogic.banner(
            listOf(
                transfer("a", TransferState.CONNECTING),
                transfer("b", TransferState.WAITING),
                transfer("c", TransferState.PAUSED),
                transfer("d", TransferState.COMPLETED),
            ),
        )
        assertEquals("a", banner?.transfer?.id)
        assertEquals(2, banner?.additional)
    }

    @Test
    fun theKindFollowsTheDirectionExceptForInterruptedTransfers() {
        assertEquals(BannerKind.SENDING, HomeLogic.bannerKind(transfer("1", TransferState.TRANSFERRING, TransferDirection.SEND)))
        assertEquals(BannerKind.RECEIVING, HomeLogic.bannerKind(transfer("2", TransferState.TRANSFERRING, TransferDirection.RECEIVE)))
        assertEquals(BannerKind.INTERRUPTED, HomeLogic.bannerKind(transfer("3", TransferState.INTERRUPTED, TransferDirection.RECEIVE)))
        assertEquals(BannerKind.INTERRUPTED, HomeLogic.bannerKind(transfer("4", TransferState.INTERRUPTED, TransferDirection.SEND)))
    }

    @Test
    fun progressIsDeterminateOnlyWhenBytesAreFlowingAndTheTotalIsKnown() {
        assertEquals(BannerProgress.DETERMINATE, HomeLogic.bannerProgress(transfer("1", TransferState.TRANSFERRING, total = 100, done = 10)))
        assertEquals(BannerProgress.DETERMINATE, HomeLogic.bannerProgress(transfer("2", TransferState.PAUSED, total = 100, done = 10)))
        assertEquals(BannerProgress.DETERMINATE, HomeLogic.bannerProgress(transfer("3", TransferState.VERIFYING, total = 100, done = 100)))
        assertEquals(BannerProgress.INDETERMINATE, HomeLogic.bannerProgress(transfer("4", TransferState.TRANSFERRING, total = 0)))
    }

    @Test
    fun beforeTheDataFlowsTheBarIsIndeterminateAndAfterwardsItIsAbsent() {
        for (state in listOf(TransferState.PREPARING, TransferState.CONNECTING, TransferState.AWAITING_ACCEPTANCE)) {
            assertEquals(state.name, BannerProgress.INDETERMINATE, HomeLogic.bannerProgress(transfer("x", state)))
        }
        for (state in listOf(TransferState.WAITING, TransferState.INTERRUPTED, TransferState.COMPLETED, TransferState.FAILED, TransferState.CANCELLED)) {
            assertEquals(state.name, BannerProgress.NONE, HomeLogic.bannerProgress(transfer("x", state)))
        }
    }

    @Test
    fun everyStateHasAProgressDecision() {
        for (state in TransferState.entries) {
            assertNotNull(HomeLogic.bannerProgress(transfer("x", state, total = 5)))
        }
    }

    @Test
    fun sizesAreShownOnlyWhileTransferringOrPausedWithAKnownTotal() {
        assertTrue(HomeLogic.bannerShowsSizes(transfer("1", TransferState.TRANSFERRING, total = 10, done = 1)))
        assertTrue(HomeLogic.bannerShowsSizes(transfer("2", TransferState.PAUSED, total = 10, done = 1)))
        assertFalse(HomeLogic.bannerShowsSizes(transfer("3", TransferState.TRANSFERRING, total = 0)))
        assertFalse(HomeLogic.bannerShowsSizes(transfer("4", TransferState.CONNECTING, total = 10)))
        assertFalse(HomeLogic.bannerShowsSizes(transfer("5", TransferState.VERIFYING, total = 10)))
    }

    @Test
    fun theGracePeriodIsAFewSeconds() {
        assertTrue(HomeLogic.NONE_FOUND_AFTER_MS in 3_000L..20_000L)
    }
}
