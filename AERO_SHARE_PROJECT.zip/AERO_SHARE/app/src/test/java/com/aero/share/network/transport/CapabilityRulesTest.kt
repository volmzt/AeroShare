package com.aero.share.network.transport

import com.aero.share.domain.CapabilityState
import com.aero.share.domain.TransportCapability
import com.aero.share.transfer.model.TransportKind
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CapabilityRulesTest {
    private fun facts(
        sdk: Int = 34,
        hardware: Boolean = true,
        direct: Boolean = true,
        wifi: Boolean = true,
        lan: Boolean = true,
        nearby: Boolean = true,
        location: Boolean = true,
    ) = CapabilityFacts(
        sdkInt = sdk,
        hasWifiHardware = hardware,
        hasWifiDirect = direct,
        wifiEnabled = wifi,
        lanConnected = lan,
        wifiConnected = lan,
        nearbyGranted = nearby,
        locationEnabled = location,
    )

    private fun states(f: CapabilityFacts): Map<TransportKind, CapabilityState> =
        CapabilityRules.compute(f).associate { it.kind to it.state }

    @Test
    fun everythingAvailableOnAConnectedDevice() {
        val result = states(facts())
        assertEquals(CapabilityState.AVAILABLE, result[TransportKind.LAN])
        assertEquals(CapabilityState.AVAILABLE, result[TransportKind.WIFI_DIRECT])
        assertEquals(CapabilityState.AVAILABLE, result[TransportKind.HOTSPOT])
        assertEquals(CapabilityState.AVAILABLE, result[TransportKind.MANUAL])
        assertEquals(4, CapabilityRules.compute(facts()).size)
    }

    @Test
    fun wifiOffIsReportedAsRadioOff() {
        val result = states(facts(wifi = false, lan = false))
        assertEquals(CapabilityState.RADIO_OFF, result[TransportKind.LAN])
        assertEquals(CapabilityState.RADIO_OFF, result[TransportKind.MANUAL])
        assertEquals(CapabilityState.RADIO_OFF, result[TransportKind.WIFI_DIRECT])
        assertEquals(CapabilityState.AVAILABLE, result[TransportKind.HOTSPOT])
    }

    @Test
    fun wifiOnWithoutNetworkIsNoNetwork() {
        val result = states(facts(lan = false))
        assertEquals(CapabilityState.NO_NETWORK, result[TransportKind.LAN])
        assertEquals(CapabilityState.NO_NETWORK, result[TransportKind.MANUAL])
        assertEquals(CapabilityState.AVAILABLE, result[TransportKind.WIFI_DIRECT])
    }

    @Test
    fun missingPermissionBlocksWifiDirectAndHotspotOnly() {
        val result = states(facts(nearby = false))
        assertEquals(CapabilityState.PERMISSION_MISSING, result[TransportKind.WIFI_DIRECT])
        assertEquals(CapabilityState.PERMISSION_MISSING, result[TransportKind.HOTSPOT])
        assertEquals(CapabilityState.AVAILABLE, result[TransportKind.LAN])
    }

    @Test
    fun permissionIsReportedBeforeWifiOff() {
        val result = states(facts(nearby = false, wifi = false, lan = false))
        assertEquals(CapabilityState.PERMISSION_MISSING, result[TransportKind.WIFI_DIRECT])
    }

    @Test
    fun missingHardwareFeaturesAreUnsupported() {
        val noDirect = states(facts(direct = false))
        assertEquals(CapabilityState.UNSUPPORTED, noDirect[TransportKind.WIFI_DIRECT])
        assertEquals(CapabilityState.AVAILABLE, noDirect[TransportKind.HOTSPOT])
        val noWifi = states(facts(hardware = false, lan = false, wifi = false))
        assertEquals(CapabilityState.UNSUPPORTED, noWifi[TransportKind.WIFI_DIRECT])
        assertEquals(CapabilityState.UNSUPPORTED, noWifi[TransportKind.HOTSPOT])
        assertEquals(CapabilityState.NO_NETWORK, noWifi[TransportKind.LAN])
    }

    @Test
    fun locationSwitchMattersOnlyOnOlderAndroid() {
        val old = states(facts(sdk = 30, location = false))
        assertEquals(CapabilityState.RADIO_OFF, old[TransportKind.WIFI_DIRECT])
        assertEquals(CapabilityState.RADIO_OFF, old[TransportKind.HOTSPOT])
        val oldOn = states(facts(sdk = 30, location = true))
        assertEquals(CapabilityState.AVAILABLE, oldOn[TransportKind.WIFI_DIRECT])
        val modern = states(facts(sdk = 34, location = false))
        assertEquals(CapabilityState.AVAILABLE, modern[TransportKind.WIFI_DIRECT])
        assertEquals(CapabilityState.AVAILABLE, modern[TransportKind.HOTSPOT])
    }

    @Test
    fun hotspotNeedsApi26() {
        assertEquals(CapabilityState.UNSUPPORTED, states(facts(sdk = 25))[TransportKind.HOTSPOT])
    }

    @Test
    fun stateLookupTreatsMissingEntriesAsUnsupported() {
        val list = listOf(TransportCapability(TransportKind.LAN, CapabilityState.AVAILABLE))
        assertEquals(CapabilityState.AVAILABLE, list.stateOf(TransportKind.LAN))
        assertEquals(CapabilityState.UNSUPPORTED, list.stateOf(TransportKind.WIFI_DIRECT))
    }

    @Test
    fun radioStatusMirrorsTheFacts() {
        val radio = CapabilityRules.radio(
            facts(sdk = 31, wifi = true, lan = false).copy(bluetoothSupported = true, bluetoothEnabled = false, locationEnabled = true),
        )
        assertTrue(radio.wifiEnabled)
        assertEquals(false, radio.wifiConnected)
        assertTrue(radio.bluetoothSupported)
        assertEquals(false, radio.bluetoothEnabled)
        assertTrue(radio.locationEnabled)
        assertEquals(31, radio.sdkInt)
        assertNull(null)
    }
}
