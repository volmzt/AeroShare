package com.aero.share.transfer.service

import com.aero.share.transfer.model.TransferDirection
import com.aero.share.transfer.model.TransferState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ServiceStateTest {
    private fun transfer(id: String = "t1", state: TransferState = TransferState.TRANSFERRING, done: Long = 0L) =
        ServiceTransfer(id, TransferDirection.SEND, state, done, 1_000L, 0L)

    @Test
    fun nothingToDoMeansIdle() {
        assertTrue(ServiceState().idle)
        assertFalse(ServiceState(waiting = 1).idle)
        assertFalse(ServiceState(receiving = true).idle)
        assertFalse(ServiceState(active = listOf(transfer())).idle)
    }

    @Test
    fun locksAreHeldOnlyWhileATransferIsActive() {
        assertFalse(ServiceState().holdsLocks)
        assertFalse("a listening receiver alone must not hold a wake lock", ServiceState(receiving = true).holdsLocks)
        assertFalse(ServiceState(waiting = 3).holdsLocks)
        assertTrue(ServiceState(active = listOf(transfer())).holdsLocks)
    }

    @Test
    fun theLayoutKeyIgnoresProgressButNoticesRealChanges() {
        val base = ServiceState(active = listOf(transfer(done = 10L)), waiting = 1, receiving = false)
        assertEquals(base.layoutKey(), base.copy(active = listOf(transfer(done = 900L))).layoutKey())
        assertNotEquals(base.layoutKey(), base.copy(active = listOf(transfer(state = TransferState.PAUSED))).layoutKey())
        assertNotEquals(base.layoutKey(), base.copy(active = listOf(transfer(), transfer(id = "t2"))).layoutKey())
        assertNotEquals(base.layoutKey(), base.copy(waiting = 2).layoutKey())
        assertNotEquals(base.layoutKey(), base.copy(receiving = true).layoutKey())
        assertNotEquals(base.layoutKey(), base.copy(active = listOf(transfer(id = "other"))).layoutKey())
    }

    private class RecordingHost : TransferServiceBridge.Host {
        val actions = ArrayList<Pair<ServiceAction, String?>>()
        var timeouts = 0
        var stops = 0

        override fun onServiceAction(action: ServiceAction, transferId: String?) {
            actions.add(action to transferId)
        }

        override fun onServiceTimeout() {
            timeouts++
        }

        override fun onServiceStopped() {
            stops++
        }
    }

    @Test
    fun theBridgeForwardsEverythingToTheRegisteredHost() {
        val host = RecordingHost()
        TransferServiceBridge.attach(host)
        TransferServiceBridge.dispatch(ServiceAction.PAUSE, "abc")
        TransferServiceBridge.dispatch(ServiceAction.STOP_RECEIVING, null)
        TransferServiceBridge.timeout()
        TransferServiceBridge.serviceStopped()
        assertEquals(listOf(ServiceAction.PAUSE to "abc", ServiceAction.STOP_RECEIVING to null), host.actions)
        assertNull(host.actions[1].second)
        assertEquals(1, host.timeouts)
        assertEquals(1, host.stops)
    }

    @Test
    fun theLatestHostReplacesTheEarlierOne() {
        val first = RecordingHost()
        val second = RecordingHost()
        TransferServiceBridge.attach(first)
        TransferServiceBridge.attach(second)
        TransferServiceBridge.dispatch(ServiceAction.CANCEL, "x")
        assertTrue(first.actions.isEmpty())
        assertEquals(1, second.actions.size)
    }

    @Test
    fun publishedStateIsReadableByTheService() {
        val state = ServiceState(active = listOf(transfer()), waiting = 2, receiving = true, lowLatencyWifi = true)
        TransferServiceBridge.update(state)
        assertEquals(state, TransferServiceBridge.state.value)
        TransferServiceBridge.update(ServiceState())
        assertTrue(TransferServiceBridge.state.value.idle)
    }
}
