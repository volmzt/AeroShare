package com.aero.share.feature.devices

import com.aero.share.domain.DeviceRecord
import com.aero.share.domain.LinkQuality
import com.aero.share.domain.NearbyDevice
import com.aero.share.transfer.model.Capabilities
import com.aero.share.transfer.model.DeviceKind
import com.aero.share.transfer.model.TransportKind
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class DevicesLogicTest {
    private fun record(
        id: String,
        name: String = "Pixel",
        alias: String? = null,
        trusted: Boolean = false,
        blocked: Boolean = false,
    ) = DeviceRecord(
        deviceId = id,
        name = name,
        alias = alias,
        kind = DeviceKind.PHONE,
        model = null,
        fingerprint = "ab".repeat(32),
        firstSeen = 1_000L,
        lastSeen = 2_000L,
        trusted = trusted,
        blocked = blocked,
        capabilities = 0,
        lastAddress = null,
        lastTransport = null,
    )

    private fun nearby(id: String, name: String = "Pixel") = NearbyDevice(
        deviceId = id,
        name = name,
        kind = DeviceKind.PHONE,
        fingerprint = null,
        appVersion = null,
        addresses = listOf("192.168.1.5"),
        port = 5000,
        transports = setOf(TransportKind.LAN),
        quality = LinkQuality.UNKNOWN,
        lastSeenElapsed = 0L,
    )

    // ---- known devices

    @Test
    fun knownKeepsTheOrderOfTheRepositoryAndAttachesTheLiveEntry() {
        val rows = DevicesLogic.known(
            listOf(record("b", trusted = true), record("a"), record("c")),
            listOf(nearby("c"), nearby("x")),
        )
        assertEquals(listOf("b", "a", "c"), rows.map { it.record.deviceId })
        assertNull(rows[0].nearby)
        assertNull(rows[1].nearby)
        assertEquals("c", rows[2].nearby?.deviceId)
    }

    @Test
    fun knownIsEmptyWithoutRecords() {
        assertTrue(DevicesLogic.known(emptyList(), listOf(nearby("a"))).isEmpty())
    }

    // ---- identifiers

    @Test
    fun shortIdIsUpperCaseAndSplitInTwo() {
        assertEquals("3F9A-12BC", DevicesLogic.shortId("3f9a12bc77aa88bb99"))
        assertEquals("ABCD-E", DevicesLogic.shortId("abcde"))
        assertEquals("ABCD", DevicesLogic.shortId("abcd"))
        assertEquals("", DevicesLogic.shortId("  "))
    }

    @Test
    fun shortIdNeverRevealsTheWholeIdentifier() {
        val id = "0123456789abcdef0123456789abcdef"
        assertTrue(DevicesLogic.shortId(id).replace("-", "").length < id.length)
    }

    @Test
    fun fingerprintIsGroupedInFoursFourBlocksPerLine() {
        val fingerprint = "0123456789abcdef".repeat(4)
        val grouped = DevicesLogic.groupFingerprint(fingerprint)
        val lines = grouped.split("\n")
        assertEquals(4, lines.size)
        assertEquals("0123 4567 89AB CDEF", lines[0])
        for (line in lines) assertEquals(4, line.split(" ").size)
        assertEquals(fingerprint.uppercase(), grouped.replace(" ", "").replace("\n", ""))
    }

    @Test
    fun fingerprintGroupingToleratesColonsAndShortInput() {
        assertEquals("AB12 CD", DevicesLogic.groupFingerprint("ab:12:cd"))
        assertEquals("", DevicesLogic.groupFingerprint(""))
        assertEquals("", DevicesLogic.groupFingerprint(" : "))
    }

    // ---- features

    @Test
    fun featuresFollowTheCapabilityBits() {
        assertTrue(DevicesLogic.features(0).isEmpty())
        assertEquals(
            listOf(DeviceFeature.COMPRESSION, DeviceFeature.RESUME, DeviceFeature.FOLDERS, DeviceFeature.WIFI_DIRECT, DeviceFeature.APK_BUNDLE),
            DevicesLogic.features(Capabilities.ALL),
        )
        assertEquals(
            listOf(DeviceFeature.RESUME, DeviceFeature.WIFI_DIRECT),
            DevicesLogic.features(Capabilities.RESUME or Capabilities.WIFI_DIRECT),
        )
    }

    @Test
    fun unknownBitsAreIgnored() {
        assertEquals(listOf(DeviceFeature.FOLDERS), DevicesLogic.features(Capabilities.FOLDERS or 0x400))
    }

    // ---- sending

    @Test
    fun sendingNeedsANearbyDeviceThatIsNotBlocked() {
        assertEquals(SendAvailability.AVAILABLE, DevicesLogic.availability(false, nearby("a")))
        assertEquals(SendAvailability.NOT_NEARBY, DevicesLogic.availability(false, null))
        assertEquals(SendAvailability.BLOCKED, DevicesLogic.availability(true, nearby("a")))
        assertEquals(SendAvailability.BLOCKED, DevicesLogic.availability(true, null))
    }

    // ---- last seen

    @Test
    fun seenAgoUsesTheLargestFittingUnit() {
        val now = 100L * 24 * 3_600_000L
        fun ago(millis: Long) = DevicesLogic.seenAgo(now, now - millis)
        assertEquals(SeenAgo(SeenUnit.NOW), ago(0L))
        assertEquals(SeenAgo(SeenUnit.NOW), ago(59_999L))
        assertEquals(SeenAgo(SeenUnit.MINUTES, 1), ago(60_000L))
        assertEquals(SeenAgo(SeenUnit.MINUTES, 59), ago(59 * 60_000L + 59_000L))
        assertEquals(SeenAgo(SeenUnit.HOURS, 1), ago(3_600_000L))
        assertEquals(SeenAgo(SeenUnit.HOURS, 23), ago(23 * 3_600_000L + 1L))
        assertEquals(SeenAgo(SeenUnit.DAYS, 1), ago(24 * 3_600_000L))
        assertEquals(SeenAgo(SeenUnit.DAYS, 29), ago(29L * 24 * 3_600_000L + 5L))
        assertEquals(SeenAgo(SeenUnit.DATE), ago(30L * 24 * 3_600_000L))
    }

    @Test
    fun seenAgoHandlesTheFutureAndMissingTimes() {
        assertEquals(SeenAgo(SeenUnit.NOW), DevicesLogic.seenAgo(1_000L, 5_000L))
        assertEquals(SeenAgo(SeenUnit.NEVER), DevicesLogic.seenAgo(1_000L, 0L))
        assertEquals(SeenAgo(SeenUnit.NEVER), DevicesLogic.seenAgo(1_000L, -1L))
    }

    // ---- alias

    @Test
    fun aliasIsTrimmedAndEmptyResetsIt() {
        assertEquals("Mum’s phone", DevicesLogic.aliasOf("  Mum’s phone  "))
        assertNull(DevicesLogic.aliasOf(""))
        assertNull(DevicesLogic.aliasOf("   "))
    }

    @Test
    fun aliasIsLimitedToFortyCharacters() {
        val alias = DevicesLogic.aliasOf("x".repeat(100))
        assertEquals(40, alias?.length)
        val spaced = DevicesLogic.aliasOf("a".repeat(39) + " bbbb")
        assertFalse(spaced.orEmpty().endsWith(" "))
    }

    // ---- target

    @Test
    fun aTargetPrefersTheStoredNameAndKnowsWhatCanBeManaged() {
        val stored = DeviceTarget("a", record("a", name = "Pixel", alias = "Mum"), nearby("a", name = "Pixel"))
        assertEquals("Mum", stored.name)
        assertTrue(stored.manageable)
        val onlyLive = DeviceTarget("b", null, nearby("b", name = "Galaxy"))
        assertEquals("Galaxy", onlyLive.name)
        assertFalse(onlyLive.manageable)
        assertFalse(onlyLive.trusted)
        assertFalse(onlyLive.blocked)
        val blocked = DeviceTarget("c", record("c", blocked = true, trusted = true), null)
        assertTrue(blocked.blocked)
        assertTrue(blocked.trusted)
    }
}
