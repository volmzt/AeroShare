package com.aero.share.core.common

import com.aero.share.transfer.model.DeviceKind
import java.util.Locale
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Before
import org.junit.Test

class FormattersTest {
    private var saved: Locale = Locale.getDefault()

    @Before
    fun setUp() {
        saved = Locale.getDefault()
        Locale.setDefault(Locale.US)
    }

    @After
    fun tearDown() {
        Locale.setDefault(saved)
    }

    @Test
    fun bytesEdges() {
        assertEquals("0 B", Formatters.bytes(0))
        assertEquals("0 B", Formatters.bytes(-5))
        assertEquals("1 B", Formatters.bytes(1))
        assertEquals("1023 B", Formatters.bytes(1023))
        assertEquals("1.0 KB", Formatters.bytes(1024))
        assertEquals("1.5 KB", Formatters.bytes(1536))
        assertEquals("1.0 MB", Formatters.bytes(1024L * 1024))
        assertEquals("1.0 MB", Formatters.bytes(1024L * 1024 - 1)) // carries instead of "1024.0 KB"
        assertEquals("2.4 GB", Formatters.bytes((2.4 * 1024 * 1024 * 1024).toLong()))
        assertEquals("1.0 TB", Formatters.bytes(1024L * 1024 * 1024 * 1024))
        assertEquals("8388608.0 TB", Formatters.bytes(Long.MAX_VALUE))
    }

    @Test
    fun speed() {
        assertEquals("0 B/s", Formatters.speed(0))
        assertEquals("12.6 MB/s", Formatters.speed(13_212_058))
        assertEquals("512 B/s", Formatters.speed(512))
    }

    @Test
    fun duration() {
        assertEquals("0:00", Formatters.duration(0))
        assertEquals("0:00", Formatters.duration(-1000))
        assertEquals("0:59", Formatters.duration(59_999))
        assertEquals("3:25", Formatters.duration(205_000))
        assertEquals("59:59", Formatters.duration(3_599_000))
        assertEquals("1:02:10", Formatters.duration(3_730_000))
    }

    @Test
    fun percent() {
        assertEquals("0%", Formatters.percent(0f))
        assertEquals("42%", Formatters.percent(0.42f))
        assertEquals("99%", Formatters.percent(0.999f))
        assertEquals("100%", Formatters.percent(1f))
        assertEquals("100%", Formatters.percent(3f))
        assertEquals("0%", Formatters.percent(-1f))
        assertEquals("0%", Formatters.percent(Float.NaN))
    }

    @Test
    fun localDeviceModelRules() {
        assertNull(LocalDeviceModel.cleanModel(null))
        assertNull(LocalDeviceModel.cleanModel("   "))
        assertEquals("Pixel 9", LocalDeviceModel.cleanModel("  Pixel 9 "))
        assertEquals(DeviceKind.PHONE, LocalDeviceModel.kindFor(411))
        assertEquals(DeviceKind.TABLET, LocalDeviceModel.kindFor(600))
        assertEquals("My phone", LocalDeviceModel.displayName("  My phone ", "Pixel"))
        assertEquals("Pixel", LocalDeviceModel.displayName("   ", "Pixel"))
        assertEquals("Pixel", LocalDeviceModel.displayName(null, "Pixel"))
        assertEquals(40, LocalDeviceModel.displayName("x".repeat(100), "Pixel").length)
    }
}
