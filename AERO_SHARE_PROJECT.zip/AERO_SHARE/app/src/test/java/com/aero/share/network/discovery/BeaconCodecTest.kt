package com.aero.share.network.discovery

import com.aero.share.transfer.model.DeviceKind
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class BeaconCodecTest {
    private val fingerprint = "ab".repeat(32)

    private fun presence(
        goodbye: Boolean = false,
        name: String = "Pixel 8",
        port: Int = 40123,
        version: String = "1.0.0",
        capabilities: Int = 31,
        kind: DeviceKind = DeviceKind.PHONE,
    ) = Beacon.Presence(goodbye, fingerprint, name, kind, port, version, capabilities)

    /** Offset of the first byte after the name: kind, port and so on follow. */
    private fun afterName(nameBytes: Int) = 6 + 1 + 32 + 1 + nameBytes

    @Test
    fun announceRoundTrips() {
        val p = presence()
        assertEquals(p, BeaconCodec.decode(BeaconCodec.encode(p)))
    }

    @Test
    fun goodbyeRoundTrips() {
        val p = presence(goodbye = true, kind = DeviceKind.TABLET, capabilities = -1)
        assertEquals(p, BeaconCodec.decode(BeaconCodec.encode(p)))
    }

    @Test
    fun queryRoundTrips() {
        assertEquals(Beacon.Query, BeaconCodec.decode(BeaconCodec.encodeQuery()))
    }

    @Test
    fun deviceIdIsTheFingerprintPrefix() {
        val decoded = BeaconCodec.decode(BeaconCodec.encode(presence())) as Beacon.Presence
        assertEquals(fingerprint.take(32), decoded.deviceId)
    }

    @Test
    fun extremePortsAndCapabilitiesSurvive() {
        for (port in listOf(1, 255, 256, 40000, 65535)) {
            val p = presence(port = port, capabilities = Int.MIN_VALUE)
            assertEquals(p, BeaconCodec.decode(BeaconCodec.encode(p)))
        }
    }

    @Test
    fun everyTruncationIsRejected() {
        val bytes = BeaconCodec.encode(presence())
        for (length in 0 until bytes.size) {
            assertNull("length $length", BeaconCodec.decode(bytes, length))
        }
        assertNotNull(BeaconCodec.decode(bytes, bytes.size))
    }

    @Test
    fun lengthBeyondTheArrayIsRejected() {
        val bytes = BeaconCodec.encode(presence())
        assertNull(BeaconCodec.decode(bytes, bytes.size + 1))
    }

    @Test
    fun trailingBytesAreRejected() {
        val bytes = BeaconCodec.encode(presence())
        assertNull(BeaconCodec.decode(bytes + byteArrayOf(0)))
        assertNull(BeaconCodec.decode(BeaconCodec.encodeQuery() + byteArrayOf(0)))
    }

    @Test
    fun badMagicIsRejected() {
        val good = BeaconCodec.encode(presence())
        for (index in 0 until 6) {
            val bad = good.copyOf()
            bad[index] = (bad[index].toInt() xor 0x01).toByte()
            assertNull("magic byte $index", BeaconCodec.decode(bad))
        }
    }

    @Test
    fun unknownTypeIsRejected() {
        val bytes = BeaconCodec.encode(presence())
        for (type in listOf(0, 4, 9, 255)) {
            val bad = bytes.copyOf()
            bad[6] = type.toByte()
            assertNull("type $type", BeaconCodec.decode(bad))
        }
    }

    @Test
    fun oversizeDatagramIsRejected() {
        val bytes = BeaconCodec.encode(presence())
        val big = ByteArray(BeaconCodec.MAX_DATAGRAM + 1)
        System.arraycopy(bytes, 0, big, 0, bytes.size)
        assertNull(BeaconCodec.decode(big))
    }

    @Test
    fun portZeroIsRejected() {
        val bytes = BeaconCodec.encode(presence(name = "Pixel 8"))
        val offset = afterName("Pixel 8".length) + 1
        bytes[offset] = 0
        bytes[offset + 1] = 0
        assertNull(BeaconCodec.decode(bytes))
    }

    @Test
    fun invalidUtf8NameIsRejected() {
        val bytes = BeaconCodec.encode(presence(name = "ab"))
        val nameStart = afterName(2) - 2
        bytes[nameStart] = 0xC3.toByte()
        bytes[nameStart + 1] = 0x28
        assertNull(BeaconCodec.decode(bytes))
    }

    @Test
    fun controlCharactersInTheNameAreRejected() {
        val bytes = BeaconCodec.encode(presence(name = "ab"))
        bytes[afterName(2) - 1] = 0x07
        assertNull(BeaconCodec.decode(bytes))
    }

    @Test
    fun nameLengthAboveTheLimitIsRejected() {
        val bytes = BeaconCodec.encode(presence(name = "ab"))
        bytes[6 + 1 + 32] = (BeaconCodec.MAX_NAME_BYTES + 1).toByte()
        assertNull(BeaconCodec.decode(bytes))
    }

    @Test
    fun longNamesAreCutOnACharacterBoundary() {
        val cyrillic = BeaconCodec.decode(BeaconCodec.encode(presence(name = "я".repeat(40)))) as Beacon.Presence
        assertEquals("я".repeat(30), cyrillic.name)
        val emoji = BeaconCodec.decode(BeaconCodec.encode(presence(name = "😀".repeat(20)))) as Beacon.Presence
        assertEquals("😀".repeat(15), emoji.name)
    }

    @Test
    fun namesAreCleanedBeforeSending() {
        val dirty = "Ann‮evil\u0007 phone\t"
        val decoded = BeaconCodec.decode(BeaconCodec.encode(presence(name = dirty))) as Beacon.Presence
        assertEquals("Annevil phone", decoded.name)
    }

    @Test
    fun largestPossibleBeaconFitsTheDatagramLimit() {
        val p = presence(name = "x".repeat(200), version = "9".repeat(200))
        val bytes = BeaconCodec.encode(p)
        assertTrue(bytes.size <= BeaconCodec.MAX_DATAGRAM)
        assertEquals(BeaconCodec.MAX_NAME_BYTES, (BeaconCodec.decode(bytes) as Beacon.Presence).name.length)
    }

    @Test
    fun invalidFingerprintsCannotBeEncoded() {
        for (bad in listOf("", "AB".repeat(32), "ab".repeat(31), "zz".repeat(32))) {
            try {
                BeaconCodec.encode(Beacon.Presence(false, bad, "n", DeviceKind.PHONE, 1000, "1", 0))
                throw AssertionError("fingerprint '$bad' must be rejected")
            } catch (e: IllegalArgumentException) {
                // expected
            }
        }
    }

    @Test
    fun unknownDeviceKindsDecodeAsOther() {
        val bytes = BeaconCodec.encode(presence(name = "ab"))
        bytes[afterName(2)] = 99
        assertEquals(DeviceKind.OTHER, (BeaconCodec.decode(bytes) as Beacon.Presence).kind)
    }
}
