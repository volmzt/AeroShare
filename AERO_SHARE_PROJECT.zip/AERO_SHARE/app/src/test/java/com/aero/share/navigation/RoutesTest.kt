package com.aero.share.navigation

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RoutesTest {
    @Test
    fun theBottomBarHasExactlyHomeDevicesAndSettingsInThatOrder() {
        assertEquals(listOf("home", "devices", "settings"), Routes.TABS)
        assertEquals(0, Routes.tabIndex(Routes.HOME))
        assertEquals(1, Routes.tabIndex(Routes.DEVICES))
        assertEquals(2, Routes.tabIndex(Routes.SETTINGS))
    }

    @Test
    fun everythingElseIsNotATab() {
        assertFalse(Routes.isTab(null))
        assertFalse(Routes.isTab(""))
        assertFalse(Routes.isTab(Routes.SETTINGS_SECTION))
        assertFalse(Routes.isTab(Routes.settingsSection(SettingsSection.POWER)))
        assertFalse(Routes.isTab(Routes.SEND_PICK))
        assertFalse(Routes.isTab(Routes.TRANSFER))
        assertFalse(Routes.isTab(Routes.HISTORY))
        assertEquals(-1, Routes.tabIndex(Routes.ABOUT))
    }

    @Test
    fun everyRoutePatternIsDistinct() {
        val all = listOf(
            Routes.HOME, Routes.DEVICES, Routes.SETTINGS, Routes.SETTINGS_SECTION, Routes.DIAGNOSTICS, Routes.ABOUT,
            Routes.HISTORY, Routes.SEND_PICK, Routes.SEND_RECIPIENTS, Routes.SEND_CONFIRM, Routes.RECEIVE, Routes.TRANSFER,
        )
        assertEquals(all.size, all.toSet().size)
    }

    @Test
    fun parameterisedPatternsNameTheirArguments() {
        assertTrue(Routes.SETTINGS_SECTION.contains("{" + Routes.ARG_SECTION + "}"))
        assertTrue(Routes.TRANSFER.contains("{" + Routes.ARG_ID + "}"))
    }

    @Test
    fun everySettingsSectionHasARouteThatReadsBackAsTheSameSection() {
        for (section in SettingsSection.entries) {
            val route = Routes.settingsSection(section)
            assertTrue(route.startsWith("settings/"))
            assertEquals(section, Routes.sectionOf(route.removePrefix("settings/")))
        }
    }

    @Test
    fun unknownSectionNamesAreRejected() {
        assertNull(Routes.sectionOf(null))
        assertNull(Routes.sectionOf(""))
        assertNull(Routes.sectionOf("general"))
        assertNull(Routes.sectionOf("../home"))
    }

    @Test
    fun aPlainTransferIdIsLeftAsItIs() {
        assertEquals("transfer/3f2b9c1e-7a54-4d0e-9a2f-0c8d5e6b7a11", Routes.transfer("3f2b9c1e-7a54-4d0e-9a2f-0c8d5e6b7a11"))
    }

    @Test
    fun anIdCanNeverAddASegmentOrAQuery() {
        assertEquals("transfer/a%2Fb%20c%3Fd%3De%23f", Routes.transfer("a/b c?d=e#f"))
    }

    @Test
    fun nonAsciiIdsAreEncodedAsUtf8() {
        assertEquals("transfer/%C3%A9", Routes.transfer("é"))
        assertEquals("transfer/%D0%B0", Routes.transfer("а"))
    }

    @Test
    fun theEncodedFormUsesOnlyUnreservedCharactersAndPercentEscapes() {
        val encoded = Routes.encodeArgument("Aa0-_.~ /%+&=é中")
        assertTrue(encoded.all { it.isLetterOrDigit() || it in "-_.~%" })
        assertTrue(encoded.startsWith("Aa0-_.~"))
    }
}
