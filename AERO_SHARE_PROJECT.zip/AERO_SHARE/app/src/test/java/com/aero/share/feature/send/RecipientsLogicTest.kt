package com.aero.share.feature.send

import com.aero.share.domain.DeviceRecord
import com.aero.share.domain.LinkQuality
import com.aero.share.domain.NearbyDevice
import com.aero.share.domain.Recipient
import com.aero.share.transfer.model.DeviceKind
import com.aero.share.transfer.model.TransportKind
import com.aero.share.transfer.pairing.QrPayload
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RecipientsLogicTest {
    private fun device(id: String, name: String = "Device $id") = NearbyDevice(
        deviceId = id,
        name = name,
        kind = DeviceKind.PHONE,
        fingerprint = null,
        appVersion = null,
        addresses = listOf("10.0.0.2"),
        port = 47474,
        transports = setOf(TransportKind.LAN),
        quality = LinkQuality.UNKNOWN,
        lastSeenElapsed = 0L,
    )

    private fun record(id: String, alias: String? = null, trusted: Boolean = false, blocked: Boolean = false) = DeviceRecord(
        deviceId = id,
        name = "Name $id",
        alias = alias,
        kind = DeviceKind.TABLET,
        model = null,
        fingerprint = "f".repeat(64),
        firstSeen = 0L,
        lastSeen = 0L,
        trusted = trusted,
        blocked = blocked,
        capabilities = 0,
        lastAddress = null,
        lastTransport = null,
    )

    private fun qr(id: String) = QrPayload(
        version = 1,
        deviceId = id,
        name = "Scanned $id",
        kind = DeviceKind.COMPUTER,
        hosts = listOf("192.168.1.7", "10.0.0.7"),
        port = 47480,
        fingerprint = "a".repeat(64),
        token = "t",
        expiresAt = 1L,
    )

    @Test
    fun nearbyDevicesAreRowsAndSelectionIsReflected() {
        val nearby = listOf(device("a"), device("b"))
        val sections = RecipientsLogic.sections(nearby, emptyList(), listOf(Recipient.Nearby(nearby[1])))
        assertEquals(2, sections.nearby.size)
        assertEquals(setOf("a" to false, "b" to true), sections.nearby.map { (it.recipient as Recipient.Nearby).device.deviceId to it.selected }.toSet())
        assertTrue(sections.added.isEmpty())
    }

    @Test
    fun aliasAndTrustComeFromTheKnownDevice() {
        val sections = RecipientsLogic.sections(listOf(device("a")), listOf(record("a", alias = "Mum's phone", trusted = true)), emptyList())
        val row = sections.nearby.single()
        assertEquals("Mum's phone", row.name)
        assertTrue(row.trusted)
        assertFalse(row.blocked)
    }

    @Test
    fun scannedCodeReplacesTheNearbyEntryOfTheSameDevice() {
        val nearby = listOf(device("a"))
        val scanned = Recipient.Qr(qr("a"))
        val sections = RecipientsLogic.sections(nearby, emptyList(), listOf(scanned))
        val row = sections.nearby.single()
        assertTrue(row.selected)
        assertEquals(RecipientSource.QR, row.source)
        assertEquals(scanned, row.recipient)
        assertTrue(sections.added.isEmpty())
    }

    @Test
    fun chosenRecipientsThatDiscoveryDoesNotSeeAreListedAsAdded() {
        val gone = device("gone")
        val chosen = listOf(Recipient.Qr(qr("q")), Recipient.Manual("192.168.1.50", 47474), Recipient.Nearby(gone))
        val sections = RecipientsLogic.sections(emptyList(), emptyList(), chosen)
        assertTrue(sections.nearby.isEmpty())
        assertEquals(3, sections.added.size)
        assertTrue(sections.added.all { it.selected && !it.visible })
        val byKey = sections.added.associateBy { it.source }
        assertEquals("Scanned q", byKey.getValue(RecipientSource.QR).name)
        assertEquals("192.168.1.7:47480", byKey.getValue(RecipientSource.QR).address)
        assertEquals("192.168.1.50:47474", byKey.getValue(RecipientSource.MANUAL).address)
        assertEquals("Device gone", byKey.getValue(RecipientSource.NEARBY).name)
    }

    @Test
    fun trustedDevicesThatAreAbsentAreOfferedAsOffline() {
        val known = listOf(
            record("near", trusted = true),
            record("far", alias = "Zed", trusted = true),
            record("far2", alias = "Amy", trusted = true),
            record("blocked", trusted = true, blocked = true),
            record("stranger", trusted = false),
            record("chosen", trusted = true),
        )
        // "chosen" is trusted and absent, but the person already picked it, so it is listed as added and not as offline.
        val chosen = listOf(Recipient.Manual("10.1.1.1", 47474), Recipient.Nearby(device("chosen")))
        val sections = RecipientsLogic.sections(listOf(device("near")), known, chosen)
        assertEquals(listOf("far2", "far"), sections.offline.map { it.deviceId })
        assertEquals(listOf("Amy", "Zed"), sections.offline.map { it.name })
        assertEquals(2, sections.added.size)
    }

    @Test
    fun manualAddressesAreAcceptedWithDefaultPort() {
        assertEquals(ManualTarget.Valid("192.168.1.20", RecipientsLogic.DEFAULT_PORT), RecipientsLogic.parseManual("192.168.1.20", ""))
        assertEquals(ManualTarget.Valid("10.0.0.5", 50000), RecipientsLogic.parseManual(" 10.0.0.5 ", " 50000 "))
    }

    @Test
    fun leadingZerosAreNormalised() {
        assertEquals(ManualTarget.Valid("10.0.0.5", 47474), RecipientsLogic.parseManual("010.000.000.005", ""))
    }

    @Test
    fun badAddressesAreRejected() {
        val bad = listOf("", "abc", "1.2.3", "1.2.3.4.5", "256.1.1.1", "1.2.3.-4", "1..2.3", "1.2.3.", "0.0.0.0", "127.0.0.1",
            "224.0.0.1", "255.255.255.255", "1.2.3.1234", "1.2.3.4a", "::1", "fe80::1")
        for (text in bad) {
            assertEquals(text, ManualTarget.InvalidHost, RecipientsLogic.parseManual(text, ""))
        }
    }

    @Test
    fun badPortsAreRejected() {
        for (port in listOf("0", "65536", "-1", "abc", "1e3", "99999999999")) {
            assertEquals(port, ManualTarget.InvalidPort, RecipientsLogic.parseManual("192.168.1.2", port))
        }
        assertEquals(ManualTarget.Valid("192.168.1.2", 65_535), RecipientsLogic.parseManual("192.168.1.2", "65535"))
        assertEquals(ManualTarget.Valid("192.168.1.2", 1), RecipientsLogic.parseManual("192.168.1.2", "1"))
    }
}
