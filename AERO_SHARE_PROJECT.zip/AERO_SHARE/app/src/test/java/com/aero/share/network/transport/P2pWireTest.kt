package com.aero.share.network.transport

import com.aero.share.network.discovery.Beacon
import com.aero.share.transfer.model.DeviceKind
import com.aero.share.transfer.model.TransportKind
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class P2pWireTest {
    private val fp = "ab".repeat(32)

    private fun presence(name: String = "Pixel 8", port: Int = 4433) =
        Beacon.Presence(false, fp, name, DeviceKind.PHONE, port, "1.0.0", 31)

    @Test
    fun serviceRecordRoundTripsWithoutTheIdAttribute() {
        val record = P2pServiceRecord.attributes(presence())
        assertFalse(record.containsKey("id"))
        assertEquals("4433", record["p"])
        assertEquals(presence(), P2pServiceRecord.parse(record))
    }

    @Test
    fun serviceRecordStaysSmall() {
        val longName = "N".repeat(200)
        val record = P2pServiceRecord.attributes(presence(name = longName))
        val bytes = record.entries.sumOf { it.key.length + it.value.toByteArray(Charsets.UTF_8).size + 2 }
        assertTrue("record is $bytes bytes", bytes <= 260)
    }

    @Test
    fun invalidRecordsAreRejected() {
        val good = P2pServiceRecord.attributes(presence())
        assertNull(P2pServiceRecord.parse(good - "p"))
        assertNull(P2pServiceRecord.parse(good - "fp"))
        assertNull(P2pServiceRecord.parse(good + ("fp" to "xyz")))
        assertNull(P2pServiceRecord.parse(good + ("v" to "2")))
        assertNull(P2pServiceRecord.parse(good + ("p" to "0")))
        assertNull(P2pServiceRecord.parse(good + ("p" to "70000")))
        assertNull(P2pServiceRecord.parse(good + ("p" to "abc")))
    }

    @Test
    fun recognisesOnlyAeroServices() {
        assertTrue(P2pServiceRecord.isAeroService("abcdef._aeroshare._tcp.local."))
        assertTrue(P2pServiceRecord.isAeroService("ABC._AeroShare._TCP.local."))
        assertFalse(P2pServiceRecord.isAeroService("printer._ipp._tcp.local."))
    }

    @Test
    fun helloRoundTrips() {
        for (port in listOf(1, 4433, 32768, 50000, 65535)) {
            val data = P2pHello.encode(fp, port)!!
            assertEquals(P2pHello.SIZE, data.size)
            assertEquals(P2pHello.Hello(fp, port), P2pHello.decode(data, data.size))
        }
    }

    @Test
    fun helloEncodingRejectsBadInput() {
        assertNull(P2pHello.encode("zz", 4433))
        assertNull(P2pHello.encode(fp.uppercase(), 4433))
        assertNull(P2pHello.encode(fp, 0))
        assertNull(P2pHello.encode(fp, 65536))
    }

    @Test
    fun helloDecodingIsStrict() {
        val data = P2pHello.encode(fp, 4433)!!
        assertNull(P2pHello.decode(data, data.size - 1))
        assertNull(P2pHello.decode(data + byteArrayOf(0), data.size + 1))
        val wrongMagic = data.copyOf().also { it[0] = 0x42 }
        assertNull(P2pHello.decode(wrongMagic, wrongMagic.size))
        val zeroPort = data.copyOf().also { it[38] = 0; it[39] = 0 }
        assertNull(P2pHello.decode(zeroPort, zeroPort.size))
        assertNull(P2pHello.decode(ByteArray(0), 0))
    }

    @Test
    fun listenerReceivesHelloOnLoopback() = runBlocking {
        val listener = P2pHelloListener.open(0) ?: throw AssertionError("cannot bind a UDP port")
        listener.use {
            assertTrue(P2pHelloSender.send("127.0.0.1", it.localPort, fp, 4433, repeat = 1, intervalMs = 0))
            val from = it.await(3_000) { hello -> hello.fingerprint == fp && hello.port == 4433 }
            assertNotNull(from)
            assertTrue(from!!.isLoopbackAddress)
        }
    }

    @Test
    fun listenerIgnoresGarbageAndForeignFingerprints() = runBlocking {
        val listener = P2pHelloListener.open(0) ?: throw AssertionError("cannot bind a UDP port")
        listener.use {
            DatagramSocket().use { raw ->
                val junk = ByteArray(40) { 7 }
                raw.send(DatagramPacket(junk, junk.size, InetAddress.getByName("127.0.0.1"), it.localPort))
            }
            P2pHelloSender.send("127.0.0.1", it.localPort, "cd".repeat(32), 4433, repeat = 1, intervalMs = 0)
            assertNull(it.await(400) { hello -> hello.fingerprint == fp })
            P2pHelloSender.send("127.0.0.1", it.localPort, fp, 4433, repeat = 1, intervalMs = 0)
            assertNotNull(it.await(3_000) { hello -> hello.fingerprint == fp })
        }
    }

    @Test
    fun awaitEndsWhenTheListenerIsClosed() = runBlocking {
        val listener = P2pHelloListener.open(0) ?: throw AssertionError("cannot bind a UDP port")
        val started = System.nanoTime()
        Thread { Thread.sleep(150); listener.close() }.start()
        assertNull(listener.await(10_000) { true })
        assertTrue((System.nanoTime() - started) / 1_000_000 < 3_000)
    }

    @Test
    fun peerTableMapsAdvertisementsToDevices() {
        val table = P2pPeerTable { "self" }
        assertTrue(table.onService("AA:BB:CC:DD:EE:01", presence(), 100))
        val device = table.snapshot().single()
        assertEquals(fp.take(32), device.deviceId)
        assertEquals("Pixel 8", device.name)
        assertEquals(setOf(TransportKind.WIFI_DIRECT), device.transports)
        assertEquals("aa:bb:cc:dd:ee:01", device.p2pAddress)
        assertTrue(device.addresses.isEmpty())
        assertEquals(4433, device.port)
        assertEquals(fp, device.fingerprint)
        assertEquals(31, device.capabilities)
    }

    @Test
    fun peerTableIgnoresSelfAndBadAddresses() {
        val table = P2pPeerTable { fp.take(32) }
        assertFalse(table.onService("aa:bb:cc:dd:ee:01", presence(), 0))
        val other = P2pPeerTable { "self" }
        assertFalse(other.onService("not-a-mac", presence(), 0))
        assertFalse(other.onService("aa:bb:cc:dd:ee", presence(), 0))
        assertEquals(0, other.size)
    }

    @Test
    fun peerTableExpiresAndKeepsRefreshedEntries() {
        val table = P2pPeerTable { "self" }
        table.onService("aa:bb:cc:dd:ee:01", presence(), 0)
        table.onService("aa:bb:cc:dd:ee:02", Beacon.Presence(false, "cd".repeat(32), "Other", DeviceKind.TABLET, 4000, "1", 0), 0)
        table.onService("aa:bb:cc:dd:ee:01", presence(), 50_000)
        assertFalse(table.expire(55_000, 60_000))
        assertTrue(table.expire(70_000, 60_000))
        assertEquals(listOf("Pixel 8"), table.snapshot().map { it.name })
        assertTrue(table.expire(200_000, 60_000))
        assertTrue(table.snapshot().isEmpty())
    }

    @Test
    fun peerTableQuantizesTheLastSeenTime() {
        val table = P2pPeerTable { "self" }
        table.onService("aa:bb:cc:dd:ee:01", presence(), 1_000)
        assertFalse(table.onService("aa:bb:cc:dd:ee:01", presence(), 6_000))
        assertEquals(1_000L, table.snapshot().single().lastSeenElapsed)
        assertTrue(table.onService("aa:bb:cc:dd:ee:01", presence(), 17_000))
        assertEquals(17_000L, table.snapshot().single().lastSeenElapsed)
    }

    @Test
    fun peerTableReportsChangedAdvertisements() {
        val table = P2pPeerTable { "self" }
        table.onService("aa:bb:cc:dd:ee:01", presence(name = "Old"), 0)
        assertTrue(table.onService("aa:bb:cc:dd:ee:01", presence(name = "New"), 1))
        assertEquals("New", table.snapshot().single().name)
    }

    @Test
    fun sameDeviceUnderTwoAddressesIsListedOnce() {
        val table = P2pPeerTable { "self" }
        table.onService("aa:bb:cc:dd:ee:01", presence(), 0)
        table.onService("aa:bb:cc:dd:ee:09", presence(), 10)
        val list = table.snapshot()
        assertEquals(1, list.size)
        assertEquals("aa:bb:cc:dd:ee:09", list.single().p2pAddress)
    }

    @Test
    fun blankNamesFallBackToTheIdPrefix() {
        val table = P2pPeerTable { "self" }
        table.onService("aa:bb:cc:dd:ee:01", presence(name = ""), 0)
        assertEquals(fp.take(6), table.snapshot().single().name)
    }

    @Test
    fun peerTableIsSortedByName() {
        val table = P2pPeerTable { "self" }
        table.onService("aa:bb:cc:dd:ee:01", Beacon.Presence(false, "11".repeat(32), "zeta", DeviceKind.PHONE, 1, "", 0), 0)
        table.onService("aa:bb:cc:dd:ee:02", Beacon.Presence(false, "22".repeat(32), "Alpha", DeviceKind.PHONE, 1, "", 0), 0)
        assertEquals(listOf("Alpha", "zeta"), table.snapshot().map { it.name })
        assertTrue(table.remove("AA:BB:CC:DD:EE:02"))
        assertEquals(listOf("zeta"), table.snapshot().map { it.name })
        assertTrue(table.clear())
        assertFalse(table.clear())
    }
}
