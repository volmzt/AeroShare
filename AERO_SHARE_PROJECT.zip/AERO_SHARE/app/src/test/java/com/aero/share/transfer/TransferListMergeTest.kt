package com.aero.share.transfer

import com.aero.share.transfer.model.TransferDirection
import com.aero.share.transfer.model.TransferSnapshot
import com.aero.share.transfer.model.TransferState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TransferListMergeTest {
    private fun snap(id: String, direction: TransferDirection = TransferDirection.SEND, state: TransferState = TransferState.WAITING) =
        TransferSnapshot(id = id, direction = direction, state = state)

    @Test
    fun newestComesFirst() {
        val sequence = mapOf("a" to 1L, "b" to 3L, "c" to 2L)
        val merged = TransferListMerge.merge(listOf(snap("a"), snap("b")), listOf(snap("c", TransferDirection.RECEIVE)), { sequence.getValue(it) })
        assertEquals(listOf("b", "c", "a"), merged.map { it.id })
    }

    @Test
    fun anIdThatAppearsOnBothSidesIsListedOnceAndTheReceiveEntryWins() {
        val send = snap("x", TransferDirection.SEND, TransferState.WAITING)
        val receive = snap("x", TransferDirection.RECEIVE, TransferState.TRANSFERRING)
        val merged = TransferListMerge.merge(listOf(send), listOf(receive), { 1L })
        assertEquals(1, merged.size)
        assertEquals(TransferDirection.RECEIVE, merged[0].direction)
        assertEquals(TransferState.TRANSFERRING, merged[0].state)
    }

    @Test
    fun emptyInputsGiveAnEmptyList() {
        assertTrue(TransferListMerge.merge(emptyList(), emptyList(), { 0L }).isEmpty())
    }

    @Test
    fun theOrderStaysTheSameWhenOnlyTheStateChanges() {
        val sequence = mapOf("a" to 1L, "b" to 2L)
        val before = TransferListMerge.merge(listOf(snap("a"), snap("b")), emptyList(), { sequence.getValue(it) })
        val after = TransferListMerge.merge(listOf(snap("a", state = TransferState.COMPLETED), snap("b")), emptyList(), { sequence.getValue(it) })
        assertEquals(before.map { it.id }, after.map { it.id })
    }
}
