package com.aero.share.feature.onboarding

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class OnboardingFlowTest {
    @Test
    fun theTourHasSixPagesAndTheLastOneIsIndexFive() {
        assertEquals(6, OnboardingFlow.COUNT)
        assertEquals(5, OnboardingFlow.LAST)
    }

    @Test
    fun thePermissionsPageIsInsideTheTourAndNotTheLastPage() {
        assertTrue(OnboardingFlow.PERMISSIONS in 0 until OnboardingFlow.LAST)
    }

    @Test
    fun nextWalksForwardAndStopsAtTheEnd() {
        var page = 0
        val visited = mutableListOf(page)
        while (true) {
            page = OnboardingFlow.next(page) ?: break
            visited.add(page)
        }
        assertEquals(listOf(0, 1, 2, 3, 4, 5), visited)
        assertNull(OnboardingFlow.next(OnboardingFlow.LAST))
    }

    @Test
    fun previousWalksBackwardAndStopsAtTheStart() {
        assertNull(OnboardingFlow.previous(0))
        assertEquals(0, OnboardingFlow.previous(1))
        assertEquals(4, OnboardingFlow.previous(5))
    }

    @Test
    fun outOfRangePagesNeverProduceANeighbour() {
        assertNull(OnboardingFlow.next(-1))
        assertNull(OnboardingFlow.next(99))
        assertNull(OnboardingFlow.previous(-1))
        assertNull(OnboardingFlow.previous(99))
    }

    @Test
    fun skipIsOfferedOnEveryPageExceptTheLast() {
        for (page in 0 until OnboardingFlow.LAST) assertTrue("page $page", OnboardingFlow.showsSkip(page))
        assertFalse(OnboardingFlow.showsSkip(OnboardingFlow.LAST))
        assertFalse(OnboardingFlow.showsSkip(-1))
    }
}
