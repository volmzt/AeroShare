package com.aero.share.transfer

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class LocalAddressesTest {
    private fun addr(name: String, host: String, prefix: Int = 24): LocalAddress =
        LocalAddress(name, host, Ipv4.parse(host) ?: throw AssertionError("bad test address"), prefix)

    @Test
    fun parsesCanonicalDottedQuads() {
        assertEquals((192 shl 24) or (168 shl 16) or (1 shl 8) or 20, Ipv4.parse("192.168.1.20"))
        assertEquals(0, Ipv4.parse("0.0.0.0"))
        assertEquals(-1, Ipv4.parse("255.255.255.255"))
    }

    @Test
    fun refusesAnythingElse() {
        for (bad in listOf("", "1.2.3", "1.2.3.4.5", "256.1.1.1", "a.b.c.d", "1.2.3.", ".1.2.3", "01.2.3.4", "1.2.3.04", "0x7f.0.0.1", "1..2.3", "fe80::1", "1.2.3.4/24", " 1.2.3.4")) {
            assertNull("should refuse '$bad'", Ipv4.parse(bad))
        }
    }

    @Test
    fun subnetContainsItsOwnAddressesOnly() {
        val subnet = Ipv4Subnet.of("192.168.43.1", 24) ?: throw AssertionError("subnet")
        assertTrue(subnet.contains(Ipv4.parse("192.168.43.1") ?: 0))
        assertTrue(subnet.contains(Ipv4.parse("192.168.43.254") ?: 0))
        assertFalse(subnet.contains(Ipv4.parse("192.168.44.1") ?: 0))
        assertFalse(subnet.contains(Ipv4.parse("10.0.0.1") ?: 0))
    }

    @Test
    fun subnetHandlesOddPrefixLengths() {
        val wide = Ipv4Subnet.of("10.8.0.5", 16) ?: throw AssertionError("subnet")
        assertTrue(wide.contains(Ipv4.parse("10.8.200.9") ?: 0))
        assertFalse(wide.contains(Ipv4.parse("10.9.0.1") ?: 0))
        val host = Ipv4Subnet.of("10.8.0.5", 32) ?: throw AssertionError("subnet")
        assertTrue(host.contains(Ipv4.parse("10.8.0.5") ?: 0))
        assertFalse(host.contains(Ipv4.parse("10.8.0.6") ?: 0))
        val narrow = Ipv4Subnet.of("172.16.5.130", 25) ?: throw AssertionError("subnet")
        assertTrue(narrow.contains(Ipv4.parse("172.16.5.200") ?: 0))
        assertFalse(narrow.contains(Ipv4.parse("172.16.5.20") ?: 0))
    }

    @Test
    fun aSubnetThatMatchesEverythingCanNeverBeBuilt() {
        assertNull(Ipv4Subnet.of("10.0.0.1", 0))
        assertNull(Ipv4Subnet.of("10.0.0.1", 7))
        assertNull(Ipv4Subnet.of("not an address", 24))
        assertNotNull(Ipv4Subnet.of("10.0.0.1", 8))
    }

    @Test
    fun cellularAndVirtualInterfacesAreNotLans() {
        for (name in listOf("rmnet_data0", "ccmni1", "tun0", "ppp0", "lo", "dummy0", "v4-rmnet_data1", "bt-pan", "docker0", "veth12")) {
            assertFalse("$name is not a LAN", LocalAddresses.isLanInterface(name))
        }
        for (name in listOf("wlan0", "wlan1", "eth0", "ap0", "swlan0", "p2p-wlan0-0", "rndis0", "usb0")) {
            assertTrue("$name is a LAN", LocalAddresses.isLanInterface(name))
        }
    }

    @Test
    fun wifiComesBeforeUsbBeforeHotspotBeforeWifiDirect() {
        val order = listOf("wlan0", "rndis0", "ap0", "p2p-wlan0-0").map { LocalAddresses.priority(it) }
        assertEquals(order.sorted(), order)
        assertEquals(4, order.distinct().size)
        assertEquals(0, LocalAddresses.priority("eth0"))
    }

    @Test
    fun qrHostsPutTheHotspotFirstAndNeverExceedTheLimit() {
        val all = listOf(
            addr("p2p-wlan0-0", "192.168.49.1"),
            addr("wlan0", "192.168.1.20"),
            addr("ap0", "192.168.43.1"),
            addr("eth0", "10.0.0.5"),
            addr("rndis0", "192.168.42.129"),
        )
        val hosts = LocalAddresses.qrHosts(all, listOf("192.168.43.1"))
        assertEquals("192.168.43.1", hosts.first())
        assertEquals(4, hosts.size)
        assertEquals(hosts.size, hosts.distinct().size)
        assertTrue("Wi-Fi must make it into the code", "192.168.1.20" in hosts)
        assertFalse("the least useful address is the one that is dropped", "192.168.49.1" in hosts)
    }

    @Test
    fun qrHostsWithoutAHotspotAreTheBestLocalAddresses() {
        val all = listOf(addr("p2p-wlan0-0", "192.168.49.1"), addr("wlan0", "192.168.1.20"))
        assertEquals(listOf("192.168.1.20", "192.168.49.1"), LocalAddresses.qrHosts(all, emptyList()))
        assertEquals(emptyList<String>(), LocalAddresses.qrHosts(emptyList(), emptyList()))
    }

    @Test
    fun receiverAddressesAreOrderedAndDistinct() {
        val all = listOf(addr("rndis0", "192.168.42.129"), addr("wlan0", "192.168.1.20"), addr("wlan0", "192.168.1.20"))
        assertEquals(listOf("192.168.1.20", "192.168.42.129"), LocalAddresses.receiverAddresses(all))
    }

    @Test
    fun enumeratingTheRealInterfacesNeverThrowsAndOnlyReturnsPrivateAddresses() {
        for (a in LocalAddresses.enumerate()) {
            assertNotNull(Ipv4.parse(a.host))
            assertTrue(a.prefixLength in 0..32)
            assertTrue(LocalAddresses.isLanInterface(a.interfaceName))
            val first = a.host.substringBefore('.').toInt()
            assertTrue("${a.host} must be an RFC 1918 address", first == 10 || first == 172 || first == 192)
        }
    }
}
