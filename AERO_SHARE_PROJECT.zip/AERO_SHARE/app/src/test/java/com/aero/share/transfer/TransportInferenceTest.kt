package com.aero.share.transfer

import com.aero.share.transfer.model.TransportKind
import org.junit.Assert.assertEquals
import org.junit.Test

class TransportInferenceTest {
    private fun addr(name: String, host: String, prefix: Int = 24): LocalAddress =
        LocalAddress(name, host, Ipv4.parse(host) ?: throw AssertionError("bad test address"), prefix)

    private val hotspot = listOfNotNull(Ipv4Subnet.of("192.168.43.1", 24))

    @Test
    fun aPeerOnTheWifiDirectInterfaceIsWifiDirect() {
        val local = listOf(addr("wlan0", "192.168.1.20"), addr("p2p-wlan0-0", "192.168.49.1"))
        assertEquals(TransportKind.WIFI_DIRECT, TransportInference.infer("192.168.49.2", local, emptyList()))
    }

    @Test
    fun aPeerInsideTheHotspotSubnetIsHotspot() {
        val local = listOf(addr("wlan0", "192.168.1.20"), addr("ap0", "192.168.43.1"))
        assertEquals(TransportKind.HOTSPOT, TransportInference.infer("192.168.43.77", local, hotspot))
    }

    @Test
    fun anOrdinaryNetworkPeerIsLan() {
        val local = listOf(addr("wlan0", "192.168.1.20"))
        assertEquals(TransportKind.LAN, TransportInference.infer("192.168.1.44", local, hotspot))
    }

    @Test
    fun theDefaultWifiDirectSubnetIsRecognisedWhenNoInterfaceOwnsIt() {
        assertEquals(TransportKind.WIFI_DIRECT, TransportInference.infer("192.168.49.2", emptyList(), emptyList()))
    }

    @Test
    fun aHomeNetworkThatHappensToUseTheWifiDirectSubnetStaysLan() {
        val local = listOf(addr("wlan0", "192.168.49.20"))
        assertEquals(TransportKind.LAN, TransportInference.infer("192.168.49.2", local, emptyList()))
    }

    @Test
    fun addressesWithSlashOrScopeAreUnderstood() {
        val local = listOf(addr("p2p-wlan0-0", "192.168.49.1"))
        assertEquals(TransportKind.WIFI_DIRECT, TransportInference.infer("/192.168.49.2", local, emptyList()))
        assertEquals(TransportKind.WIFI_DIRECT, TransportInference.infer("192.168.49.2%p2p-wlan0-0", local, emptyList()))
    }

    @Test
    fun anythingThatIsNotIpv4IsPlainLan() {
        assertEquals(TransportKind.LAN, TransportInference.infer("fe80::1%wlan0", emptyList(), hotspot))
        assertEquals(TransportKind.LAN, TransportInference.infer("", emptyList(), hotspot))
        assertEquals(TransportKind.LAN, TransportInference.infer("not-an-address", emptyList(), hotspot))
    }
}
