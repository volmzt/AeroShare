package com.aero.share.transfer

import com.aero.share.transfer.model.DeviceKind
import com.aero.share.transfer.pairing.HotspotCredentials
import com.aero.share.transfer.pairing.PairToken
import com.aero.share.transfer.pairing.QrPayload
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class QrBuilderTest {
    private val fingerprint = "ab".repeat(32)
    private val deviceId = fingerprint.take(32)
    private val token = PairToken(ByteArray(24) { (it + 1).toByte() }, 1_800_000_000_000L, 1)

    private fun build(
        name: String = "Pixel 8",
        hosts: List<String> = listOf("192.168.1.20"),
        hotspot: HotspotCredentials? = null,
        pairToken: PairToken = token,
    ): QrPayload? = QrBuilder.build(deviceId, name, DeviceKind.PHONE, hosts, 47474, fingerprint, pairToken, hotspot)

    @Test
    fun theBuiltPayloadSurvivesEncodingAndParsing() {
        val payload = build(hosts = listOf("192.168.1.20", "192.168.43.1")) ?: throw AssertionError("expected a payload")
        val parsed = QrPayload.parse(payload.encode()) ?: throw AssertionError("expected the text to parse")
        assertEquals(payload, parsed)
        assertEquals("Pixel 8", parsed.name)
        assertEquals(listOf("192.168.1.20", "192.168.43.1"), parsed.hosts)
        assertEquals(47474, parsed.port)
        assertEquals(fingerprint, parsed.fingerprint)
        assertEquals(deviceId, parsed.deviceId)
        assertEquals(DeviceKind.PHONE, parsed.kind)
        assertEquals(token.expiresAt, parsed.expiresAt)
        assertNull(parsed.hotspot)
    }

    @Test
    fun theTokenIsCarriedAndCanBeDecodedAgain() {
        val payload = build() ?: throw AssertionError("expected a payload")
        assertEquals(token.encoded, payload.token)
        val bytes = payload.tokenBytes() ?: throw AssertionError("token must decode")
        assertTrue(bytes.contentEquals(token.bytes))
    }

    @Test
    fun hotspotCredentialsTravelInTheCode() {
        val credentials = HotspotCredentials("DIRECT-AeroShare-12", "p4ssw0rd-Local")
        val payload = build(hotspot = credentials) ?: throw AssertionError("expected a payload")
        val parsed = QrPayload.parse(payload.encode()) ?: throw AssertionError("expected the text to parse")
        assertEquals(credentials, parsed.hotspot)
    }

    @Test
    fun anEmptyOrBlankNameFallsBackToTheProductName() {
        assertEquals(QrBuilder.FALLBACK_NAME, build(name = "")?.name)
        assertEquals(QrBuilder.FALLBACK_NAME, build(name = "  \n ")?.name)
    }

    @Test
    fun controlCharactersAndLongNamesAreCleanedBeforeTheyReachTheCode() {
        val payload = build(name = "Phone\u0000‮\n" + "x".repeat(200)) ?: throw AssertionError("expected a payload")
        assertTrue(payload.name.length <= DisplayText.MAX_NAME)
        assertTrue(payload.name.none { it.code < 0x20 || it.code == 0x202E })
        assertNotNull(QrPayload.parse(payload.encode()))
    }

    @Test
    fun atMostFourHostsAreKept() {
        val many = listOf("10.0.0.1", "10.0.0.2", "10.0.0.3", "10.0.0.4", "10.0.0.5", "10.0.0.6")
        val payload = build(hosts = many) ?: throw AssertionError("expected a payload")
        assertEquals(many.take(4), payload.hosts)
    }

    @Test
    fun theTextNeverExceedsTheLimitEvenWithWideCharacters() {
        val wideName = "你".repeat(60)
        val wideHotspot = HotspotCredentials("你".repeat(32), "p".repeat(63))
        val hosts = listOf("192.168.43.1", "192.168.1.20", "10.0.0.5", "192.168.42.129")
        val payload = build(name = wideName, hosts = hosts, hotspot = wideHotspot) ?: throw AssertionError("expected a payload")
        val text = payload.encode()
        assertTrue("length ${text.length}", text.length <= QrBuilder.MAX_LENGTH)
        assertNotNull(QrPayload.parse(text))
        assertTrue("the name is shortened rather than the code refused", payload.name.length < wideName.length)
        assertEquals(wideHotspot, payload.hotspot)
        assertEquals("192.168.43.1", payload.hosts.first())
    }

    @Test
    fun anAddressTheScannerWouldRefuseGivesNoCodeAtAll() {
        assertNull(build(hosts = listOf("not-an-address")))
        assertNull(build(hosts = emptyList()))
    }

    @Test
    fun hotspotCredentialsTheScannerWouldRefuseGiveNoCode() {
        assertNull(build(hotspot = HotspotCredentials("x".repeat(40), "longenoughpassword")))
        assertNull(build(hotspot = HotspotCredentials("ssid", "short")))
    }

    @Test
    fun aTokenOfTheWrongSizeGivesNoCode() {
        assertNull(build(pairToken = PairToken(ByteArray(8) { 1 }, 1_800_000_000_000L, 1)))
        assertNull(build(pairToken = PairToken(ByteArray(40) { 1 }, 1_800_000_000_000L, 1)))
    }
}
