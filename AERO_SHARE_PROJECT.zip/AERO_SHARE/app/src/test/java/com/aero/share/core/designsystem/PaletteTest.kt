package com.aero.share.core.designsystem

import com.aero.share.domain.AccentColor
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PaletteTest {
    @Test
    fun contrastOfBlackAndWhiteIsTwentyOne() {
        assertEquals(21.0, ColorMath.contrast(ColorMath.WHITE, ColorMath.BLACK), 0.001)
        assertEquals(1.0, ColorMath.contrast(0xFF123456L, 0xFF123456L), 0.0001)
    }

    @Test
    fun contrastIsSymmetric() {
        assertEquals(ColorMath.contrast(0xFFFF7900L, 0xFF090909L), ColorMath.contrast(0xFF090909L, 0xFFFF7900L), 1e-9)
    }

    @Test
    fun mixAndAlphaBehave() {
        assertEquals(0xFF000000L, ColorMath.mix(ColorMath.BLACK, ColorMath.WHITE, 0.0))
        assertEquals(0xFFFFFFFFL, ColorMath.mix(ColorMath.BLACK, ColorMath.WHITE, 1.0))
        assertEquals(0xFF808080L, ColorMath.mix(ColorMath.BLACK, ColorMath.WHITE, 0.5))
        assertEquals(0x80FF7900L, ColorMath.withAlpha(0xFFFF7900L, 0.5))
        assertEquals(0x00FF7900L, ColorMath.withAlpha(0xFFFF7900L, -3.0))
        assertEquals(0xFFFF7900L, ColorMath.withAlpha(0x12FF7900L, 9.0))
    }

    @Test
    fun readableOnPicksTheBetterOfWhiteAndBlack() {
        assertEquals(ColorMath.NEAR_BLACK, ColorMath.readableOn(0xFFFF7900L))
        assertEquals(ColorMath.WHITE, ColorMath.readableOn(0xFF111111L))
    }

    @Test
    fun ensureContrastLeavesGoodColoursAloneAndFixesBadOnes() {
        assertEquals(0xFFFFFFFFL, ColorMath.ensureContrast(0xFFFFFFFFL, 0xFF000000L, 4.5, ColorMath.WHITE))
        val fixed = ColorMath.ensureContrast(0xFFFF7900L, 0xFFEDEDEFL, 4.5, ColorMath.BLACK)
        assertTrue(ColorMath.contrast(fixed, 0xFFEDEDEFL) >= 4.5)
    }

    @Test
    fun brandOrangeDarkThemeUsesTheDocumentedTokens() {
        val t = AeroPalette.tokens(dark = true, accent = AccentColor.ORANGE)
        assertEquals(0xFF090909L, t.background)
        assertEquals(0xFF141414L, t.surface)
        assertEquals(0xFF1C1C1CL, t.surfaceAlt)
        assertEquals(0xFF222222L, t.surfaceElevated)
        assertEquals(0xFFFF7900L, t.accent)
        assertEquals(0xFFFF9A35L, t.accentSecondary)
        assertEquals(0xFFFFFFFFL, t.textPrimary)
        assertEquals(0xFFA3A3A3L, t.textSecondary)
        assertEquals(0xFF303030L, t.divider)
        assertTrue(t.isDark)
    }

    @Test
    fun brandOrangeLightThemeMirrorsThePalette() {
        val t = AeroPalette.tokens(dark = false, accent = AccentColor.ORANGE)
        assertEquals(0xFFF4F4F5L, t.background)
        assertEquals(0xFFFFFFFFL, t.surface)
        assertEquals(0xFFEDEDEFL, t.surfaceAlt)
        assertEquals(0xFF111111L, t.textPrimary)
        assertEquals(0xFF5C5C63L, t.textSecondary)
    }

    @Test
    fun orangeButtonsGetDarkLabelsBecauseWhiteWouldNotBeReadable() {
        val t = AeroPalette.tokens(dark = true, accent = AccentColor.ORANGE)
        assertEquals(ColorMath.NEAR_BLACK, t.onAccent)
        assertTrue(ColorMath.contrast(t.onAccent, t.accent) >= 4.5)
    }

    @Test
    fun everyCombinationOfThemeAndAccentIsReadable() {
        for (dark in listOf(true, false)) {
            for (accent in AccentColor.entries) {
                val t = AeroPalette.tokens(dark, accent)
                val label = "dark=$dark accent=$accent"
                val surfaces = listOf(t.background, t.surface, t.surfaceAlt, t.surfaceElevated)
                for (surface in surfaces) {
                    assertTrue("$label primary text on ${surface.toString(16)}", ColorMath.contrast(t.textPrimary, surface) >= 7.0)
                    assertTrue("$label secondary text on ${surface.toString(16)}", ColorMath.contrast(t.textSecondary, surface) >= 4.5)
                }
                for (surface in listOf(t.background, t.surface, t.surfaceAlt)) {
                    assertTrue("$label accent text on ${surface.toString(16)}", ColorMath.contrast(t.accentText, surface) >= 4.5)
                    assertTrue("$label success on ${surface.toString(16)}", ColorMath.contrast(t.success, surface) >= 4.5)
                    assertTrue("$label warning on ${surface.toString(16)}", ColorMath.contrast(t.warning, surface) >= 4.5)
                    assertTrue("$label danger on ${surface.toString(16)}", ColorMath.contrast(t.danger, surface) >= 4.5)
                }
                assertTrue("$label label on accent", ColorMath.contrast(t.onAccent, t.accent) >= 4.5)
                assertTrue("$label label on danger", ColorMath.contrast(t.onDanger, t.danger) >= 4.5)
            }
        }
    }

    @Test
    fun accentTextKeepsTheBrandColourWhereItAlreadyReadsWell() {
        val dark = AeroPalette.tokens(dark = true, accent = AccentColor.ORANGE)
        assertEquals(dark.accent, dark.accentText)
        val light = AeroPalette.tokens(dark = false, accent = AccentColor.ORANGE)
        assertTrue("light accent text is darker than the brand fill", ColorMath.luminance(light.accentText) < ColorMath.luminance(light.accent))
    }

    @Test
    fun theAccentWashIsTranslucentAndKeepsTheAccentHue() {
        for (accent in AccentColor.entries) {
            val t = AeroPalette.tokens(dark = true, accent = accent)
            assertTrue(((t.accentContainer shr 24) and 0xFFL) in 20L..80L)
            assertEquals(t.accent and 0x00FFFFFFL, t.accentContainer and 0x00FFFFFFL)
        }
    }
}
