package com.aero.share.network.transport

import com.aero.share.domain.CapabilityState
import com.aero.share.domain.DiscoveryProblem
import com.aero.share.domain.DiscoveryState
import com.aero.share.domain.DiscoveryStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DiscoveryRulesTest {
    private fun inputs(
        owned: Boolean = false,
        port: Int? = null,
        visible: Boolean = true,
        lan: Boolean = true,
        p2p: Boolean = true,
        capability: CapabilityState = CapabilityState.AVAILABLE,
    ) = RouteInputs(owned, port, visible, lan, p2p, capability)

    private fun stateInputs(
        route: RoutePlan,
        owned: Boolean = true,
        lanEnabled: Boolean = true,
        p2pEnabled: Boolean = true,
        lanProblem: DiscoveryProblem? = null,
        lanMethods: Set<String> = emptySet(),
        p2pRunning: Boolean = false,
        capability: CapabilityState = CapabilityState.AVAILABLE,
    ) = StateInputs(route, owned, lanEnabled, p2pEnabled, lanProblem, lanMethods, p2pRunning, capability)

    @Test
    fun nothingWantedMeansNothingRuns() {
        assertEquals(RoutePlan.NONE, DiscoveryRules.route(inputs()))
        assertFalse(DiscoveryRules.route(inputs()).any)
    }

    @Test
    fun discoveryStartsBothMechanismsWhenAllowed() {
        val plan = DiscoveryRules.route(inputs(owned = true))
        assertTrue(plan.lanDiscovery)
        assertTrue(plan.p2pDiscovery)
        assertFalse(plan.lanAdvertising)
        assertFalse(plan.p2pAdvertising)
    }

    @Test
    fun hiddenDevicesDoNotAdvertise() {
        val plan = DiscoveryRules.route(inputs(port = 4433, visible = false))
        assertFalse(plan.any)
        val visible = DiscoveryRules.route(inputs(port = 4433))
        assertTrue(visible.lanAdvertising)
        assertTrue(visible.p2pAdvertising)
        assertFalse(visible.lanDiscovery)
    }

    @Test
    fun settingsTurnMechanismsOff() {
        val plan = DiscoveryRules.route(inputs(owned = true, port = 1, lan = false))
        assertFalse(plan.lanDiscovery)
        assertFalse(plan.lanAdvertising)
        assertTrue(plan.p2pDiscovery)
        val noDirect = DiscoveryRules.route(inputs(owned = true, port = 1, p2p = false))
        assertFalse(noDirect.p2pWanted)
        assertTrue(noDirect.lanWanted)
    }

    @Test
    fun wifiDirectOnlyRunsWhenTheDeviceCanUseIt() {
        for (state in listOf(CapabilityState.PERMISSION_MISSING, CapabilityState.RADIO_OFF, CapabilityState.UNSUPPORTED, CapabilityState.NO_NETWORK)) {
            val plan = DiscoveryRules.route(inputs(owned = true, port = 1, capability = state))
            assertFalse("p2p must not run when $state", plan.p2pWanted)
            assertTrue(plan.lanDiscovery)
        }
    }

    @Test
    fun idleWhenNobodyAsks() {
        assertEquals(DiscoveryState(), DiscoveryRules.state(stateInputs(RoutePlan.NONE, owned = false)))
    }

    @Test
    fun searchingWithMethodsAndAdvertisingFlag() {
        val route = RoutePlan(lanDiscovery = true, lanAdvertising = true, p2pDiscovery = true, p2pAdvertising = true)
        val state = DiscoveryRules.state(stateInputs(route, lanMethods = setOf("mdns", "multicast"), p2pRunning = true))
        assertEquals(DiscoveryStatus.SEARCHING, state.status)
        assertEquals(setOf("mdns", "multicast", DiscoveryRules.METHOD_WIFI_DIRECT), state.activeMethods)
        assertTrue(state.advertising)
        assertEquals(null, state.problem)
    }

    @Test
    fun advertisingOnlyIsIdleButAdvertising() {
        val route = RoutePlan(lanDiscovery = false, lanAdvertising = true, p2pDiscovery = false, p2pAdvertising = false)
        val state = DiscoveryRules.state(stateInputs(route, owned = false, lanMethods = setOf("mdns")))
        assertEquals(DiscoveryStatus.IDLE, state.status)
        assertTrue(state.advertising)
    }

    @Test
    fun advertisingFlagIsFalseUntilSomethingReallyAdvertises() {
        val route = RoutePlan(lanDiscovery = false, lanAdvertising = true, p2pDiscovery = false, p2pAdvertising = false)
        val state = DiscoveryRules.state(stateInputs(route, owned = false, lanProblem = DiscoveryProblem.NO_NETWORK))
        assertFalse(state.advertising)
        assertEquals(DiscoveryStatus.PROBLEM, state.status)
        assertEquals(DiscoveryProblem.NO_NETWORK, state.problem)
    }

    @Test
    fun lanProblemIsReportedWhenNothingElseCouldWork() {
        val route = RoutePlan(lanDiscovery = true, lanAdvertising = false, p2pDiscovery = false, p2pAdvertising = false)
        for (problem in listOf(DiscoveryProblem.WIFI_OFF, DiscoveryProblem.NO_NETWORK, DiscoveryProblem.UNAVAILABLE)) {
            val state = DiscoveryRules.state(stateInputs(route, lanProblem = problem))
            assertEquals(DiscoveryStatus.PROBLEM, state.status)
            assertEquals(problem, state.problem)
            assertTrue(state.activeMethods.isEmpty())
        }
    }

    @Test
    fun startingIsNotAProblem() {
        val lanStarting = RoutePlan(lanDiscovery = true, lanAdvertising = false, p2pDiscovery = false, p2pAdvertising = false)
        val first = DiscoveryRules.state(stateInputs(lanStarting))
        assertEquals(DiscoveryStatus.SEARCHING, first.status)
        assertEquals(null, first.problem)
        val directStarting = RoutePlan(lanDiscovery = true, lanAdvertising = false, p2pDiscovery = true, p2pAdvertising = false)
        val second = DiscoveryRules.state(stateInputs(directStarting, lanProblem = DiscoveryProblem.NO_NETWORK))
        assertEquals(DiscoveryStatus.SEARCHING, second.status)
        assertEquals(null, second.problem)
    }

    @Test
    fun wifiDirectAloneWithoutPermissionIsAPermissionProblem() {
        val state = DiscoveryRules.state(
            stateInputs(RoutePlan.NONE, lanEnabled = false, capability = CapabilityState.PERMISSION_MISSING),
        )
        assertEquals(DiscoveryStatus.PROBLEM, state.status)
        assertEquals(DiscoveryProblem.PERMISSION_MISSING, state.problem)
    }

    @Test
    fun missingPermissionIsNotReportedWhileTheLanWorksOrHasItsOwnProblem() {
        val route = RoutePlan(lanDiscovery = true, lanAdvertising = false, p2pDiscovery = false, p2pAdvertising = false)
        val state = DiscoveryRules.state(
            stateInputs(route, lanProblem = DiscoveryProblem.NO_NETWORK, capability = CapabilityState.PERMISSION_MISSING),
        )
        assertEquals(DiscoveryProblem.NO_NETWORK, state.problem)
    }

    @Test
    fun everythingDisabledByTheUserIsUnavailable() {
        val state = DiscoveryRules.state(stateInputs(RoutePlan.NONE, lanEnabled = false, p2pEnabled = false))
        assertEquals(DiscoveryStatus.PROBLEM, state.status)
        assertEquals(DiscoveryProblem.UNAVAILABLE, state.problem)
    }

    @Test
    fun wifiDirectAloneWithWifiOffIsWifiOff() {
        val state = DiscoveryRules.state(stateInputs(RoutePlan.NONE, lanEnabled = false, capability = CapabilityState.RADIO_OFF))
        assertEquals(DiscoveryProblem.WIFI_OFF, state.problem)
    }
}
