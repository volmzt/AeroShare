package com.aero.share.transfer.work

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CleanupRulesTest {
    private val now = 1_800_000_000_000L
    private val day = 24L * 60L * 60L * 1000L

    @Test
    fun aDayIsTwentyFourHours() {
        assertEquals(day, CleanupRules.DAY_MS)
    }

    @Test
    fun partialDataIsKeptForTheConfiguredDays() {
        assertEquals(now - 3 * day, CleanupRules.partialCutoff(now, 3))
        assertEquals(now - 30 * day, CleanupRules.partialCutoff(now, 30))
    }

    @Test
    fun partialDataIsKeptForAtLeastOneDayWhateverTheSetting() {
        assertEquals(now - day, CleanupRules.partialCutoff(now, 1))
        assertEquals(now - day, CleanupRules.partialCutoff(now, 0))
        assertEquals(now - day, CleanupRules.partialCutoff(now, -7))
    }

    @Test
    fun anAbsurdRetentionDoesNotOverflow() {
        assertTrue(CleanupRules.partialCutoff(now, Int.MAX_VALUE) < now)
    }

    @Test
    fun historyIsKeptForeverWhenRetentionIsZeroOrNegative() {
        assertNull(CleanupRules.historyCutoff(now, 0))
        assertNull(CleanupRules.historyCutoff(now, -1))
    }

    @Test
    fun historyOlderThanTheRetentionIsCut() {
        assertEquals(now - 7 * day, CleanupRules.historyCutoff(now, 7))
        assertEquals(now - 90 * day, CleanupRules.historyCutoff(now, 90))
    }

    @Test
    fun temporaryApkFilesLiveForOneDay() {
        assertEquals(now - day, CleanupRules.tempCutoff(now))
    }

    @Test
    fun bothApkCacheFoldersAreCleaned() {
        assertEquals(listOf("bundles", "apk-inspect"), CleanupRules.TEMP_DIRS)
    }
}
