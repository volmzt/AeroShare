package com.aero.share.feature.send

import com.aero.share.domain.AppItem
import com.aero.share.domain.FileItem
import com.aero.share.domain.FolderItem
import com.aero.share.transfer.model.FileCategory
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SelectionMathTest {
    private fun file(id: String, size: Long, category: FileCategory) = FileItem(
        id = id,
        uri = id,
        displayName = id,
        size = size,
        category = category,
        mimeType = null,
        lastModified = 0L,
    )

    @Test
    fun emptySelectionHasNothing() {
        val summary = SelectionMath.summarize(emptyList())
        assertTrue(summary.isEmpty)
        assertEquals(0, summary.files)
        assertEquals(0L, summary.knownBytes)
        assertFalse(summary.sizeIsPartial)
        assertTrue(summary.categories.isEmpty())
    }

    @Test
    fun countsFilesFoldersAndApps() {
        val items = listOf(
            file("a", 100L, FileCategory.IMAGE),
            file("b", 200L, FileCategory.IMAGE),
            file("c", 50L, FileCategory.AUDIO),
            FolderItem(id = "f", treeUri = "f", displayName = "Folder", size = 1_000L, fileCount = 7),
            AppItem(id = "p", packageName = "p", displayName = "App", versionName = null, size = 4_000L, splitCount = 2),
        )
        val summary = SelectionMath.summarize(items)
        assertEquals(5, summary.entries)
        assertEquals(1, summary.folders)
        assertEquals(1, summary.apps)
        // 3 single files + 7 inside the folder + 1 app package.
        assertEquals(11, summary.files)
        assertEquals(5_350L, summary.knownBytes)
        assertFalse(summary.sizeIsPartial)
    }

    @Test
    fun categoriesFollowTheEnumOrderAndIncludeApps() {
        val items = listOf(
            file("d", 1L, FileCategory.DOCUMENT),
            file("i", 1L, FileCategory.IMAGE),
            file("i2", 1L, FileCategory.IMAGE),
            file("apk", 1L, FileCategory.APK),
            AppItem(id = "p", packageName = "p", displayName = "App", versionName = null, size = 1L, splitCount = 0),
        )
        val categories = SelectionMath.summarize(items).categories
        assertEquals(
            listOf(FileCategory.IMAGE to 2, FileCategory.DOCUMENT to 1, FileCategory.APK to 2),
            categories,
        )
    }

    @Test
    fun unknownSizesAreFlaggedNotGuessed() {
        val items = listOf(file("a", 10L, FileCategory.OTHER), file("b", -1L, FileCategory.OTHER))
        val summary = SelectionMath.summarize(items)
        assertEquals(10L, summary.knownBytes)
        assertEquals(1, summary.unknownSizeEntries)
        assertTrue(summary.sizeIsPartial)
    }

    @Test
    fun zeroSizedFilesAreKnown() {
        val summary = SelectionMath.summarize(listOf(file("a", 0L, FileCategory.OTHER)))
        assertEquals(0, summary.unknownSizeEntries)
    }

    @Test
    fun emptyFolderCountsAsZeroFiles() {
        val folder = FolderItem(id = "f", treeUri = "f", displayName = "Empty", size = 0L, fileCount = 0)
        val summary = SelectionMath.summarize(listOf(folder))
        assertEquals(1, summary.entries)
        assertEquals(0, summary.files)
    }

    @Test
    fun idsReturnsEveryId() {
        val ids = SelectionMath.ids(listOf(file("a", 1L, FileCategory.OTHER), file("b", 1L, FileCategory.OTHER)))
        assertEquals(setOf("a", "b"), ids)
    }
}
