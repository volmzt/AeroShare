package com.aero.share.network.discovery

import com.aero.share.domain.LinkQuality
import com.aero.share.transfer.model.DeviceKind
import com.aero.share.transfer.model.TransportKind
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DeviceTableTest {
    private fun fingerprintOf(c: Char) = c.toString().repeat(64)

    private fun presence(c: Char, name: String = "Device $c", port: Int = 5000, goodbye: Boolean = false) =
        Beacon.Presence(goodbye, fingerprintOf(c), name, DeviceKind.PHONE, port, "1.0", 7)

    private fun tableWith(self: Char = 'f'): DeviceTable {
        val table = DeviceTable { fingerprintOf(self).take(32) }
        table.setSubnets(listOf(LocalSubnet("192.168.1.20", 24)))
        return table
    }

    @Test
    fun ownDeviceIsNeverListed() {
        val table = tableWith(self = 'a')
        table.onBeacon(presence('a'), "192.168.1.5", 0)
        table.onNsd("svc", presence('a'), listOf("192.168.1.5"), 0)
        assertTrue(table.snapshot().isEmpty())
    }

    @Test
    fun nsdAndBeaconAddressesAreMerged() {
        val table = tableWith()
        table.onNsd("svc-a", presence('a'), listOf("192.168.1.7"), 100)
        table.onBeacon(presence('a'), "192.168.1.8", 200)
        val device = table.snapshot().single()
        assertEquals(listOf("192.168.1.7", "192.168.1.8"), device.addresses)
        assertEquals(setOf(TransportKind.LAN), device.transports)
        assertEquals(fingerprintOf('a'), device.fingerprint)
        assertEquals(5000, device.port)
        assertEquals(7, device.capabilities)
        assertEquals("1.0", device.appVersion)
    }

    @Test
    fun addressesOutsideTheLocalSubnetAreHiddenAndUnreachableDevicesAreNotListed() {
        val table = tableWith()
        table.onNsd("svc-a", presence('a'), listOf("10.1.2.3", "192.168.1.7"), 0)
        table.onNsd("svc-b", presence('b'), listOf("10.9.9.9"), 0)
        val devices = table.snapshot()
        assertEquals(1, devices.size)
        assertEquals(listOf("192.168.1.7"), devices[0].addresses)
    }

    @Test
    fun nsdLossRemovesTheDeviceOnlyWhenNoBeaconKeepsItAlive() {
        val table = tableWith()
        table.onNsd("svc-a", presence('a'), listOf("192.168.1.7"), 0)
        table.onNsd("svc-b", presence('b'), listOf("192.168.1.9"), 0)
        table.onBeacon(presence('b'), "192.168.1.9", 0)
        table.onNsdLost("svc-a")
        table.onNsdLost("svc-b")
        assertEquals(listOf("Device b"), table.snapshot().map { it.name })
    }

    @Test
    fun beaconAddressesExpireButNsdEntriesDoNot() {
        val table = tableWith()
        table.onBeacon(presence('a'), "192.168.1.7", 0)
        table.onNsd("svc-b", presence('b'), listOf("192.168.1.9"), 0)
        table.expire(now = 8_000, beaconTtlMs = 9_000)
        assertEquals(2, table.snapshot().size)
        table.expire(now = 10_000, beaconTtlMs = 9_000)
        assertEquals(listOf("Device b"), table.snapshot().map { it.name })
    }

    @Test
    fun aRefreshedBeaconKeepsTheDeviceAlive() {
        val table = tableWith()
        table.onBeacon(presence('a'), "192.168.1.7", 0)
        table.onBeacon(presence('a'), "192.168.1.7", 8_000)
        table.expire(now = 12_000, beaconTtlMs = 9_000)
        assertEquals(1, table.snapshot().size)
    }

    @Test
    fun goodbyeFromAKnownAddressRemovesTheDevice() {
        val table = tableWith()
        table.onBeacon(presence('a'), "192.168.1.7", 0)
        table.onBeacon(presence('a', goodbye = true), "192.168.1.7", 1)
        assertTrue(table.snapshot().isEmpty())
    }

    @Test
    fun goodbyeFromAnotherAddressIsIgnored() {
        val table = tableWith()
        table.onBeacon(presence('a'), "192.168.1.7", 0)
        table.onBeacon(presence('a', goodbye = true), "192.168.1.66", 1)
        assertEquals(1, table.snapshot().size)
    }

    @Test
    fun goodbyeDoesNotRemoveADeviceThatMdnsStillReports() {
        val table = tableWith()
        table.onNsd("svc-a", presence('a'), listOf("192.168.1.7"), 0)
        table.onBeacon(presence('a'), "192.168.1.7", 0)
        table.onBeacon(presence('a', goodbye = true), "192.168.1.7", 1)
        assertEquals(1, table.snapshot().size)
    }

    @Test
    fun aDifferentFingerprintUnderTheSameIdIsIgnored() {
        val table = tableWith()
        table.onBeacon(presence('a', name = "Real"), "192.168.1.7", 0)
        val forged = Beacon.Presence(false, fingerprintOf('a').take(32) + "b".repeat(32), "Forged", DeviceKind.PHONE, 9999, "6", 0)
        table.onBeacon(forged, "192.168.1.99", 1)
        val device = table.snapshot().single()
        assertEquals("Real", device.name)
        assertEquals(listOf("192.168.1.7"), device.addresses)
        assertEquals(5000, device.port)
    }

    @Test
    fun theLatestAdvertisementWinsForNamePortAndKind() {
        val table = tableWith()
        table.onBeacon(presence('a', name = "Old", port = 5000), "192.168.1.7", 0)
        table.onBeacon(presence('a', name = "New", port = 6000), "192.168.1.7", 1)
        val device = table.snapshot().single()
        assertEquals("New", device.name)
        assertEquals(6000, device.port)
    }

    @Test
    fun publishedLastSeenMovesInSteps() {
        val table = tableWith()
        table.onBeacon(presence('a'), "192.168.1.7", 1_000)
        table.onBeacon(presence('a'), "192.168.1.7", 5_000)
        assertEquals(1_000L, table.snapshot().single().lastSeenElapsed)
        table.onBeacon(presence('a'), "192.168.1.7", 16_000)
        assertEquals(16_000L, table.snapshot().single().lastSeenElapsed)
    }

    @Test
    fun aSteadyBeaconDoesNotChangeThePublishedList() {
        val table = tableWith()
        table.onBeacon(presence('a'), "192.168.1.7", 1_000)
        val first = table.snapshot()
        table.onBeacon(presence('a'), "192.168.1.7", 4_000)
        assertEquals(first, table.snapshot())
    }

    @Test
    fun devicesAreSortedByNameIgnoringCase() {
        val table = tableWith()
        table.onBeacon(presence('a', name = "zeta"), "192.168.1.1", 0)
        table.onBeacon(presence('b', name = "Alpha"), "192.168.1.2", 0)
        table.onBeacon(presence('c', name = "beta"), "192.168.1.3", 0)
        assertEquals(listOf("Alpha", "beta", "zeta"), table.snapshot().map { it.name })
    }

    @Test
    fun aBlankNameFallsBackToTheIdPrefix() {
        val table = tableWith()
        table.onBeacon(presence('a', name = ""), "192.168.1.7", 0)
        assertEquals(fingerprintOf('a').take(6), table.snapshot().single().name)
    }

    @Test
    fun measuredQualityIsKeptAndStartsUnknown() {
        val table = tableWith()
        table.onBeacon(presence('a'), "192.168.1.7", 0)
        assertEquals(LinkQuality.UNKNOWN, table.snapshot().single().quality)
        table.setQuality(presence('a').deviceId, LinkQuality.STRONG)
        table.onBeacon(presence('a'), "192.168.1.7", 1_000)
        assertEquals(LinkQuality.STRONG, table.snapshot().single().quality)
    }

    @Test
    fun probeTargetsListOnlyReachableDevices() {
        val table = tableWith()
        table.onBeacon(presence('a', port = 4444), "192.168.1.7", 0)
        table.onNsd("svc-b", presence('b'), listOf("10.9.9.9"), 0)
        val target = table.probeTargets().single()
        assertEquals(presence('a').deviceId, target.deviceId)
        assertEquals(4444, target.port)
        assertEquals(listOf("192.168.1.7"), target.addresses)
    }

    @Test
    fun clearingEmptiesTheTable() {
        val table = tableWith()
        table.onBeacon(presence('a'), "192.168.1.7", 0)
        table.clear()
        assertTrue(table.snapshot().isEmpty())
    }
}
