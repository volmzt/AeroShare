package com.aero.share.network.transport

import com.aero.share.transfer.engine.SocketConnector
import java.net.ConnectException
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketTimeoutException
import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class HostProbeTest {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val probe = HostProbe(scope)

    @After
    fun tearDown() {
        scope.cancel()
    }

    @Test
    fun aListeningPortIsReachable() = runBlocking {
        ServerSocket(0).use { server ->
            val result = probe.probeAny(listOf("127.0.0.1"), server.localPort, 2_000, SocketConnector.DEFAULT)
            assertEquals("127.0.0.1", result.host)
            assertEquals(listOf(ProbeOutcome.REACHABLE), result.outcomes)
        }
    }

    @Test
    fun aClosedPortIsRefused() = runBlocking {
        val port = ServerSocket(0).use { it.localPort }
        val result = probe.probeAny(listOf("127.0.0.1"), port, 2_000, SocketConnector.DEFAULT)
        assertNull(result.host)
        assertEquals(listOf(ProbeOutcome.REFUSED), result.outcomes)
    }

    @Test
    fun emptyAddressListIsNoAttempt() = runBlocking {
        val result = probe.probeAny(emptyList(), 1, 1_000, SocketConnector.DEFAULT)
        assertNull(result.host)
        assertTrue(result.outcomes.isEmpty())
    }

    @Test
    fun theFirstReachableAddressWinsWithoutWaitingForSlowOnes() = runBlocking {
        ServerSocket(0).use { server ->
            val connector = SocketConnector { host, port, timeoutMs ->
                if (host == "10.255.255.1") {
                    Thread.sleep(1_500)
                    throw SocketTimeoutException("slow")
                }
                SocketConnector.DEFAULT.connect(host, port, timeoutMs)
            }
            val started = System.nanoTime()
            val result = probe.probeAny(listOf("10.255.255.1", "127.0.0.1"), server.localPort, 5_000, connector)
            val tookMs = (System.nanoTime() - started) / 1_000_000
            assertEquals("127.0.0.1", result.host)
            assertTrue("took $tookMs ms", tookMs < 1_200)
        }
    }

    @Test
    fun allTimeoutsAreReported() = runBlocking {
        val connector = SocketConnector { _, _, _ -> throw SocketTimeoutException("timed out") }
        val result = probe.probeAny(listOf("192.0.2.1", "192.0.2.2", "192.0.2.1"), 4433, 1_000, connector)
        assertNull(result.host)
        assertEquals(listOf(ProbeOutcome.TIMED_OUT, ProbeOutcome.TIMED_OUT), result.outcomes)
    }

    @Test
    fun retryEventuallySucceedsWhenTheLinkComesUp() = runBlocking {
        ServerSocket(0).use { server ->
            val calls = AtomicInteger()
            val connector = SocketConnector { host, port, timeoutMs ->
                if (calls.incrementAndGet() <= 2) throw ConnectException("Connection refused")
                SocketConnector.DEFAULT.connect(host, port, timeoutMs)
            }
            val result = probe.probeWithRetry(listOf("127.0.0.1"), server.localPort, 1_000, connector, attempts = 4, pauseMs = 10)
            assertEquals("127.0.0.1", result.host)
            assertEquals(3, calls.get())
        }
    }

    @Test
    fun retryGivesUpAfterTheLastAttempt() = runBlocking {
        val calls = AtomicInteger()
        val connector = SocketConnector { _, _, _ ->
            calls.incrementAndGet()
            throw ConnectException("Connection refused")
        }
        val result = probe.probeWithRetry(listOf("127.0.0.1"), 9, 1_000, connector, attempts = 3, pauseMs = 5)
        assertNull(result.host)
        assertEquals(3, calls.get())
        assertEquals(listOf(ProbeOutcome.REFUSED), result.outcomes)
    }

    @Test
    fun connectedSocketsAreClosedAfterTheProbe() = runBlocking {
        val opened = ArrayList<Socket>()
        ServerSocket(0).use { server ->
            val connector = SocketConnector { host, port, timeoutMs ->
                val socket = SocketConnector.DEFAULT.connect(host, port, timeoutMs)
                synchronized(opened) { opened.add(socket) }
                socket
            }
            probe.probeAny(listOf("127.0.0.1"), server.localPort, 2_000, connector)
        }
        synchronized(opened) {
            assertEquals(1, opened.size)
            assertTrue(opened[0].isClosed)
        }
    }
}
