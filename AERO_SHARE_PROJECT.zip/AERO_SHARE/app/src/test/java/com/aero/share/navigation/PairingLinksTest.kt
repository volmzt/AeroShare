package com.aero.share.navigation

import com.aero.share.network.transport.PlanRules
import com.aero.share.transfer.model.DeviceKind
import com.aero.share.transfer.pairing.PairToken
import com.aero.share.transfer.pairing.QrPayload
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PairingLinksTest {
    private val fingerprint = "cd".repeat(32)
    private val now = 1_800_000_000_000L

    private fun link(expiresAt: Long, deviceId: String = fingerprint.take(32), scheme: String = "aero://pair?"): String {
        val token = PairToken(ByteArray(24) { (it + 3).toByte() }, expiresAt, 1)
        val payload = QrPayload(1, deviceId, "Galaxy Tab", DeviceKind.TABLET, listOf("192.168.0.7"), 47474, fingerprint, token.encoded, expiresAt)
        return payload.encode().replaceFirst("aero://pair?", scheme)
    }

    @Test
    fun aFreshLinkIsUsableAndCarriesThePayload() {
        val result = PairingLinks.evaluate(link(now + 60_000L), now)
        assertTrue(result is PairingLink.Usable)
        val payload = (result as PairingLink.Usable).payload
        assertEquals("Galaxy Tab", payload.name)
        assertEquals(DeviceKind.TABLET, payload.kind)
        assertEquals(listOf("192.168.0.7"), payload.hosts)
        assertEquals(47474, payload.port)
    }

    @Test
    fun aLinkThatExpiredLongAgoIsExpired() {
        assertEquals(PairingLink.Expired, PairingLinks.evaluate(link(now - 10 * 60_000L), now))
    }

    @Test
    fun aSmallClockDifferenceBetweenPhonesIsForgiven() {
        val justExpired = now - PlanRules.QR_SKEW_GRACE_MS / 2
        assertTrue(PairingLinks.evaluate(link(justExpired), now) is PairingLink.Usable)
    }

    @Test
    fun theGraceEndsAfterTheConfiguredWindow() {
        val tooOld = now - PlanRules.QR_SKEW_GRACE_MS - 1
        assertEquals(PairingLink.Expired, PairingLinks.evaluate(link(tooOld), now))
    }

    @Test
    fun linksThatAreNotPairingLinksAreInvalid() {
        assertEquals(PairingLink.Invalid, PairingLinks.evaluate("", now))
        assertEquals(PairingLink.Invalid, PairingLinks.evaluate("https://example.com/pair", now))
        assertEquals(PairingLink.Invalid, PairingLinks.evaluate("aero://pair?", now))
        assertEquals(PairingLink.Invalid, PairingLinks.evaluate("aero://other?v=1", now))
        assertEquals(PairingLink.Invalid, PairingLinks.evaluate(link(now + 60_000L, scheme = "aero://send?"), now))
    }

    @Test
    fun aDeviceIdThatDoesNotMatchTheCertificateIsInvalid() {
        assertEquals(PairingLink.Invalid, PairingLinks.evaluate(link(now + 60_000L, deviceId = "00".repeat(16)), now))
    }

    @Test
    fun anOversizedLinkIsInvalid() {
        assertEquals(PairingLink.Invalid, PairingLinks.evaluate(link(now + 60_000L) + "&x=" + "a".repeat(2000), now))
    }
}
