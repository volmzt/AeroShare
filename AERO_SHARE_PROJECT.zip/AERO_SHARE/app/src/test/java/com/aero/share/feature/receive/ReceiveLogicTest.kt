package com.aero.share.feature.receive

import com.aero.share.domain.CapabilityState
import com.aero.share.domain.TransportCapability
import com.aero.share.transfer.model.TransportKind
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ReceiveLogicTest {
    // ---- QR countdown

    @Test
    fun remainingSecondsRoundsUp() {
        assertEquals(60L, QrLogic.remainingSeconds(expiresAtMillis = 61_000L, nowMillis = 1_000L))
        assertEquals(2L, QrLogic.remainingSeconds(expiresAtMillis = 2_001L, nowMillis = 1_000L))
        assertEquals(1L, QrLogic.remainingSeconds(expiresAtMillis = 1_001L, nowMillis = 1_000L))
    }

    @Test
    fun remainingSecondsIsZeroOnceExpired() {
        assertEquals(0L, QrLogic.remainingSeconds(1_000L, 1_000L))
        assertEquals(0L, QrLogic.remainingSeconds(1_000L, 9_999L))
    }

    @Test
    fun expiryIsInclusive() {
        assertTrue(QrLogic.isExpired(1_000L, 1_000L))
        assertTrue(QrLogic.isExpired(1_000L, 1_001L))
        assertFalse(QrLogic.isExpired(1_000L, 999L))
    }

    @Test
    fun clockFormatsMinutesAndPaddedSeconds() {
        assertEquals("0:00", QrLogic.clock(0))
        assertEquals("0:09", QrLogic.clock(9))
        assertEquals("1:05", QrLogic.clock(65))
        assertEquals("2:00", QrLogic.clock(120))
        assertEquals("10:00", QrLogic.clock(600))
        assertEquals("0:00", QrLogic.clock(-5))
    }

    // ---- hotspot offer

    private fun caps(hotspot: CapabilityState?): List<TransportCapability> {
        val base = mutableListOf(TransportCapability(TransportKind.LAN, CapabilityState.AVAILABLE))
        if (hotspot != null) base.add(TransportCapability(TransportKind.HOTSPOT, hotspot))
        return base
    }

    @Test
    fun hotspotIsOfferedWhenAvailableOrOnlyMissingThePermission() {
        assertEquals(HotspotOffer.AVAILABLE, ReceiveLogic.hotspotOffer(caps(CapabilityState.AVAILABLE)))
        assertEquals(HotspotOffer.NEEDS_PERMISSION, ReceiveLogic.hotspotOffer(caps(CapabilityState.PERMISSION_MISSING)))
    }

    @Test
    fun hotspotIsHiddenWhenItCannotSucceed() {
        assertEquals(HotspotOffer.NONE, ReceiveLogic.hotspotOffer(caps(CapabilityState.RADIO_OFF)))
        assertEquals(HotspotOffer.NONE, ReceiveLogic.hotspotOffer(caps(CapabilityState.UNSUPPORTED)))
        assertEquals(HotspotOffer.NONE, ReceiveLogic.hotspotOffer(caps(CapabilityState.NO_NETWORK)))
        assertEquals(HotspotOffer.NONE, ReceiveLogic.hotspotOffer(caps(null)))
        assertEquals(HotspotOffer.NONE, ReceiveLogic.hotspotOffer(emptyList()))
    }

    // ---- addresses

    @Test
    fun endpointsJoinAddressAndPort() {
        assertEquals(
            listOf("192.168.1.20:47474", "10.0.0.5:47474"),
            ReceiveLogic.endpoints(listOf("192.168.1.20", " 10.0.0.5 "), 47474),
        )
    }

    @Test
    fun endpointsAreEmptyWithoutPort() {
        assertTrue(ReceiveLogic.endpoints(listOf("192.168.1.20"), null).isEmpty())
    }

    @Test
    fun endpointsSkipBlankAddresses() {
        assertEquals(listOf("10.0.0.5:1"), ReceiveLogic.endpoints(listOf("", "  ", "10.0.0.5"), 1))
    }

    // ---- verification code

    @Test
    fun codeIsGroupedInThrees() {
        assertEquals("482 913", IncomingLogic.groupCode("482913"))
        assertEquals("482 913", IncomingLogic.groupCode("482 913"))
        assertEquals("123 45", IncomingLogic.groupCode("12345"))
    }

    @Test
    fun missingOrBlankCodeGivesEmptyText() {
        assertEquals("", IncomingLogic.groupCode(null))
        assertEquals("", IncomingLogic.groupCode(""))
        assertEquals("", IncomingLogic.groupCode("   "))
    }

    // ---- request countdown

    @Test
    fun requestCountdownUsesTheSameClockForBothValues() {
        assertEquals(30L, IncomingLogic.remainingSeconds(expiresAtElapsed = 50_000L, nowElapsed = 20_000L))
        assertEquals(1L, IncomingLogic.remainingSeconds(expiresAtElapsed = 20_001L, nowElapsed = 20_000L))
        assertEquals(0L, IncomingLogic.remainingSeconds(expiresAtElapsed = 20_000L, nowElapsed = 20_000L))
        assertEquals(0L, IncomingLogic.remainingSeconds(expiresAtElapsed = 10_000L, nowElapsed = 20_000L))
    }

    // ---- storage

    @Test
    fun unknownFreeSpaceIsNotAProblem() {
        assertEquals(StorageCheck.UNKNOWN, IncomingLogic.storage(null, 5_000L))
    }

    @Test
    fun tooLittleSpaceIsFlagged() {
        assertEquals(StorageCheck.TOO_LITTLE, IncomingLogic.storage(1_000L, 5_000L))
        assertEquals(StorageCheck.ENOUGH, IncomingLogic.storage(5_000L, 5_000L))
        assertEquals(StorageCheck.ENOUGH, IncomingLogic.storage(9_000L, 5_000L))
    }

    @Test
    fun emptyOfferNeverCountsAsTooLittle() {
        assertEquals(StorageCheck.ENOUGH, IncomingLogic.storage(0L, 0L))
    }

    // ---- receive lease

    @Test
    fun lastHolderToLeaveMayStopReceiving() {
        val lease = ReceiveLease()
        lease.acquire()
        val ticket = lease.release()
        assertEquals(1L, ticket)
        assertTrue(lease.mayStop(ticket!!))
    }

    @Test
    fun leavingWhileAnotherScreenHoldsTheLeaseDoesNotStop() {
        val lease = ReceiveLease()
        lease.acquire()
        lease.acquire()
        assertNull(lease.release())
        assertNotNull(lease.release())
    }

    @Test
    fun postponedStopIsDroppedWhenAScreenOpensAgain() {
        val lease = ReceiveLease()
        lease.acquire()
        val ticket = lease.release()!!
        lease.acquire()
        assertFalse(lease.mayStop(ticket))
    }

    @Test
    fun postponedStopIsDroppedEvenIfTheNewScreenAlreadyLeft() {
        val lease = ReceiveLease()
        lease.acquire()
        val first = lease.release()!!
        lease.acquire()
        val second = lease.release()!!
        assertFalse(lease.mayStop(first))
        assertTrue(lease.mayStop(second))
    }

    @Test
    fun releaseWithoutAcquireDoesNotGoNegative() {
        val lease = ReceiveLease()
        assertEquals(0L, lease.release())
        lease.acquire()
        assertEquals(1L, lease.release())
    }
}
