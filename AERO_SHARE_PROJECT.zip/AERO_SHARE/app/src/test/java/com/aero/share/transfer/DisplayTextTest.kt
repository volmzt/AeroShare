package com.aero.share.transfer

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DisplayTextTest {
    @Test
    fun plainNamesAreUnchanged() {
        assertEquals("Pixel 8 Pro", DisplayText.clean("Pixel 8 Pro"))
        assertEquals("Телефон Олега", DisplayText.clean("Телефон Олега"))
    }

    @Test
    fun controlCharactersBecomeSpacesAndAreCollapsed() {
        assertEquals("a b", DisplayText.clean("a\u0000\u0007\nb"))
        assertEquals("a b", DisplayText.clean("a    b"))
        assertEquals("a b", DisplayText.clean("  a \t b  "))
    }

    @Test
    fun bidirectionalOverridesCannotSpoofTheName() {
        val spoofed = "Safe‮exe.txt"
        val cleaned = DisplayText.clean(spoofed)
        assertFalse(cleaned.contains('‮'))
        assertTrue(cleaned.startsWith("Safe"))
        assertFalse(DisplayText.clean("a​b⁦c⁩d﻿").any { it.code in 0x200B..0x200F || it.code in 0x2066..0x2069 || it.code == 0xFEFF })
    }

    @Test
    fun longTextIsCutAtTheLimit() {
        val cut = DisplayText.clean("x".repeat(500))
        assertEquals(DisplayText.MAX_NAME, cut.length)
        assertEquals(10, DisplayText.clean("abcdefghijklmnop", 10).length)
    }

    @Test
    fun aCutNeverLeavesALoneSurrogate() {
        // 59 letters + an emoji (two chars) would be cut in the middle of the pair at 60 characters.
        val text = "a".repeat(59) + "😀" + "tail"
        val cut = DisplayText.clean(text)
        assertFalse(cut.last().isHighSurrogate())
        assertTrue(cut.length <= DisplayText.MAX_NAME)
    }

    @Test
    fun emptyAndBlankInputGiveAnEmptyString() {
        assertEquals("", DisplayText.clean(""))
        assertEquals("", DisplayText.clean(" \n\t "))
    }
}
