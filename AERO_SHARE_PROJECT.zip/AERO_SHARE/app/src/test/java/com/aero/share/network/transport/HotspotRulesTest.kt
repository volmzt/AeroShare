package com.aero.share.network.transport

import com.aero.share.transfer.pairing.HotspotCredentials
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class HotspotRulesTest {
    @Test
    fun plainValuesPass() {
        assertEquals(HotspotCredentials("AndroidShare_1234", "s3cretpass"), HotspotRules.build("AndroidShare_1234", "s3cretpass"))
    }

    @Test
    fun quotesAreRemoved() {
        assertEquals(HotspotCredentials("Net", "12345678"), HotspotRules.build("\"Net\"", "\"12345678\""))
        assertEquals(HotspotCredentials("\"", "12345678"), HotspotRules.build("\"", "12345678"))
    }

    @Test
    fun limitsMatchTheQrFormat() {
        assertNull(HotspotRules.build(null, "12345678"))
        assertNull(HotspotRules.build("Net", null))
        assertNull(HotspotRules.build("", "12345678"))
        assertNull(HotspotRules.build("x".repeat(33), "12345678"))
        assertEquals(HotspotCredentials("x".repeat(32), "12345678"), HotspotRules.build("x".repeat(32), "12345678"))
        assertNull(HotspotRules.build("Net", "1234567"))
        assertNull(HotspotRules.build("Net", "p".repeat(64)))
        assertEquals(HotspotCredentials("Net", "p".repeat(63)), HotspotRules.build("Net", "p".repeat(63)))
    }

    @Test
    fun controlCharactersAreRejected() {
        assertNull(HotspotRules.build("Ne\nt", "12345678"))
        assertNull(HotspotRules.build("Net", "1234\u00005678"))
    }
}
