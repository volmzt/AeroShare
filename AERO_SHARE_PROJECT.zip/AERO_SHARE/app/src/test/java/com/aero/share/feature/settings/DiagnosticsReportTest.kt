package com.aero.share.feature.settings

import com.aero.share.core.common.DiagnosticEntry
import com.aero.share.domain.AppSettings
import com.aero.share.domain.CapabilityState
import com.aero.share.domain.DiscoveryProblem
import com.aero.share.domain.DiscoveryState
import com.aero.share.domain.DiscoveryStatus
import com.aero.share.domain.RadioStatus
import com.aero.share.domain.ReceiverStatus
import com.aero.share.domain.TransportCapability
import com.aero.share.transfer.model.TransportKind
import java.util.TimeZone
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DiagnosticsReportTest {
    private val utc = TimeZone.getTimeZone("UTC")

    private fun radio(wifi: Boolean = true, connected: Boolean = true, bluetoothSupported: Boolean = true, bluetooth: Boolean = false) =
        RadioStatus(wifi, connected, bluetoothSupported, bluetooth, locationEnabled = true, sdkInt = 34)

    private fun input(
        log: List<DiagnosticEntry> = emptyList(),
        settings: AppSettings = AppSettings(),
        capabilities: List<TransportCapability> = emptyList(),
        radio: RadioStatus = radio(),
        discovery: DiscoveryState = DiscoveryState(),
        permissions: List<PermissionLine> = emptyList(),
    ) = DiagnosticsInput(
        appVersion = "1.2.3",
        buildNumber = 45,
        androidRelease = "14",
        sdkInt = 34,
        deviceModel = "Acme Phone 1",
        capabilities = capabilities,
        radio = radio,
        discovery = discovery,
        nearbyCount = 2,
        receiver = ReceiverStatus.LISTENING,
        activeTransfers = 1,
        permissions = permissions,
        canInstallPackages = false,
        settings = settings,
        log = log,
    )

    private fun report(input: DiagnosticsInput) = DiagnosticsReport.build(input, utc)

    private fun entry(n: Int) = DiagnosticEntry(1_700_000_000_000L + n * 1000L, "cat$n", "message $n")

    @Test
    fun reportStartsWithVersionAndPlatform() {
        val lines = report(input()).lines()
        assertEquals("AERO SHARE diagnostics", lines[0])
        assertEquals("App: 1.2.3 (build 45)", lines[1])
        assertEquals("Android: 14 (API 34)", lines[2])
        assertEquals("Device: Acme Phone 1", lines[3])
    }

    @Test
    fun capabilitiesAreListedInAFixedOrderWithTheirState() {
        val text = report(
            input(
                capabilities = listOf(
                    TransportCapability(TransportKind.HOTSPOT, CapabilityState.RADIO_OFF),
                    TransportCapability(TransportKind.LAN, CapabilityState.AVAILABLE),
                ),
            ),
        )
        val lan = text.indexOf("- LAN: AVAILABLE")
        val hotspot = text.indexOf("- HOTSPOT: RADIO_OFF")
        assertTrue(lan in 0 until hotspot)
    }

    @Test
    fun anUncheckedCapabilityListSaysSo() {
        assertTrue(report(input()).contains("- not checked yet"))
    }

    @Test
    fun radiosAreDescribedAndBluetoothIsNeverPresentedAsATransport() {
        val on = report(input(radio = radio(bluetooth = true)))
        assertTrue(on.contains("- Wi-Fi: on, connected"))
        assertTrue(on.contains("- Bluetooth: on (not used to transfer files)"))
        val off = report(input(radio = radio(wifi = false, connected = false, bluetoothSupported = false)))
        assertTrue(off.contains("- Wi-Fi: off, not connected"))
        assertTrue(off.contains("- Bluetooth: not supported (not used to transfer files)"))
    }

    @Test
    fun discoveryProblemAndMethodsAreShown() {
        val text = report(
            input(discovery = DiscoveryState(DiscoveryStatus.PROBLEM, DiscoveryProblem.WIFI_OFF, advertising = true, activeMethods = setOf("mdns", "multicast"))),
        )
        assertTrue(text.contains("- Discovery: PROBLEM (WIFI_OFF)"))
        assertTrue(text.contains("- Announcing this device: yes"))
        assertTrue(text.contains("- Discovery methods: mdns, multicast"))
        assertTrue(report(input()).contains("- Discovery methods: none"))
    }

    @Test
    fun permissionsShowTheirState() {
        val text = report(input(permissions = listOf(PermissionLine(PermissionKind.CAMERA, true), PermissionLine(PermissionKind.NEARBY, false), PermissionLine(PermissionKind.NOTIFICATIONS, true))))
        assertTrue(text.contains("- Camera: granted"))
        assertTrue(text.contains("- Nearby devices: not granted"))
        assertTrue(text.contains("- Notifications: granted"))
        assertTrue(text.contains("- Install other apps: not allowed"))
    }

    @Test
    fun theReportNeverContainsTheDeviceNameOrTheChosenFolder() {
        val settings = AppSettings(customDeviceName = "Alice's private phone", saveDirectoryUri = "content://secret/tree/Alice")
        val text = report(input(settings = settings))
        assertFalse(text.contains("Alice"))
        assertFalse(text.contains("secret"))
        assertTrue(text.contains("- Receive folder: custom"))
        assertTrue(report(input()).contains("- Receive folder: default"))
    }

    @Test
    fun onlyTheNewestFiftyEventsAreIncludedOldestFirst() {
        val log = (1..60).map { entry(it) }
        val recent = DiagnosticsReport.recentEvents(log)
        assertEquals(50, recent.size)
        assertEquals("message 11", recent.first().message)
        assertEquals("message 60", recent.last().message)
        val text = report(input(log = log))
        assertTrue(text.contains("Recent events (50)"))
        assertFalse(text.contains("message 10\n"))
        assertTrue(text.indexOf("message 11") < text.indexOf("message 60"))
    }

    @Test
    fun anEmptyLogSaysSo() {
        val text = report(input())
        assertTrue(text.contains("Recent events (0)"))
        assertTrue(text.trimEnd().endsWith("- none"))
    }

    @Test
    fun eventsKeepOneLineEachEvenWithLineBreaksInTheMessage() {
        val text = report(input(log = listOf(DiagnosticEntry(0L, "a\nb", "first\r\nsecond"))))
        val eventLines = text.lines().filter { it.startsWith("1970-01-01") }
        assertEquals(1, eventLines.size)
        assertEquals("1970-01-01 00:00:00 [a b] first  second", eventLines[0])
    }

    @Test
    fun timesFollowTheGivenTimeZone() {
        val kyiv = TimeZone.getTimeZone("Europe/Kyiv")
        // 2026-11-20 23:30 UTC is 2026-11-21 01:30 in Kyiv (UTC+2 in winter).
        val input = input(log = listOf(DiagnosticEntry(1_795_217_400_000L, "x", "y")))
        assertTrue(DiagnosticsReport.build(input, utc).contains("2026-11-20 23:30:00 [x] y"))
        assertTrue(DiagnosticsReport.build(input, kyiv).contains("2026-11-21 01:30:00 [x] y"))
    }

    @Test
    fun theReportIsPlainAsciiFriendlyTextWithoutNullOrObjectDumps() {
        val text = report(input(log = listOf(entry(1))))
        assertFalse(text.contains("null"))
        assertFalse(text.contains("@"))
        assertFalse(text.contains("DiscoveryState("))
    }
}
