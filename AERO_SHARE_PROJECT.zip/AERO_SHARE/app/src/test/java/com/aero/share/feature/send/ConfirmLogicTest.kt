package com.aero.share.feature.send

import com.aero.share.domain.AppItem
import com.aero.share.domain.DeviceRecord
import com.aero.share.domain.FileItem
import com.aero.share.domain.LinkQuality
import com.aero.share.domain.NearbyDevice
import com.aero.share.domain.RadioStatus
import com.aero.share.domain.Recipient
import com.aero.share.domain.TransportMode
import com.aero.share.transfer.model.CompressionMode
import com.aero.share.transfer.model.DeviceKind
import com.aero.share.transfer.model.FileCategory
import com.aero.share.transfer.model.TransportKind
import com.aero.share.transfer.pairing.HotspotCredentials
import com.aero.share.transfer.pairing.QrPayload
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ConfirmLogicTest {
    private val radioOk = RadioStatus(
        wifiEnabled = true,
        wifiConnected = true,
        bluetoothSupported = true,
        bluetoothEnabled = true,
        locationEnabled = true,
        sdkInt = 34,
    )

    private fun file(size: Long) = FileItem(
        id = "f$size",
        uri = "f$size",
        displayName = "f",
        size = size,
        category = FileCategory.VIDEO,
        mimeType = null,
        lastModified = 0L,
    )

    private fun summary(vararg sizes: Long) = SelectionMath.summarize(sizes.map { file(it) })

    private fun device(id: String) = NearbyDevice(
        deviceId = id,
        name = "Device $id",
        kind = DeviceKind.PHONE,
        fingerprint = null,
        appVersion = null,
        addresses = listOf("10.0.0.2"),
        port = 47474,
        transports = setOf(TransportKind.LAN),
        quality = LinkQuality.UNKNOWN,
        lastSeenElapsed = 0L,
    )

    private fun record(id: String, trusted: Boolean, blocked: Boolean = false) = DeviceRecord(
        deviceId = id,
        name = "Name $id",
        alias = null,
        kind = DeviceKind.PHONE,
        model = null,
        fingerprint = "f".repeat(64),
        firstSeen = 0L,
        lastSeen = 0L,
        trusted = trusted,
        blocked = blocked,
        capabilities = 0,
        lastAddress = null,
        lastTransport = null,
    )

    private fun qr(id: String, hotspot: Boolean) = QrPayload(
        version = 1,
        deviceId = id,
        name = "Scanned",
        kind = DeviceKind.PHONE,
        hosts = listOf("10.0.0.3"),
        port = 47474,
        fingerprint = "a".repeat(64),
        token = "t",
        expiresAt = 1L,
        hotspot = if (hotspot) HotspotCredentials("AERO-1234", "passphrase1") else null,
    )

    private val trustedOne = ConfirmLogic.recipients(listOf(Recipient.Nearby(device("t"))), listOf(record("t", true)), TransportMode.AUTO)
    private val untrustedOne = ConfirmLogic.recipients(listOf(Recipient.Nearby(device("u"))), emptyList(), TransportMode.AUTO)

    @Test
    fun quietSendHasNoWarnings() {
        assertTrue(ConfirmLogic.warnings(summary(1_000L), trustedOne, 2_000_000_000L, radioOk).isEmpty())
    }

    @Test
    fun largeTransfersAreFlaggedAtTheThreshold() {
        val limit = 2L * 1024 * 1024 * 1024
        assertFalse(ConfirmWarning.LARGE_TRANSFER in ConfirmLogic.warnings(summary(limit - 1), trustedOne, limit, radioOk))
        assertTrue(ConfirmWarning.LARGE_TRANSFER in ConfirmLogic.warnings(summary(limit), trustedOne, limit, radioOk))
        assertTrue(ConfirmWarning.LARGE_TRANSFER in ConfirmLogic.warnings(summary(limit / 2, limit / 2), trustedOne, limit, radioOk))
    }

    @Test
    fun aZeroThresholdDisablesTheLargeTransferWarning() {
        assertFalse(ConfirmWarning.LARGE_TRANSFER in ConfirmLogic.warnings(summary(Long.MAX_VALUE / 2), trustedOne, 0L, radioOk))
    }

    @Test
    fun unknownSizesAreMentioned() {
        val partial = SelectionMath.summarize(listOf(file(10L), file(-1L)))
        assertTrue(ConfirmWarning.UNKNOWN_SIZES in ConfirmLogic.warnings(partial, trustedOne, 0L, radioOk))
    }

    @Test
    fun wifiProblemsAreReported() {
        val off = radioOk.copy(wifiEnabled = false, wifiConnected = false)
        val notJoined = radioOk.copy(wifiConnected = false)
        assertEquals(listOf(ConfirmWarning.WIFI_OFF), ConfirmLogic.warnings(summary(1L), trustedOne, 0L, off))
        assertEquals(listOf(ConfirmWarning.WIFI_NOT_CONNECTED), ConfirmLogic.warnings(summary(1L), trustedOne, 0L, notJoined))
    }

    @Test
    fun untrustedNearbyDevicesNeedACode() {
        assertTrue(ConfirmWarning.VERIFICATION_CODE in ConfirmLogic.warnings(summary(1L), untrustedOne, 0L, radioOk))
    }

    @Test
    fun scannedCodesAreAuthenticatedByTheCodeItself() {
        val scanned = ConfirmLogic.recipients(listOf(Recipient.Qr(qr("q", false))), emptyList(), TransportMode.AUTO)
        assertFalse(ConfirmWarning.VERIFICATION_CODE in ConfirmLogic.warnings(summary(1L), scanned, 0L, radioOk))
    }

    @Test
    fun manualAddressesNeedACode() {
        val manual = ConfirmLogic.recipients(listOf(Recipient.Manual("10.0.0.9", 47474)), emptyList(), TransportMode.AUTO)
        assertTrue(ConfirmWarning.VERIFICATION_CODE in ConfirmLogic.warnings(summary(1L), manual, 0L, radioOk))
    }

    @Test
    fun severalRecipientsAreQueued() {
        val two = trustedOne + untrustedOne
        assertTrue(ConfirmWarning.QUEUED_ONE_BY_ONE in ConfirmLogic.warnings(summary(1L), two, 0L, radioOk))
        assertFalse(ConfirmWarning.QUEUED_ONE_BY_ONE in ConfirmLogic.warnings(summary(1L), trustedOne, 0L, radioOk))
    }

    @Test
    fun blockedRecipientsComeFirst() {
        val blocked = ConfirmLogic.recipients(listOf(Recipient.Nearby(device("b"))), listOf(record("b", trusted = false, blocked = true)), TransportMode.AUTO)
        val warnings = ConfirmLogic.warnings(summary(1L), blocked, 0L, radioOk.copy(wifiEnabled = false))
        assertEquals(ConfirmWarning.BLOCKED_RECIPIENT, warnings.first())
    }

    @Test
    fun connectionMethodFollowsTheSettingAndTheCode() {
        val nearby = listOf(Recipient.Nearby(device("a")))
        assertEquals(ConnectionMethod.AUTOMATIC, ConfirmLogic.recipients(nearby, emptyList(), TransportMode.AUTO).single().method)
        assertEquals(ConnectionMethod.LAN_ONLY, ConfirmLogic.recipients(nearby, emptyList(), TransportMode.LAN_ONLY).single().method)
        assertEquals(
            ConnectionMethod.WIFI_DIRECT_PREFERRED,
            ConfirmLogic.recipients(nearby, emptyList(), TransportMode.WIFI_DIRECT_PREFERRED).single().method,
        )
        assertEquals(ConnectionMethod.QR_CODE, ConfirmLogic.recipients(listOf(Recipient.Qr(qr("q", false))), emptyList(), TransportMode.AUTO).single().method)
        assertEquals(ConnectionMethod.QR_HOTSPOT, ConfirmLogic.recipients(listOf(Recipient.Qr(qr("q", true))), emptyList(), TransportMode.AUTO).single().method)
        assertEquals(ConnectionMethod.MANUAL_ADDRESS, ConfirmLogic.recipients(listOf(Recipient.Manual("10.0.0.1", 1)), emptyList(), TransportMode.AUTO).single().method)
    }

    @Test
    fun recipientNamesPreferTheAlias() {
        val named = DeviceRecord(
            deviceId = "a", name = "Raw", alias = "Kitchen tablet", kind = DeviceKind.TABLET, model = null,
            fingerprint = "f".repeat(64), firstSeen = 0L, lastSeen = 0L, trusted = true, blocked = false,
            capabilities = 0, lastAddress = null, lastTransport = null,
        )
        assertEquals("Kitchen tablet", ConfirmLogic.recipients(listOf(Recipient.Nearby(device("a"))), listOf(named), TransportMode.AUTO).single().name)
    }

    @Test
    fun compressionIsMentionedOnlyWhenItCanApply() {
        assertTrue(ConfirmLogic.mentionsCompression(CompressionMode.SMART, summary(1L)))
        assertFalse(ConfirmLogic.mentionsCompression(CompressionMode.OFF, summary(1L)))
        assertFalse(ConfirmLogic.mentionsCompression(CompressionMode.SMART, SelectionMath.summarize(emptyList())))
    }

    @Test
    fun sendingNeedsItemsAndRecipients() {
        assertTrue(ConfirmLogic.canSend(summary(1L), trustedOne))
        assertFalse(ConfirmLogic.canSend(summary(1L), emptyList()))
        assertFalse(ConfirmLogic.canSend(SelectionMath.summarize(emptyList()), trustedOne))
        val app = AppItem(id = "p", packageName = "p", displayName = "App", versionName = null, size = 1L, splitCount = 0)
        assertTrue(ConfirmLogic.canSend(SelectionMath.summarize(listOf(app)), trustedOne))
    }
}
