package com.aero.share.network.transport

import com.aero.share.domain.CapabilityState
import com.aero.share.domain.PlanResult
import com.aero.share.domain.TransportMode
import com.aero.share.transfer.model.TransferFailure
import java.io.IOException
import java.net.ConnectException
import java.net.NoRouteToHostException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test

class PlanRulesTest {
    @Test
    fun autoPrefersLanThenWifiDirect() {
        assertEquals(
            listOf(Route.LAN, Route.WIFI_DIRECT),
            PlanRules.routes(TransportMode.AUTO, hasAddresses = true, hasP2pAddress = true, p2pUsable = true),
        )
        assertEquals(
            listOf(Route.WIFI_DIRECT),
            PlanRules.routes(TransportMode.AUTO, hasAddresses = false, hasP2pAddress = true, p2pUsable = true),
        )
        assertEquals(
            listOf(Route.LAN),
            PlanRules.routes(TransportMode.AUTO, hasAddresses = true, hasP2pAddress = true, p2pUsable = false),
        )
    }

    @Test
    fun lanOnlyNeverUsesWifiDirect() {
        assertEquals(
            listOf(Route.LAN),
            PlanRules.routes(TransportMode.LAN_ONLY, hasAddresses = true, hasP2pAddress = true, p2pUsable = true),
        )
        assertTrue(PlanRules.routes(TransportMode.LAN_ONLY, hasAddresses = false, hasP2pAddress = true, p2pUsable = true).isEmpty())
    }

    @Test
    fun wifiDirectPreferredTriesItFirstButKeepsLanAsFallback() {
        assertEquals(
            listOf(Route.WIFI_DIRECT, Route.LAN),
            PlanRules.routes(TransportMode.WIFI_DIRECT_PREFERRED, hasAddresses = true, hasP2pAddress = true, p2pUsable = true),
        )
        assertEquals(
            listOf(Route.LAN),
            PlanRules.routes(TransportMode.WIFI_DIRECT_PREFERRED, hasAddresses = true, hasP2pAddress = false, p2pUsable = true),
        )
    }

    @Test
    fun withoutAnyAddressThereIsNoRoute() {
        assertTrue(PlanRules.routes(TransportMode.AUTO, hasAddresses = false, hasP2pAddress = false, p2pUsable = true).isEmpty())
        val failed = PlanRules.noRoute(TransportMode.AUTO, hasP2pAddress = false, p2pEnabled = true, p2pCapability = CapabilityState.AVAILABLE)
        assertEquals(PlanResult.Failed(TransferFailure.UNREACHABLE, PlanDetail.NO_ROUTE), failed)
    }

    @Test
    fun noRouteExplainsWhyWifiDirectCannotBeUsed() {
        fun reason(mode: TransportMode, enabled: Boolean, capability: CapabilityState) =
            PlanRules.noRoute(mode, hasP2pAddress = true, p2pEnabled = enabled, p2pCapability = capability)
        assertEquals(
            PlanResult.Failed(TransferFailure.UNREACHABLE, PlanDetail.LAN_ONLY_NO_ADDRESS),
            reason(TransportMode.LAN_ONLY, true, CapabilityState.AVAILABLE),
        )
        assertEquals(
            PlanResult.Failed(TransferFailure.UNREACHABLE, PlanDetail.WIFI_DIRECT_DISABLED),
            reason(TransportMode.AUTO, false, CapabilityState.AVAILABLE),
        )
        assertEquals(
            PlanResult.Failed(TransferFailure.PERMISSION, PlanDetail.WIFI_DIRECT_PERMISSION),
            reason(TransportMode.AUTO, true, CapabilityState.PERMISSION_MISSING),
        )
        assertEquals(
            PlanResult.Failed(TransferFailure.UNREACHABLE, PlanDetail.WIFI_OFF),
            reason(TransportMode.AUTO, true, CapabilityState.RADIO_OFF),
        )
        assertEquals(
            PlanResult.Failed(TransferFailure.UNREACHABLE, PlanDetail.WIFI_DIRECT_UNSUPPORTED),
            reason(TransportMode.AUTO, true, CapabilityState.UNSUPPORTED),
        )
    }

    @Test
    fun timeoutsOnDiscoveredAddressesPointToClientIsolation() {
        val failed = PlanRules.failureFromProbes(listOf(ProbeOutcome.TIMED_OUT, ProbeOutcome.TIMED_OUT), discovered = true)
        assertEquals(TransferFailure.NETWORK_BLOCKED, failed.failure)
        assertEquals(PlanDetail.LAN_TIMEOUT, failed.detail)
    }

    @Test
    fun timeoutsOnTypedOrScannedAddressesAreJustTimeouts() {
        val failed = PlanRules.failureFromProbes(listOf(ProbeOutcome.TIMED_OUT), discovered = false)
        assertEquals(TransferFailure.TIMEOUT, failed.failure)
    }

    @Test
    fun refusedConnectionsMeanTheDeviceIsNotReceiving() {
        val failed = PlanRules.failureFromProbes(listOf(ProbeOutcome.TIMED_OUT, ProbeOutcome.REFUSED), discovered = true)
        assertEquals(PlanResult.Failed(TransferFailure.UNREACHABLE, PlanDetail.LAN_REFUSED), failed)
    }

    @Test
    fun mixedFailuresAndNoAttemptsAreUnreachable() {
        assertEquals(
            PlanResult.Failed(TransferFailure.UNREACHABLE, PlanDetail.LAN_NO_ROUTE),
            PlanRules.failureFromProbes(listOf(ProbeOutcome.TIMED_OUT, ProbeOutcome.NO_ROUTE), discovered = true),
        )
        assertEquals(
            PlanResult.Failed(TransferFailure.UNREACHABLE, PlanDetail.NO_ROUTE),
            PlanRules.failureFromProbes(emptyList(), discovered = true),
        )
    }

    @Test
    fun wifiDirectFailuresMapToPreciseTransferFailures() {
        assertEquals(TransferFailure.PERMISSION, PlanRules.directFailure(P2pFailure.PERMISSION).failure)
        assertEquals(TransferFailure.BUSY, PlanRules.directFailure(P2pFailure.BUSY).failure)
        assertEquals(TransferFailure.DECLINED, PlanRules.directFailure(P2pFailure.DECLINED).failure)
        assertEquals(TransferFailure.TIMEOUT, PlanRules.directFailure(P2pFailure.TIMEOUT).failure)
        assertEquals(PlanDetail.WIFI_OFF, PlanRules.directFailure(P2pFailure.RADIO_OFF).detail)
        for (reason in P2pFailure.values()) {
            val failed = PlanRules.directFailure(reason)
            assertTrue(failed.detail!!.startsWith("wifi-"))
        }
        assertEquals(TransferFailure.TIMEOUT, PlanRules.directProbeFailure(listOf(ProbeOutcome.TIMED_OUT)).failure)
        assertEquals(TransferFailure.UNREACHABLE, PlanRules.directProbeFailure(listOf(ProbeOutcome.REFUSED)).failure)
        assertEquals(TransferFailure.UNREACHABLE, PlanRules.directProbeFailure(emptyList()).failure)
    }

    @Test
    fun groupPeerAddressDependsOnTheRole() {
        assertEquals("192.168.49.1", P2pGroup("192.168.49.1", false, null).peerAddress)
        assertEquals("192.168.49.7", P2pGroup("192.168.49.1", true, "192.168.49.7").peerAddress)
        assertNull(P2pGroup("192.168.49.1", true, null).peerAddress)
    }

    @Test
    fun theMostActionableFailureWins() {
        val unreachable = PlanResult.Failed(TransferFailure.UNREACHABLE, "a")
        val blocked = PlanResult.Failed(TransferFailure.NETWORK_BLOCKED, "b")
        val permission = PlanResult.Failed(TransferFailure.PERMISSION, "c")
        val timeout = PlanResult.Failed(TransferFailure.TIMEOUT, "d")
        assertSame(unreachable, PlanRules.moreSpecific(null, unreachable))
        assertSame(blocked, PlanRules.moreSpecific(unreachable, blocked))
        assertSame(blocked, PlanRules.moreSpecific(blocked, timeout))
        assertSame(permission, PlanRules.moreSpecific(blocked, permission))
        assertSame(unreachable, PlanRules.moreSpecific(unreachable, PlanResult.Failed(TransferFailure.UNREACHABLE, "e")))
    }

    @Test
    fun qrExpiryAllowsForClockSkew() {
        val expiresAt = 1_000_000L
        assertFalse(PlanRules.isExpired(expiresAt, expiresAt - 1))
        assertFalse(PlanRules.isExpired(expiresAt, expiresAt))
        assertFalse(PlanRules.isExpired(expiresAt, expiresAt + PlanRules.QR_SKEW_GRACE_MS))
        assertTrue(PlanRules.isExpired(expiresAt, expiresAt + PlanRules.QR_SKEW_GRACE_MS + 1))
        assertFalse(PlanRules.isExpired(Long.MAX_VALUE, Long.MAX_VALUE))
    }

    @Test
    fun connectionErrorsAreClassified() {
        assertEquals(ProbeOutcome.TIMED_OUT, ProbeClassifier.classify(SocketTimeoutException("failed to connect to /192.168.1.5 (port 4433) after 3000ms")))
        assertEquals(ProbeOutcome.REFUSED, ProbeClassifier.classify(ConnectException("Connection refused")))
        assertEquals(
            ProbeOutcome.REFUSED,
            ProbeClassifier.classify(ConnectException("failed to connect to /192.168.1.5 (port 4433): isConnected failed: ECONNREFUSED (Connection refused)")),
        )
        assertEquals(ProbeOutcome.NO_ROUTE, ProbeClassifier.classify(NoRouteToHostException("No route to host")))
        assertEquals(ProbeOutcome.NO_ROUTE, ProbeClassifier.classify(UnknownHostException("nope")))
        assertEquals(ProbeOutcome.NO_ROUTE, ProbeClassifier.classify(ConnectException("Network is unreachable")))
        assertEquals(ProbeOutcome.TIMED_OUT, ProbeClassifier.classify(IOException("connect timed out")))
        assertEquals(ProbeOutcome.NO_ROUTE, ProbeClassifier.classify(IOException()))
        assertNull(PlanResult.Failed(TransferFailure.INTERNAL, null).detail)
    }
}
