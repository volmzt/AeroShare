# AERO SHARE release shrinking rules.
# Room, WorkManager, CameraX and Compose ship their own consumer rules.
-keep class com.aero.share.transfer.** { *; }
-dontwarn org.slf4j.**
