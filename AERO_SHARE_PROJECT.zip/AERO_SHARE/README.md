# AERO SHARE

AERO SHARE is a native Android app (Kotlin + Jetpack Compose, custom design system) that sends files, folders and
installed apps **directly between nearby Android devices** — over the local Wi-Fi network, Wi-Fi Direct or a local-only
hotspot, without the internet and without any server in the middle.

* Free. No ads, no accounts, no analytics, no tracking. Offline-first.
* Optional, voluntary developer support (hidden unless a support address is configured at build time).
* Developer / publisher: **AERO**.
* Languages: English, Ukrainian, Russian. Themes: system / light / dark. Accent: orange `#FF7900` by default.

---

## Status — please read this first

This repository was written in an environment that had **no Android SDK, no emulator and no real device**. The status is
therefore split into what was actually verified and what was not.

| Area | Status |
|---|---|
| `:transfer` module (protocol, TLS, SHA-256, resume, queue, storage, compression) | **Compiled and tested.** 142 JUnit tests run the real TLS engine over loopback; all passed in the authoring environment. |
| Pure logic of the app (view-model logic, rules, mappers, discovery/transport planning, settings logic, QR payloads, APK bundle format, …) | **Compiled and tested** on a plain JVM: 478 JUnit tests, all passed in the authoring environment. |
| String resources (en / uk / ru) | **Validated by script**: 724 strings and 22 plurals per language, identical key sets, placeholders and plural forms checked. |
| Android layer (Compose UI, services, Room, DataStore, NSD, Wi-Fi Direct, hotspot, CameraX, PackageInstaller, notifications, manifest, resource linking, KSP) | **Never compiled and never run.** It was written and statically cross-checked only (imports, string references, Compose call contexts). The first CI build may report compile errors that have to be fixed. |
| Real devices | **Nothing was tested on a real device.** Discovery, Wi-Fi Direct, hotspot, QR scanning, installation of received apps, notifications and battery behaviour are untested. |

Please do not describe this build as "fully tested". See [docs/TEST_RESULTS.md](docs/TEST_RESULTS.md) for exactly what
was run, and for a checklist you can use to test on real devices.

**Кратко по-русски.** Это настоящее нативное Android-приложение (Kotlin + Jetpack Compose), а не макет и не WebView.
Проверено автоматически только то, что работает на обычной JVM: модуль `:transfer` (142 теста, настоящий TLS по
loopback) и чистая логика приложения (478 тестов). Слой Android (экраны, сервисы, Room, NSD, Wi-Fi Direct и т. д.)
локально ни разу не компилировался — возможны ошибки сборки при первом запуске GitHub Actions. На реальных
устройствах не проверялось ничего. Подробности — в `docs/DEVELOPMENT_REPORT.md`, `docs/LIMITATIONS_AND_FUTURE.md`
и `docs/TEST_RESULTS.md`.

---

## Features

**Sending**
* Custom file picker: photos, videos, audio, documents/any files, whole folders and installed apps; selection bar with
  totals; media thumbnails.
* Share-sheet integration: "Share" from other apps (`SEND` / `SEND_MULTIPLE`) opens the recipient screen directly.
* Apps are sent as `.apk`; apps with split APKs are packed into one `.aeroapks` bundle
  (see [docs/APK_BUNDLE_FORMAT.md](docs/APK_BUNDLE_FORMAT.md)). Received apps are installed only through the system
  `PackageInstaller` after the user confirms.
* Recipient screen: nearby devices, QR scan, manual address entry (when "Advanced connection" is on).
* Confirmation screen with the list and the total size before anything is sent. Compression (smart / off) is a setting
  under Settings → Transfers.
* An `aero://pair?…` link (from a QR code scanned with the system camera) starts a send to that device.

**Receiving**
* Receive screen with a QR code, the device name and (optionally) the manual address.
* Every request from a device that is not trusted must be accepted explicitly. Auto-accept for trusted devices exists and
  is **off by default**.
* Receive folder: `Downloads/AERO SHARE` by default, or any folder the user picks with the system folder chooser
  (Storage Access Framework). Incoming data always goes to a private staging area first and is moved to the destination
  only after the checksum matches.
* Name-conflict policy: keep both / replace / skip.

**Transfer engine**
* One TLS connection per transfer, mutual authentication with self-signed EC P-256 certificates, peer trust by
  certificate fingerprint.
* SHA-256 per file, verified before the file is finalised; atomic finalise from a staging area.
* Streaming (no whole-file buffering), so 10 GB and larger files are supported by design (the tests send a 2.3 GiB file and
  resume a transfer beyond the 2 GiB offset).
* Pause / resume / cancel, resume after a broken connection, one-at-a-time queue, folders with structure,
  path-traversal protection.
* Optional "smart" compression (only for compressible content, only when both devices support it).
* Live progress, speed and remaining time computed from real byte counters. Nothing is simulated.

**Connections**
* Local Wi-Fi network: DNS-SD (NSD/mDNS) plus a UDP multicast beacon.
* Wi-Fi Direct (best effort; depends on the manufacturer's implementation).
* Local-only hotspot: a phone can start one for QR pairing (two phones without a router), and the other phone joins it
  from the QR code (joining needs Android 10+).
* QR pairing: one-time or time-limited tokens, shown only on the receiving device.
* Manual IP address and port.
* Bluetooth is **not** used to send files in this version. The app only shows whether Bluetooth is on.

**Management**
* Devices: nearby devices, trusted / blocked / known devices, rename, trust, block, forget.
* History with details and filters (direction: all / sent / received; status: all / completed / failed / cancelled).
  An interrupted or failed outgoing transfer can be retried from its transfer screen.
* Settings: General, Connections, Transfers, Power, Customization, Security, Plugins, Diagnostics, About. Every visible
  setting changes real behaviour; nothing is decorative.
* Diagnostics: capabilities and current state of the device, recent events, a report that can be copied or shared
  (it contains no file names, device name, addresses or keys).
* Foreground service with notifications for running transfers and incoming requests.
* First-launch onboarding. Every permission request is preceded by an explanation inside the app.

**Design**
* Own design system (`core/designsystem`), no Material 3 look: palette, typography, buttons, controls, sheets, toasts,
  optional glass effect, compact lists, reduced motion, haptics and sounds that can be switched off, 48 dp touch targets,
  font scaling.

---

## Build

### With GitHub Actions (recommended)

1. Put `AERO_SHARE_PROJECT.zip` and `.github/workflows/build.yml` into the root of a GitHub repository and push.
2. Open **Actions → Build AERO SHARE → Run workflow** (it also runs on every push and pull request).
3. When the run finishes, download the artifact **app-debug-apk** — it contains `app-debug.apk`.
   The artifacts **test-reports** and **build-logs** are uploaded even if a step fails.

The workflow extracts the ZIP, finds the Gradle project, sets up JDK 17 and the Android SDK (platform 35), makes
`gradlew` executable, validates the build with `./gradlew tasks`, runs the unit tests, builds `assembleDebug`, checks
that `app-debug.apk` exists and uploads it. If unit tests fail, the APK is still built and uploaded, and the job is
then marked as failed so the failure is not hidden.

Optional: create a repository variable `AERO_SUPPORT_URL` (an `https://` address) to show the "Support the developer"
action at the bottom of About. When it is not set the action is hidden.

### Locally

Requirements: JDK 17 and the Android SDK (platform 35, build-tools 34/35; set `ANDROID_HOME` or `sdk.dir` in
`local.properties`).

```bash
chmod +x gradlew
./gradlew :transfer:test :app:testDebugUnitTest   # unit tests
./gradlew assembleDebug                           # app/build/outputs/apk/debug/app-debug.apk
```

The debug APK is signed with the standard Android debug key. A release signing configuration is intentionally not
included: add your own keystore before publishing a release build.

---

## Project layout

```
AERO_SHARE/
├── app/                  Android application (Kotlin, Jetpack Compose)
│   └── src/main/java/com/aero/share/
│       ├── core/         design system, database (Room), settings (DataStore), security, storage, permissions, common
│       ├── domain/       models and interfaces shared by features (settings, discovery, coordinator, power)
│       ├── network/      discovery (NSD, multicast beacon), transport planning, Wi-Fi Direct, hotspot, QR
│       ├── transfer/     coordinator, receiver controller, power policy, foreground service, cleanup worker
│       ├── feature/      home, send, receive, transfer, devices, history, settings, onboarding
│       ├── navigation/   routes, nav host, pairing links, external requests (share intents)
│       └── di/           hand-written app container (no DI framework)
├── transfer/             pure Kotlin/JVM transfer engine (no Android dependencies)
│   └── src/main/kotlin/com/aero/share/transfer/
│       ├── proto/        wire format and messages
│       ├── security/     certificates (own DER/X.509 builder), TLS contexts, fingerprints
│       ├── engine/       sender, receiver server, sessions, compression, progress meter
│       ├── storage/      staged incoming storage with a resume ledger
│       ├── queue/        transfer queue
│       ├── pairing/      one-time / expiring pairing tokens
│       ├── path/         path-safety rules
│       └── model/        public models and tracking
├── docs/                 reports and technical notes
├── gradle/               version catalog and the Gradle wrapper
└── README.md
```

Size: about 23,100 lines in `app`, 4,200 lines in `:transfer`, 9,000 lines of tests; 197 + 20 Kotlin source files.

Toolchain: Gradle 8.10.2, Android Gradle Plugin 8.7.3, Kotlin 2.0.21 (Compose compiler plugin), KSP 2.0.21-1.0.28,
compileSdk / targetSdk 35, minSdk 26, JDK 17. Dependency versions are in `gradle/libs.versions.toml`.

---

## How it works

### Protocol (`:transfer`)
* Frames have a 5-byte header (type + length). Control payloads are at most 256 KiB, data payloads at most 2 MiB.
* Session: `HELLO` / `HELLO_ACK` → `OFFER` (+ `OFFER_ENTRIES`, `OFFER_END`) → `OFFER_REPLY` → per file
  `FILE_BEGIN` / `FILE_DATA`… / `FILE_END` / `FILE_RESULT` → `TRANSFER_END` / `TRANSFER_DONE`; `PAUSE`, `RESUME`,
  `CANCEL`, `PING` while running.
* Compression, when used, is Deflate (best speed, sync-flush per chunk), and is skipped for already-compressed formats.

### Security
* TLS with a self-signed EC P-256 certificate per installation (SHA256withECDSA); both sides authenticate.
* A device id is the first 32 hex characters of its certificate's SHA-256 fingerprint. Trust is bound to the
  fingerprint, so renaming a device does not make it trusted.
* A pairing QR code carries the receiver's addresses and port, its certificate fingerprint, a one-time token with an
  expiry time and, when a local-only hotspot was started for it, the hotspot's credentials. It contains no permanent
  secret. Tokens are compared in constant time; the lifetime and the single-use rule are set in Settings → Security.
* Unknown devices need explicit approval on the receiver. "Block unknown devices" refuses never-seen devices.
* Each file is hashed with SHA-256 and verified before it is moved to its final location.
* File names from the network are sanitised; paths that try to leave the destination are rejected.
* Hidden mode only stops the app from announcing itself on the network (LAN, NSD, Wi-Fi Direct). It is **not** a security
  boundary: the device is still reachable through its QR code or address.

### Discovery and ports
* DNS-SD service type `_aeroshare._tcp.` (attribute `v=1`); UDP multicast beacon on 239.255.42.99:47475; Wi-Fi Direct
  peer handshake on port 47476; the receiver prefers TCP port 47474 (an ephemeral port is used if it is busy).
* Discovery is IPv4 Wi-Fi / Ethernet only in this version.

### Android 15 and background work
* Transfers run in a `dataSync` foreground service. Android 15 limits such services in time; when the limit is hit the
  receiver stops and running sends are interrupted and can be resumed.
* A daily WorkManager job deletes unfinished received data and, if a retention period is set, old history records
  (according to Settings → Transfers), plus leftover temporary APK files.

---

## Permissions

Requested only when the related feature is used, after an explanation in the app.

| Permission | Why |
|---|---|
| `INTERNET`, `ACCESS_NETWORK_STATE`, `ACCESS_WIFI_STATE`, `CHANGE_WIFI_STATE`, `CHANGE_NETWORK_STATE`, `CHANGE_WIFI_MULTICAST_STATE` | Local sockets, network detection, multicast discovery. The app does not need the internet. |
| `NEARBY_WIFI_DEVICES` (declared `neverForLocation`), `ACCESS_FINE_LOCATION` (Android 12L and lower only) | Wi-Fi Direct and local-only hotspot. Location is never read. |
| `POST_NOTIFICATIONS`, `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_DATA_SYNC`, `WAKE_LOCK` | Transfers that continue with the screen off, and notifications. |
| `VIBRATE` | Optional haptic feedback (can be switched off). |
| `CAMERA` | Scanning a QR code. Only when the scanner is opened. |
| `READ_MEDIA_IMAGES`, `READ_MEDIA_VIDEO`, `READ_MEDIA_AUDIO`, `READ_MEDIA_VISUAL_USER_SELECTED`, `READ_EXTERNAL_STORAGE` (≤ Android 12L), `WRITE_EXTERNAL_STORAGE` (≤ Android 9) | Browsing media in the picker and saving received media on old Android versions. Folders and documents use the system file chooser. |
| `REQUEST_INSTALL_PACKAGES` | Lets the user install a received APK through the system installer. Nothing is installed silently. |

The app does not declare `QUERY_ALL_PACKAGES`; the apps list contains apps that have a launcher icon.

---

## Privacy

No accounts, no ads, no analytics, no crash reporting service, no network calls other than the transfers the user
starts. History, trusted devices and settings are stored on the device only (`allowBackup` is off). The diagnostic
report is created only when the user taps Share or Copy.

---

## Known limitations

A short list; the full list with details is in [docs/LIMITATIONS_AND_FUTURE.md](docs/LIMITATIONS_AND_FUTURE.md).

* The Android layer has not been compiled or run yet (see Status).
* Bluetooth file transfer is not implemented. Wi-Fi Direct is best effort and depends on the device.
* Receiving works only while the Receive screen is open (or until the running transfer ends).
* LAN discovery is IPv4 only; a device that is itself the hotspot owner cannot discover others on its own network.
* APK inspection shows metadata and the signer comparison where Android allows it; it is not malware scanning.
* Plugins is a single "planned" card: no plugin system exists yet.

---

## Open-source components

AERO SHARE uses these libraries, all under the Apache License 2.0 (the notices are also shown in the app, Settings →
About): Kotlin and kotlinx.coroutines, AndroidX Core / Activity / Lifecycle / Navigation, Jetpack Compose (UI,
Foundation, Animation, Material Icons Extended), Room, DataStore, WorkManager, DocumentFile, CameraX, and ZXing core.

The project itself does not contain a license file yet. Add the license you prefer before publishing the source.
