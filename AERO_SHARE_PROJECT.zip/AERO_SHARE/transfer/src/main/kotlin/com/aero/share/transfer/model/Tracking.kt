package com.aero.share.transfer.model

import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update

/** Holds the observable state of one transfer. The engine writes, the UI observes [state]. */
class TransferTracker(initial: TransferSnapshot) {
    private val _state = MutableStateFlow(initial)
    val state: StateFlow<TransferSnapshot> get() = _state.asStateFlow()
    val current: TransferSnapshot get() = _state.value
    fun update(transform: (TransferSnapshot) -> TransferSnapshot) {
        _state.update(transform)
    }
}

/** User controls for one transfer. Thread-safe; the engine polls/awaits it. */
class TransferControl {
    private val paused = MutableStateFlow(false)
    private val cancelSignal = CompletableDeferred<Unit>()

    @Volatile
    private var cancelledFlag = false

    val pausedFlow: StateFlow<Boolean> get() = paused.asStateFlow()
    val isPaused: Boolean get() = paused.value
    val isCancelled: Boolean get() = cancelledFlag

    fun pause() {
        if (!cancelledFlag) paused.value = true
    }

    fun resume() {
        paused.value = false
    }

    fun cancel() {
        cancelledFlag = true
        cancelSignal.complete(Unit)
        paused.value = false
    }

    /** Suspends until cancel() is called. */
    suspend fun awaitCancelled() {
        cancelSignal.await()
    }

    /** Suspends while paused. Returns immediately when not paused. */
    suspend fun awaitNotPaused() {
        paused.first { !it }
    }
}
