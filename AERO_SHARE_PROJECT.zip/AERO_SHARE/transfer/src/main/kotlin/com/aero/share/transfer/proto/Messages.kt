package com.aero.share.transfer.proto

object Protocol {
    const val VERSION = 1
    val MAGIC = byteArrayOf('A'.code.toByte(), 'E'.code.toByte(), 'R'.code.toByte(), 'O'.code.toByte())

    const val MAX_ID = 64
    const val MAX_NAME = 128
    const val MAX_APP_VERSION = 32
    const val MAX_TITLE = 256
    const val MAX_PATH = 1024
    const val MAX_MIME = 128
    const val MAX_DETAIL = 200
    const val SHA256_BYTES = 32
    const val MAX_ENTRIES_PER_BATCH = 200
    const val MAX_BATCH_BYTES = 60 * 1024
}

/** HELLO_ACK status codes. */
object HelloStatus {
    const val OK = 0
    const val BUSY = 1
    const val BLOCKED = 2
    const val UNSUPPORTED_VERSION = 3
    const val AUTH_FAILED = 4
}

/** OFFER_REPLY decision codes. */
object ReplyCode {
    const val ACCEPT = 0
    const val DECLINE_USER = 1
    const val BUSY = 2
    const val NO_SPACE = 3
    const val NOT_ALLOWED = 4
    const val TIMEOUT = 5
    const val STORAGE_ERROR = 6
}

/** FILE_RESULT status codes. */
object FileStatus {
    const val OK = 0
    const val HASH_MISMATCH = 1
    const val IO_ERROR = 2
    const val NO_SPACE = 3
    const val REJECTED = 4
}

/** CANCEL reason codes. */
object CancelReason {
    const val USER = 0
    const val SOURCE_CHANGED = 1
    const val ERROR = 2
}

object Encoding {
    const val RAW = 0
    const val DEFLATE = 1
}

class Hello(
    val version: Int,
    val deviceId: String,
    val name: String,
    val kind: Int,
    val appVersion: String,
    val capabilities: Int,
    val token: ByteArray?,
) {
    fun encode(): ByteArray {
        val w = MsgWriter(160).bytes(Protocol.MAGIC).u8(version)
            .str(deviceId, Protocol.MAX_ID).str(MsgWriter.clip(name, Protocol.MAX_NAME), Protocol.MAX_NAME)
            .u8(kind).str(MsgWriter.clip(appVersion, Protocol.MAX_APP_VERSION), Protocol.MAX_APP_VERSION)
            .u32(capabilities.toLong() and 0xFFFFFFFFL)
        if (token == null) w.u8(0) else {
            require(token.size in 16..32)
            w.u8(token.size).bytes(token)
        }
        return w.toByteArray()
    }

    companion object {
        /** Returns only the version for unsupported versions (the rest of the layout is not defined for them). */
        fun decode(frame: Frame): Hello {
            val r = MsgReader(frame)
            val magic = r.bytes(4)
            if (!magic.contentEquals(Protocol.MAGIC)) throw ProtocolException("bad magic")
            val version = r.u8()
            if (version != Protocol.VERSION) return Hello(version, "", "", 3, "", 0, null)
            val deviceId = r.str(Protocol.MAX_ID)
            val name = r.str(Protocol.MAX_NAME)
            val kind = r.u8()
            val appVersion = r.str(Protocol.MAX_APP_VERSION)
            val caps = r.u32().toInt()
            val tokenLen = r.u8()
            if (tokenLen != 0 && tokenLen !in 16..32) throw ProtocolException("bad token length")
            val token = if (tokenLen == 0) null else r.bytes(tokenLen)
            r.requireEnd()
            return Hello(version, deviceId, name, kind, appVersion, caps, token)
        }
    }
}

class HelloAck(
    val version: Int,
    val status: Int,
    val deviceId: String,
    val name: String,
    val kind: Int,
    val appVersion: String,
    val capabilities: Int,
    val authenticatedByQr: Boolean,
    /** true when the receiver shows a verification code (first contact without QR) and expects the user to compare it. */
    val showsCode: Boolean,
) {
    fun encode(): ByteArray =
        MsgWriter(160).u8(version).u8(status)
            .str(deviceId, Protocol.MAX_ID).str(MsgWriter.clip(name, Protocol.MAX_NAME), Protocol.MAX_NAME)
            .u8(kind).str(MsgWriter.clip(appVersion, Protocol.MAX_APP_VERSION), Protocol.MAX_APP_VERSION)
            .u32(capabilities.toLong() and 0xFFFFFFFFL)
            .u8(if (authenticatedByQr) 1 else 0).u8(if (showsCode) 1 else 0)
            .toByteArray()

    companion object {
        fun decode(frame: Frame): HelloAck {
            val r = MsgReader(frame)
            val version = r.u8()
            val status = r.u8()
            val deviceId = r.str(Protocol.MAX_ID)
            val name = r.str(Protocol.MAX_NAME)
            val kind = r.u8()
            val appVersion = r.str(Protocol.MAX_APP_VERSION)
            val caps = r.u32().toInt()
            val qr = r.u8() != 0
            val code = r.u8() != 0
            r.requireEnd()
            return HelloAck(version, status, deviceId, name, kind, appVersion, caps, qr, code)
        }
    }
}

class OfferHeader(
    val transferId: String,
    val fileCount: Long,
    val totalBytes: Long,
    val folder: Boolean,
    val compressionRequested: Boolean,
    val categoriesMask: Int,
    val title: String?,
) {
    fun encode(): ByteArray {
        val w = MsgWriter(128).str(transferId, Protocol.MAX_ID).u32(fileCount).i64(totalBytes)
            .u8((if (folder) 1 else 0) or (if (compressionRequested) 2 else 0))
            .u32(categoriesMask.toLong() and 0xFFFFFFFFL)
        if (title == null) w.u8(0) else w.u8(1).str(MsgWriter.clip(title, Protocol.MAX_TITLE), Protocol.MAX_TITLE)
        return w.toByteArray()
    }

    companion object {
        fun decode(frame: Frame): OfferHeader {
            val r = MsgReader(frame)
            val id = r.str(Protocol.MAX_ID)
            if (id.isEmpty()) throw ProtocolException("empty transfer id")
            val count = r.u32()
            val total = r.i64()
            if (total < 0) throw ProtocolException("negative total size")
            val flags = r.u8()
            val mask = r.u32().toInt()
            val title = if (r.u8() != 0) r.str(Protocol.MAX_TITLE) else null
            r.requireEnd()
            return OfferHeader(id, count, total, (flags and 1) != 0, (flags and 2) != 0, mask, title)
        }
    }
}

class WireEntry(
    val id: Long,
    val path: String,
    val size: Long,
    val lastModified: Long,
    val category: Int,
    val mimeType: String?,
)

object OfferEntriesCodec {
    /** Splits [entries] into frames of at most [Protocol.MAX_ENTRIES_PER_BATCH] entries / [Protocol.MAX_BATCH_BYTES] bytes. */
    fun encodeBatches(entries: List<WireEntry>): List<ByteArray> {
        val out = ArrayList<ByteArray>()
        var i = 0
        while (i < entries.size) {
            val body = MsgWriter(4096)
            var count = 0
            while (i < entries.size && count < Protocol.MAX_ENTRIES_PER_BATCH && body.size < Protocol.MAX_BATCH_BYTES) {
                val e = entries[i]
                body.u32(e.id).str(e.path, Protocol.MAX_PATH).i64(e.size).i64(e.lastModified).u8(e.category)
                if (e.mimeType == null) body.u8(0) else body.u8(1).str(MsgWriter.clip(e.mimeType, Protocol.MAX_MIME), Protocol.MAX_MIME)
                count++
                i++
            }
            out.add(MsgWriter(body.size + 2).u16(count).bytes(body.toByteArray()).toByteArray())
        }
        return out
    }

    fun decode(frame: Frame): List<WireEntry> {
        val r = MsgReader(frame)
        val count = r.u16()
        if (count > Protocol.MAX_ENTRIES_PER_BATCH * 4) throw ProtocolException("too many entries in one frame")
        val list = ArrayList<WireEntry>(minOf(count, 256))
        repeat(count) {
            val id = r.u32()
            val path = r.str(Protocol.MAX_PATH)
            val size = r.i64()
            val mtime = r.i64()
            val category = r.u8()
            val mime = if (r.u8() != 0) r.str(Protocol.MAX_MIME) else null
            list.add(WireEntry(id, path, size, mtime, category, mime))
        }
        r.requireEnd()
        return list
    }
}

class ReplyEntry(val id: Long, val offset: Long, val prefixSha256: ByteArray)

class OfferReply(val decision: Int, val entries: List<ReplyEntry>) {
    fun encode(): ByteArray {
        val w = MsgWriter(16 + entries.size * 44).u8(decision)
        if (decision == ReplyCode.ACCEPT) {
            w.u32(entries.size.toLong())
            for (e in entries) {
                require(e.prefixSha256.size == Protocol.SHA256_BYTES)
                w.u32(e.id).i64(e.offset).bytes(e.prefixSha256)
            }
        }
        return w.toByteArray()
    }

    companion object {
        fun decode(frame: Frame, maxEntries: Int): OfferReply {
            val r = MsgReader(frame)
            val decision = r.u8()
            if (decision != ReplyCode.ACCEPT) {
                r.requireEnd()
                return OfferReply(decision, emptyList())
            }
            val n = r.u32()
            if (n > maxEntries || n * 44 != r.remaining.toLong()) throw ProtocolException("bad reply entry count")
            val list = ArrayList<ReplyEntry>(n.toInt())
            for (i in 0 until n.toInt()) {
                val id = r.u32()
                val off = r.i64()
                if (off < 0) throw ProtocolException("negative offset")
                list.add(ReplyEntry(id, off, r.bytes(Protocol.SHA256_BYTES)))
            }
            r.requireEnd()
            return OfferReply(decision, list)
        }
    }
}

class FileBegin(val id: Long, val startOffset: Long, val encoding: Int) {
    fun encode(): ByteArray = MsgWriter(16).u32(id).i64(startOffset).u8(encoding).toByteArray()

    companion object {
        fun decode(frame: Frame): FileBegin {
            val r = MsgReader(frame)
            val id = r.u32()
            val off = r.i64()
            val enc = r.u8()
            r.requireEnd()
            if (off < 0) throw ProtocolException("negative offset")
            if (enc != Encoding.RAW && enc != Encoding.DEFLATE) throw ProtocolException("unknown encoding")
            return FileBegin(id, off, enc)
        }
    }
}

class FileEnd(val id: Long, val sha256: ByteArray) {
    fun encode(): ByteArray {
        require(sha256.size == Protocol.SHA256_BYTES)
        return MsgWriter(40).u32(id).bytes(sha256).toByteArray()
    }

    companion object {
        fun decode(frame: Frame): FileEnd {
            val r = MsgReader(frame)
            val id = r.u32()
            val sha = r.bytes(Protocol.SHA256_BYTES)
            r.requireEnd()
            return FileEnd(id, sha)
        }
    }
}

class FileResult(val id: Long, val status: Int, val detail: String) {
    fun encode(): ByteArray =
        MsgWriter(32).u32(id).u8(status).str(MsgWriter.clip(detail, Protocol.MAX_DETAIL), Protocol.MAX_DETAIL).toByteArray()

    companion object {
        fun decode(frame: Frame): FileResult {
            val r = MsgReader(frame)
            val id = r.u32()
            val status = r.u8()
            val detail = r.str(Protocol.MAX_DETAIL)
            r.requireEnd()
            return FileResult(id, status, detail)
        }
    }
}

class CancelMsg(val reason: Int) {
    fun encode(): ByteArray = MsgWriter(2).u8(reason).toByteArray()

    companion object {
        fun decode(frame: Frame): CancelMsg {
            val r = MsgReader(frame)
            val reason = r.u8()
            r.requireEnd()
            return CancelMsg(reason)
        }
    }
}

class TransferDone(val status: Int, val okCount: Long, val failedCount: Long) {
    fun encode(): ByteArray = MsgWriter(12).u8(status).u32(okCount).u32(failedCount).toByteArray()

    companion object {
        const val OK = 0
        const val FAILED = 1

        fun decode(frame: Frame): TransferDone {
            val r = MsgReader(frame)
            val status = r.u8()
            val ok = r.u32()
            val failed = r.u32()
            r.requireEnd()
            return TransferDone(status, ok, failed)
        }
    }
}
