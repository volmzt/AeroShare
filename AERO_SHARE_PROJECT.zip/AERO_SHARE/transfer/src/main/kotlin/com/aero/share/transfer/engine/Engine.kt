package com.aero.share.transfer.engine

import com.aero.share.transfer.model.CompressionMode
import com.aero.share.transfer.model.FileCategory
import com.aero.share.transfer.model.ManifestEntry
import com.aero.share.transfer.model.PeerInfo
import com.aero.share.transfer.model.PeerTrust
import com.aero.share.transfer.model.TransferControl
import com.aero.share.transfer.model.TransferFailure
import com.aero.share.transfer.model.TransferTracker
import com.aero.share.transfer.model.TransportKind
import kotlinx.coroutines.Deferred
import java.io.InputStream
import java.net.InetSocketAddress
import java.net.Socket

/** Tunables of the engine. The app derives these from the power mode and the connection-timeout setting. */
data class EngineConfig(
    val chunkSize: Int = 256 * 1024,
    val connectTimeoutMs: Int = 15_000,
    /** Max silence on a connection (peers exchange PING frames, so this detects dead links). */
    val idleTimeoutMs: Int = 45_000,
    val pingIntervalMs: Long = 10_000,
    /** How long the sender waits for the receiver's user to accept. */
    val acceptTimeoutMs: Long = 120_000,
    /** A pause longer than this closes the connection; the transfer becomes INTERRUPTED (resumable). */
    val pauseTimeoutMs: Long = 600_000,
    val maxManifestEntries: Int = 200_000,
    val progressIntervalMs: Long = 100,
)

/** Receives non-sensitive diagnostic lines (never file names, keys or tokens). */
fun interface EngineLogger {
    fun log(message: String)

    companion object {
        val NONE = EngineLogger { }
    }
}

/** Opens the TCP connection. The app supplies network-bound connectors for Wi-Fi Direct / hotspot networks. */
fun interface SocketConnector {
    fun connect(host: String, port: Int, timeoutMs: Int): Socket

    companion object {
        val DEFAULT = SocketConnector { host, port, timeoutMs ->
            val s = Socket()
            try {
                s.connect(InetSocketAddress(host, port), timeoutMs)
                s
            } catch (t: Throwable) {
                runCatching { s.close() }
                throw t
            }
        }
    }
}

data class SourceVersion(val size: Long, val lastModified: Long)

/** A file the sender can stream. Implemented by the app for content URIs, folders and APK bundles. */
interface SendableFile {
    val id: Int
    /** '/' separated; for a single file this is just its name. */
    val relativePath: String
    val size: Long
    val lastModified: Long
    val category: FileCategory
    val mimeType: String?

    /** Opens a stream positioned at [offset] (never reads the whole file into memory). Caller closes it. */
    fun open(offset: Long): InputStream

    /** Current size/mtime, used to detect that the source changed during the transfer; null if it vanished. */
    fun currentVersion(): SourceVersion?
}

class SendRequest(
    val transferId: String,
    val files: List<SendableFile>,
    val title: String?,
    val compression: CompressionMode,
)

class SendTarget(
    val host: String,
    val port: Int,
    /** Pinned certificate fingerprint (QR pairing or a known device). null = first contact, verified by code. */
    val expectedFingerprint: String?,
    /** Raw token from a pairing QR code, or null. */
    val pairToken: ByteArray?,
    val transport: TransportKind,
    val connector: SocketConnector = SocketConnector.DEFAULT,
)

sealed interface TransferResult {
    data class Completed(val files: Int, val bytes: Long) : TransferResult
    data class Failed(val failure: TransferFailure, val detail: String?, val resumable: Boolean) : TransferResult
    data object Cancelled : TransferResult
}

/** Decides whether a peer is trusted / known / blocked. Implemented by the app on top of its device repository. */
fun interface PeerPolicy {
    suspend fun trustOf(peer: PeerInfo): PeerTrust
}

enum class DeclineReason { USER, BUSY, NO_SPACE, NOT_ALLOWED, TIMEOUT }

sealed interface OfferDecision {
    data object Accept : OfferDecision
    data class Decline(val reason: DeclineReason) : OfferDecision
}

/** Everything the UI needs to ask the user whether to accept an incoming transfer. */
class IncomingOffer(
    val transferId: String,
    val peer: PeerInfo,
    val trust: PeerTrust,
    /** true when the sender proved knowledge of a valid one-time QR token. */
    val authenticatedByQr: Boolean,
    /** Short code both devices display for first contact (null when trust is already established). */
    val verificationCode: String?,
    val remoteAddress: String,
    val title: String?,
    val fileCount: Int,
    val totalBytes: Long,
    val categories: Set<FileCategory>,
    val entries: List<ManifestEntry>,
    /** true when partial data from an earlier attempt of this transfer exists. */
    val isResume: Boolean,
    val resumeBytes: Long,
    val destinationLabel: String,
    val freeBytes: Long?,
)

class ReceiveSession(
    val transferId: String,
    val control: TransferControl,
    val tracker: TransferTracker,
    val completion: Deferred<TransferResult>,
)

interface IncomingListener {
    /** May suspend for as long as the user decides (the engine applies [EngineConfig.acceptTimeoutMs]). */
    suspend fun onOffer(offer: IncomingOffer): OfferDecision

    /** Called when an accepted transfer starts. */
    fun onSession(session: ReceiveSession)

    /** Connection refused before an offer (blocked device, bad token, version mismatch). For diagnostics. */
    fun onRejected(peer: PeerInfo?, remoteAddress: String, failure: TransferFailure) {}
}
