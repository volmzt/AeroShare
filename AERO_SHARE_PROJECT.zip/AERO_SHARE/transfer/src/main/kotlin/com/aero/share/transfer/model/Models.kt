package com.aero.share.transfer.model

/** Kind of device, shown as an icon and sent in the protocol handshake. */
enum class DeviceKind(val code: Int) {
    PHONE(0), TABLET(1), COMPUTER(2), OTHER(3);

    companion object {
        fun fromCode(code: Int): DeviceKind = entries.firstOrNull { it.code == code } ?: OTHER
    }
}

/** Coarse file category used for the file picker, offer summaries and history. */
enum class FileCategory(val code: Int) {
    IMAGE(0), VIDEO(1), AUDIO(2), DOCUMENT(3), ARCHIVE(4), APK(5), OTHER(6);

    /** Bit used in category masks (see [maskOf]). */
    val bit: Int get() = 1 shl code

    companion object {
        fun fromCode(code: Int): FileCategory = entries.firstOrNull { it.code == code } ?: OTHER

        fun maskOf(categories: Collection<FileCategory>): Int =
            categories.fold(0) { acc, c -> acc or c.bit }

        fun fromMask(mask: Int): Set<FileCategory> =
            entries.filter { (mask and it.bit) != 0 }.toSet()

        private val documentExt = setOf(
            "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "odt", "ods", "odp", "txt", "rtf",
            "csv", "md", "epub", "fb2", "djvu", "json", "xml", "html", "htm", "log",
        )
        private val archiveExt = setOf("zip", "rar", "7z", "tar", "gz", "tgz", "bz2", "xz", "zst", "iso")
        private val apkExt = setOf("apk", "apks", "xapk", "apkm", "aeroapks")
        private val imageExt = setOf("jpg", "jpeg", "png", "gif", "webp", "heic", "heif", "bmp", "avif", "svg", "dng", "raw")
        private val videoExt = setOf("mp4", "mkv", "webm", "avi", "mov", "3gp", "m4v", "ts", "flv", "wmv")
        private val audioExt = setOf("mp3", "m4a", "aac", "flac", "ogg", "opus", "wav", "amr", "wma", "mid", "midi")

        /** Classifies by MIME type first and falls back to the file extension. */
        fun classify(fileName: String, mimeType: String?): FileCategory {
            val ext = fileName.substringAfterLast('.', "").lowercase()
            val mime = mimeType?.lowercase().orEmpty()
            return when {
                mime == "application/vnd.android.package-archive" || ext in apkExt -> APK
                mime.startsWith("image/") || ext in imageExt -> IMAGE
                mime.startsWith("video/") || ext in videoExt -> VIDEO
                mime.startsWith("audio/") || ext in audioExt -> AUDIO
                ext in archiveExt || mime == "application/zip" || mime == "application/x-rar-compressed" -> ARCHIVE
                ext in documentExt || mime == "application/pdf" || mime.startsWith("text/") -> DOCUMENT
                else -> OTHER
            }
        }
    }
}

/** How two devices are physically connected. Only reported when it is actually known. */
enum class TransportKind { LAN, WIFI_DIRECT, HOTSPOT, MANUAL }

enum class TransferDirection { SEND, RECEIVE }

/** Life cycle of one transfer. Valid transitions are encoded in [TransferStateMachine]. */
enum class TransferState {
    WAITING, PREPARING, CONNECTING, AWAITING_ACCEPTANCE, TRANSFERRING, PAUSED,
    INTERRUPTED, VERIFYING, COMPLETED, FAILED, CANCELLED;

    val isTerminal: Boolean get() = this == COMPLETED || this == FAILED || this == CANCELLED
    val isActive: Boolean
        get() = this == PREPARING || this == CONNECTING || this == AWAITING_ACCEPTANCE ||
            this == TRANSFERRING || this == PAUSED || this == VERIFYING
}

/** Why a transfer did not complete. The UI maps each value to a localized message and a recovery hint. */
enum class TransferFailure {
    DECLINED, BUSY, BLOCKED, UNREACHABLE, TIMEOUT, NETWORK_BLOCKED, AUTH_FAILED, UNSUPPORTED_VERSION,
    INTEGRITY, NO_SPACE, STORAGE, SOURCE_CHANGED, SOURCE_UNREADABLE, PROTOCOL, PEER_CANCELLED,
    INTERRUPTED, PERMISSION, INTERNAL
}

enum class ConflictPolicy { KEEP_BOTH, REPLACE, SKIP }

enum class CompressionMode { OFF, SMART }

enum class PeerTrust { TRUSTED, KNOWN, UNKNOWN, BLOCKED }

/** Capability bits exchanged in the handshake. */
object Capabilities {
    const val COMPRESSION = 1
    const val RESUME = 2
    const val FOLDERS = 4
    const val WIFI_DIRECT = 8
    const val APK_BUNDLE = 16
    const val ALL = COMPRESSION or RESUME or FOLDERS or WIFI_DIRECT or APK_BUNDLE
}

/** Identity of this device as announced to peers. [deviceId] is derived from the TLS certificate. */
data class LocalPeer(
    val deviceId: String,
    val name: String,
    val kind: DeviceKind,
    val appVersion: String,
    val capabilities: Int = Capabilities.ALL,
)

/** A remote device. [fingerprint] always comes from the authenticated TLS certificate, never from the peer's claims. */
data class PeerInfo(
    val deviceId: String,
    val name: String,
    val kind: DeviceKind,
    val appVersion: String,
    val fingerprint: String,
    val capabilities: Int = 0,
)

/** One file in a transfer manifest. [relativePath] uses '/' separators and is validated before use. */
data class ManifestEntry(
    val id: Int,
    val relativePath: String,
    val size: Long,
    val lastModified: Long,
    val category: FileCategory,
    val mimeType: String?,
)

/** A received file after verification and publishing to its final location. */
data class SavedFile(
    val uri: String,
    val displayName: String,
    val relativePath: String,
    val size: Long,
    val mimeType: String?,
    val category: FileCategory,
    val sha256: String,
)

/** Immutable view of a transfer for the UI, notifications and history. */
data class TransferSnapshot(
    val id: String,
    val direction: TransferDirection,
    val state: TransferState,
    val peer: PeerInfo? = null,
    val peerName: String = "",
    val transport: TransportKind? = null,
    val title: String? = null,
    val totalFiles: Int = 0,
    val completedFiles: Int = 0,
    val currentFileName: String? = null,
    val currentFileIndex: Int = 0,
    val currentFileSize: Long = 0,
    val currentFileBytes: Long = 0,
    val totalBytes: Long = 0,
    val transferredBytes: Long = 0,
    val bytesPerSecond: Long = 0,
    val elapsedMillis: Long = 0,
    val etaMillis: Long? = null,
    val failure: TransferFailure? = null,
    val failureDetail: String? = null,
    val resumable: Boolean = false,
    val compressed: Boolean = false,
    val startedAt: Long = 0,
    val finishedAt: Long? = null,
    val savedFiles: List<SavedFile> = emptyList(),
    val verificationCode: String? = null,
    val pausedByPeer: Boolean = false,
) {
    /** Overall progress in 0..1. */
    val fraction: Float
        get() = if (totalBytes <= 0L) 0f else (transferredBytes.toDouble() / totalBytes.toDouble()).toFloat().coerceIn(0f, 1f)
}

/** Allowed state transitions; used by the queue and unit tests. */
object TransferStateMachine {
    private val allowed: Map<TransferState, Set<TransferState>> = mapOf(
        TransferState.WAITING to setOf(
            TransferState.PREPARING, TransferState.CONNECTING, TransferState.PAUSED,
            TransferState.CANCELLED, TransferState.FAILED,
        ),
        TransferState.PREPARING to setOf(
            TransferState.CONNECTING, TransferState.AWAITING_ACCEPTANCE, TransferState.TRANSFERRING,
            TransferState.CANCELLED, TransferState.FAILED, TransferState.PAUSED,
        ),
        TransferState.CONNECTING to setOf(
            TransferState.AWAITING_ACCEPTANCE, TransferState.TRANSFERRING, TransferState.INTERRUPTED,
            TransferState.FAILED, TransferState.CANCELLED, TransferState.PAUSED,
        ),
        TransferState.AWAITING_ACCEPTANCE to setOf(
            TransferState.TRANSFERRING, TransferState.FAILED, TransferState.CANCELLED,
            TransferState.INTERRUPTED, TransferState.PAUSED,
        ),
        TransferState.TRANSFERRING to setOf(
            TransferState.PAUSED, TransferState.VERIFYING, TransferState.COMPLETED,
            TransferState.INTERRUPTED, TransferState.FAILED, TransferState.CANCELLED,
        ),
        TransferState.PAUSED to setOf(
            TransferState.TRANSFERRING, TransferState.WAITING, TransferState.CONNECTING,
            TransferState.INTERRUPTED, TransferState.FAILED, TransferState.CANCELLED,
        ),
        TransferState.INTERRUPTED to setOf(
            TransferState.WAITING, TransferState.CONNECTING, TransferState.FAILED, TransferState.CANCELLED,
        ),
        TransferState.VERIFYING to setOf(
            TransferState.TRANSFERRING, TransferState.COMPLETED, TransferState.FAILED,
            TransferState.INTERRUPTED, TransferState.CANCELLED,
        ),
        TransferState.COMPLETED to emptySet(),
        TransferState.FAILED to setOf(TransferState.WAITING),
        TransferState.CANCELLED to emptySet(),
    )

    fun canTransition(from: TransferState, to: TransferState): Boolean =
        from == to || to in (allowed[from] ?: emptySet())
}
