package com.aero.share.transfer.engine

/**
 * Throughput and ETA estimation. Speed is an exponential moving average with a time constant of about
 * [windowMs]; the ETA is only reported after [minEtaMs] of active transfer and a positive speed, otherwise null.
 * Thread-safe. Time is injectable for tests.
 */
class ProgressMeter(
    private val clock: () -> Long = { System.nanoTime() / 1_000_000L },
    private val windowMs: Long = 2_000,
    private val minEtaMs: Long = 2_000,
    private val sampleMs: Long = 200,
) {
    private var lastSampleAt = -1L
    private var lastDataAt = -1L
    private var bytesSinceSample = 0L
    private var ema = 0.0
    private var hasSpeed = false
    private var activeMs = 0L

    @Synchronized
    fun add(bytes: Long) {
        if (bytes <= 0) return
        val now = clock()
        lastDataAt = now
        if (lastSampleAt < 0) {
            // the first chunk only starts the clock: counting its bytes against a zero-length window would inflate the speed
            lastSampleAt = now
            return
        }
        bytesSinceSample += bytes
        val dt = now - lastSampleAt
        if (dt >= sampleMs) {
            val instant = bytesSinceSample * 1000.0 / dt
            ema = if (!hasSpeed) instant else ema + (dt.toDouble() / (windowMs + dt)) * (instant - ema)
            hasSpeed = true
            activeMs += dt
            lastSampleAt = now
            bytesSinceSample = 0
        }
    }

    /** Call when the transfer stops moving data (pause, waiting): the next samples start fresh. */
    @Synchronized
    fun idle() {
        lastSampleAt = -1L
        lastDataAt = -1L
        bytesSinceSample = 0
        ema = 0.0
        hasSpeed = false
    }

    /** Bytes per second; 0 when nothing was observed recently. */
    @Synchronized
    fun speed(): Long {
        if (!hasSpeed) return 0
        val now = clock()
        if (lastDataAt >= 0 && now - lastDataAt > windowMs * 2) return 0
        return ema.toLong()
    }

    /** Remaining time in milliseconds, or null while the estimate is not reliable yet. */
    @Synchronized
    fun etaMillis(remainingBytes: Long): Long? {
        if (remainingBytes <= 0) return 0
        if (activeMs < minEtaMs) return null
        val v = speed()
        if (v <= 0) return null
        return remainingBytes * 1000L / v
    }
}
