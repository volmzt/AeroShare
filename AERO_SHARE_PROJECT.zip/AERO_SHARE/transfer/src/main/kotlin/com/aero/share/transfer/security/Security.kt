package com.aero.share.transfer.security

import java.io.ByteArrayInputStream
import java.security.GeneralSecurityException
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.SecureRandom
import java.security.Signature
import java.security.cert.Certificate
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.spec.ECGenParameterSpec
import java.security.spec.PKCS8EncodedKeySpec

/**
 * Long-term device identity: an EC P-256 key pair and a self-signed X.509 certificate.
 * The certificate is built with plain DER encoding and signed with the platform's SHA256withECDSA
 * (no custom cryptography). [deviceId] is derived from the certificate, so a device ID can never be
 * claimed by another key.
 */
class DeviceIdentity private constructor(
    val privateKey: PrivateKey,
    val certificate: X509Certificate,
) {
    /** Lower-case hex SHA-256 of the DER certificate (64 chars). */
    val fingerprint: String = Fingerprints.sha256Hex(certificate.encoded)

    /** First 32 hex characters of [fingerprint]. */
    val deviceId: String get() = deviceIdFromFingerprint(fingerprint)

    fun privateKeyPkcs8(): ByteArray = privateKey.encoded
    fun certificateDer(): ByteArray = certificate.encoded

    companion object {
        fun generate(commonName: String = "AERO SHARE"): DeviceIdentity {
            val gen = KeyPairGenerator.getInstance("EC")
            gen.initialize(ECGenParameterSpec("secp256r1"), SecureRandom())
            val pair = gen.generateKeyPair()
            val der = X509Builder.selfSigned(pair, commonName)
            val cert = parseCertificate(der)
            cert.verify(pair.public)
            return DeviceIdentity(pair.private, cert)
        }

        /** Throws IllegalArgumentException when the stored material is invalid or the certificate is expired. */
        fun restore(privateKeyPkcs8: ByteArray, certificateDer: ByteArray): DeviceIdentity {
            try {
                val key = KeyFactory.getInstance("EC").generatePrivate(PKCS8EncodedKeySpec(privateKeyPkcs8))
                val cert = parseCertificate(certificateDer)
                cert.checkValidity()
                cert.verify(cert.publicKey)
                // The private key must belong to the certificate.
                val probe = "aero-identity-check".toByteArray()
                val sig = Signature.getInstance("SHA256withECDSA")
                sig.initSign(key)
                sig.update(probe)
                val signature = sig.sign()
                val ver = Signature.getInstance("SHA256withECDSA")
                ver.initVerify(cert.publicKey)
                ver.update(probe)
                require(ver.verify(signature)) { "private key does not match certificate" }
                return DeviceIdentity(key, cert)
            } catch (e: IllegalArgumentException) {
                throw e
            } catch (e: GeneralSecurityException) {
                throw IllegalArgumentException("invalid identity material", e)
            } catch (e: RuntimeException) {
                throw IllegalArgumentException("invalid identity material", e)
            }
        }

        fun deviceIdFromFingerprint(fingerprint: String): String = fingerprint.take(32)

        private fun parseCertificate(der: ByteArray): X509Certificate =
            CertificateFactory.getInstance("X.509").generateCertificate(ByteArrayInputStream(der)) as X509Certificate
    }
}

object Fingerprints {
    private val HEX = "0123456789abcdef".toCharArray()

    fun sha256Hex(bytes: ByteArray): String = toHex(MessageDigest.getInstance("SHA-256").digest(bytes))
    fun ofCertificate(cert: Certificate): String = sha256Hex(cert.encoded)

    /** true for 64 lower-case hex characters. */
    fun isValid(fingerprint: String): Boolean = fingerprint.length == 64 && fingerprint.all { it in '0'..'9' || it in 'a'..'f' }
    fun constantTimeEquals(a: String, b: String): Boolean =
        MessageDigest.isEqual(a.toByteArray(Charsets.UTF_8), b.toByteArray(Charsets.UTF_8))

    fun toHex(bytes: ByteArray): String {
        val out = CharArray(bytes.size * 2)
        for (i in bytes.indices) {
            val v = bytes[i].toInt() and 0xFF
            out[i * 2] = HEX[v ushr 4]
            out[i * 2 + 1] = HEX[v and 0x0F]
        }
        return String(out)
    }

    /** Parses lower/upper-case hex; null if malformed. */
    fun fromHex(hex: String): ByteArray? {
        if (hex.length % 2 != 0) return null
        val out = ByteArray(hex.length / 2)
        for (i in out.indices) {
            val hi = Character.digit(hex[i * 2], 16)
            val lo = Character.digit(hex[i * 2 + 1], 16)
            if (hi < 0 || lo < 0) return null
            out[i] = ((hi shl 4) or lo).toByte()
        }
        return out
    }
}

/** Short authentication string shown on both devices on first contact (like Bluetooth numeric comparison). */
object Sas {
    /** Symmetric in its arguments. Returns e.g. "482 913" (6 digits). */
    fun code(fingerprintA: String, fingerprintB: String): String {
        val sorted = listOf(fingerprintA, fingerprintB).sorted()
        val digest = MessageDigest.getInstance("SHA-256").digest(sorted.joinToString(":").toByteArray(Charsets.UTF_8))
        var v = 0L
        for (i in 0 until 4) v = (v shl 8) or (digest[i].toLong() and 0xFF)
        val n = v % 1_000_000L
        return String.format(java.util.Locale.ROOT, "%03d %03d", n / 1000, n % 1000)
    }
}
