package com.aero.share.transfer.engine

import com.aero.share.transfer.model.TransferControl
import com.aero.share.transfer.model.TransferFailure
import com.aero.share.transfer.proto.CancelMsg
import com.aero.share.transfer.proto.CancelReason
import com.aero.share.transfer.proto.FrameReader
import com.aero.share.transfer.proto.FrameType
import com.aero.share.transfer.proto.FrameWriter
import com.aero.share.transfer.proto.ProtocolException
import java.io.BufferedInputStream
import java.io.IOException
import java.io.InputStream
import java.net.Socket
import java.net.SocketTimeoutException
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference
import javax.net.ssl.SSLHandshakeException
import javax.net.ssl.SSLKeyException
import javax.net.ssl.SSLPeerUnverifiedException
import javax.net.ssl.SSLSocket
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

/** Final outcome of a transfer carried as an exception through the session code. [failure] == null means "cancelled by the user". */
internal class TransferAbort(
    val failure: TransferFailure?,
    val detail: String?,
    val resumable: Boolean,
) : Exception(detail, null, false, false) {
    val cancelled: Boolean get() = failure == null

    companion object {
        fun cancelled() = TransferAbort(null, null, false)
    }
}

internal fun nowMs(): Long = System.currentTimeMillis()
internal fun monoMs(): Long = System.nanoTime() / 1_000_000L

/**
 * How long a side that cancelled keeps the connection open after its CANCEL notice. The peer closes the connection as soon as it
 * has read the notice, which ends the wait; the limit only matters when the peer does not answer.
 */
internal const val CANCEL_LINGER_MS = 1_000L

/** Hard stop after a cancel: the sockets are closed even when the notice could not be written (stalled peer). */
private const val CANCEL_HARD_STOP_MS = 1_500L

internal val ZERO_SHA = ByteArray(32)

/** Reads up to [len] bytes, looping over short reads; returns the number of bytes read (less than [len] only at end of stream). */
internal fun readFully(input: InputStream, buf: ByteArray, off: Int, len: Int): Int {
    var total = 0
    while (total < len) {
        val n = input.read(buf, off + total, len - total)
        if (n < 0) break
        total += n
    }
    return total
}

internal fun isNoSpace(t: Throwable): Boolean {
    var c: Throwable? = t
    var depth = 0
    while (c != null && depth < 5) {
        val m = c.message.orEmpty()
        if (m.contains("ENOSPC") || m.contains("No space left", ignoreCase = true) || m.contains("not enough space", ignoreCase = true)) return true
        c = c.cause
        depth++
    }
    return false
}

internal fun shortDetail(t: Throwable): String =
    (t.javaClass.simpleName + (t.message?.let { ": $it" } ?: "")).take(160)

internal fun closeQuietly(c: AutoCloseable?) {
    try {
        c?.close()
    } catch (e: Exception) {
        // ignore
    }
}

/**
 * Shared machinery of one TLS connection of a transfer (sender or receiver side): serialized frame writing,
 * keep-alive PINGs, pause handling, first-cause-wins abort that unblocks blocking socket calls by closing the sockets,
 * and mapping of low-level exceptions to [TransferFailure].
 */
internal abstract class ConnectionSession(
    protected val config: EngineConfig,
    protected val logger: EngineLogger,
    protected val control: TransferControl,
) {
    protected val helpers = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    protected val writeLock = Mutex()
    private val abortRef = AtomicReference<TransferAbort?>(null)
    protected val aborted = MutableStateFlow(false)
    protected val peerPaused = MutableStateFlow(false)

    @Volatile protected var plainSocket: Socket? = null

    @Volatile protected var sslSocket: SSLSocket? = null

    @Volatile private var readerRef: FrameReader? = null

    @Volatile private var writerRef: FrameWriter? = null

    @Volatile private var lastWriteMs = monoMs()
    private var sentPause = false

    /** True once the offer was accepted: from then on a lost connection is resumable. */
    @Volatile protected var inTransferPhase = false

    protected val reader: FrameReader get() = readerRef ?: error("not connected")
    protected val writer: FrameWriter get() = writerRef ?: error("not connected")
    protected val isConnected: Boolean get() = writerRef != null
    protected val abortCause: TransferAbort? get() = abortRef.get()

    protected fun attach(plain: Socket?, ssl: SSLSocket) {
        plainSocket = plain
        sslSocket = ssl
        readerRef = FrameReader(BufferedInputStream(ssl.inputStream, 64 * 1024))
        writerRef = FrameWriter(ssl.outputStream)
    }

    protected open fun onAbort(a: TransferAbort) {}

    /** First call wins: records the outcome, wakes up waiters and closes the sockets so blocked I/O fails immediately. */
    protected fun abort(a: TransferAbort) {
        if (abortRef.compareAndSet(null, a)) {
            aborted.value = true
            onAbort(a)
            closeSocket()
        }
    }

    protected fun abortFrom(t: Throwable) = abort(classify(t))

    protected fun closeSocket() {
        closeQuietly(plainSocket)
        closeQuietly(sslSocket)
    }

    /** Orderly TLS shutdown (close_notify) used after a successful transfer. */
    protected fun closeGracefully() {
        closeQuietly(sslSocket)
        closeQuietly(plainSocket)
    }

    protected suspend fun sendFrame(type: Int, payload: ByteArray = ByteArray(0)) {
        writeLock.withLock {
            writer.write(type, payload)
            lastWriteMs = monoMs()
        }
    }

    /** DATA frame whose payload sits at buf[5 until 5 + len] (5 bytes of room for the header). */
    protected suspend fun sendData(buf: ByteArray, len: Int) {
        writeLock.withLock {
            writer.writeWithRoom(FrameType.FILE_DATA, buf, len)
            lastWriteMs = monoMs()
        }
    }

    /** Best effort write that never waits for a busy writer for longer than [waitMs]. */
    protected suspend fun sendFrameQuickly(type: Int, payload: ByteArray, waitMs: Long = 500) {
        if (!isConnected) return
        val got = withTimeoutOrNull(waitMs) {
            writeLock.lock()
            true
        }
        if (got != true) return
        try {
            writer.write(type, payload)
            lastWriteMs = monoMs()
        } catch (e: IOException) {
            // the connection is going away anyway
        } finally {
            writeLock.unlock()
        }
    }

    private val progressDirty = AtomicBoolean(false)

    /** Marks progress as changed; [progressLoop] publishes it (at most every progressIntervalMs, with a trailing update). */
    protected fun markProgress() {
        progressDirty.set(true)
    }

    protected abstract fun flushProgress()

    protected suspend fun progressLoop() {
        while (true) {
            delay(config.progressIntervalMs.coerceAtLeast(10))
            if (progressDirty.getAndSet(false)) flushProgress()
        }
    }

    /** Sends PING whenever nothing was written for the ping interval. Runs until cancelled; I/O errors abort the session. */
    protected suspend fun pingLoop() {
        try {
            while (true) {
                val wait = config.pingIntervalMs - (monoMs() - lastWriteMs)
                if (wait > 0) {
                    delay(wait)
                    continue
                }
                if (writeLock.tryLock()) {
                    try {
                        writer.write(FrameType.PING)
                        lastWriteMs = monoMs()
                    } finally {
                        writeLock.unlock()
                    }
                } else {
                    delay(config.pingIntervalMs) // a frame is being written right now, which counts as activity
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (t: Throwable) {
            abortFrom(t)
        }
    }

    private val cancelNotice = Mutex()
    private var cancelNoticeSent = false // guarded by cancelNotice

    /**
     * Tells the peer that the user cancelled. Sent at most once and best effort. The cancel watcher and the main flow of a
     * session both call this, and whichever comes second waits for the first, so the notice is on the wire before anybody
     * closes the connection: the peer then learns about the cancel instead of seeing a connection that simply vanished.
     */
    protected suspend fun sendCancelNotice() {
        withContext(NonCancellable) {
            cancelNotice.withLock {
                if (!cancelNoticeSent) {
                    cancelNoticeSent = true
                    if (isConnected) sendFrameQuickly(FrameType.CANCEL, CancelMsg(CancelReason.USER).encode())
                }
            }
        }
    }

    /**
     * Keeps the connection open after a CANCEL notice until the peer has closed it or [CANCEL_LINGER_MS] has passed. Closing at
     * once would let a peer that is still writing run into a broken pipe before it has read the notice, and it would then report
     * a lost connection instead of the cancel. The end of the peer's connection is seen by the reader, which records it as an abort.
     */
    protected suspend fun waitForPeerToClose() {
        withContext(NonCancellable) {
            withTimeoutOrNull(CANCEL_LINGER_MS) { aborted.first { it } }
        }
    }

    /** Waits for the user's cancel, tells the peer (best effort), gives it a moment to answer and tears the connection down. */
    protected suspend fun cancelWatcher() {
        control.awaitCancelled()
        if (isConnected) {
            helpers.launch {
                delay(CANCEL_HARD_STOP_MS)
                abort(TransferAbort.cancelled()) // hard stop if the courtesy CANCEL frame cannot be written in time
            }
            sendCancelNotice()
            waitForPeerToClose()
        }
        abort(TransferAbort.cancelled())
    }

    protected fun checkLive() {
        abortRef.get()?.let { throw it }
        if (control.isCancelled) throw TransferAbort.cancelled()
    }

    protected abstract fun onPauseState(paused: Boolean, byPeer: Boolean)

    /**
     * Called between chunks/frames. Blocks while this side (or, if [holdForPeer], the peer) has paused, announces
     * PAUSE/RESUME to the peer, and gives up (resumable) after [EngineConfig.pauseTimeoutMs].
     */
    protected suspend fun gate(holdForPeer: Boolean) {
        checkLive()
        if (!control.isPaused && !(holdForPeer && peerPaused.value)) return
        if (control.isPaused && !sentPause) {
            sendFrame(FrameType.PAUSE)
            sentPause = true
        }
        onPauseState(true, !control.isPaused)
        val resumed = withTimeoutOrNull(config.pauseTimeoutMs) {
            combine(control.pausedFlow, peerPaused, aborted) { local, peer, ab ->
                ab || !(local || (holdForPeer && peer))
            }.first { it }
            true
        }
        if (resumed == null) throw TransferAbort(TransferFailure.INTERRUPTED, "paused for too long", true)
        checkLive()
        if (sentPause) {
            sendFrame(FrameType.RESUME)
            sentPause = false
        }
        onPauseState(false, false)
    }

    /** Maps whatever went wrong to the outcome shown to the user. The user's cancel and explicit aborts take precedence. */
    protected fun classify(t: Throwable): TransferAbort {
        if (control.isCancelled) return TransferAbort.cancelled()
        if (t is TransferAbort) return t
        abortRef.get()?.let { return it }
        return when (t) {
            is ProtocolException -> TransferAbort(TransferFailure.PROTOCOL, t.message, false)
            is SSLHandshakeException, is SSLPeerUnverifiedException, is SSLKeyException ->
                TransferAbort(TransferFailure.AUTH_FAILED, shortDetail(t), false)
            is SocketTimeoutException -> TransferAbort(TransferFailure.TIMEOUT, "no data received in time", inTransferPhase)
            is IOException ->
                if (isNoSpace(t)) TransferAbort(TransferFailure.NO_SPACE, shortDetail(t), inTransferPhase)
                else TransferAbort(TransferFailure.INTERRUPTED, shortDetail(t), inTransferPhase)
            else -> TransferAbort(TransferFailure.INTERNAL, shortDetail(t), false)
        }
    }
}
