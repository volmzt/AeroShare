package com.aero.share.transfer.security

import java.io.ByteArrayOutputStream
import java.math.BigInteger
import java.time.Instant
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter

/** Minimal DER (ASN.1) encoder, just enough to build an X.509 v3 certificate. */
internal object Der {
    const val TAG_BOOLEAN = 0x01
    const val TAG_INTEGER = 0x02
    const val TAG_BIT_STRING = 0x03
    const val TAG_OCTET_STRING = 0x04
    const val TAG_OID = 0x06
    const val TAG_UTF8 = 0x0C
    const val TAG_UTC_TIME = 0x17
    const val TAG_GENERALIZED_TIME = 0x18
    const val TAG_SEQUENCE = 0x30
    const val TAG_SET = 0x31

    private val utcFormat = DateTimeFormatter.ofPattern("yyMMddHHmmss'Z'").withZone(ZoneOffset.UTC)
    private val genFormat = DateTimeFormatter.ofPattern("yyyyMMddHHmmss'Z'").withZone(ZoneOffset.UTC)

    fun length(n: Int): ByteArray {
        require(n >= 0)
        if (n < 0x80) return byteArrayOf(n.toByte())
        val bytes = ArrayList<Byte>()
        var v = n
        while (v > 0) {
            bytes.add(0, (v and 0xFF).toByte())
            v = v ushr 8
        }
        return byteArrayOf((0x80 or bytes.size).toByte()) + bytes.toByteArray()
    }

    fun tlv(tag: Int, content: ByteArray): ByteArray {
        val out = ByteArrayOutputStream(content.size + 6)
        out.write(tag)
        out.write(length(content.size))
        out.write(content)
        return out.toByteArray()
    }

    fun concat(vararg parts: ByteArray): ByteArray {
        val out = ByteArrayOutputStream()
        parts.forEach { out.write(it) }
        return out.toByteArray()
    }

    fun sequence(vararg parts: ByteArray): ByteArray = tlv(TAG_SEQUENCE, concat(*parts))
    fun set(vararg parts: ByteArray): ByteArray = tlv(TAG_SET, concat(*parts))
    fun integer(v: BigInteger): ByteArray = tlv(TAG_INTEGER, v.toByteArray())
    fun integer(v: Long): ByteArray = integer(BigInteger.valueOf(v))
    fun boolean(v: Boolean): ByteArray = tlv(TAG_BOOLEAN, byteArrayOf(if (v) 0xFF.toByte() else 0))
    fun octetString(content: ByteArray): ByteArray = tlv(TAG_OCTET_STRING, content)
    fun utf8(s: String): ByteArray = tlv(TAG_UTF8, s.toByteArray(Charsets.UTF_8))

    /** BIT STRING with [unusedBits] unused trailing bits. */
    fun bitString(content: ByteArray, unusedBits: Int = 0): ByteArray =
        tlv(TAG_BIT_STRING, byteArrayOf(unusedBits.toByte()) + content)

    /** Context-specific constructed explicit tag [n]. */
    fun explicit(n: Int, content: ByteArray): ByteArray = tlv(0xA0 or n, content)

    fun oid(dotted: String): ByteArray {
        val parts = dotted.split('.').map { it.toLong() }
        require(parts.size >= 2)
        val out = ByteArrayOutputStream()
        writeBase128(out, parts[0] * 40 + parts[1])
        for (i in 2 until parts.size) writeBase128(out, parts[i])
        return tlv(TAG_OID, out.toByteArray())
    }

    private fun writeBase128(out: ByteArrayOutputStream, value: Long) {
        var v = value
        val tmp = ArrayList<Int>()
        tmp.add((v and 0x7F).toInt())
        v = v ushr 7
        while (v > 0) {
            tmp.add(0, ((v and 0x7F) or 0x80).toInt())
            v = v ushr 7
        }
        tmp.forEach { out.write(it) }
    }

    /** UTCTime for years 1950..2049, GeneralizedTime otherwise (RFC 5280 4.1.2.5). */
    fun time(millis: Long): ByteArray {
        val instant = Instant.ofEpochMilli(millis)
        val year = instant.atZone(ZoneOffset.UTC).year
        return if (year in 1950..2049) {
            tlv(TAG_UTC_TIME, utcFormat.format(instant).toByteArray(Charsets.US_ASCII))
        } else {
            tlv(TAG_GENERALIZED_TIME, genFormat.format(instant).toByteArray(Charsets.US_ASCII))
        }
    }
}
