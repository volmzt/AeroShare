package com.aero.share.transfer.storage

import com.aero.share.transfer.model.ConflictPolicy
import com.aero.share.transfer.model.FileCategory
import com.aero.share.transfer.model.ManifestEntry
import com.aero.share.transfer.model.SavedFile
import com.aero.share.transfer.security.Fingerprints
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.io.InputStream
import java.io.RandomAccessFile
import java.net.URLDecoder
import java.net.URLEncoder
import java.security.MessageDigest

/**
 * Shared staging logic. Incoming bytes are always written to private staging files below [partsDir]
 * (namespaced per sending peer, matched by relative path + size + last-modified, so a new transfer of the same
 * files resumes). After the engine verified SHA-256, [publish] moves/copies the file to its final destination.
 * The completed-files ledger lives in the same namespace. Subclasses only implement the destination.
 */
abstract class StagedIncomingStorage(
    protected val partsDir: File,
    protected val conflictPolicy: ConflictPolicy,
) : IncomingStorage {
    /** Free bytes of the final destination, or null if unknown. */
    protected abstract fun destinationFreeBytes(): Long?

    /** Moves/copies a verified staging file to its final place applying [conflictPolicy]; must not throw for conflicts. */
    protected abstract fun publish(entry: ManifestEntry, staged: File, sha256: String): SavedFile

    /** min(staging free space, [destinationFreeBytes]); null if both unknown. */
    override fun availableBytes(): Long? {
        partsDir.mkdirs()
        val staging = partsDir.usableSpace
        val dest = destinationFreeBytes()
        return if (dest == null) staging else minOf(staging, dest)
    }

    override fun open(transferId: String, title: String?, peerKey: String): IncomingTransferStore {
        val ns = File(partsDir, sha256Hex(peerKey).take(16))
        if (!ns.isDirectory && !ns.mkdirs() && !ns.isDirectory) throw IOException("cannot create staging directory")
        return StagedStore(ns)
    }

    private inner class StagedStore(private val ns: File) : IncomingTransferStore {
        private val touched = LinkedHashSet<String>()

        private fun key(e: ManifestEntry) = sha256Hex("${e.relativePath}|${e.size}|${e.lastModified}").take(24)
        private fun partFile(k: String) = File(ns, "$k.part")
        private fun ledgerFile(k: String) = File(ns, "$k.done")

        override fun partial(entry: ManifestEntry): PartialInfo? {
            val k = key(entry)
            val f = partFile(k)
            if (!f.isFile) return null
            val len = f.length()
            if (len > entry.size) {
                f.delete()
                return null
            }
            if (len == 0L) return null
            touched.add(k)
            return PartialInfo(len)
        }

        override fun completed(entry: ManifestEntry): SavedFile? {
            val k = key(entry)
            val f = ledgerFile(k)
            if (!f.isFile) return null
            val saved = readLedger(f)
            if (saved == null) f.delete() else touched.add(k)
            return saved
        }

        override fun createPart(entry: ManifestEntry): PartWriter {
            val k = key(entry)
            touched.add(k)
            ledgerFile(k).delete()
            val raf = RandomAccessFile(partFile(k), "rw")
            raf.setLength(0)
            return StagedPartWriter(partFile(k), raf)
        }

        override fun reopenPart(entry: ManifestEntry): PartWriter? {
            val k = key(entry)
            val f = partFile(k)
            if (!f.isFile) return null
            touched.add(k)
            val raf = RandomAccessFile(f, "rw")
            raf.seek(raf.length())
            return StagedPartWriter(f, raf)
        }

        override fun commit(entry: ManifestEntry, part: PartWriter, sha256: String): SavedFile {
            val k = key(entry)
            val writer = part as? StagedPartWriter ?: throw IllegalArgumentException("foreign part writer")
            writer.sync()
            writer.close()
            val saved = publish(entry, writer.file, sha256)
            writeLedger(ledgerFile(k), saved)
            writer.file.delete()
            touched.add(k)
            return saved
        }

        override fun discard(entry: ManifestEntry) {
            val k = key(entry)
            partFile(k).delete()
            ledgerFile(k).delete()
            touched.remove(k)
        }

        override fun discardAll() = deleteTouched()

        override fun finish() = deleteTouched()

        private fun deleteTouched() {
            for (k in touched) {
                partFile(k).delete()
                ledgerFile(k).delete()
            }
            touched.clear()
            ns.delete() // only succeeds when empty
        }
    }

    private class StagedPartWriter(val file: File, private val raf: RandomAccessFile) : PartWriter {
        override val size: Long get() = raf.length()

        override fun write(buf: ByteArray, off: Int, len: Int) {
            raf.write(buf, off, len)
        }

        override fun openPrefix(length: Long): InputStream {
            require(length in 0..raf.length()) { "prefix beyond end of part" }
            return LimitedStream(FileInputStream(file), length)
        }

        override fun truncate(length: Long) {
            require(length in 0..raf.length()) { "cannot extend a part" }
            raf.setLength(length)
            raf.seek(length)
        }

        override fun sync() {
            raf.fd.sync()
        }

        override fun close() {
            raf.close()
        }
    }

    private class LimitedStream(private val inner: InputStream, private var remaining: Long) : InputStream() {
        override fun read(): Int {
            if (remaining <= 0) return -1
            val b = inner.read()
            if (b >= 0) remaining--
            return b
        }

        override fun read(b: ByteArray, off: Int, len: Int): Int {
            if (remaining <= 0) return -1
            val n = inner.read(b, off, minOf(len.toLong(), remaining).toInt())
            if (n > 0) remaining -= n
            return n
        }

        override fun close() = inner.close()
    }

    companion object {
        /** Deletes staging data (parts and ledgers) not modified since [cutoffMillis]. Returns the number of deleted files. */
        fun purgeOlderThan(partsDir: File, cutoffMillis: Long): Int {
            var deleted = 0
            val namespaces = partsDir.listFiles() ?: return 0
            for (ns in namespaces) {
                if (!ns.isDirectory) continue
                for (f in ns.listFiles() ?: emptyArray()) {
                    if (f.isFile && f.lastModified() < cutoffMillis && f.delete()) deleted++
                }
                ns.delete() // only succeeds when empty
            }
            return deleted
        }

        internal fun sha256Hex(s: String): String =
            Fingerprints.toHex(MessageDigest.getInstance("SHA-256").digest(s.toByteArray(Charsets.UTF_8)))

        private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")
        private fun dec(s: String): String = URLDecoder.decode(s, "UTF-8")

        private fun writeLedger(target: File, f: SavedFile) {
            val tmp = File(target.parentFile, target.name + ".tmp")
            val text = buildString {
                append("uri=").append(enc(f.uri)).append('\n')
                append("name=").append(enc(f.displayName)).append('\n')
                append("path=").append(enc(f.relativePath)).append('\n')
                append("size=").append(f.size).append('\n')
                append("mime=").append(enc(f.mimeType ?: "")).append('\n')
                append("cat=").append(f.category.code).append('\n')
                append("sha=").append(f.sha256).append('\n')
            }
            tmp.writeText(text, Charsets.UTF_8)
            if (!tmp.renameTo(target)) {
                target.delete()
                if (!tmp.renameTo(target)) {
                    tmp.delete()
                    throw IOException("cannot write ledger")
                }
            }
        }

        private fun readLedger(f: File): SavedFile? {
            return try {
                val map = HashMap<String, String>()
                f.readLines(Charsets.UTF_8).forEach { line ->
                    val i = line.indexOf('=')
                    if (i > 0) map[line.substring(0, i)] = line.substring(i + 1)
                }
                val mime = dec(map["mime"] ?: "").ifEmpty { null }
                SavedFile(
                    uri = dec(map["uri"] ?: return null),
                    displayName = dec(map["name"] ?: return null),
                    relativePath = dec(map["path"] ?: return null),
                    size = map["size"]?.toLongOrNull() ?: return null,
                    mimeType = mime,
                    category = FileCategory.fromCode(map["cat"]?.toIntOrNull() ?: return null),
                    sha256 = (map["sha"] ?: return null).also { if (!Fingerprints.isValid(it)) return null },
                )
            } catch (e: Exception) {
                null
            }
        }
    }
}
