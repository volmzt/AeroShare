package com.aero.share.transfer.engine

import com.aero.share.transfer.proto.ProtocolException
import java.util.zip.DataFormatException
import java.util.zip.Deflater
import java.util.zip.Inflater

/** Decides which files are worth deflating: formats that are already compressed are sent as they are. */
object CompressionPolicy {
    private val alreadyCompressed = setOf(
        "jpg", "jpeg", "png", "webp", "heic", "heif", "avif", "gif", "jxl",
        "mp3", "m4a", "aac", "ogg", "opus", "flac", "wma", "amr",
        "mp4", "m4v", "mkv", "webm", "mov", "3gp", "avi", "wmv", "mpg", "mpeg",
        "zip", "rar", "7z", "gz", "tgz", "xz", "bz2", "zst", "lz4", "br", "jar", "cab",
        "apk", "apks", "xapk", "apkm", "aeroapks",
        "pdf", "docx", "xlsx", "pptx", "odt", "ods", "odp", "epub",
    )

    fun shouldCompress(relativePath: String, bytesToSend: Long): Boolean {
        if (bytesToSend < 512) return false
        val name = relativePath.substringAfterLast('/')
        val ext = name.substringAfterLast('.', "").lowercase()
        return ext !in alreadyCompressed
    }
}

/** Per-file deflate stream; every chunk is a self-contained SYNC_FLUSH block. */
internal class ChunkDeflater(maxChunk: Int) {
    private val deflater = Deflater(Deflater.BEST_SPEED)

    /** Output with 5 bytes of header room in front (see FrameWriter.writeWithRoom); payload starts at offset 5. */
    var buffer = ByteArray(5 + maxChunk + maxChunk / 8 + 1024)
        private set

    /** Compresses [len] bytes of [src] and returns the compressed payload length (payload at buffer[5..5+result)). */
    fun compress(src: ByteArray, off: Int, len: Int): Int {
        deflater.setInput(src, off, len)
        var n = 0
        while (true) {
            val c = deflater.deflate(buffer, 5 + n, buffer.size - 5 - n, Deflater.SYNC_FLUSH)
            n += c
            if (5 + n < buffer.size) break
            buffer = buffer.copyOf(buffer.size * 2)
        }
        return n
    }

    fun close() {
        deflater.end()
    }
}

/** Inflates frames of a deflate stream with a hard cap on the output of one frame (no decompression bombs). */
internal class ChunkInflater(private val maxOutputPerFrame: Int) {
    private val inflater = Inflater()
    private val out = ByteArray(64 * 1024)

    fun inflate(src: ByteArray, off: Int, len: Int, sink: (ByteArray, Int) -> Unit) {
        inflater.setInput(src, off, len)
        var total = 0L
        try {
            while (true) {
                val n = inflater.inflate(out)
                if (n > 0) {
                    total += n
                    if (total > maxOutputPerFrame) throw ProtocolException("inflated frame too large")
                    sink(out, n)
                    continue
                }
                if (inflater.needsDictionary()) throw ProtocolException("unexpected dictionary")
                break // needs more input (the frame is fully consumed) or the stream ended
            }
        } catch (e: DataFormatException) {
            throw ProtocolException("corrupt compressed data")
        }
    }

    fun close() {
        inflater.end()
    }
}
