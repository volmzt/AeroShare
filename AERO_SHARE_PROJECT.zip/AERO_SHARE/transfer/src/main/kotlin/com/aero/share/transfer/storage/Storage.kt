package com.aero.share.transfer.storage

import com.aero.share.transfer.model.ManifestEntry
import com.aero.share.transfer.model.SavedFile
import java.io.Closeable
import java.io.InputStream

/** Where received files go. The engine never touches paths directly; all I/O is behind these interfaces. */
interface IncomingStorage {
    /** Free bytes at the destination (and staging area), or null when unknown. */
    fun availableBytes(): Long?

    /** Human readable destination, e.g. "Downloads/AERO SHARE". */
    fun destinationLabel(): String

    /**
     * Storage session for one transfer. [peerKey] identifies the sending device (e.g. its certificate fingerprint).
     * Partial data is namespaced by [peerKey] and matched by relative path + size + last-modified, so a NEW transfer
     * of the same files from the same device resumes where the previous attempt stopped (even after a restart).
     */
    fun open(transferId: String, title: String?, peerKey: String): IncomingTransferStore
}

class PartialInfo(val bytes: Long)

interface IncomingTransferStore {
    /** Existing partial data for [entry] from an earlier attempt by the same peer, or null. */
    fun partial(entry: ManifestEntry): PartialInfo?

    /**
     * A file of the same peer that an earlier attempt already received completely and published
     * (same relative path, size and last-modified), or null. Lets a retry skip finished files.
     */
    fun completed(entry: ManifestEntry): SavedFile?

    /** Creates a new (or truncates the existing) part for [entry]. */
    fun createPart(entry: ManifestEntry): PartWriter

    /** Reopens the existing part for appending, or null if it is gone. */
    fun reopenPart(entry: ManifestEntry): PartWriter?

    /**
     * Publishes a verified part (its SHA-256 is [sha256], lower-case hex) to its final location applying the conflict
     * policy, records it in the completed ledger and closes the writer.
     */
    fun commit(entry: ManifestEntry, part: PartWriter, sha256: String): SavedFile

    /** Removes the part of one entry. */
    fun discard(entry: ManifestEntry)

    /** Removes all partial data of this transfer (user cancelled or transfer failed unrecoverably). */
    fun discardAll()

    /** Every file is done: drops resume bookkeeping (completed ledger, leftover parts) for this transfer. */
    fun finish()
}

interface PartWriter : Closeable {
    /** Bytes currently stored. */
    val size: Long
    fun write(buf: ByteArray, off: Int, len: Int)

    /** Stream over the first [length] bytes (used to re-verify a prefix when resuming). Caller closes it. */
    fun openPrefix(length: Long): InputStream

    fun truncate(length: Long)
    fun sync()
}
