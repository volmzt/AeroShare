package com.aero.share.transfer.engine

import com.aero.share.transfer.model.Capabilities
import com.aero.share.transfer.model.CompressionMode
import com.aero.share.transfer.model.DeviceKind
import com.aero.share.transfer.model.FileCategory
import com.aero.share.transfer.model.LocalPeer
import com.aero.share.transfer.model.PeerInfo
import com.aero.share.transfer.model.TransferControl
import com.aero.share.transfer.model.TransferFailure
import com.aero.share.transfer.model.TransferSnapshot
import com.aero.share.transfer.model.TransferState
import com.aero.share.transfer.model.TransferTracker
import com.aero.share.transfer.path.PathSafety
import com.aero.share.transfer.proto.CancelMsg
import com.aero.share.transfer.proto.CancelReason
import com.aero.share.transfer.proto.Encoding
import com.aero.share.transfer.proto.FileBegin
import com.aero.share.transfer.proto.FileEnd
import com.aero.share.transfer.proto.FileResult
import com.aero.share.transfer.proto.FileStatus
import com.aero.share.transfer.proto.FrameType
import com.aero.share.transfer.proto.Hello
import com.aero.share.transfer.proto.HelloAck
import com.aero.share.transfer.proto.HelloStatus
import com.aero.share.transfer.proto.OfferEntriesCodec
import com.aero.share.transfer.proto.OfferHeader
import com.aero.share.transfer.proto.OfferReply
import com.aero.share.transfer.proto.Protocol
import com.aero.share.transfer.proto.ProtocolException
import com.aero.share.transfer.proto.ReplyCode
import com.aero.share.transfer.proto.ReplyEntry
import com.aero.share.transfer.proto.TransferDone
import com.aero.share.transfer.proto.WireEntry
import com.aero.share.transfer.proto.WireLimits
import com.aero.share.transfer.security.DeviceIdentity
import com.aero.share.transfer.security.Sas
import com.aero.share.transfer.security.TlsContexts
import java.io.IOException
import java.io.InputStream
import java.net.ConnectException
import java.net.Socket
import java.net.SocketTimeoutException
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import javax.net.ssl.SSLException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Sends one transfer. Calling [send] again with the same transferId after an interruption resumes:
 * the receiver reports verified offsets per file and only the missing bytes are sent.
 * All progress and the final state are published through [TransferTracker].
 */
class TransferSender(
    private val identity: DeviceIdentity,
    private val local: LocalPeer,
    private val config: EngineConfig = EngineConfig(),
    private val logger: EngineLogger = EngineLogger.NONE,
) {
    suspend fun send(
        target: SendTarget,
        request: SendRequest,
        control: TransferControl,
        tracker: TransferTracker,
    ): TransferResult = withContext(Dispatchers.IO) {
        SenderSession(identity, local, config, logger, target, request, control, tracker).run()
    }
}

private const val FINALIZE_TIMEOUT_MS = 30L * 60 * 1000

private class SenderSession(
    private val identity: DeviceIdentity,
    private val local: LocalPeer,
    config: EngineConfig,
    logger: EngineLogger,
    private val target: SendTarget,
    private val request: SendRequest,
    control: TransferControl,
    private val tracker: TransferTracker,
) : ConnectionSession(config, logger, control) {
    private val files = request.files
    private var totalBytes = 0L
    private val startedAt = nowMs()
    private val meter = ProgressMeter()
    private val chunk = config.chunkSize.coerceIn(16 * 1024, 1024 * 1024)

    @Volatile private var doneBytes = 0L

    @Volatile private var currentBytes = 0L

    @Volatile private var currentName: String? = null

    @Volatile private var currentIndex = 0

    @Volatile private var currentSize = 0L

    @Volatile private var anyCompressed = false

    @Volatile private var finished = false
    private val completedFiles = AtomicInteger(0)
    private var peerCaps = 0
    private val connected = CompletableDeferred<Socket>()
    private val offerReply = CompletableDeferred<OfferReply>()
    private val transferDone = CompletableDeferred<TransferDone>()
    private val results = ConcurrentHashMap<Long, FileResult>()

    override fun onAbort(a: TransferAbort) {
        connected.completeExceptionally(a)
        offerReply.completeExceptionally(a)
        transferDone.completeExceptionally(a)
    }

    // ---------------------------------------------------------------- state / progress

    private fun progressFields(s: TransferSnapshot, now: Long): TransferSnapshot {
        val transferred = doneBytes + currentBytes
        val paused = s.state == TransferState.PAUSED
        return s.copy(
            completedFiles = completedFiles.get(),
            currentFileName = currentName,
            currentFileIndex = currentIndex,
            currentFileSize = currentSize,
            currentFileBytes = currentBytes,
            transferredBytes = transferred,
            bytesPerSecond = if (paused) 0 else meter.speed(),
            etaMillis = if (paused) null else meter.etaMillis(totalBytes - transferred),
            elapsedMillis = now - startedAt,
            compressed = anyCompressed,
        )
    }

    private fun publish(force: Boolean = false) {
        if (force) flushProgress() else markProgress()
    }

    override fun flushProgress() {
        val now = nowMs()
        tracker.update { progressFields(it, now) }
    }

    private fun setState(state: TransferState, change: (TransferSnapshot) -> TransferSnapshot = { it }) {
        val now = nowMs()
        tracker.update { s -> progressFields(change(s).copy(state = state), now) }
    }

    private fun finish(state: TransferState, change: (TransferSnapshot) -> TransferSnapshot) {
        val now = nowMs()
        tracker.update { s ->
            progressFields(change(s).copy(state = state), now).copy(finishedAt = now, bytesPerSecond = 0, etaMillis = null)
        }
    }

    override fun onPauseState(paused: Boolean, byPeer: Boolean) {
        meter.idle()
        if (paused) setState(TransferState.PAUSED) { it.copy(pausedByPeer = byPeer) }
        else setState(TransferState.TRANSFERRING) { it.copy(pausedByPeer = false) }
    }

    // ---------------------------------------------------------------- main flow

    suspend fun run(): TransferResult {
        try {
            prepare()
            helpers.launch { cancelWatcher() }
            connect()
            helpers.launch { readerLoop() }
            helpers.launch { pingLoop() }
            helpers.launch { progressLoop() }
            sendOffer()
            val reply = awaitAcceptance()
            transfer(reply)
            return complete()
        } catch (t: Throwable) {
            val result = failWith(t)
            if (control.isCancelled) {
                // The user cancelled: the notice must reach the receiver before the connection goes away, and the
                // connection stays open until the receiver has read it (the reader sees it close).
                sendCancelNotice()
                waitForPeerToClose()
            }
            return result
        } finally {
            finished = true
            helpers.cancel()
            closeSocket()
        }
    }

    private fun prepare() {
        if (files.isEmpty()) throw TransferAbort(TransferFailure.INTERNAL, "nothing to send", false)
        val ids = HashSet<Int>()
        var total = 0L
        for (f in files) {
            if (f.size < 0 || !ids.add(f.id) || PathSafety.sanitizeRelativePath(f.relativePath) == null) {
                throw TransferAbort(TransferFailure.INTERNAL, "invalid file list", false)
            }
            total = try {
                Math.addExact(total, f.size)
            } catch (e: ArithmeticException) {
                throw TransferAbort(TransferFailure.INTERNAL, "total size overflow", false)
            }
        }
        totalBytes = total
        tracker.update {
            it.copy(
                state = TransferState.PREPARING,
                transport = target.transport,
                title = request.title ?: it.title,
                totalFiles = files.size,
                completedFiles = 0,
                currentFileName = null,
                currentFileIndex = 0,
                currentFileSize = 0,
                currentFileBytes = 0,
                totalBytes = total,
                transferredBytes = 0,
                bytesPerSecond = 0,
                elapsedMillis = 0,
                etaMillis = null,
                failure = null,
                failureDetail = null,
                resumable = false,
                compressed = false,
                startedAt = startedAt,
                finishedAt = null,
                savedFiles = emptyList(),
                verificationCode = null,
                pausedByPeer = false,
            )
        }
    }

    private suspend fun connect() {
        setState(TransferState.CONNECTING)
        helpers.launch {
            try {
                val s = target.connector.connect(target.host, target.port, config.connectTimeoutMs)
                plainSocket = s
                if (abortCause != null) closeQuietly(s)
                connected.complete(s)
            } catch (e: Throwable) {
                connected.completeExceptionally(e)
            }
        }
        val plain = try {
            connected.await()
        } catch (e: TransferAbort) {
            throw e
        } catch (e: CancellationException) {
            throw e
        } catch (e: SocketTimeoutException) {
            throw TransferAbort(TransferFailure.NETWORK_BLOCKED, "connection attempt timed out", false)
        } catch (e: ConnectException) {
            throw TransferAbort(TransferFailure.UNREACHABLE, "connection refused or unreachable", false)
        } catch (e: Exception) {
            throw TransferAbort(TransferFailure.UNREACHABLE, shortDetail(e), false)
        }
        checkLive()
        val ssl = try {
            TlsContexts.wrapClient(TlsContexts.client(identity, target.expectedFingerprint), plain, target.host, target.port)
        } catch (e: IllegalArgumentException) {
            throw TransferAbort(TransferFailure.INTERNAL, "invalid pinned fingerprint", false)
        }
        sslSocket = ssl
        ssl.soTimeout = config.connectTimeoutMs
        try {
            ssl.startHandshake()
        } catch (e: SocketTimeoutException) {
            throw TransferAbort(TransferFailure.TIMEOUT, "secure handshake timed out", false)
        } catch (e: SSLException) {
            throw TransferAbort(TransferFailure.AUTH_FAILED, "secure connection could not be established", false)
        }
        val peerFp = TlsContexts.peerFingerprint(ssl)
        attach(plain, ssl)
        writer.write(
            FrameType.HELLO,
            Hello(Protocol.VERSION, identity.deviceId, local.name, local.kind.code, local.appVersion, local.capabilities, target.pairToken).encode(),
        )
        val frame = reader.read()
        if (frame.type != FrameType.HELLO_ACK) throw ProtocolException("expected HELLO_ACK")
        val ack = HelloAck.decode(frame)
        when (ack.status) {
            HelloStatus.OK -> Unit
            HelloStatus.BUSY -> throw TransferAbort(TransferFailure.BUSY, null, false)
            HelloStatus.BLOCKED -> throw TransferAbort(TransferFailure.BLOCKED, null, false)
            HelloStatus.UNSUPPORTED_VERSION -> throw TransferAbort(TransferFailure.UNSUPPORTED_VERSION, null, false)
            HelloStatus.AUTH_FAILED -> throw TransferAbort(TransferFailure.AUTH_FAILED, "the other device rejected the pairing code", false)
            else -> throw ProtocolException("unknown HELLO_ACK status")
        }
        if (ack.version != Protocol.VERSION) throw TransferAbort(TransferFailure.UNSUPPORTED_VERSION, null, false)
        if (ack.deviceId != peerFp.take(32)) throw TransferAbort(TransferFailure.AUTH_FAILED, "device identity does not match its certificate", false)
        peerCaps = ack.capabilities
        val peer = PeerInfo(ack.deviceId, ack.name, DeviceKind.fromCode(ack.kind), ack.appVersion, peerFp, ack.capabilities)
        val code = if (ack.showsCode) Sas.code(identity.fingerprint, peerFp) else null
        tracker.update { it.copy(peer = peer, peerName = ack.name, verificationCode = code) }
        ssl.soTimeout = config.idleTimeoutMs
    }

    private suspend fun readerLoop() {
        try {
            while (true) {
                val f = reader.read()
                when (f.type) {
                    FrameType.PING -> Unit
                    FrameType.PAUSE -> peerPaused.value = true
                    FrameType.RESUME -> peerPaused.value = false
                    FrameType.CANCEL -> {
                        abort(TransferAbort(TransferFailure.PEER_CANCELLED, null, false))
                        return
                    }
                    FrameType.OFFER_REPLY -> offerReply.complete(OfferReply.decode(f, files.size))
                    FrameType.FILE_RESULT -> onFileResult(FileResult.decode(f))
                    FrameType.TRANSFER_DONE -> {
                        transferDone.complete(TransferDone.decode(f))
                        return
                    }
                    else -> throw ProtocolException("unexpected frame")
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (t: Throwable) {
            if (!finished) abortFrom(t)
        }
    }

    private fun onFileResult(r: FileResult) {
        results[r.id] = r
        when (r.status) {
            FileStatus.OK -> completedFiles.incrementAndGet()
            FileStatus.HASH_MISMATCH -> abort(TransferAbort(TransferFailure.INTEGRITY, "the receiver found a checksum mismatch", false))
            FileStatus.IO_ERROR -> abort(TransferAbort(TransferFailure.STORAGE, "the receiver could not store the file", true))
            FileStatus.NO_SPACE -> abort(TransferAbort(TransferFailure.NO_SPACE, "the receiver is out of space", true))
            else -> abort(TransferAbort(TransferFailure.PROTOCOL, "the receiver rejected the file", false))
        }
    }

    private suspend fun sendOffer() {
        val entries = files.map {
            WireEntry(it.id.toLong(), it.relativePath, it.size, it.lastModified, it.category.code, it.mimeType)
        }
        val folder = files.any { it.relativePath.contains('/') }
        val compression = compressionEnabled()
        sendFrame(
            FrameType.OFFER,
            OfferHeader(
                request.transferId, files.size.toLong(), totalBytes, folder, compression,
                FileCategory.maskOf(files.map { it.category }), request.title,
            ).encode(),
        )
        for (batch in OfferEntriesCodec.encodeBatches(entries)) sendFrame(FrameType.OFFER_ENTRIES, batch)
        sendFrame(FrameType.OFFER_END)
        setState(TransferState.AWAITING_ACCEPTANCE)
    }

    private fun compressionEnabled(): Boolean =
        request.compression == CompressionMode.SMART && (peerCaps and Capabilities.COMPRESSION) != 0 &&
            (local.capabilities and Capabilities.COMPRESSION) != 0

    private suspend fun awaitAcceptance(): OfferReply {
        val reply = withTimeoutOrNull(config.acceptTimeoutMs + 20_000) { offerReply.await() }
            ?: throw TransferAbort(TransferFailure.TIMEOUT, "no answer from the other device", false)
        when (reply.decision) {
            ReplyCode.ACCEPT -> Unit
            ReplyCode.DECLINE_USER -> throw TransferAbort(TransferFailure.DECLINED, null, false)
            ReplyCode.BUSY -> throw TransferAbort(TransferFailure.BUSY, null, false)
            ReplyCode.NO_SPACE -> throw TransferAbort(TransferFailure.NO_SPACE, "not enough free space on the other device", false)
            ReplyCode.NOT_ALLOWED -> throw TransferAbort(TransferFailure.BLOCKED, "the other device does not allow this transfer", false)
            ReplyCode.TIMEOUT -> throw TransferAbort(TransferFailure.TIMEOUT, "the other device did not answer in time", false)
            ReplyCode.STORAGE_ERROR -> throw TransferAbort(TransferFailure.STORAGE, "the other device cannot store files right now", false)
            else -> throw ProtocolException("unknown decision")
        }
        return reply
    }

    private suspend fun transfer(reply: OfferReply) {
        inTransferPhase = true
        val byId = HashMap<Long, ReplyEntry>()
        for (r in reply.entries) {
            val f = files.firstOrNull { it.id.toLong() == r.id } ?: throw ProtocolException("reply references an unknown file")
            if (r.offset > f.size) throw ProtocolException("offset beyond the end of the file")
            byId[r.id] = r
        }
        setState(TransferState.TRANSFERRING)
        for ((index, file) in files.withIndex()) sendFile(index, file, byId[file.id.toLong()])

        setState(TransferState.VERIFYING)
        sendFrame(FrameType.TRANSFER_END)
        val done = withTimeoutOrNull(FINALIZE_TIMEOUT_MS) { transferDone.await() }
            ?: throw TransferAbort(TransferFailure.TIMEOUT, "the receiver did not finish in time", true)
        val allOk = results.size == files.size && results.values.all { it.status == FileStatus.OK }
        if (!allOk || done.status != TransferDone.OK || done.okCount != files.size.toLong() || done.failedCount != 0L) {
            throw TransferAbort(TransferFailure.PROTOCOL, "the receiver reported an incomplete transfer", false)
        }
    }

    private fun complete(): TransferResult {
        finished = true
        finish(TransferState.COMPLETED) {
            it.copy(
                completedFiles = files.size,
                failure = null,
                failureDetail = null,
                resumable = false,
                pausedByPeer = false,
            )
        }
        closeGracefully()
        return TransferResult.Completed(files.size, totalBytes)
    }

    private fun failWith(t: Throwable): TransferResult {
        if (t is CancellationException && abortCause == null && !control.isCancelled) {
            // The caller's coroutine was cancelled (e.g. the service stopped): leave a resumable state behind.
            finish(TransferState.INTERRUPTED) {
                it.copy(failure = TransferFailure.INTERRUPTED, failureDetail = null, resumable = inTransferPhase)
            }
            throw t
        }
        val a = classify(t)
        logger.log("send failed: " + (a.failure?.name ?: "CANCELLED") + (if (a.failure == TransferFailure.INTERNAL) " (" + shortDetail(t) + ")" else ""))
        if (a.cancelled) {
            finish(TransferState.CANCELLED) { it.copy(failure = null, failureDetail = null, resumable = false) }
            return TransferResult.Cancelled
        }
        val failure = a.failure ?: TransferFailure.INTERNAL
        val state = if (a.resumable) TransferState.INTERRUPTED else TransferState.FAILED
        finish(state) { it.copy(failure = failure, failureDetail = a.detail, resumable = a.resumable) }
        return TransferResult.Failed(failure, a.detail, a.resumable)
    }

    // ---------------------------------------------------------------- per-file sending

    private suspend fun sourceProblem(failure: TransferFailure, detail: String, reason: Int): Nothing {
        sendFrameQuickly(FrameType.CANCEL, CancelMsg(reason).encode())
        waitForPeerToClose() // the receiver closes as soon as it has read the notice
        throw TransferAbort(failure, detail, false)
    }

    private suspend fun checkSource(file: SendableFile) {
        val v = try {
            file.currentVersion()
        } catch (e: Exception) {
            null
        } ?: sourceProblem(TransferFailure.SOURCE_UNREADABLE, "a file is no longer available", CancelReason.SOURCE_CHANGED)
        if (v.size != file.size || v.lastModified != file.lastModified) {
            sourceProblem(TransferFailure.SOURCE_CHANGED, "a file changed while sending", CancelReason.SOURCE_CHANGED)
        }
    }

    private suspend fun openSource(file: SendableFile, offset: Long): InputStream = try {
        file.open(offset)
    } catch (e: SecurityException) {
        sourceProblem(TransferFailure.PERMISSION, "no permission to read a file", CancelReason.ERROR)
    } catch (e: IOException) {
        sourceProblem(TransferFailure.SOURCE_UNREADABLE, "a file could not be opened", CancelReason.ERROR)
    }

    /** Reads from the source; I/O errors here are source problems, never connection problems. */
    private suspend fun readSource(input: InputStream, buf: ByteArray, off: Int, len: Int): Int = try {
        readFully(input, buf, off, len)
    } catch (e: IOException) {
        sourceProblem(TransferFailure.SOURCE_UNREADABLE, "a file could not be read", CancelReason.ERROR)
    }

    /** Hashes the first `resume.offset` bytes of [input]; true when they equal the receiver's prefix digest. */
    private suspend fun verifyPrefix(input: InputStream, md: MessageDigest, resume: ReplyEntry): Boolean {
        val big = resume.offset >= 8L * 1024 * 1024
        if (big) setState(TransferState.VERIFYING)
        val scratch = ByteArray(64 * 1024)
        var left = resume.offset
        while (left > 0) {
            checkLive()
            val n = readSource(input, scratch, 0, minOf(scratch.size.toLong(), left).toInt())
            if (n <= 0) return false
            md.update(scratch, 0, n)
            left -= n
        }
        if (big) setState(TransferState.TRANSFERRING)
        val snapshot = try {
            (md.clone() as MessageDigest).digest()
        } catch (e: CloneNotSupportedException) {
            return false
        }
        return MessageDigest.isEqual(snapshot, resume.prefixSha256)
    }

    private suspend fun sendFile(index: Int, file: SendableFile, resume: ReplyEntry?) {
        gate(holdForPeer = true)
        currentName = file.relativePath.substringAfterLast('/')
        currentIndex = index + 1
        currentSize = file.size
        currentBytes = 0
        publish(force = true)
        checkSource(file)

        val md = MessageDigest.getInstance("SHA-256")
        var input = openSource(file, 0)
        var deflater: ChunkDeflater? = null
        try {
            var start = 0L
            if (resume != null && !resume.prefixSha256.contentEquals(ZERO_SHA)) {
                if (verifyPrefix(input, md, resume)) {
                    start = resume.offset
                } else {
                    closeQuietly(input)
                    md.reset()
                    input = openSource(file, 0)
                }
            }
            val useDeflate = compressionEnabled() && CompressionPolicy.shouldCompress(file.relativePath, file.size - start)
            if (useDeflate) {
                deflater = ChunkDeflater(chunk)
                anyCompressed = true
            }
            sendFrame(
                FrameType.FILE_BEGIN,
                FileBegin(file.id.toLong(), start, if (useDeflate) Encoding.DEFLATE else Encoding.RAW).encode(),
            )
            currentBytes = start
            meter.idle()
            publish(force = true)

            var sent = start
            val buf = ByteArray(WireLimits.HEADER_SIZE + chunk)
            while (sent < file.size) {
                gate(holdForPeer = true)
                val want = minOf(chunk.toLong(), file.size - sent).toInt()
                val n = readSource(input, buf, WireLimits.HEADER_SIZE, want)
                if (n < want) {
                    sourceProblem(TransferFailure.SOURCE_CHANGED, "a file became shorter while sending", CancelReason.SOURCE_CHANGED)
                }
                md.update(buf, WireLimits.HEADER_SIZE, n)
                if (deflater != null) {
                    val len = deflater.compress(buf, WireLimits.HEADER_SIZE, n)
                    sendData(deflater.buffer, len)
                } else {
                    sendData(buf, n)
                }
                sent += n
                currentBytes = sent
                meter.add(n.toLong())
                publish()
            }
            if (readSource(input, buf, WireLimits.HEADER_SIZE, 1) > 0) {
                sourceProblem(TransferFailure.SOURCE_CHANGED, "a file grew while sending", CancelReason.SOURCE_CHANGED)
            }
            checkSource(file)
            sendFrame(FrameType.FILE_END, FileEnd(file.id.toLong(), md.digest()).encode())
            doneBytes += file.size
            currentBytes = 0
            publish(force = true)
        } finally {
            deflater?.close()
            closeQuietly(input)
        }
    }
}
