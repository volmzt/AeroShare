package com.aero.share.transfer.storage

import com.aero.share.transfer.model.ConflictPolicy
import com.aero.share.transfer.model.FileCategory
import com.aero.share.transfer.model.ManifestEntry
import com.aero.share.transfer.model.SavedFile
import com.aero.share.transfer.path.PathSafety
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException

/**
 * Plain java.io.File backed storage: committed files go to [destinationDir].
 * Used for legacy external storage (API 26-28), app-private fallback and unit tests.
 */
class FileIncomingStorage(
    private val destinationDir: File,
    partsDir: File,
    conflictPolicy: ConflictPolicy,
    private val label: String = destinationDir.path,
    private val uriOf: (File) -> String = { it.toURI().toString() },
) : StagedIncomingStorage(partsDir, conflictPolicy) {
    override fun destinationLabel(): String = label

    override fun destinationFreeBytes(): Long? {
        destinationDir.mkdirs()
        return destinationDir.usableSpace
    }

    override fun publish(entry: ManifestEntry, staged: File, sha256: String): SavedFile {
        val rel = PathSafety.sanitizeRelativePath(entry.relativePath)
            ?: throw IOException("unsafe path")
        val root = destinationDir.canonicalFile
        val wanted = File(root, rel)
        val parent = wanted.parentFile ?: root
        parent.mkdirs()
        if (!parent.canonicalPath.startsWith(root.path)) throw IOException("path escapes destination")

        var target = wanted
        val exists = wanted.exists()
        if (exists) {
            when (conflictPolicy) {
                ConflictPolicy.SKIP -> {
                    staged.delete()
                    return saved(entry, target, rel, sha256)
                }
                ConflictPolicy.KEEP_BOTH -> {
                    val unique = PathSafety.uniqueName(wanted.name) { File(parent, it).exists() }
                    target = File(parent, unique)
                }
                ConflictPolicy.REPLACE -> Unit
            }
        }
        moveInto(staged, target)
        val usedRel = if (target.name == wanted.name) rel else rel.substringBeforeLast('/', "").let {
            if (it.isEmpty()) target.name else it + "/" + target.name
        }
        return saved(entry, target, usedRel, sha256)
    }

    private fun saved(entry: ManifestEntry, file: File, rel: String, sha256: String) = SavedFile(
        uri = uriOf(file),
        displayName = file.name,
        relativePath = rel,
        size = entry.size,
        mimeType = entry.mimeType,
        category = FileCategory.classify(file.name, entry.mimeType),
        sha256 = sha256,
    )

    /** Rename when possible, otherwise copy into a temp file next to the target and rename atomically. */
    private fun moveInto(src: File, dst: File) {
        if (src.renameTo(dst)) return
        val tmp = File(dst.parentFile, "." + dst.name + ".aero-tmp")
        try {
            FileInputStream(src).use { input ->
                FileOutputStream(tmp).use { out ->
                    val buf = ByteArray(256 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                    }
                    out.fd.sync()
                }
            }
            if (!tmp.renameTo(dst)) {
                dst.delete()
                if (!tmp.renameTo(dst)) throw IOException("cannot publish file")
            }
            src.delete()
        } finally {
            if (tmp.exists()) tmp.delete()
        }
    }
}
