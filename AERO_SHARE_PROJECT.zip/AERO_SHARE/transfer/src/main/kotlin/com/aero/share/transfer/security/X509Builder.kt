package com.aero.share.transfer.security

import java.math.BigInteger
import java.security.KeyPair
import java.security.SecureRandom
import java.security.Signature

/** Builds a self-signed X.509 v3 certificate (EC key, SHA256withECDSA) with hand-written DER. */
internal object X509Builder {
    private const val OID_ECDSA_SHA256 = "1.2.840.10045.4.3.2"
    private const val OID_COMMON_NAME = "2.5.4.3"
    private const val OID_BASIC_CONSTRAINTS = "2.5.29.19"
    private const val OID_KEY_USAGE = "2.5.29.15"
    private const val DAY_MS = 24L * 3600 * 1000
    private const val YEAR_MS = 365L * DAY_MS

    fun selfSigned(
        keyPair: KeyPair,
        commonName: String,
        nowMillis: Long = System.currentTimeMillis(),
        random: SecureRandom = SecureRandom(),
    ): ByteArray {
        val cn = commonName.ifEmpty { "AERO SHARE" }
        val algId = Der.sequence(Der.oid(OID_ECDSA_SHA256))
        val name = Der.sequence(Der.set(Der.sequence(Der.oid(OID_COMMON_NAME), Der.utf8(cn))))
        val serial = BigInteger(63, random).add(BigInteger.ONE)
        val notBefore = nowMillis - DAY_MS
        val notAfter = nowMillis + 20 * YEAR_MS + 5 * DAY_MS
        val validity = Der.sequence(Der.time(notBefore), Der.time(notAfter))
        val basicConstraints = Der.sequence(
            Der.oid(OID_BASIC_CONSTRAINTS),
            Der.boolean(true),
            Der.octetString(Der.sequence()),
        )
        // digitalSignature = bit 0 -> 0x80 with 7 unused bits.
        val keyUsage = Der.sequence(
            Der.oid(OID_KEY_USAGE),
            Der.boolean(true),
            Der.octetString(Der.bitString(byteArrayOf(0x80.toByte()), unusedBits = 7)),
        )
        val tbs = Der.sequence(
            Der.explicit(0, Der.integer(2)),
            Der.integer(serial),
            algId,
            name,
            validity,
            name,
            keyPair.public.encoded,
            Der.explicit(3, Der.sequence(basicConstraints, keyUsage)),
        )
        val signer = Signature.getInstance("SHA256withECDSA")
        signer.initSign(keyPair.private)
        signer.update(tbs)
        val signature = signer.sign()
        return Der.sequence(tbs, algId, Der.bitString(signature))
    }
}
