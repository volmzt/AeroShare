package com.aero.share.transfer.queue

import com.aero.share.transfer.engine.TransferResult
import com.aero.share.transfer.model.TransferControl
import com.aero.share.transfer.model.TransferFailure
import com.aero.share.transfer.model.TransferSnapshot
import com.aero.share.transfer.model.TransferState
import com.aero.share.transfer.model.TransferStateMachine
import com.aero.share.transfer.model.TransferTracker
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class QueuedJob<P : Any>(
    val id: String,
    val payload: P,
    val tracker: TransferTracker,
    val control: TransferControl,
)

/**
 * Runs queued transfers strictly one at a time, in order. The [runner] performs the actual transfer and
 * updates the job's tracker; the queue handles ordering, pausing/cancelling jobs that have not started,
 * retry of failed/interrupted jobs and publishing a combined snapshot list.
 *
 * Jobs must be enqueued in state [TransferState.WAITING]. While a job runs, the engine owns its tracker; the
 * queue only reconciles the final state if the runner returned without publishing one.
 */
class TransferQueue<P : Any>(
    private val scope: CoroutineScope,
    private val runner: suspend (QueuedJob<P>) -> TransferResult,
    private val clock: () -> Long = System::currentTimeMillis,
) {
    private val lock = Any()
    private val jobsFlow = MutableStateFlow<List<QueuedJob<P>>>(emptyList())
    private val snapshotsFlow = MutableStateFlow<List<TransferSnapshot>>(emptyList())
    private val watchers = HashMap<String, Job>()
    private var worker: Job? = null
    private var runningId: String? = null

    /** All jobs in queue order (finished ones stay until removed), newest last. */
    val jobs: StateFlow<List<QueuedJob<P>>> = jobsFlow.asStateFlow()

    val snapshots: StateFlow<List<TransferSnapshot>> = snapshotsFlow.asStateFlow()

    fun enqueue(job: QueuedJob<P>) {
        synchronized(lock) {
            if (jobsFlow.value.any { it.id == job.id }) return
            job.tracker.update { if (it.state == TransferState.WAITING || it.state.isTerminal) it else it.copy(state = TransferState.WAITING) }
            jobsFlow.value = jobsFlow.value + job
            watchers[job.id] = scope.launch(start = CoroutineStart.UNDISPATCHED) {
                job.tracker.state.collect { refreshSnapshots() }
            }
            refreshSnapshots()
            ensureWorkerLocked()
        }
    }

    fun get(id: String): QueuedJob<P>? = jobsFlow.value.firstOrNull { it.id == id }

    /** Cancels a waiting job immediately or asks the running job to cancel. */
    fun cancel(id: String) {
        synchronized(lock) {
            val job = findLocked(id) ?: return
            if (job.tracker.current.state.isTerminal) return
            job.control.cancel()
            if (runningId != id) {
                transitionLocked(job, TransferState.CANCELLED) { it.copy(finishedAt = clock(), bytesPerSecond = 0, etaMillis = null) }
            }
            refreshSnapshots()
        }
    }

    fun pause(id: String) {
        synchronized(lock) {
            val job = findLocked(id) ?: return
            val state = job.tracker.current.state
            if (state.isTerminal || state == TransferState.INTERRUPTED || state == TransferState.FAILED) return
            job.control.pause()
            if (runningId != id && state == TransferState.WAITING) {
                transitionLocked(job, TransferState.PAUSED) { it }
            }
            refreshSnapshots()
        }
    }

    fun resume(id: String) {
        synchronized(lock) {
            val job = findLocked(id) ?: return
            val state = job.tracker.current.state
            when {
                state.isTerminal -> return
                runningId == id -> job.control.resume()
                state == TransferState.PAUSED -> {
                    job.control.resume()
                    transitionLocked(job, TransferState.WAITING) { it }
                }
                state == TransferState.INTERRUPTED -> requeueLocked(job)
                else -> Unit
            }
            refreshSnapshots()
            ensureWorkerLocked()
        }
    }

    /** Re-queues a FAILED or INTERRUPTED job (same transferId, so resume applies). */
    fun retry(id: String) {
        synchronized(lock) {
            val job = findLocked(id) ?: return
            val state = job.tracker.current.state
            if (state != TransferState.FAILED && state != TransferState.INTERRUPTED) return
            if (!requeueLocked(job)) return
            refreshSnapshots()
            ensureWorkerLocked()
        }
    }

    /** Removes a finished job (completed, failed, cancelled or interrupted) from the list. Running jobs are kept. */
    fun remove(id: String) {
        synchronized(lock) {
            val job = findLocked(id) ?: return
            val state = job.tracker.current.state
            val finished = state.isTerminal || state == TransferState.INTERRUPTED
            if (!finished || runningId == id) return
            watchers.remove(id)?.cancel()
            jobsFlow.value = jobsFlow.value.filter { it.id != id }
            refreshSnapshots()
        }
    }

    // ---- internals (all *Locked functions require [lock]) ----

    private fun findLocked(id: String): QueuedJob<P>? = jobsFlow.value.firstOrNull { it.id == id }

    private fun refreshSnapshots() {
        synchronized(lock) {
            snapshotsFlow.value = jobsFlow.value.map { it.tracker.current }
        }
    }

    /** Applies [to] if the state machine allows it; returns whether the transition happened. */
    private fun transitionLocked(
        job: QueuedJob<P>,
        to: TransferState,
        change: (TransferSnapshot) -> TransferSnapshot,
    ): Boolean {
        var applied = false
        job.tracker.update { s ->
            if (TransferStateMachine.canTransition(s.state, to)) {
                applied = true
                change(s).copy(state = to)
            } else {
                applied = false
                s
            }
        }
        return applied
    }

    /** Moves a FAILED/INTERRUPTED job back to WAITING at the end of the queue. */
    private fun requeueLocked(job: QueuedJob<P>): Boolean {
        if (runningId == job.id) return false
        val ok = transitionLocked(job, TransferState.WAITING) {
            it.copy(
                failure = null,
                failureDetail = null,
                finishedAt = null,
                bytesPerSecond = 0,
                etaMillis = null,
                pausedByPeer = false,
            )
        }
        if (!ok) return false
        job.control.resume()
        jobsFlow.value = jobsFlow.value.filter { it.id != job.id } + job
        return true
    }

    private fun ensureWorkerLocked() {
        if (worker?.isActive == true) return
        if (jobsFlow.value.none { it.tracker.current.state == TransferState.WAITING }) return
        val w = scope.launch(start = CoroutineStart.LAZY) { runLoop() }
        worker = w
        w.start()
    }

    /** Next WAITING job, marked as running; when there is none the worker slot is released (atomically). */
    private fun takeNext(): QueuedJob<P>? = synchronized(lock) {
        val next = jobsFlow.value.firstOrNull { it.tracker.current.state == TransferState.WAITING }
        if (next == null) {
            worker = null
            null
        } else {
            runningId = next.id
            next
        }
    }

    private suspend fun runLoop() {
        while (true) {
            val job = takeNext() ?: return
            try {
                val result: TransferResult = try {
                    runner(job)
                } catch (e: CancellationException) {
                    throw e
                } catch (t: Throwable) {
                    TransferResult.Failed(TransferFailure.INTERNAL, t.javaClass.simpleName, false)
                }
                reconcile(job, result)
            } catch (e: CancellationException) {
                // The queue's scope was cancelled (e.g. the service stopped): the transfer can be resumed later.
                markInterrupted(job)
                throw e
            } finally {
                synchronized(lock) { if (runningId == job.id) runningId = null }
                refreshSnapshots()
            }
        }
    }

    /** The engine publishes final states itself; this only covers a runner that returned without doing so. */
    private fun reconcile(job: QueuedJob<P>, result: TransferResult) {
        val now = clock()
        job.tracker.update { s ->
            if (s.state.isTerminal || s.state == TransferState.INTERRUPTED) {
                s
            } else when (result) {
                is TransferResult.Completed -> s.copy(
                    state = TransferState.COMPLETED,
                    finishedAt = s.finishedAt ?: now,
                    bytesPerSecond = 0,
                    etaMillis = null,
                )
                is TransferResult.Failed -> s.copy(
                    state = if (result.resumable) TransferState.INTERRUPTED else TransferState.FAILED,
                    failure = result.failure,
                    failureDetail = result.detail,
                    resumable = result.resumable,
                    finishedAt = now,
                    bytesPerSecond = 0,
                    etaMillis = null,
                )
                TransferResult.Cancelled -> s.copy(
                    state = TransferState.CANCELLED,
                    finishedAt = now,
                    bytesPerSecond = 0,
                    etaMillis = null,
                )
            }
        }
    }

    private fun markInterrupted(job: QueuedJob<P>) {
        val now = clock()
        job.tracker.update { s ->
            if (s.state.isTerminal || s.state == TransferState.INTERRUPTED) {
                s
            } else {
                s.copy(
                    state = TransferState.INTERRUPTED,
                    failure = TransferFailure.INTERRUPTED,
                    resumable = true,
                    finishedAt = now,
                    bytesPerSecond = 0,
                    etaMillis = null,
                )
            }
        }
    }
}
