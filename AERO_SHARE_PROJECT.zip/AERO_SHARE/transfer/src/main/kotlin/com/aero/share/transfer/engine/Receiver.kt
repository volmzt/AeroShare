package com.aero.share.transfer.engine

import com.aero.share.transfer.model.DeviceKind
import com.aero.share.transfer.model.FileCategory
import com.aero.share.transfer.model.LocalPeer
import com.aero.share.transfer.model.ManifestEntry
import com.aero.share.transfer.model.PeerInfo
import com.aero.share.transfer.model.PeerTrust
import com.aero.share.transfer.model.SavedFile
import com.aero.share.transfer.model.TransferControl
import com.aero.share.transfer.model.TransferDirection
import com.aero.share.transfer.model.TransferFailure
import com.aero.share.transfer.model.TransferSnapshot
import com.aero.share.transfer.model.TransferState
import com.aero.share.transfer.model.TransferTracker
import com.aero.share.transfer.pairing.PairTokenRegistry
import com.aero.share.transfer.path.PathSafety
import com.aero.share.transfer.proto.CancelMsg
import com.aero.share.transfer.proto.CancelReason
import com.aero.share.transfer.proto.Encoding
import com.aero.share.transfer.proto.FileBegin
import com.aero.share.transfer.proto.FileEnd
import com.aero.share.transfer.proto.FileResult
import com.aero.share.transfer.proto.FileStatus
import com.aero.share.transfer.proto.Frame
import com.aero.share.transfer.proto.FrameType
import com.aero.share.transfer.proto.Hello
import com.aero.share.transfer.proto.HelloAck
import com.aero.share.transfer.proto.HelloStatus
import com.aero.share.transfer.proto.OfferEntriesCodec
import com.aero.share.transfer.proto.OfferHeader
import com.aero.share.transfer.proto.OfferReply
import com.aero.share.transfer.proto.Protocol
import com.aero.share.transfer.proto.ProtocolException
import com.aero.share.transfer.proto.ReplyCode
import com.aero.share.transfer.proto.ReplyEntry
import com.aero.share.transfer.proto.TransferDone
import com.aero.share.transfer.proto.WireEntry
import com.aero.share.transfer.security.DeviceIdentity
import com.aero.share.transfer.security.Fingerprints
import com.aero.share.transfer.security.Sas
import com.aero.share.transfer.security.TlsContexts
import com.aero.share.transfer.storage.IncomingStorage
import com.aero.share.transfer.storage.IncomingTransferStore
import com.aero.share.transfer.storage.PartWriter
import java.io.IOException
import java.io.InputStream
import java.net.BindException
import java.net.InetSocketAddress
import java.net.Socket
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import javax.net.ssl.SSLServerSocket
import javax.net.ssl.SSLSocket
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

/** Storage failure raised from inside a non-suspending callback; converted to a FILE_RESULT by the frame handler. */
private class StorageIo(cause: IOException) : Exception(cause)

/** TLS server that accepts transfers. One active incoming transfer at a time; others get BUSY. */
class ReceiverServer(
    private val identity: DeviceIdentity,
    private val local: () -> LocalPeer,
    private val config: () -> EngineConfig,
    private val policy: PeerPolicy,
    private val tokens: PairTokenRegistry,
    private val storageProvider: () -> IncomingStorage,
    private val listener: IncomingListener,
    private val logger: EngineLogger = EngineLogger.NONE,
) {
    private val lock = Any()
    private var serverSocket: SSLServerSocket? = null
    private var scope: CoroutineScope? = null
    private val busy = AtomicBoolean(false)

    @Volatile private var active: Connection? = null
    private val unauthenticated = AtomicInteger(0)
    private val openSockets: MutableSet<Socket> = ConcurrentHashMap.newKeySet()

    val isRunning: Boolean get() = synchronized(lock) { serverSocket?.isClosed == false }
    val port: Int? get() = synchronized(lock) { serverSocket?.takeIf { !it.isClosed }?.localPort }

    /** Binds [preferredPort] (falls back to an ephemeral port when busy) and starts accepting. Returns the bound port. */
    suspend fun start(preferredPort: Int): Int = withContext(Dispatchers.IO) {
        synchronized(lock) {
            val existing = serverSocket
            if (existing != null && !existing.isClosed) return@synchronized existing.localPort
            val ss = TlsContexts.createServerSocket(TlsContexts.server(identity))
            try {
                ss.bind(InetSocketAddress(preferredPort), BACKLOG)
            } catch (e: BindException) {
                ss.bind(InetSocketAddress(0), BACKLOG)
            }
            val sc = CoroutineScope(SupervisorJob() + Dispatchers.IO)
            serverSocket = ss
            scope = sc
            sc.launch { acceptLoop(ss, sc) }
            ss.localPort
        }
    }

    fun stop() {
        val ss: SSLServerSocket?
        val sc: CoroutineScope?
        synchronized(lock) {
            ss = serverSocket
            sc = scope
            serverSocket = null
            scope = null
        }
        closeQuietly(ss)
        for (s in openSockets.toList()) closeQuietly(s)
        sc?.cancel()
    }

    private suspend fun acceptLoop(ss: SSLServerSocket, sc: CoroutineScope) {
        while (!ss.isClosed) {
            val s = try {
                ss.accept() as SSLSocket
            } catch (e: IOException) {
                if (ss.isClosed) break
                delay(50)
                continue
            }
            if (unauthenticated.incrementAndGet() > MAX_UNAUTHENTICATED) {
                unauthenticated.decrementAndGet()
                closeQuietly(s)
                continue
            }
            sc.launch { Connection(s).run() }
        }
    }

    private inner class Connection(private val socket: SSLSocket) :
        ConnectionSession(config(), logger, TransferControl()) {
        private val remote: String = socket.inetAddress?.hostAddress ?: "unknown"
        private var peer: PeerInfo? = null
        private var holdsBusy = false

        @Volatile var peerFingerprint: String? = null
            private set

        /** A new connection from the same device replaces this one (e.g. after a silent network drop). Partial data is kept. */
        fun supersede() {
            abort(TransferAbort(TransferFailure.INTERRUPTED, "replaced by a new connection from the same device", true))
        }
        private var inUnauthenticated = true

        @Volatile private var accepted = false

        @Volatile private var declined = false
        private val meter = ProgressMeter()

        // --- session state (valid once [accepted]) ---
        private lateinit var store: IncomingTransferStore
        private lateinit var tracker: TransferTracker
        private lateinit var completion: CompletableDeferred<TransferResult>
        private var entries: List<ManifestEntry> = emptyList()
        private var totalBytes = 0L
        private var startedAt = 0L
        private var completed: Map<Int, SavedFile> = emptyMap()
        private var reported: Map<Int, ReplyEntry> = emptyMap()
        private var compressionAllowed = false
        @Volatile private var nextIndex = 0
        @Volatile private var cur: FileRecv? = null
        @Volatile private var saved: List<SavedFile> = emptyList()
        @Volatile private var doneBytes = 0L
        @Volatile private var currentBytes = 0L
        @Volatile private var currentName: String? = null
        @Volatile private var anyCompressed = false
        @Volatile private var completedFiles = 0

        private inner class FileRecv(
            val entry: ManifestEntry,
            val startOffset: Long,
            val writer: PartWriter?,
            val md: MessageDigest,
            val skip: Boolean,
            val encoding: Int,
        ) {
            var received = startOffset
            val inflater: ChunkInflater? = if (encoding == Encoding.DEFLATE) ChunkInflater(INFLATE_CAP) else null
        }

        // ------------------------------------------------------------ lifecycle

        suspend fun run() {
            openSockets.add(socket)
            try {
                serve()
            } catch (t: Throwable) {
                handleFailure(t)
                if (control.isCancelled) {
                    // The user cancelled: the notice must reach the sender before the connection goes away, and the
                    // connection stays open (and is read) until the sender has seen it and closed its end.
                    sendCancelNotice()
                    drainAfterCancel()
                }
            } finally {
                cur?.let {
                    closeQuietly(it.writer)
                    it.inflater?.close()
                }
                helpers.cancel()
                closeSocket()
                openSockets.remove(socket)
                if (inUnauthenticated) unauthenticated.decrementAndGet()
                if (holdsBusy) {
                    if (active === this) active = null
                    busy.set(false)
                }
            }
        }

        private fun leaveUnauthenticated() {
            if (inUnauthenticated) {
                inUnauthenticated = false
                unauthenticated.decrementAndGet()
            }
        }

        /** Reads frames until the peer closes (or a short timeout), so our last frame is not lost to a TCP reset. */
        private fun linger() {
            try {
                socket.soTimeout = 1_500
                val deadline = monoMs() + 2_000
                while (monoMs() < deadline) reader.read()
            } catch (e: Exception) {
                // closed by the peer or timed out: exactly what we wait for
            }
        }

        private fun expect(type: Int): Frame {
            while (true) {
                val f = reader.read()
                if (f.type == FrameType.PING) continue
                if (f.type != type) throw ProtocolException("unexpected frame")
                return f
            }
        }

        private suspend fun serve() {
            val cfg = config
            socket.soTimeout = cfg.connectTimeoutMs
            TlsContexts.harden(socket)
            socket.startHandshake()
            val fp = TlsContexts.peerFingerprint(socket)
            peerFingerprint = fp
            attach(null, socket)
            val hello = Hello.decode(expect(FrameType.HELLO))
            val me = local()

            suspend fun reject(status: Int, failure: TransferFailure) {
                listener.onRejected(peer, remote, failure)
                sendFrame(
                    FrameType.HELLO_ACK,
                    HelloAck(Protocol.VERSION, status, me.deviceId, me.name, me.kind.code, me.appVersion, me.capabilities, false, false).encode(),
                )
                linger()
            }

            if (hello.version != Protocol.VERSION) return reject(HelloStatus.UNSUPPORTED_VERSION, TransferFailure.UNSUPPORTED_VERSION)
            if (hello.deviceId != fp.take(32)) return reject(HelloStatus.AUTH_FAILED, TransferFailure.AUTH_FAILED)
            val p = PeerInfo(hello.deviceId, hello.name, DeviceKind.fromCode(hello.kind), hello.appVersion, fp, hello.capabilities)
            peer = p
            val trust = try {
                policy.trustOf(p)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                PeerTrust.UNKNOWN
            }
            if (trust == PeerTrust.BLOCKED) return reject(HelloStatus.BLOCKED, TransferFailure.BLOCKED)
            if (!busy.compareAndSet(false, true)) {
                // A retry from the same device may arrive before the old (possibly dead) connection has timed out.
                var tookOver = false
                val old = active
                if (old != null && old !== this && old.peerFingerprint == fp) {
                    old.supersede()
                    val deadline = monoMs() + 3_000
                    while (monoMs() < deadline) {
                        if (busy.compareAndSet(false, true)) {
                            tookOver = true
                            break
                        }
                        delay(20)
                    }
                }
                if (!tookOver) return reject(HelloStatus.BUSY, TransferFailure.BUSY)
            }
            holdsBusy = true
            active = this
            var viaQr = false
            if (hello.token != null) {
                viaQr = tokens.consume(hello.token)
                if (!viaQr) return reject(HelloStatus.AUTH_FAILED, TransferFailure.AUTH_FAILED)
            }
            val showsCode = trust == PeerTrust.UNKNOWN && !viaQr
            sendFrame(
                FrameType.HELLO_ACK,
                HelloAck(Protocol.VERSION, HelloStatus.OK, me.deviceId, me.name, me.kind.code, me.appVersion, me.capabilities, viaQr, showsCode).encode(),
            )
            leaveUnauthenticated()
            val verification = if (showsCode) Sas.code(identity.fingerprint, fp) else null
            helpers.launch { pingLoop() }
            socket.soTimeout = cfg.idleTimeoutMs

            // ---- offer
            val header = OfferHeader.decode(expect(FrameType.OFFER))
            val wire = ArrayList<WireEntry>()
            if (header.fileCount < 1 || header.fileCount > cfg.maxManifestEntries) return rejectOffer(ReplyCode.NOT_ALLOWED, TransferFailure.PROTOCOL)
            while (true) {
                val f = reader.read()
                when (f.type) {
                    FrameType.PING -> Unit
                    FrameType.OFFER_ENTRIES -> {
                        wire.addAll(OfferEntriesCodec.decode(f))
                        if (wire.size > header.fileCount) throw ProtocolException("more entries than announced")
                    }
                    FrameType.OFFER_END -> break
                    else -> throw ProtocolException("unexpected frame in offer")
                }
            }
            if (wire.size.toLong() != header.fileCount) throw ProtocolException("entry count mismatch")
            val manifest = validate(header, wire) ?: return rejectOffer(ReplyCode.NOT_ALLOWED, TransferFailure.PROTOCOL)

            // ---- storage, resume information and free space
            val storage = storageProvider()
            val opened = try {
                storage.open(header.transferId, header.title, fp)
            } catch (e: IOException) {
                return rejectOffer(ReplyCode.STORAGE_ERROR, TransferFailure.STORAGE)
            }
            store = opened
            val ledger = HashMap<Int, SavedFile>()
            val partial = HashMap<Int, Long>()
            var resumeBytes = 0L
            for (e in manifest) {
                val done = store.completed(e)
                if (done != null && Fingerprints.fromHex(done.sha256) != null) {
                    ledger[e.id] = done
                    resumeBytes += e.size
                    continue
                }
                val part = store.partial(e)
                if (part != null && part.bytes in 1..e.size) {
                    partial[e.id] = part.bytes
                    resumeBytes += part.bytes
                }
            }
            val free = storage.availableBytes()
            if (free != null && header.totalBytes - resumeBytes > free) return rejectOffer(ReplyCode.NO_SPACE, TransferFailure.NO_SPACE)

            entries = manifest
            totalBytes = header.totalBytes
            completed = ledger
            compressionAllowed = header.compressionRequested && (me.capabilities and com.aero.share.transfer.model.Capabilities.COMPRESSION) != 0
            val offer = IncomingOffer(
                transferId = header.transferId,
                peer = p,
                trust = trust,
                authenticatedByQr = viaQr,
                verificationCode = verification,
                remoteAddress = remote,
                title = header.title,
                fileCount = manifest.size,
                totalBytes = header.totalBytes,
                categories = manifest.map { it.category }.toSet(),
                entries = manifest,
                isResume = resumeBytes > 0,
                resumeBytes = resumeBytes,
                destinationLabel = storage.destinationLabel(),
                freeBytes = free,
            )
            helpers.launch { decideAndReply(offer, partial) }
            dispatch()
        }

        private suspend fun rejectOffer(code: Int, failure: TransferFailure) {
            listener.onRejected(peer, remote, failure)
            sendFrame(FrameType.OFFER_REPLY, OfferReply(code, emptyList()).encode())
            linger()
        }

        private fun validate(header: OfferHeader, wire: List<WireEntry>): List<ManifestEntry>? {
            val ids = HashSet<Long>()
            val usedPaths = HashSet<String>()
            var total = 0L
            val out = ArrayList<ManifestEntry>(wire.size)
            for (w in wire) {
                if (w.id < 0 || w.id > Int.MAX_VALUE || !ids.add(w.id) || w.size < 0) return null
                var path = PathSafety.sanitizeRelativePath(w.path) ?: return null
                if (!usedPaths.add(path)) {
                    // two different names became the same after sanitizing ("a:b.txt" and "a_b.txt"): keep both files
                    val dir = path.substringBeforeLast('/', "")
                    val prefix = if (dir.isEmpty()) "" else "$dir/"
                    path = prefix + PathSafety.uniqueName(path.substringAfterLast('/')) { usedPaths.contains(prefix + it) }
                    usedPaths.add(path)
                }
                total = try {
                    Math.addExact(total, w.size)
                } catch (e: ArithmeticException) {
                    return null
                }
                out.add(ManifestEntry(w.id.toInt(), path, w.size, w.lastModified, FileCategory.fromCode(w.category), w.mimeType))
            }
            return if (total == header.totalBytes) out else null
        }

        // ------------------------------------------------------------ decision

        private suspend fun decideAndReply(offer: IncomingOffer, partial: Map<Int, Long>) {
            val decision: OfferDecision = try {
                withTimeoutOrNull(config.acceptTimeoutMs) { listener.onOffer(offer) } ?: OfferDecision.Decline(DeclineReason.TIMEOUT)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                OfferDecision.Decline(DeclineReason.USER)
            }
            try {
                when (decision) {
                    is OfferDecision.Decline -> {
                        declined = true
                        val code = when (decision.reason) {
                            DeclineReason.USER -> ReplyCode.DECLINE_USER
                            DeclineReason.BUSY -> ReplyCode.BUSY
                            DeclineReason.NO_SPACE -> ReplyCode.NO_SPACE
                            DeclineReason.NOT_ALLOWED -> ReplyCode.NOT_ALLOWED
                            DeclineReason.TIMEOUT -> ReplyCode.TIMEOUT
                        }
                        sendFrame(FrameType.OFFER_REPLY, OfferReply(code, emptyList()).encode())
                        delay(1_500)
                        closeSocket()
                    }
                    OfferDecision.Accept -> accept(offer, partial)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (t: Throwable) {
                abortFrom(t)
            }
        }

        private suspend fun accept(offer: IncomingOffer, partial: Map<Int, Long>) {
            // Offsets and prefix digests of everything this device already has (resume).
            val replyEntries = ArrayList<ReplyEntry>()
            for (e in entries) {
                val done = completed[e.id]
                if (done != null) {
                    replyEntries.add(ReplyEntry(e.id.toLong(), e.size, Fingerprints.fromHex(done.sha256) ?: ZERO_SHA))
                    continue
                }
                val have = partial[e.id] ?: continue
                val digest = prefixDigest(e, have) ?: continue
                replyEntries.add(ReplyEntry(e.id.toLong(), have, digest))
            }
            reported = replyEntries.associateBy { it.id.toInt() }
            startedAt = nowMs()
            tracker = TransferTracker(
                TransferSnapshot(
                    id = offer.transferId,
                    direction = TransferDirection.RECEIVE,
                    state = TransferState.PREPARING,
                    peer = offer.peer,
                    peerName = offer.peer.name,
                    title = offer.title,
                    totalFiles = entries.size,
                    totalBytes = totalBytes,
                    startedAt = startedAt,
                    verificationCode = offer.verificationCode,
                ),
            )
            completion = CompletableDeferred()
            inTransferPhase = true
            helpers.launch { cancelWatcher() }
            helpers.launch { progressLoop() }
            listener.onSession(ReceiveSession(offer.transferId, control, tracker, completion))
            accepted = true
            sendFrame(FrameType.OFFER_REPLY, OfferReply(ReplyCode.ACCEPT, replyEntries).encode())
        }

        private fun prefixDigest(entry: ManifestEntry, bytes: Long): ByteArray? {
            val w = try {
                store.reopenPart(entry)
            } catch (e: IOException) {
                null
            } ?: return null
            try {
                if (w.size < bytes) return null
                val md = MessageDigest.getInstance("SHA-256")
                w.openPrefix(bytes).use { hashInto(it, md, bytes) }
                return md.digest()
            } catch (e: IOException) {
                return null
            } finally {
                closeQuietly(w)
            }
        }

        private fun hashInto(input: InputStream, md: MessageDigest, bytes: Long) {
            val buf = ByteArray(64 * 1024)
            var left = bytes
            while (left > 0) {
                val n = input.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                if (n < 0) throw IOException("unexpected end of partial data")
                md.update(buf, 0, n)
                left -= n
            }
        }

        // ------------------------------------------------------------ progress / state

        private fun progressFields(s: TransferSnapshot, now: Long): TransferSnapshot {
            val transferred = doneBytes + currentBytes
            val paused = s.state == TransferState.PAUSED
            return s.copy(
                completedFiles = completedFiles,
                currentFileName = currentName,
                currentFileIndex = if (cur != null) nextIndex + 1 else nextIndex,
                currentFileSize = cur?.entry?.size ?: 0,
                currentFileBytes = currentBytes,
                transferredBytes = transferred,
                bytesPerSecond = if (paused) 0 else meter.speed(),
                etaMillis = if (paused) null else meter.etaMillis(totalBytes - transferred),
                elapsedMillis = now - startedAt,
                compressed = anyCompressed,
                savedFiles = saved,
            )
        }

        private fun publish(force: Boolean = false) {
            if (force) flushProgress() else markProgress()
        }

        override fun flushProgress() {
            val now = nowMs()
            tracker.update { progressFields(it, now) }
        }

        private fun setState(state: TransferState, change: (TransferSnapshot) -> TransferSnapshot = { it }) {
            val now = nowMs()
            tracker.update { s -> progressFields(change(s).copy(state = state), now) }
        }

        private fun finishSession(state: TransferState, result: TransferResult, change: (TransferSnapshot) -> TransferSnapshot = { it }) {
            val now = nowMs()
            tracker.update { s ->
                progressFields(change(s).copy(state = state), now).copy(finishedAt = now, bytesPerSecond = 0, etaMillis = null)
            }
            completion.complete(result)
        }

        override fun onPauseState(paused: Boolean, byPeer: Boolean) {
            if (!accepted) return
            meter.idle()
            if (paused) setState(TransferState.PAUSED) { it.copy(pausedByPeer = false) }
            else setState(TransferState.TRANSFERRING) { it.copy(pausedByPeer = false) }
        }

        private fun showPeerPause(paused: Boolean) {
            meter.idle()
            setState(if (paused) TransferState.PAUSED else TransferState.TRANSFERRING) { it.copy(pausedByPeer = paused) }
        }

        /**
         * After the user's cancel: keeps reading (and ignoring) frames until the sender closes its end, which it does as soon as it
         * has read the CANCEL notice, or [CANCEL_LINGER_MS] has passed. Only this flow reads the connection at this point.
         */
        private fun drainAfterCancel() {
            val ssl = sslSocket ?: return
            val deadline = monoMs() + CANCEL_LINGER_MS
            try {
                while (true) {
                    val left = deadline - monoMs()
                    if (left <= 0) return
                    ssl.soTimeout = left.toInt()
                    if (reader.read().type == FrameType.CANCEL) return
                }
            } catch (e: Exception) {
                // closed, reset, timed out or garbled: there is nothing left to wait for
            }
        }

        // ------------------------------------------------------------ frame dispatch

        private suspend fun dispatch() {
            while (true) {
                if (accepted) gate(holdForPeer = false)
                val f = reader.read()
                when (f.type) {
                    FrameType.PING -> Unit
                    FrameType.PAUSE -> {
                        peerPaused.value = true
                        if (accepted && !control.isPaused) showPeerPause(true)
                    }
                    FrameType.RESUME -> {
                        peerPaused.value = false
                        if (accepted && !control.isPaused) showPeerPause(false)
                    }
                    FrameType.CANCEL -> {
                        CancelMsg.decode(f)
                        throw TransferAbort(TransferFailure.PEER_CANCELLED, null, false)
                    }
                    FrameType.FILE_BEGIN -> onFileBegin(FileBegin.decode(f))
                    FrameType.FILE_DATA -> onFileData(f)
                    FrameType.FILE_END -> onFileEnd(FileEnd.decode(f))
                    FrameType.TRANSFER_END -> {
                        onTransferEnd()
                        return
                    }
                    else -> throw ProtocolException("unexpected frame")
                }
            }
        }

        private suspend fun storageFailure(entry: ManifestEntry, e: IOException): Nothing {
            val noSpace = isNoSpace(e)
            try {
                sendFrame(FrameType.FILE_RESULT, FileResult(entry.id.toLong(), if (noSpace) FileStatus.NO_SPACE else FileStatus.IO_ERROR, "").encode())
            } catch (io: IOException) {
                // the connection is going away anyway
            }
            throw TransferAbort(if (noSpace) TransferFailure.NO_SPACE else TransferFailure.STORAGE, shortDetail(e), true)
        }

        private suspend fun onFileBegin(b: FileBegin) {
            if (!accepted) throw ProtocolException("data before acceptance")
            if (cur != null) throw ProtocolException("previous file not finished")
            val entry = entries.getOrNull(nextIndex) ?: throw ProtocolException("more files than announced")
            if (b.id != entry.id.toLong()) throw ProtocolException("file out of order")
            if (b.encoding == Encoding.DEFLATE && !compressionAllowed) throw ProtocolException("compression was not negotiated")
            val ledger = completed[entry.id]
            val rep = reported[entry.id]
            val md = MessageDigest.getInstance("SHA-256")
            var writer: PartWriter? = null
            var skip = false
            try {
                when {
                    ledger != null && b.startOffset == entry.size -> skip = true
                    b.startOffset == 0L -> writer = store.createPart(entry)
                    ledger == null && rep != null && b.startOffset == rep.offset && rep.offset > 0 -> {
                        val w = store.reopenPart(entry) ?: throw ProtocolException("partial data is gone")
                        writer = w
                        if (w.size < b.startOffset) throw ProtocolException("partial data is shorter than reported")
                        if (w.size > b.startOffset) w.truncate(b.startOffset)
                        w.openPrefix(b.startOffset).use { hashInto(it, md, b.startOffset) }
                    }
                    else -> throw ProtocolException("unexpected start offset")
                }
            } catch (e: IOException) {
                if (e is ProtocolException) throw e
                closeQuietly(writer)
                storageFailure(entry, e)
            }
            val c = FileRecv(entry, b.startOffset, writer, md, skip, b.encoding)
            cur = c
            if (b.encoding == Encoding.DEFLATE && !skip) anyCompressed = true
            currentName = entry.relativePath.substringAfterLast('/')
            currentBytes = b.startOffset
            meter.idle()
            if (nextIndex == 0) setState(TransferState.TRANSFERRING) else publish(force = true)
        }

        private suspend fun onFileData(f: Frame) {
            val c = cur ?: throw ProtocolException("data without a file")
            if (c.writer == null) throw ProtocolException("data for a file that is already complete")
            try {
                if (c.inflater == null) {
                    consume(c, f.payload, 0, f.length)
                } else {
                    c.inflater.inflate(f.payload, 0, f.length) { buf, n -> consume(c, buf, 0, n) }
                }
            } catch (e: StorageIo) {
                storageFailure(c.entry, e.cause as IOException)
            }
        }

        private fun consume(c: FileRecv, buf: ByteArray, off: Int, len: Int) {
            if (c.received + len > c.entry.size) throw ProtocolException("more data than declared")
            try {
                c.writer!!.write(buf, off, len)
            } catch (e: IOException) {
                throw StorageIo(e)
            }
            c.md.update(buf, off, len)
            c.received += len
            currentBytes = c.received
            meter.add(len.toLong())
            publish()
        }

        private suspend fun onFileEnd(e: FileEnd) {
            val c = cur ?: throw ProtocolException("end without a file")
            val entry = c.entry
            if (e.id != entry.id.toLong()) throw ProtocolException("mismatched file end")
            val result: SavedFile
            if (c.skip) {
                val known = completed.getValue(entry.id)
                val want = Fingerprints.fromHex(known.sha256)
                if (want == null || !MessageDigest.isEqual(want, e.sha256)) hashMismatch(c)
                result = known
            } else {
                if (c.received != entry.size) throw ProtocolException("file ended early")
                val digest = c.md.digest()
                if (!MessageDigest.isEqual(digest, e.sha256)) hashMismatch(c)
                result = try {
                    store.commit(entry, c.writer!!, Fingerprints.toHex(digest))
                } catch (io: IOException) {
                    storageFailure(entry, io)
                }
            }
            c.inflater?.close()
            sendFrame(FrameType.FILE_RESULT, FileResult(entry.id.toLong(), FileStatus.OK, "").encode())
            saved = saved + result
            completedFiles++
            doneBytes += entry.size
            currentBytes = 0
            cur = null
            nextIndex++
            publish(force = true)
        }

        private suspend fun hashMismatch(c: FileRecv): Nothing {
            closeQuietly(c.writer)
            c.inflater?.close()
            try {
                store.discard(c.entry)
            } catch (e: Exception) {
                // nothing more to do
            }
            cur = null
            try {
                sendFrame(FrameType.FILE_RESULT, FileResult(c.entry.id.toLong(), FileStatus.HASH_MISMATCH, "").encode())
            } catch (io: IOException) {
                // the connection is going away anyway
            }
            throw TransferAbort(TransferFailure.INTEGRITY, "checksum mismatch", false)
        }

        private suspend fun onTransferEnd() {
            if (!accepted || cur != null || nextIndex != entries.size) throw ProtocolException("transfer ended before all files arrived")
            try {
                store.finish()
            } catch (e: Exception) {
                // bookkeeping only
            }
            finishSession(TransferState.COMPLETED, TransferResult.Completed(entries.size, totalBytes)) {
                it.copy(failure = null, failureDetail = null, resumable = false, pausedByPeer = false)
            }
            sendFrameQuickly(FrameType.TRANSFER_DONE, TransferDone(TransferDone.OK, entries.size.toLong(), 0).encode(), 2_000)
            linger()
        }

        // ------------------------------------------------------------ failure handling

        private fun handleFailure(t: Throwable) {
            if (t is CancellationException && abortCause == null && !control.isCancelled) {
                if (accepted) {
                    finishSession(TransferState.INTERRUPTED, TransferResult.Failed(TransferFailure.INTERRUPTED, null, true)) {
                        it.copy(failure = TransferFailure.INTERRUPTED, resumable = true)
                    }
                }
                throw t
            }
            val a = classify(t)
            logger.log("receive ended: " + (a.failure?.name ?: "CANCELLED") + (if (a.failure == TransferFailure.INTERNAL) " (" + shortDetail(t) + ")" else ""))
            if (!accepted) {
                val f = a.failure
                if (!declined && (f == TransferFailure.PROTOCOL || f == TransferFailure.AUTH_FAILED)) listener.onRejected(peer, remote, f)
                return
            }
            val discard = a.cancelled || a.failure == TransferFailure.PEER_CANCELLED || a.failure == TransferFailure.PROTOCOL
            if (discard) {
                try {
                    store.discardAll()
                } catch (e: Exception) {
                    // best effort
                }
            }
            if (a.cancelled) {
                finishSession(TransferState.CANCELLED, TransferResult.Cancelled) { it.copy(failure = null, failureDetail = null, resumable = false) }
                return
            }
            val failure = a.failure ?: TransferFailure.INTERNAL
            val state = if (a.resumable) TransferState.INTERRUPTED else TransferState.FAILED
            finishSession(state, TransferResult.Failed(failure, a.detail, a.resumable)) {
                it.copy(failure = failure, failureDetail = a.detail, resumable = a.resumable)
            }
        }
    }

    private companion object {
        const val BACKLOG = 16
        const val MAX_UNAUTHENTICATED = 12
        const val INFLATE_CAP = 4 * 1024 * 1024
    }
}
