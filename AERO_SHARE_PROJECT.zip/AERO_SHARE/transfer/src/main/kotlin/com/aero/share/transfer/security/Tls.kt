package com.aero.share.transfer.security

import java.net.Socket
import java.security.KeyStore
import java.security.SecureRandom
import java.security.cert.CertificateException
import java.security.cert.X509Certificate
import javax.net.ssl.KeyManagerFactory
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLPeerUnverifiedException
import javax.net.ssl.SSLServerSocket
import javax.net.ssl.SSLSocket
import javax.net.ssl.X509TrustManager

/**
 * TLS contexts for mutual authentication with self-signed device certificates.
 * Trust is decided by fingerprint (pin) / app policy, not by a certificate authority.
 */
object TlsContexts {
    private const val KEY_PASSWORD = "aero-share"

    fun server(identity: DeviceIdentity): SSLContext = build(identity, SelfSignedTrust(null))

    fun client(identity: DeviceIdentity, pinnedFingerprint: String?): SSLContext {
        require(pinnedFingerprint == null || Fingerprints.isValid(pinnedFingerprint)) { "invalid pin" }
        return build(identity, SelfSignedTrust(pinnedFingerprint))
    }

    private fun build(identity: DeviceIdentity, trust: X509TrustManager): SSLContext {
        val ks = KeyStore.getInstance("PKCS12")
        ks.load(null, null)
        ks.setKeyEntry("aero", identity.privateKey, KEY_PASSWORD.toCharArray(), arrayOf(identity.certificate))
        val kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm())
        kmf.init(ks, KEY_PASSWORD.toCharArray())
        val ctx = SSLContext.getInstance("TLS")
        ctx.init(kmf.keyManagers, arrayOf(trust), SecureRandom())
        return ctx
    }

    /** Wraps a connected plain socket into a client-mode TLS socket (handshake not started yet). */
    fun wrapClient(ctx: SSLContext, plain: Socket, host: String, port: Int): SSLSocket {
        val s = ctx.socketFactory.createSocket(plain, host, port, true) as SSLSocket
        s.useClientMode = true
        harden(s)
        return s
    }

    fun createServerSocket(ctx: SSLContext): SSLServerSocket {
        val s = ctx.serverSocketFactory.createServerSocket() as SSLServerSocket
        s.needClientAuth = true
        s.enabledProtocols = protocols(s.supportedProtocols)
        s.enabledCipherSuites = cipherSuites(s.supportedCipherSuites)
        s.reuseAddress = true
        return s
    }

    /** Applies protocol / cipher restrictions and TCP tuning to an accepted or connected TLS socket. */
    fun harden(s: SSLSocket) {
        s.enabledProtocols = protocols(s.supportedProtocols)
        s.enabledCipherSuites = cipherSuites(s.supportedCipherSuites)
        tune(s)
    }

    fun tune(s: Socket) {
        runCatching { s.tcpNoDelay = true }
        runCatching { s.keepAlive = true }
        runCatching { s.sendBufferSize = 1 shl 20 }
        runCatching { s.receiveBufferSize = 1 shl 20 }
    }

    internal fun protocols(supported: Array<String>): Array<String> =
        listOf("TLSv1.3", "TLSv1.2").filter { it in supported }.toTypedArray()

    /** TLS 1.3 suites plus TLS 1.2 ECDHE with AEAD (GCM / ChaCha20) only. */
    internal fun cipherSuites(supported: Array<String>): Array<String> {
        val ok = supported.filter { name ->
            val tls13 = name.startsWith("TLS_AES_") || name.startsWith("TLS_CHACHA20_")
            val tls12 = name.startsWith("TLS_ECDHE_") && (name.contains("_GCM_") || name.contains("CHACHA20"))
            (tls13 || tls12) && !name.contains("SCSV")
        }
        return ok.toTypedArray()
    }

    /** SHA-256 fingerprint of the peer's leaf certificate of an established TLS session. */
    fun peerFingerprint(socket: SSLSocket): String {
        val certs = try {
            socket.session.peerCertificates
        } catch (e: SSLPeerUnverifiedException) {
            throw e
        }
        if (certs.isEmpty()) throw SSLPeerUnverifiedException("no peer certificate")
        return Fingerprints.ofCertificate(certs[0])
    }

    /**
     * Accepts a syntactically valid, currently valid self-signed leaf. With a pin, the leaf fingerprint must match.
     * Deliberately a plain [X509TrustManager] (works on every Android version).
     */
    private class SelfSignedTrust(private val pin: String?) : X509TrustManager {
        override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) = check(chain)
        override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) = check(chain)
        override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()

        private fun check(chain: Array<out X509Certificate>?) {
            if (chain == null || chain.isEmpty()) throw CertificateException("empty certificate chain")
            val leaf = chain[0]
            try {
                leaf.checkValidity()
                leaf.verify(leaf.publicKey)
            } catch (e: CertificateException) {
                throw e
            } catch (e: Exception) {
                throw CertificateException("invalid certificate", e)
            }
            if (pin != null && !Fingerprints.constantTimeEquals(pin, Fingerprints.ofCertificate(leaf))) {
                throw CertificateException("certificate does not match the pinned fingerprint")
            }
        }
    }
}
