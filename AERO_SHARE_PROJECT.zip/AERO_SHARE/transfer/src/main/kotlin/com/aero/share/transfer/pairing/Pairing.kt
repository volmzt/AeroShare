package com.aero.share.transfer.pairing

import com.aero.share.transfer.model.DeviceKind
import com.aero.share.transfer.security.Fingerprints
import java.net.URLDecoder
import java.net.URLEncoder
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64

/** Short-lived random token embedded in a pairing QR code. */
class PairToken(val bytes: ByteArray, val expiresAt: Long, val maxUses: Int) {
    /** base64url without padding. */
    val encoded: String get() = Base64.getUrlEncoder().withoutPadding().encodeToString(bytes)
}

/** Issues and validates one-time pairing tokens. Constant-time comparison; expired or used-up tokens are purged. */
class PairTokenRegistry(
    private val clock: () -> Long = { System.currentTimeMillis() },
) {
    private class Entry(val bytes: ByteArray, val expiresAt: Long, var remaining: Int)

    private val random = SecureRandom()
    private val lock = Any()
    private val entries = ArrayList<Entry>()

    fun issue(ttlMillis: Long, maxUses: Int = 1): PairToken {
        require(ttlMillis > 0) { "ttl must be positive" }
        require(maxUses >= 1) { "maxUses must be >= 1" }
        val bytes = ByteArray(TOKEN_BYTES)
        random.nextBytes(bytes)
        val expiresAt = clock() + ttlMillis
        synchronized(lock) {
            purgeLocked()
            entries.add(Entry(bytes.copyOf(), expiresAt, maxUses))
        }
        return PairToken(bytes, expiresAt, maxUses)
    }

    /** Returns true and consumes one use if [token] is valid and not expired. */
    fun consume(token: ByteArray): Boolean {
        synchronized(lock) {
            purgeLocked()
            var matched: Entry? = null
            // Compare against every entry (no early exit) so timing does not reveal which token matched.
            for (e in entries) {
                if (MessageDigest.isEqual(e.bytes, token) && matched == null) matched = e
            }
            val hit = matched ?: return false
            hit.remaining -= 1
            if (hit.remaining <= 0) entries.remove(hit)
            return true
        }
    }

    fun invalidateAll() {
        synchronized(lock) { entries.clear() }
    }

    fun activeCount(): Int = synchronized(lock) {
        purgeLocked()
        entries.size
    }

    private fun purgeLocked() {
        val now = clock()
        entries.removeAll { it.expiresAt <= now || it.remaining <= 0 }
    }

    companion object {
        const val TOKEN_BYTES = 16
    }
}

/** Ephemeral credentials of a local-only hotspot. Valid only until the hotspot is stopped. */
data class HotspotCredentials(val ssid: String, val passphrase: String)

/**
 * Content of a pairing QR code: aero://pair?v=1&id=..&n=..&k=..&h=host1,host2&p=port&fp=..&t=token&e=expiryMillis[&ssid=..&pw=..]
 * Contains no permanent secret: only the public certificate fingerprint and a short-lived one-time token.
 */
data class QrPayload(
    val version: Int,
    val deviceId: String,
    val name: String,
    val kind: DeviceKind,
    val hosts: List<String>,
    val port: Int,
    val fingerprint: String,
    val token: String,
    val expiresAt: Long,
    val hotspot: HotspotCredentials? = null,
) {
    fun encode(): String {
        val sb = StringBuilder(PREFIX)
        sb.append("v=").append(version)
        sb.append("&id=").append(enc(deviceId))
        sb.append("&n=").append(enc(name))
        sb.append("&k=").append(kind.code)
        sb.append("&h=").append(hosts.joinToString(",") { enc(it) })
        sb.append("&p=").append(port)
        sb.append("&fp=").append(enc(fingerprint))
        sb.append("&t=").append(enc(token))
        sb.append("&e=").append(expiresAt)
        if (hotspot != null) {
            sb.append("&ssid=").append(enc(hotspot.ssid))
            sb.append("&pw=").append(enc(hotspot.passphrase))
        }
        return sb.toString()
    }

    /** Raw token bytes, or null when [token] is not valid base64url of 16..32 bytes. */
    fun tokenBytes(): ByteArray? = decodeToken(token)

    companion object {
        private const val PREFIX = "aero://pair?"
        private const val MAX_LENGTH = 1000
        private const val MAX_HOSTS = 4

        private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

        private fun decodeToken(t: String): ByteArray? {
            val bytes = try {
                Base64.getUrlDecoder().decode(t)
            } catch (e: IllegalArgumentException) {
                return null
            }
            return if (bytes.size in 16..32) bytes else null
        }

        /** Strict parser with length limits; returns null for anything malformed. */
        fun parse(text: String): QrPayload? {
            val trimmed = text.trim()
            if (trimmed.length > MAX_LENGTH || !trimmed.startsWith(PREFIX)) return null
            val map = HashMap<String, String>()
            for (pair in trimmed.substring(PREFIX.length).split('&')) {
                val i = pair.indexOf('=')
                if (i <= 0) return null
                val key = pair.substring(0, i)
                val value = try {
                    URLDecoder.decode(pair.substring(i + 1), "UTF-8")
                } catch (e: IllegalArgumentException) {
                    return null
                }
                if (map.put(key, value) != null) return null
            }
            if (map["v"] != "1") return null
            val fp = map["fp"] ?: return null
            if (!Fingerprints.isValid(fp)) return null
            val id = map["id"] ?: return null
            if (id != fp.take(32)) return null
            val name = map["n"] ?: return null
            if (name.isEmpty() || name.length > 60 || name.any { it.code < 0x20 || it.code == 0x7F }) return null
            val kindCode = map["k"]?.toIntOrNull() ?: return null
            if (kindCode !in 0..3) return null
            val hosts = (map["h"] ?: return null).split(',').filter { it.isNotEmpty() }
            if (hosts.isEmpty() || hosts.size > MAX_HOSTS || !hosts.all { isLiteralAddress(it) }) return null
            val port = map["p"]?.toIntOrNull() ?: return null
            if (port !in 1..65535) return null
            val token = map["t"] ?: return null
            if (decodeToken(token) == null) return null
            val expiresAt = map["e"]?.toLongOrNull() ?: return null
            if (expiresAt <= 0) return null
            val ssid = map["ssid"]
            val pw = map["pw"]
            val hotspot = when {
                ssid == null && pw == null -> null
                ssid != null && pw != null &&
                    ssid.length in 1..32 && pw.length in 8..63 &&
                    ssid.none { it.code < 0x20 } && pw.none { it.code < 0x20 } -> HotspotCredentials(ssid, pw)
                else -> return null
            }
            return QrPayload(1, id, name, DeviceKind.fromCode(kindCode), hosts, port, fp, token, expiresAt, hotspot)
        }

        private fun isLiteralAddress(s: String): Boolean {
            if (s.length > 45) return false
            if (s.contains(':')) {
                return s.all { it in '0'..'9' || it in 'a'..'f' || it in 'A'..'F' || it == ':' || it == '.' } &&
                    s.count { it == ':' } in 2..7
            }
            val octets = s.split('.')
            return octets.size == 4 && octets.all { o ->
                o.isNotEmpty() && o.length <= 3 && o.all { it in '0'..'9' } && o.toInt() <= 255
            }
        }
    }
}
