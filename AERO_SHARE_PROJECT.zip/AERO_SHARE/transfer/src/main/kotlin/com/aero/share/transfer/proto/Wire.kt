package com.aero.share.transfer.proto

import java.io.DataInputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream

/** The peer violated the wire protocol (or sent something outside the agreed limits). */
class ProtocolException(message: String) : IOException(message)

object FrameType {
    const val HELLO = 0x01
    const val HELLO_ACK = 0x02
    const val OFFER = 0x10
    const val OFFER_ENTRIES = 0x11
    const val OFFER_END = 0x12
    const val OFFER_REPLY = 0x20
    const val FILE_BEGIN = 0x30
    const val FILE_DATA = 0x31
    const val FILE_END = 0x32
    const val FILE_RESULT = 0x33
    const val PAUSE = 0x40
    const val RESUME = 0x41
    const val CANCEL = 0x42
    const val PING = 0x43
    const val TRANSFER_END = 0x50
    const val TRANSFER_DONE = 0x51

    private val known = setOf(
        HELLO, HELLO_ACK, OFFER, OFFER_ENTRIES, OFFER_END, OFFER_REPLY, FILE_BEGIN, FILE_DATA, FILE_END,
        FILE_RESULT, PAUSE, RESUME, CANCEL, PING, TRANSFER_END, TRANSFER_DONE,
    )

    fun isKnown(type: Int): Boolean = type in known
}

object WireLimits {
    const val HEADER_SIZE = 5
    const val MAX_CONTROL_PAYLOAD = 256 * 1024
    const val MAX_DATA_PAYLOAD = 2 * 1024 * 1024

    fun maxPayload(type: Int): Int = if (type == FrameType.FILE_DATA) MAX_DATA_PAYLOAD else MAX_CONTROL_PAYLOAD
}

/**
 * A received frame. [payload] is a buffer owned by the [FrameReader]: it is only valid until the next
 * [FrameReader.read] call and only its first [length] bytes belong to the frame.
 */
class Frame(val type: Int, val payload: ByteArray, val length: Int) {
    fun copyPayload(): ByteArray = payload.copyOf(length)
}

/** Reads frames (`type u8 | length u32 | payload`). Not thread-safe. End of stream between frames throws EOFException. */
class FrameReader(input: InputStream) {
    private val din = DataInputStream(input)
    private val header = ByteArray(WireLimits.HEADER_SIZE)
    private var buffer = ByteArray(64 * 1024)

    fun read(): Frame {
        din.readFully(header, 0, WireLimits.HEADER_SIZE)
        val type = header[0].toInt() and 0xFF
        val len = ((header[1].toInt() and 0xFF) shl 24) or ((header[2].toInt() and 0xFF) shl 16) or
            ((header[3].toInt() and 0xFF) shl 8) or (header[4].toInt() and 0xFF)
        if (!FrameType.isKnown(type)) throw ProtocolException("unknown frame type")
        if (len < 0 || len > WireLimits.maxPayload(type)) throw ProtocolException("frame too large")
        if (buffer.size < len) buffer = ByteArray(minOf(maxOf(len, buffer.size * 2), WireLimits.MAX_DATA_PAYLOAD))
        din.readFully(buffer, 0, len)
        return Frame(type, buffer, len)
    }
}

/** Writes frames. Not thread-safe: callers serialize access. */
class FrameWriter(private val out: OutputStream) {
    /** Writes a frame with the given payload in a single write call. */
    fun write(type: Int, payload: ByteArray = EMPTY, off: Int = 0, len: Int = payload.size) {
        require(len >= 0 && len <= WireLimits.maxPayload(type)) { "payload too large" }
        val buf = ByteArray(WireLimits.HEADER_SIZE + len)
        putHeader(buf, type, len)
        System.arraycopy(payload, off, buf, WireLimits.HEADER_SIZE, len)
        out.write(buf)
        out.flush()
    }

    /** Writes a frame whose payload already sits in [buf] at offset [WireLimits.HEADER_SIZE] (5 bytes of room in front). */
    fun writeWithRoom(type: Int, buf: ByteArray, payloadLen: Int) {
        require(payloadLen >= 0 && payloadLen <= WireLimits.maxPayload(type) && buf.size >= WireLimits.HEADER_SIZE + payloadLen) {
            "payload too large"
        }
        putHeader(buf, type, payloadLen)
        out.write(buf, 0, WireLimits.HEADER_SIZE + payloadLen)
        out.flush()
    }

    private fun putHeader(buf: ByteArray, type: Int, len: Int) {
        buf[0] = type.toByte()
        buf[1] = (len ushr 24).toByte()
        buf[2] = (len ushr 16).toByte()
        buf[3] = (len ushr 8).toByte()
        buf[4] = len.toByte()
    }

    companion object {
        private val EMPTY = ByteArray(0)
    }
}

/** Builds a message payload (big-endian integers, strings = u16 byte length + UTF-8). */
class MsgWriter(initialCapacity: Int = 64) {
    private var buf = ByteArray(initialCapacity)
    private var n = 0

    val size: Int get() = n

    private fun ensure(extra: Int) {
        if (n + extra > buf.size) buf = buf.copyOf(maxOf(buf.size * 2, n + extra))
    }

    fun u8(v: Int): MsgWriter {
        require(v in 0..0xFF)
        ensure(1)
        buf[n++] = v.toByte()
        return this
    }

    fun u16(v: Int): MsgWriter {
        require(v in 0..0xFFFF)
        ensure(2)
        buf[n++] = (v ushr 8).toByte()
        buf[n++] = v.toByte()
        return this
    }

    fun u32(v: Long): MsgWriter {
        require(v in 0..0xFFFFFFFFL)
        ensure(4)
        buf[n++] = (v ushr 24).toByte()
        buf[n++] = (v ushr 16).toByte()
        buf[n++] = (v ushr 8).toByte()
        buf[n++] = v.toByte()
        return this
    }

    fun i64(v: Long): MsgWriter {
        ensure(8)
        for (shift in 56 downTo 0 step 8) buf[n++] = (v ushr shift).toByte()
        return this
    }

    fun bytes(b: ByteArray): MsgWriter {
        ensure(b.size)
        System.arraycopy(b, 0, buf, n, b.size)
        n += b.size
        return this
    }

    /** UTF-8 string; fails when longer than [maxBytes] (callers truncate with [clip] first when needed). */
    fun str(s: String, maxBytes: Int): MsgWriter {
        val b = s.toByteArray(Charsets.UTF_8)
        require(b.size <= maxBytes) { "string too long" }
        u16(b.size)
        return bytes(b)
    }

    fun toByteArray(): ByteArray = buf.copyOf(n)

    companion object {
        /** Truncates [s] to at most [maxBytes] UTF-8 bytes on a code point boundary. */
        fun clip(s: String, maxBytes: Int): String {
            if (s.toByteArray(Charsets.UTF_8).size <= maxBytes) return s
            val sb = StringBuilder()
            var used = 0
            var i = 0
            while (i < s.length) {
                val cp = s.codePointAt(i)
                val piece = String(Character.toChars(cp))
                val len = piece.toByteArray(Charsets.UTF_8).size
                if (used + len > maxBytes) break
                sb.append(piece)
                used += len
                i += Character.charCount(cp)
            }
            return sb.toString()
        }
    }
}

/** Parses a message payload; every underflow or invalid value throws [ProtocolException]. */
class MsgReader(private val buf: ByteArray, private var pos: Int, private val end: Int) {
    constructor(frame: Frame) : this(frame.payload, 0, frame.length)

    val remaining: Int get() = end - pos

    private fun need(n: Int) {
        if (n < 0 || n > end - pos) throw ProtocolException("truncated message")
    }

    fun u8(): Int {
        need(1)
        return buf[pos++].toInt() and 0xFF
    }

    fun u16(): Int {
        need(2)
        val v = ((buf[pos].toInt() and 0xFF) shl 8) or (buf[pos + 1].toInt() and 0xFF)
        pos += 2
        return v
    }

    fun u32(): Long {
        need(4)
        var v = 0L
        for (i in 0 until 4) v = (v shl 8) or (buf[pos + i].toLong() and 0xFF)
        pos += 4
        return v
    }

    fun i64(): Long {
        need(8)
        var v = 0L
        for (i in 0 until 8) v = (v shl 8) or (buf[pos + i].toLong() and 0xFF)
        pos += 8
        return v
    }

    fun bytes(n: Int): ByteArray {
        need(n)
        val out = buf.copyOfRange(pos, pos + n)
        pos += n
        return out
    }

    fun str(maxBytes: Int): String {
        val len = u16()
        if (len > maxBytes) throw ProtocolException("string too long")
        need(len)
        val s = String(buf, pos, len, Charsets.UTF_8)
        pos += len
        if (s.indexOf('\u0000') >= 0) throw ProtocolException("invalid string")
        return s
    }

    fun requireEnd() {
        if (pos != end) throw ProtocolException("trailing bytes in message")
    }
}
