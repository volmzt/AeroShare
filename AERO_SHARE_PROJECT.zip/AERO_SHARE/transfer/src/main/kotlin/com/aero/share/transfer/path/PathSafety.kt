package com.aero.share.transfer.path

/** Validation of names and relative paths coming from untrusted peers. */
object PathSafety {
    const val MAX_SEGMENT_BYTES = 255
    const val MAX_PATH_BYTES = 1024
    const val MAX_DEPTH = 32

    private val illegalChars = setOf('\\', ':', '*', '?', '"', '<', '>', '|')
    private val reservedNames: Set<String> =
        setOf("CON", "PRN", "AUX", "NUL") + (1..9).map { "COM$it" } + (1..9).map { "LPT$it" }

    /**
     * Returns a safe relative path with '/' separators, or null if it cannot be made safe
     * (empty, absolute, contains '..' segments, too long, too deep). Control characters and characters that are
     * illegal on common file systems are replaced; backslashes are treated as separators.
     */
    fun sanitizeRelativePath(raw: String): String? {
        if (raw.isEmpty() || raw.length > MAX_PATH_BYTES * 2) return null
        val normalized = raw.replace('\\', '/')
        if (normalized.startsWith("/")) return null
        val out = ArrayList<String>()
        val parts = normalized.split('/')
        for ((index, part) in parts.withIndex()) {
            if (part.isEmpty() || part == ".") continue
            if (part == "..") return null
            // "C:" or "C:\..." as the first segment is a Windows drive prefix (absolute path): refuse.
            if (index == 0 && part.length == 2 && part[1] == ':' && part[0].isLetter()) return null
            out.add(sanitizeSegment(part))
        }
        if (out.isEmpty() || out.size > MAX_DEPTH) return null
        val joined = out.joinToString("/")
        if (joined.toByteArray(Charsets.UTF_8).size > MAX_PATH_BYTES) return null
        return joined
    }

    /** Never empty, never '.' or '..', no separators, at most [MAX_SEGMENT_BYTES] UTF-8 bytes (extension preserved). */
    fun sanitizeFileName(raw: String): String {
        val last = raw.replace('\\', '/').substringAfterLast('/')
        return sanitizeSegment(last)
    }

    /** "name.ext" -> "name (1).ext", "name (2).ext", ... until [exists] returns false. */
    fun uniqueName(name: String, exists: (String) -> Boolean): String {
        if (!exists(name)) return name
        val dot = name.lastIndexOf('.')
        val stem = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var n = 1
        while (n <= 10_000) {
            val suffix = " ($n)"
            val room = MAX_SEGMENT_BYTES - ext.toByteArray(Charsets.UTF_8).size - suffix.toByteArray(Charsets.UTF_8).size
            val candidate = truncateUtf8(stem, room.coerceAtLeast(1)) + suffix + ext
            if (!exists(candidate)) return candidate
            n++
        }
        return truncateUtf8(stem, 100) + " (" + java.util.UUID.randomUUID().toString().take(8) + ")" + ext
    }

    private fun sanitizeSegment(raw: String): String {
        val sb = StringBuilder(raw.length)
        for (ch in raw) {
            sb.append(if (ch.code < 0x20 || ch.code == 0x7F || ch in illegalChars) '_' else ch)
        }
        var s = sb.toString().trimEnd('.', ' ').trimStart(' ')
        if (s.isEmpty()) s = "_"
        if (s.substringBefore('.').uppercase() in reservedNames) s = "_$s"
        return truncateUtf8(s, MAX_SEGMENT_BYTES)
    }

    /** Truncates on a code point boundary keeping a short extension. */
    private fun truncateUtf8(s: String, maxBytes: Int): String {
        if (s.toByteArray(Charsets.UTF_8).size <= maxBytes) return s
        val dot = s.lastIndexOf('.')
        val ext = if (dot > 0 && s.length - dot <= 16) s.substring(dot) else ""
        val stem = if (ext.isEmpty()) s else s.substring(0, dot)
        val budget = (maxBytes - ext.toByteArray(Charsets.UTF_8).size).coerceAtLeast(1)
        val sb = StringBuilder()
        var used = 0
        var i = 0
        while (i < stem.length) {
            val cp = stem.codePointAt(i)
            val piece = String(Character.toChars(cp))
            val len = piece.toByteArray(Charsets.UTF_8).size
            if (used + len > budget) break
            sb.append(piece)
            used += len
            i += Character.charCount(cp)
        }
        val trimmed = sb.toString().trimEnd('.', ' ')
        return (if (trimmed.isEmpty()) "_" else trimmed) + ext
    }
}
