package com.aero.share.transfer.engine

import com.aero.share.transfer.model.TransferControl
import com.aero.share.transfer.model.TransferFailure
import com.aero.share.transfer.model.TransferState
import java.util.concurrent.TimeUnit
import kotlin.random.Random
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

/**
 * When the user cancels, the other device must learn that the transfer was cancelled (and drop the partial data), not
 * merely that the connection disappeared. The cancel watcher and the main flow of a session wake up at the same moment,
 * so the outcome used to depend on which of them got there first. The rounds below are repeated to catch such a race.
 */
class CancelAnnouncementTest {
    @get:Rule
    val tmp = TemporaryFolder()

    private val created = ArrayList<Harness>()

    private fun harness(): Harness = Harness(tmp.newFolder("h${System.nanoTime()}")).start().also { created.add(it) }

    @After
    fun tearDown() {
        created.forEach { it.stop() }
    }

    @Test
    fun cancelBySenderIsAlwaysReportedToTheReceiverAsCancelled() {
        repeat(ROUNDS) { round ->
            val h = harness()
            val file = GatedFile(1, "big.bin", Random(round).nextBytes(1_048_576), gateAt = 262_144)
            val control = TransferControl()
            val tracker = h.tracker("s$round")
            val job = Thread { runBlocking { h.sender().send(h.target(), h.request(listOf(file)), control, tracker) } }.also { it.start() }
            assertTrue(file.reached.await(10, TimeUnit.SECONDS))
            val session = h.awaitSession()
            session.tracker.awaitState { it.transferredBytes >= 262_144 }
            control.cancel()
            file.release.countDown()
            job.join(15_000)
            assertEquals("round $round", TransferState.CANCELLED, tracker.awaitState { it.state.isTerminal }.state)
            val result = runBlocking { withTimeout(10_000) { session.completion.await() } }
            assertEquals("round $round", TransferFailure.PEER_CANCELLED, (result as TransferResult.Failed).failure)
            assertTrue("round $round", h.dest.walkTopDown().none { it.isFile })
            assertTrue("round $round", h.parts.walkTopDown().none { it.isFile })
        }
    }

    @Test
    fun cancelByReceiverIsAlwaysReportedToTheSenderAsCancelled() {
        repeat(ROUNDS) { round ->
            val h = harness()
            val file = GatedFile(1, "big.bin", Random(round + 1_000).nextBytes(1_048_576), gateAt = 262_144)
            val tracker = h.tracker("r$round")
            val job = Thread { runBlocking { h.sender().send(h.target(), h.request(listOf(file)), TransferControl(), tracker) } }.also { it.start() }
            assertTrue(file.reached.await(10, TimeUnit.SECONDS))
            val session = h.awaitSession()
            session.tracker.awaitState { it.transferredBytes >= 262_144 }
            session.control.cancel()
            file.release.countDown()
            job.join(15_000)
            val result = runBlocking { withTimeout(10_000) { session.completion.await() } }
            assertEquals("round $round", TransferResult.Cancelled, result)
            val state = tracker.awaitState { it.state.isTerminal }
            assertEquals("round $round", TransferFailure.PEER_CANCELLED, state.failure)
            assertTrue("round $round", h.dest.walkTopDown().none { it.isFile })
            assertTrue("round $round", h.parts.walkTopDown().none { it.isFile })
        }
    }

    private companion object {
        const val ROUNDS = 25
    }
}
