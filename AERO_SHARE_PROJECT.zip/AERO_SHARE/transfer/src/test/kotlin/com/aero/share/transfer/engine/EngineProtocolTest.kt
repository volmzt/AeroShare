package com.aero.share.transfer.engine

import com.aero.share.transfer.model.TransferControl
import com.aero.share.transfer.model.TransferFailure
import com.aero.share.transfer.model.TransferState
import com.aero.share.transfer.proto.Encoding
import com.aero.share.transfer.proto.FileBegin
import com.aero.share.transfer.proto.FileEnd
import com.aero.share.transfer.proto.FileResult
import com.aero.share.transfer.proto.FileStatus
import com.aero.share.transfer.proto.FrameType
import com.aero.share.transfer.proto.HelloAck
import com.aero.share.transfer.proto.HelloStatus
import com.aero.share.transfer.proto.OfferReply
import com.aero.share.transfer.proto.ReplyCode
import com.aero.share.transfer.proto.TransferDone
import com.aero.share.transfer.security.DeviceIdentity
import com.aero.share.transfer.model.Capabilities
import java.io.File
import java.util.concurrent.atomic.AtomicLong
import kotlin.random.Random
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

/** Tests that speak the wire protocol directly, to cover peers that misbehave. */
class EngineProtocolTest {
    @get:Rule
    val tmp = TemporaryFolder()

    private val created = ArrayList<Harness>()

    private fun harness(): Harness = Harness(tmp.newFolder("h${System.nanoTime()}")).start().also { created.add(it) }

    @After
    fun tearDown() {
        created.forEach { it.stop() }
    }

    private fun session(h: Harness): ReceiveSession = h.awaitSession()

    private fun completion(s: ReceiveSession): TransferResult = runBlocking { withTimeout(10_000) { s.completion.await() } }

    private fun expectClosed(c: RawClient) {
        try {
            c.ssl.soTimeout = 5_000
            while (true) c.reader.read()
        } catch (e: java.io.IOException) {
            return // closed or reset: what we expect
        }
    }

    private fun assertNothingPublished(h: Harness) {
        assertTrue(h.dest.walkTopDown().none { it.isFile })
        assertTrue(h.parts.walkTopDown().none { it.isFile })
    }

    @Test
    fun corruptedContentIsDetectedAndNeverPublished() {
        val h = harness()
        RawClient(h).use { c ->
            c.hello()
            c.offer("t", listOf(wireEntry(1, "doc.txt", 10)))
            assertEquals(ReplyCode.ACCEPT, c.readReply().decision)
            c.writer.write(FrameType.FILE_BEGIN, FileBegin(1, 0, Encoding.RAW).encode())
            val data = "0123456789".toByteArray()
            c.writer.write(FrameType.FILE_DATA, data)
            // the digest announced by the sender does not match what was received
            c.writer.write(FrameType.FILE_END, FileEnd(1, sha256Bytes("0123456780".toByteArray())).encode())
            val r = FileResult.decode(c.expect(FrameType.FILE_RESULT))
            assertEquals(FileStatus.HASH_MISMATCH, r.status)
        }
        val s = session(h)
        val result = completion(s)
        assertEquals(TransferFailure.INTEGRITY, (result as TransferResult.Failed).failure)
        assertEquals(TransferState.FAILED, s.tracker.current.state)
        assertNothingPublished(h)
    }

    @Test
    fun receivingMoreThanDeclaredIsAProtocolError() {
        val h = harness()
        RawClient(h).use { c ->
            c.hello()
            c.offer("t", listOf(wireEntry(1, "doc.txt", 10)))
            assertEquals(ReplyCode.ACCEPT, c.readReply().decision)
            c.writer.write(FrameType.FILE_BEGIN, FileBegin(1, 0, Encoding.RAW).encode())
            c.writer.write(FrameType.FILE_DATA, ByteArray(11))
            expectClosed(c)
        }
        val result = completion(session(h))
        assertEquals(TransferFailure.PROTOCOL, (result as TransferResult.Failed).failure)
        assertNothingPublished(h)
    }

    @Test
    fun fileEndingEarlyIsAProtocolError() {
        val h = harness()
        RawClient(h).use { c ->
            c.hello()
            c.offer("t", listOf(wireEntry(1, "doc.txt", 10)))
            assertEquals(ReplyCode.ACCEPT, c.readReply().decision)
            c.writer.write(FrameType.FILE_BEGIN, FileBegin(1, 0, Encoding.RAW).encode())
            c.writer.write(FrameType.FILE_DATA, ByteArray(4))
            c.writer.write(FrameType.FILE_END, FileEnd(1, sha256Bytes(ByteArray(4))).encode())
            expectClosed(c)
        }
        assertEquals(TransferFailure.PROTOCOL, (completion(session(h)) as TransferResult.Failed).failure)
        assertNothingPublished(h)
    }

    @Test
    fun filesMustArriveInManifestOrder() {
        val h = harness()
        RawClient(h).use { c ->
            c.hello()
            c.offer("t", listOf(wireEntry(1, "a.txt", 3), wireEntry(2, "b.txt", 3)))
            assertEquals(ReplyCode.ACCEPT, c.readReply().decision)
            c.writer.write(FrameType.FILE_BEGIN, FileBegin(2, 0, Encoding.RAW).encode())
            expectClosed(c)
        }
        assertEquals(TransferFailure.PROTOCOL, (completion(session(h)) as TransferResult.Failed).failure)
    }

    @Test
    fun transferEndBeforeAllFilesIsRefused() {
        val h = harness()
        RawClient(h).use { c ->
            c.hello()
            c.offer("t", listOf(wireEntry(1, "a.txt", 3)))
            assertEquals(ReplyCode.ACCEPT, c.readReply().decision)
            c.writer.write(FrameType.TRANSFER_END)
            expectClosed(c)
        }
        assertEquals(TransferFailure.PROTOCOL, (completion(session(h)) as TransferResult.Failed).failure)
    }

    @Test
    fun pathTraversalInTheManifestIsRefused() {
        val h = harness()
        for (bad in listOf("../evil.txt", "a/../../evil.txt", "/etc/passwd", "C:/evil.txt", "")) {
            RawClient(h).use { c ->
                c.hello()
                c.offer("t", listOf(wireEntry(1, bad, 5)))
                assertEquals("path '$bad'", ReplyCode.NOT_ALLOWED, c.readReply().decision)
            }
        }
        assertTrue(h.rejected.all { it == TransferFailure.PROTOCOL })
        assertTrue(h.rejected.size >= 5)
        assertFalse(File(h.dest.parentFile, "evil.txt").exists())
        assertTrue(h.sessions.isEmpty())
    }

    @Test
    fun inconsistentManifestsAreRefused() {
        val h = harness()
        // total does not match the sum of the sizes
        RawClient(h).use { c ->
            c.hello()
            c.offer("t", listOf(wireEntry(1, "a.txt", 5)), total = 6)
            assertEquals(ReplyCode.NOT_ALLOWED, c.readReply().decision)
        }
        // duplicate ids
        RawClient(h).use { c ->
            c.hello()
            c.offer("t", listOf(wireEntry(1, "a.txt", 5), wireEntry(1, "b.txt", 5)))
            assertEquals(ReplyCode.NOT_ALLOWED, c.readReply().decision)
        }
        // negative size
        RawClient(h).use { c ->
            c.hello()
            c.offer("t", listOf(wireEntry(1, "a.txt", -5)), total = -5)
            expectClosed(c)
        }
        assertTrue(h.offers.isEmpty())
    }

    @Test
    fun dataBeforeAcceptanceClosesTheConnection() {
        val h = harness()
        val never = CompletableDeferred<OfferDecision>()
        h.decide = { never.await() }
        RawClient(h).use { c ->
            c.hello()
            c.offer("t", listOf(wireEntry(1, "a.txt", 3)))
            c.writer.write(FrameType.FILE_BEGIN, FileBegin(1, 0, Encoding.RAW).encode())
            expectClosed(c)
        }
        assertTrue(h.sessions.isEmpty())
        assertTrue(h.rejected.contains(TransferFailure.PROTOCOL))
    }

    @Test
    fun malformedAndOversizedFramesAreRejected() {
        val h = harness()
        // unknown frame type
        RawClient(h).use { c ->
            c.hello()
            c.ssl.outputStream.write(byteArrayOf(0x7F, 0, 0, 0, 0))
            c.ssl.outputStream.flush()
            expectClosed(c)
        }
        // control frame larger than the limit
        RawClient(h).use { c ->
            c.hello()
            c.ssl.outputStream.write(byteArrayOf(FrameType.OFFER_ENTRIES.toByte(), 0x00, 0x10, 0x00, 0x00))
            c.ssl.outputStream.flush()
            expectClosed(c)
        }
        // truncated OFFER payload
        RawClient(h).use { c ->
            c.hello()
            c.writer.write(FrameType.OFFER, byteArrayOf(0, 5, 1))
            expectClosed(c)
        }
        assertTrue(h.offers.isEmpty())
        // the server is still healthy
        assertTrue(runBlocking {
            withTimeout(20_000) {
                h.sender().send(h.target(), h.request(listOf(MemoryFile(1, "ok.txt", Random(1).nextBytes(100)))), TransferControl(), h.tracker("ok"))
            }
        } is TransferResult.Completed)
    }

    @Test
    fun helloWithWrongDeviceIdOrVersionIsRefused() {
        val h = harness()
        RawClient(h).use { c ->
            val ack = c.hello(deviceId = "0".repeat(32))
            assertEquals(HelloStatus.AUTH_FAILED, ack.status)
        }
        RawClient(h).use { c ->
            val ack = c.hello(version = 2)
            assertEquals(HelloStatus.UNSUPPORTED_VERSION, ack.status)
        }
        assertTrue(h.rejected.contains(TransferFailure.AUTH_FAILED))
        assertTrue(h.rejected.contains(TransferFailure.UNSUPPORTED_VERSION))
    }

    @Test
    fun clientWithoutAValidCertificateCannotTalkToTheServer() {
        val h = harness()
        // a TLS client that does not present a certificate at all
        val ctx = javax.net.ssl.SSLContext.getInstance("TLS")
        ctx.init(null, arrayOf(object : javax.net.ssl.X509TrustManager {
            override fun checkClientTrusted(chain: Array<out java.security.cert.X509Certificate>?, authType: String?) {}
            override fun checkServerTrusted(chain: Array<out java.security.cert.X509Certificate>?, authType: String?) {}
            override fun getAcceptedIssuers(): Array<java.security.cert.X509Certificate> = emptyArray()
        }), null)
        val s = ctx.socketFactory.createSocket("127.0.0.1", h.port) as javax.net.ssl.SSLSocket
        s.soTimeout = 3_000
        try {
            s.startHandshake()
            // TLS 1.3 completes the client side before the server verified the (missing) certificate: the first read fails
            s.outputStream.write(1)
            s.outputStream.flush()
            val r = s.inputStream.read()
            assertTrue("server must not answer an unauthenticated client", r < 0)
        } catch (e: java.io.IOException) {
            // expected: handshake failure or connection closed
        } finally {
            s.close()
        }
        assertTrue(h.offers.isEmpty())
    }

    // ------------------------------------------------------------------ sender against a misbehaving receiver

    private fun helloAck(identity: DeviceIdentity, status: Int = HelloStatus.OK, deviceId: String = identity.deviceId) =
        HelloAck(1, status, deviceId, "Fake", 0, "1.0", Capabilities.ALL, false, false).encode()

    private fun runSenderAgainst(fake: FakeReceiver, files: List<SendableFile>, h: Harness): Pair<TransferResult, com.aero.share.transfer.model.TransferTracker> {
        val tracker = h.tracker("fake")
        val r = runBlocking {
            withTimeout(30_000) {
                h.sender().send(com.aero.share.transfer.engine.SendTarget("127.0.0.1", fake.port, fake.identity.fingerprint, null, com.aero.share.transfer.model.TransportKind.LAN), h.request(files), TransferControl(), tracker)
            }
        }
        return r to tracker
    }

    @Test
    fun senderTreatsAReceiverReportedChecksumMismatchAsFailure() {
        val h = harness()
        val id = DeviceIdentity.generate("fake")
        FakeReceiver(id) { r, w ->
            r.read() // HELLO
            w.write(FrameType.HELLO_ACK, helloAck(id))
            while (r.read().type != FrameType.OFFER_END) { /* manifest */ }
            w.write(FrameType.OFFER_REPLY, OfferReply(ReplyCode.ACCEPT, emptyList()).encode())
            while (true) {
                val f = r.read()
                if (f.type == FrameType.FILE_END) {
                    w.write(FrameType.FILE_RESULT, FileResult(FileEnd.decode(f).id, FileStatus.HASH_MISMATCH, "bad").encode())
                    break
                }
            }
            Thread.sleep(500)
        }.use { fake ->
            val (result, tracker) = runSenderAgainst(fake, listOf(MemoryFile(1, "a.bin", Random(3).nextBytes(50_000))), h)
            assertEquals(TransferFailure.INTEGRITY, (result as TransferResult.Failed).failure)
            assertEquals(TransferState.FAILED, tracker.current.state)
            assertFalse(tracker.current.resumable)
        }
    }

    @Test
    fun senderNeverReportsSuccessWithoutAllFileResults() {
        val h = harness()
        val id = DeviceIdentity.generate("fake")
        FakeReceiver(id) { r, w ->
            r.read()
            w.write(FrameType.HELLO_ACK, helloAck(id))
            while (r.read().type != FrameType.OFFER_END) { /* manifest */ }
            w.write(FrameType.OFFER_REPLY, OfferReply(ReplyCode.ACCEPT, emptyList()).encode())
            while (true) {
                val f = r.read()
                if (f.type == FrameType.TRANSFER_END) {
                    // claims success but never confirmed the file
                    w.write(FrameType.TRANSFER_DONE, TransferDone(TransferDone.OK, 1, 0).encode())
                    break
                }
            }
            Thread.sleep(500)
        }.use { fake ->
            val (result, tracker) = runSenderAgainst(fake, listOf(MemoryFile(1, "a.bin", Random(4).nextBytes(10_000))), h)
            assertTrue(result is TransferResult.Failed)
            assertTrue(tracker.current.state != TransferState.COMPLETED)
        }
    }

    @Test
    fun senderRefusesAReceiverWhoseIdentityDoesNotMatchItsCertificate() {
        val h = harness()
        val id = DeviceIdentity.generate("fake")
        FakeReceiver(id) { r, w ->
            r.read()
            w.write(FrameType.HELLO_ACK, helloAck(id, deviceId = "f".repeat(32)))
            Thread.sleep(500)
        }.use { fake ->
            val (result, _) = runSenderAgainst(fake, listOf(MemoryFile(1, "a.bin", ByteArray(10))), h)
            assertEquals(TransferFailure.AUTH_FAILED, (result as TransferResult.Failed).failure)
        }
    }

    @Test
    fun senderMapsDeclineCodesAndGarbage() {
        val h = harness()
        val cases = mapOf(
            ReplyCode.DECLINE_USER to TransferFailure.DECLINED,
            ReplyCode.BUSY to TransferFailure.BUSY,
            ReplyCode.NO_SPACE to TransferFailure.NO_SPACE,
            ReplyCode.NOT_ALLOWED to TransferFailure.BLOCKED,
            ReplyCode.TIMEOUT to TransferFailure.TIMEOUT,
            ReplyCode.STORAGE_ERROR to TransferFailure.STORAGE,
        )
        for ((code, expected) in cases) {
            val id = DeviceIdentity.generate("fake")
            FakeReceiver(id) { r, w ->
                r.read()
                w.write(FrameType.HELLO_ACK, helloAck(id))
                while (r.read().type != FrameType.OFFER_END) { /* manifest */ }
                w.write(FrameType.OFFER_REPLY, OfferReply(code, emptyList()).encode())
                Thread.sleep(300)
            }.use { fake ->
                val (result, _) = runSenderAgainst(fake, listOf(MemoryFile(1, "a.bin", ByteArray(10))), h)
                assertEquals("reply code $code", expected, (result as TransferResult.Failed).failure)
            }
        }
        // a receiver that sends a frame the sender never expects
        val id = DeviceIdentity.generate("fake")
        FakeReceiver(id) { r, w ->
            r.read()
            w.write(FrameType.HELLO_ACK, helloAck(id))
            w.write(FrameType.FILE_DATA, ByteArray(3))
            Thread.sleep(500)
        }.use { fake ->
            val (result, _) = runSenderAgainst(fake, listOf(MemoryFile(1, "a.bin", ByteArray(10))), h)
            assertEquals(TransferFailure.PROTOCOL, (result as TransferResult.Failed).failure)
        }
    }

    @Test
    fun compressionReducesBytesOnTheWireOnlyForCompressibleFiles() {
        val h = harness()
        val text = "The quick brown fox jumps over the lazy dog. ".repeat(30_000).toByteArray() // ~1.3 MB
        val jpg = Random(9).nextBytes(400_000)
        fun measure(files: List<SendableFile>, mode: com.aero.share.transfer.model.CompressionMode): Triple<Long, List<Int>, TransferResult> {
            val id = DeviceIdentity.generate("fake")
            val dataBytes = AtomicLong(0)
            val encodings = java.util.concurrent.CopyOnWriteArrayList<Int>()
            val fake = FakeReceiver(id) { r, w ->
                r.read()
                w.write(FrameType.HELLO_ACK, helloAck(id))
                while (r.read().type != FrameType.OFFER_END) { /* manifest */ }
                w.write(FrameType.OFFER_REPLY, OfferReply(ReplyCode.ACCEPT, emptyList()).encode())
                while (true) {
                    val f = r.read()
                    when (f.type) {
                        FrameType.FILE_BEGIN -> encodings.add(FileBegin.decode(f).encoding)
                        FrameType.FILE_DATA -> dataBytes.addAndGet(f.length.toLong())
                        FrameType.FILE_END -> w.write(FrameType.FILE_RESULT, FileResult(FileEnd.decode(f).id, FileStatus.OK, "").encode())
                        FrameType.TRANSFER_END -> {
                            w.write(FrameType.TRANSFER_DONE, TransferDone(TransferDone.OK, files.size.toLong(), 0).encode())
                            Thread.sleep(300)
                            return@FakeReceiver
                        }
                    }
                }
            }
            fake.use {
                val tracker = h.tracker("c")
                val result = runBlocking {
                    withTimeout(30_000) {
                        h.sender().send(
                            com.aero.share.transfer.engine.SendTarget("127.0.0.1", fake.port, id.fingerprint, null, com.aero.share.transfer.model.TransportKind.LAN),
                            h.request(files, compression = mode), TransferControl(), tracker,
                        )
                    }
                }
                return Triple(dataBytes.get(), encodings.toList(), result)
            }
        }

        val off = measure(listOf(MemoryFile(1, "notes.txt", text)), com.aero.share.transfer.model.CompressionMode.OFF)
        assertEquals(text.size.toLong(), off.first)
        assertEquals(listOf(Encoding.RAW), off.second)

        val smart = measure(listOf(MemoryFile(1, "notes.txt", text)), com.aero.share.transfer.model.CompressionMode.SMART)
        assertTrue(smart.third is TransferResult.Completed)
        assertEquals(listOf(Encoding.DEFLATE), smart.second)
        assertTrue("compressed to ${smart.first} of ${text.size}", smart.first < text.size / 5)

        val photo = measure(listOf(MemoryFile(1, "IMG_1.jpg", jpg)), com.aero.share.transfer.model.CompressionMode.SMART)
        assertEquals(jpg.size.toLong(), photo.first)
        assertEquals(listOf(Encoding.RAW), photo.second)
    }
}
