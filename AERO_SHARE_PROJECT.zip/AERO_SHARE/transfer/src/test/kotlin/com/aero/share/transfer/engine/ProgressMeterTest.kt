package com.aero.share.transfer.engine

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ProgressMeterTest {
    private var now = 0L
    private fun meter() = ProgressMeter(clock = { now })

    @Test
    fun startsWithoutAnEstimate() {
        val m = meter()
        assertEquals(0L, m.speed())
        assertNull(m.etaMillis(1_000))
        assertEquals(0L, m.etaMillis(0))
    }

    @Test
    fun steadyRateConvergesAndTheEtaFollows() {
        val m = meter()
        repeat(50) {
            now += 200
            m.add(200_000) // 1 MB/s
        }
        val v = m.speed()
        assertTrue("speed $v", v in 970_000..1_030_000)
        val eta = m.etaMillis(5_000_000)
        assertNotNull(eta)
        assertTrue("eta $eta", eta!! in 4_850..5_150)
    }

    @Test
    fun noEtaBeforeTwoSecondsOfTransfer() {
        val m = meter()
        repeat(6) {
            now += 200
            m.add(200_000)
        }
        assertTrue(m.speed() > 0)
        assertNull(m.etaMillis(1_000_000))
        repeat(10) {
            now += 200
            m.add(200_000)
        }
        assertNotNull(m.etaMillis(1_000_000))
    }

    @Test
    fun adaptsToANewRate() {
        val m = meter()
        repeat(25) {
            now += 200
            m.add(200_000)
        }
        repeat(50) {
            now += 200
            m.add(800_000) // 4 MB/s
        }
        val v = m.speed()
        assertTrue("speed $v", v in 3_800_000..4_100_000)
    }

    @Test
    fun manyTinyChunksDoNotSpikeTheSpeed() {
        val m = meter()
        repeat(500) {
            now += 10
            m.add(1_000) // 100 KB/s in 1 KB pieces
        }
        val v = m.speed()
        assertTrue("speed $v", v in 95_000..105_000)
    }

    @Test
    fun speedDropsToZeroWhenDataStops() {
        val m = meter()
        repeat(20) {
            now += 200
            m.add(200_000)
        }
        assertTrue(m.speed() > 0)
        now += 4_500
        assertEquals(0L, m.speed())
        assertNull(m.etaMillis(1_000))
    }

    @Test
    fun idleStartsAFreshEstimate() {
        val m = meter()
        repeat(20) {
            now += 200
            m.add(1_000_000) // 5 MB/s
        }
        m.idle()
        assertEquals(0L, m.speed())
        assertNull(m.etaMillis(1_000))
        now += 30_000 // a long pause must not count as slow transfer
        repeat(20) {
            now += 200
            m.add(100_000) // 0.5 MB/s
        }
        val v = m.speed()
        assertTrue("speed $v", v in 480_000..520_000)
    }

    @Test
    fun emptyAndNegativeChunksAreIgnored() {
        val m = meter()
        now += 200
        m.add(0)
        m.add(-5)
        now += 200
        assertEquals(0L, m.speed())
    }

    @Test
    fun nothingRemainingMeansNoWaiting() {
        val m = meter()
        assertEquals(0L, m.etaMillis(0))
        assertEquals(0L, m.etaMillis(-10))
    }
}
