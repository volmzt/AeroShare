package com.aero.share.transfer.storage

import com.aero.share.transfer.model.ConflictPolicy
import com.aero.share.transfer.model.FileCategory
import com.aero.share.transfer.model.ManifestEntry
import com.aero.share.transfer.security.Fingerprints
import java.io.File
import java.io.IOException
import java.security.MessageDigest
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

class StagedStorageTest {
    @get:Rule
    val tmp = TemporaryFolder()

    private fun entry(path: String = "docs/a.txt", size: Long = 10, mtime: Long = 123) =
        ManifestEntry(0, path, size, mtime, FileCategory.DOCUMENT, "text/plain")

    private fun sha(b: ByteArray) = Fingerprints.toHex(MessageDigest.getInstance("SHA-256").digest(b))

    private fun storage(policy: ConflictPolicy = ConflictPolicy.KEEP_BOTH): Triple<FileIncomingStorage, File, File> {
        val dest = tmp.newFolder("dest")
        val parts = tmp.newFolder("parts")
        return Triple(FileIncomingStorage(dest, parts, policy), dest, parts)
    }

    private val data = "0123456789".toByteArray()

    private fun receiveAll(store: IncomingTransferStore, e: ManifestEntry, bytes: ByteArray) =
        store.createPart(e).let { p ->
            p.write(bytes, 0, bytes.size)
            store.commit(e, p, sha(bytes))
        }

    @Test
    fun commitPublishesFileAndRecordsLedger() {
        val (st, dest, parts) = storage()
        val e = entry()
        val store = st.open("t1", "title", "peerA")
        val saved = receiveAll(store, e, data)
        val out = File(dest, "docs/a.txt")
        assertTrue(out.isFile)
        assertArrayEquals(data, out.readBytes())
        assertEquals("a.txt", saved.displayName)
        assertEquals("docs/a.txt", saved.relativePath)
        assertEquals(10L, saved.size)
        assertEquals(sha(data), saved.sha256)
        assertEquals(FileCategory.DOCUMENT, saved.category)
        // no staging leftovers except the ledger
        assertTrue(parts.walkTopDown().filter { it.isFile }.all { it.name.endsWith(".done") })
        // ledger lets a later attempt skip the file
        val again = st.open("t2", "title", "peerA").completed(e)
        assertNotNull(again)
        assertEquals(saved, again)
        // finish() forgets it
        store.finish()
        assertNull(st.open("t3", null, "peerA").completed(e))
    }

    @Test
    fun partialDataResumesAcrossTransfersOfTheSamePeer() {
        val (st, dest, _) = storage()
        val e = entry()
        val s1 = st.open("t1", null, "peerA")
        assertNull(s1.partial(e))
        val w = s1.createPart(e)
        w.write(data, 0, 4)
        w.sync()
        w.close()

        val s2 = st.open("t2", null, "peerA")
        val info = s2.partial(e)
        assertNotNull(info)
        assertEquals(4L, info!!.bytes)
        val w2 = s2.reopenPart(e)!!
        assertEquals(4L, w2.size)
        assertArrayEquals(data.copyOfRange(0, 4), w2.openPrefix(4).use { it.readBytes() })
        assertArrayEquals(data.copyOfRange(0, 2), w2.openPrefix(2).use { it.readBytes() })
        w2.write(data, 4, 6)
        assertEquals(10L, w2.size)
        s2.commit(e, w2, sha(data))
        assertArrayEquals(data, File(dest, "docs/a.txt").readBytes())
    }

    @Test
    fun partialsAreIsolatedPerPeerAndPerFileVersion() {
        val (st, _, _) = storage()
        val e = entry()
        val w = st.open("t1", null, "peerA").createPart(e)
        w.write(data, 0, 5)
        w.close()
        assertNull(st.open("t2", null, "peerB").partial(e))
        assertNull(st.open("t3", null, "peerA").partial(e.copy(lastModified = 999)))
        assertNull(st.open("t3", null, "peerA").partial(e.copy(size = 11)))
        assertNotNull(st.open("t4", null, "peerA").partial(e))
    }

    @Test
    fun oversizedPartialIsDiscardedAndTruncateWorks() {
        val (st, _, _) = storage()
        val e = entry(size = 5)
        val store = st.open("t1", null, "p")
        val w = store.createPart(e)
        w.write(data, 0, 8) // longer than the declared size: cannot be a valid prefix
        w.close()
        assertNull(st.open("t2", null, "p").partial(e))

        val w2 = store.createPart(e)
        w2.write(data, 0, 5)
        w2.truncate(2)
        assertEquals(2L, w2.size)
        w2.write(data, 2, 3)
        assertEquals(5L, w2.size)
        w2.close()
    }

    @Test
    fun discardAllRemovesStagingData() {
        val (st, _, parts) = storage()
        val e = entry()
        val store = st.open("t1", null, "p")
        val w = store.createPart(e)
        w.write(data, 0, 3)
        w.close()
        store.discardAll()
        assertTrue(parts.walkTopDown().none { it.isFile })
        assertNull(st.open("t2", null, "p").partial(e))
    }

    @Test
    fun keepBothAddsCounterReplaceOverwritesSkipKeepsOld() {
        val e = entry()
        run {
            val (st, dest, _) = storage(ConflictPolicy.KEEP_BOTH)
            File(dest, "docs").mkdirs()
            File(dest, "docs/a.txt").writeText("old")
            val saved = receiveAll(st.open("t", null, "p"), e, data)
            assertEquals("a (1).txt", saved.displayName)
            assertEquals("docs/a (1).txt", saved.relativePath)
            assertEquals("old", File(dest, "docs/a.txt").readText())
            assertArrayEquals(data, File(dest, "docs/a (1).txt").readBytes())
        }
        run {
            val st2 = FileIncomingStorage(tmp.newFolder("d2"), tmp.newFolder("p2"), ConflictPolicy.REPLACE)
            File(tmp.root, "d2/docs").mkdirs()
            File(tmp.root, "d2/docs/a.txt").writeText("old")
            receiveAll(st2.open("t", null, "p"), e, data)
            assertArrayEquals(data, File(tmp.root, "d2/docs/a.txt").readBytes())
        }
        run {
            val st3 = FileIncomingStorage(tmp.newFolder("d3"), tmp.newFolder("p3"), ConflictPolicy.SKIP)
            File(tmp.root, "d3/docs").mkdirs()
            File(tmp.root, "d3/docs/a.txt").writeText("old")
            val saved = receiveAll(st3.open("t", null, "p"), e, data)
            assertEquals("old", File(tmp.root, "d3/docs/a.txt").readText())
            assertEquals("a.txt", saved.displayName)
        }
    }

    @Test
    fun pathTraversalIsRefused() {
        val (st, dest, _) = storage()
        val e = entry(path = "../evil.txt")
        val store = st.open("t", null, "p")
        val w = store.createPart(e)
        w.write(data, 0, 10)
        try {
            store.commit(e, w, sha(data))
            fail("traversal must be refused")
        } catch (ex: IOException) {
            // expected
        }
        assertFalse(File(dest.parentFile, "evil.txt").exists())
    }

    @Test
    fun availableBytesIsKnown() {
        val (st, _, _) = storage()
        val free = st.availableBytes()
        assertNotNull(free)
        assertTrue(free!! > 0)
    }

    @Test
    fun purgeOlderThanRemovesOnlyOldStagingData() {
        val (st, _, parts) = storage()
        val oldEntry = entry(path = "old.bin")
        val newEntry = entry(path = "new.bin")
        val w1 = st.open("t1", null, "p").createPart(oldEntry)
        w1.write(data, 0, 5)
        w1.close()
        val w2 = st.open("t2", null, "q").createPart(newEntry)
        w2.write(data, 0, 5)
        w2.close()
        val oldFile = parts.walkTopDown().filter { it.isFile }.first { it.length() == 5L && it.name.endsWith(".part") }
        // make exactly one of the two files old
        oldFile.setLastModified(1_000L)
        val removed = StagedIncomingStorage.purgeOlderThan(parts, 2_000L)
        assertEquals(1, removed)
        assertEquals(1, parts.walkTopDown().count { it.isFile })
    }
}
