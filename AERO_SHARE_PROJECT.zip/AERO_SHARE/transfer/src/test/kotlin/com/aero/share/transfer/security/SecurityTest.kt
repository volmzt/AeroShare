package com.aero.share.transfer.security

import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.CompletableFuture
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLException
import javax.net.ssl.SSLSocket
import kotlin.concurrent.thread
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class SecurityTest {
    @Test
    fun identityHasValidFingerprintAndDerivedId() {
        val id = DeviceIdentity.generate("Test phone")
        assertTrue(Fingerprints.isValid(id.fingerprint))
        assertEquals(id.fingerprint.take(32), id.deviceId)
        assertEquals(Fingerprints.ofCertificate(id.certificate), id.fingerprint)
        id.certificate.checkValidity()
        id.certificate.verify(id.certificate.publicKey)
    }

    @Test
    fun twoIdentitiesAreDifferent() {
        assertNotEquals(DeviceIdentity.generate().fingerprint, DeviceIdentity.generate().fingerprint)
    }

    @Test
    fun restoreRoundTripsAndRejectsMismatchedKey() {
        val a = DeviceIdentity.generate()
        val b = DeviceIdentity.generate()
        val restored = DeviceIdentity.restore(a.privateKeyPkcs8(), a.certificateDer())
        assertEquals(a.fingerprint, restored.fingerprint)
        try {
            DeviceIdentity.restore(b.privateKeyPkcs8(), a.certificateDer())
            fail("a key that does not belong to the certificate must be rejected")
        } catch (e: IllegalArgumentException) {
            // expected
        }
        try {
            DeviceIdentity.restore(ByteArray(10), a.certificateDer())
            fail("garbage key must be rejected")
        } catch (e: IllegalArgumentException) {
            // expected
        }
    }

    @Test
    fun hexRoundTrip() {
        val bytes = ByteArray(32) { (it * 7).toByte() }
        val hex = Fingerprints.toHex(bytes)
        assertEquals(64, hex.length)
        assertArrayEquals(bytes, Fingerprints.fromHex(hex))
        assertNull(Fingerprints.fromHex("zz"))
        assertFalse(Fingerprints.isValid(hex.uppercase().replace('0', 'G')))
        assertTrue(Fingerprints.constantTimeEquals(hex, hex))
        assertFalse(Fingerprints.constantTimeEquals(hex, hex.reversed() + "0"))
    }

    @Test
    fun sasIsSymmetricSixDigitsAndDependsOnBothSides() {
        val a = DeviceIdentity.generate().fingerprint
        val b = DeviceIdentity.generate().fingerprint
        val c = DeviceIdentity.generate().fingerprint
        val code = Sas.code(a, b)
        assertEquals(code, Sas.code(b, a))
        assertTrue(code, Regex("\\d{3} \\d{3}").matches(code))
        assertNotEquals(code, Sas.code(a, c))
    }

    private class Loopback(val server: DeviceIdentity, val client: DeviceIdentity) {
        val ss = TlsContexts.createServerSocket(TlsContexts.server(server)).also {
            it.bind(InetSocketAddress(InetAddress.getLoopbackAddress(), 0))
        }
        val seenClientFingerprint = CompletableFuture<String>()

        init {
            thread(isDaemon = true) {
                try {
                    val s = ss.accept() as SSLSocket
                    s.soTimeout = 5000
                    s.startHandshake()
                    seenClientFingerprint.complete(TlsContexts.peerFingerprint(s))
                    val b = s.inputStream.read()
                    s.outputStream.write(b)
                    s.outputStream.flush()
                    s.close()
                } catch (t: Throwable) {
                    seenClientFingerprint.completeExceptionally(t)
                }
            }
        }

        fun connect(pin: String?): SSLSocket {
            val plain = Socket()
            plain.connect(InetSocketAddress(InetAddress.getLoopbackAddress(), ss.localPort), 5000)
            val c = TlsContexts.wrapClient(TlsContexts.client(client, pin), plain, "127.0.0.1", ss.localPort)
            c.soTimeout = 5000
            return c
        }

        fun close() = ss.close()
    }

    @Test
    fun mutualTlsWithCorrectPinExchangesDataAndFingerprints() {
        val lb = Loopback(DeviceIdentity.generate("server"), DeviceIdentity.generate("client"))
        try {
            val c = lb.connect(lb.server.fingerprint)
            c.startHandshake()
            assertEquals(lb.server.fingerprint, TlsContexts.peerFingerprint(c))
            c.outputStream.write(42)
            c.outputStream.flush()
            assertEquals(42, c.inputStream.read())
            assertEquals(lb.client.fingerprint, lb.seenClientFingerprint.get(5, TimeUnit.SECONDS))
            c.close()
        } finally {
            lb.close()
        }
    }

    @Test
    fun firstContactWithoutPinStillReportsPeerFingerprint() {
        val lb = Loopback(DeviceIdentity.generate("server"), DeviceIdentity.generate("client"))
        try {
            val c = lb.connect(null)
            c.startHandshake()
            assertEquals(lb.server.fingerprint, TlsContexts.peerFingerprint(c))
            c.close()
        } finally {
            lb.close()
        }
    }

    @Test
    fun wrongPinFailsTheHandshake() {
        val lb = Loopback(DeviceIdentity.generate("server"), DeviceIdentity.generate("client"))
        try {
            val c = lb.connect(DeviceIdentity.generate("someone else").fingerprint)
            try {
                c.startHandshake()
                fail("handshake must fail when the pinned fingerprint does not match")
            } catch (e: SSLException) {
                // expected
            }
            c.close()
        } finally {
            lb.close()
        }
    }
}
