package com.aero.share.transfer.model

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ModelsTest {
    @Test
    fun classifiesByMimeThenExtension() {
        assertEquals(FileCategory.IMAGE, FileCategory.classify("a.bin", "image/png"))
        assertEquals(FileCategory.IMAGE, FileCategory.classify("IMG_1.HEIC", null))
        assertEquals(FileCategory.VIDEO, FileCategory.classify("clip.mkv", null))
        assertEquals(FileCategory.AUDIO, FileCategory.classify("a.flac", "application/octet-stream"))
        assertEquals(FileCategory.DOCUMENT, FileCategory.classify("a.pdf", null))
        assertEquals(FileCategory.ARCHIVE, FileCategory.classify("a.7z", null))
        assertEquals(FileCategory.APK, FileCategory.classify("a.apk", null))
        assertEquals(FileCategory.APK, FileCategory.classify("bundle.aeroapks", null))
        assertEquals(FileCategory.APK, FileCategory.classify("x", "application/vnd.android.package-archive"))
        assertEquals(FileCategory.OTHER, FileCategory.classify("noext", null))
    }

    @Test
    fun categoryMaskRoundTrip() {
        val set = setOf(FileCategory.IMAGE, FileCategory.APK, FileCategory.OTHER)
        assertEquals(set, FileCategory.fromMask(FileCategory.maskOf(set)))
        assertEquals(emptySet<FileCategory>(), FileCategory.fromMask(0))
        assertEquals(FileCategory.OTHER, FileCategory.fromCode(99))
        assertEquals(DeviceKind.OTHER, DeviceKind.fromCode(-1))
    }

    @Test
    fun stateMachineRules() {
        assertTrue(TransferStateMachine.canTransition(TransferState.WAITING, TransferState.CONNECTING))
        assertTrue(TransferStateMachine.canTransition(TransferState.TRANSFERRING, TransferState.PAUSED))
        assertTrue(TransferStateMachine.canTransition(TransferState.INTERRUPTED, TransferState.WAITING))
        assertTrue(TransferStateMachine.canTransition(TransferState.FAILED, TransferState.WAITING))
        assertFalse(TransferStateMachine.canTransition(TransferState.COMPLETED, TransferState.WAITING))
        assertFalse(TransferStateMachine.canTransition(TransferState.CANCELLED, TransferState.WAITING))
        assertFalse(TransferStateMachine.canTransition(TransferState.WAITING, TransferState.COMPLETED))
        for (s in TransferState.values()) assertTrue(TransferStateMachine.canTransition(s, s))
    }

    @Test
    fun fractionIsClamped() {
        val s = TransferSnapshot("x", TransferDirection.SEND, TransferState.TRANSFERRING, totalBytes = 100, transferredBytes = 250)
        assertEquals(1f, s.fraction, 0f)
        assertEquals(0f, s.copy(totalBytes = 0).fraction, 0f)
        assertEquals(0.5f, s.copy(transferredBytes = 50).fraction, 0.0001f)
    }
}
