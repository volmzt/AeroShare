package com.aero.share.transfer.path

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PathSafetyTest {
    @Test
    fun acceptsOrdinaryPaths() {
        assertEquals("a/b/c.txt", PathSafety.sanitizeRelativePath("a/b/c.txt"))
        assertEquals("report.pdf", PathSafety.sanitizeRelativePath("report.pdf"))
        assertEquals("dir/file.txt", PathSafety.sanitizeRelativePath("dir\\file.txt"))
        assertEquals("a/b", PathSafety.sanitizeRelativePath("./a//b"))
        assertEquals("Фото/Відпустка 2024/img (1).jpg", PathSafety.sanitizeRelativePath("Фото/Відпустка 2024/img (1).jpg"))
    }

    @Test
    fun rejectsTraversalAbsoluteAndEmpty() {
        for (bad in listOf("", "/", "/etc/passwd", "../x", "a/../../b", "a/..", "..", "C:\\Windows\\x", "c:/x", "\\\\server\\share\\x", ".")) {
            assertNull("must reject '$bad'", PathSafety.sanitizeRelativePath(bad))
        }
    }

    @Test
    fun rejectsTooDeepAndTooLong() {
        val deep = (1..40).joinToString("/") { "d$it" } + "/f.txt"
        assertNull(PathSafety.sanitizeRelativePath(deep))
        val long = (1..10).joinToString("/") { "x".repeat(200) }
        assertNull(PathSafety.sanitizeRelativePath(long))
    }

    @Test
    fun replacesIllegalCharactersAndTrimsTrailingDots() {
        assertEquals("a_b_c_.txt", PathSafety.sanitizeRelativePath("a:b*c?.txt"))
        assertEquals("name", PathSafety.sanitizeRelativePath("name. "))
        assertEquals("x_y.txt", PathSafety.sanitizeRelativePath("x\u0001y.txt"))
        assertEquals("_CON.txt", PathSafety.sanitizeRelativePath("CON.txt"))
        assertEquals("d/_nul", PathSafety.sanitizeRelativePath("d/nul"))
    }

    @Test
    fun fileNamesAreNeverEmptyOrTraversing() {
        assertEquals("evil.sh", PathSafety.sanitizeFileName("../../evil.sh"))
        assertEquals("_", PathSafety.sanitizeFileName(".."))
        assertEquals("_", PathSafety.sanitizeFileName(""))
        assertEquals("a.txt", PathSafety.sanitizeFileName("x\\y\\a.txt"))
    }

    @Test
    fun longNamesAreTruncatedKeepingExtension() {
        val name = "я".repeat(300) + ".jpeg"
        val safe = PathSafety.sanitizeFileName(name)
        assertTrue(safe.toByteArray(Charsets.UTF_8).size <= PathSafety.MAX_SEGMENT_BYTES)
        assertTrue(safe.endsWith(".jpeg"))
        assertNotNull(PathSafety.sanitizeRelativePath("dir/$name"))
    }

    @Test
    fun uniqueNameAddsCounterBeforeExtension() {
        val taken = mutableSetOf("a.txt", "a (1).txt")
        assertEquals("fresh.txt", PathSafety.uniqueName("fresh.txt") { it in taken })
        assertEquals("a (2).txt", PathSafety.uniqueName("a.txt") { it in taken })
        assertEquals("noext (1)", PathSafety.uniqueName("noext") { it == "noext" })
        assertEquals(".hidden (1)", PathSafety.uniqueName(".hidden") { it == ".hidden" })
    }
}
