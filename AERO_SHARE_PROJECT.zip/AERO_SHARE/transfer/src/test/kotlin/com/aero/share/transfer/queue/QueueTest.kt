package com.aero.share.transfer.queue

import com.aero.share.transfer.engine.TransferResult
import com.aero.share.transfer.model.TransferControl
import com.aero.share.transfer.model.TransferDirection
import com.aero.share.transfer.model.TransferFailure
import com.aero.share.transfer.model.TransferSnapshot
import com.aero.share.transfer.model.TransferState
import com.aero.share.transfer.model.TransferTracker
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class QueueTest {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    @After
    fun tearDown() {
        scope.cancel()
    }

    private fun job(id: String): QueuedJob<String> = QueuedJob(
        id = id,
        payload = id,
        tracker = TransferTracker(TransferSnapshot(id, TransferDirection.SEND, TransferState.WAITING)),
        control = TransferControl(),
    )

    private fun <T> blocking(block: suspend () -> T): T = runBlocking { withTimeout(15_000) { block() } }

    private suspend fun QueuedJob<String>.await(state: TransferState) {
        tracker.state.first { it.state == state }
    }

    private fun TransferTracker.set(state: TransferState) = update { it.copy(state = state) }

    @Test
    fun runsJobsOneAtATimeInOrder() = blocking {
        val order = CopyOnWriteArrayList<String>()
        val active = AtomicInteger(0)
        val maxActive = AtomicInteger(0)
        val queue = TransferQueue<String>(scope, { j ->
            val now = active.incrementAndGet()
            maxActive.updateAndGet { maxOf(it, now) }
            order.add(j.id)
            j.tracker.set(TransferState.TRANSFERRING)
            kotlinx.coroutines.delay(20)
            j.tracker.set(TransferState.COMPLETED)
            active.decrementAndGet()
            TransferResult.Completed(1, 1)
        })
        val jobs = listOf(job("a"), job("b"), job("c"))
        jobs.forEach { queue.enqueue(it) }
        jobs.forEach { it.await(TransferState.COMPLETED) }
        assertEquals(listOf("a", "b", "c"), order.toList())
        assertEquals(1, maxActive.get())
        assertEquals(listOf("a", "b", "c"), queue.jobs.value.map { it.id })
    }

    @Test
    fun cancelledWaitingJobNeverRuns() = blocking {
        val gate = CompletableDeferred<Unit>()
        val ran = CopyOnWriteArrayList<String>()
        val queue = TransferQueue<String>(scope, { j ->
            ran.add(j.id)
            j.tracker.set(TransferState.TRANSFERRING)
            gate.await()
            j.tracker.set(TransferState.COMPLETED)
            TransferResult.Completed(1, 1)
        })
        val a = job("a")
        val b = job("b")
        queue.enqueue(a)
        queue.enqueue(b)
        a.await(TransferState.TRANSFERRING)
        queue.cancel("b")
        b.await(TransferState.CANCELLED)
        assertTrue(b.control.isCancelled)
        gate.complete(Unit)
        a.await(TransferState.COMPLETED)
        assertEquals(listOf("a"), ran.toList())
        assertNotNull(b.tracker.current.finishedAt)
    }

    @Test
    fun cancellingRunningJobSignalsRunnerAndReconcilesState() = blocking {
        val queue = TransferQueue<String>(scope, { j ->
            j.tracker.set(TransferState.TRANSFERRING)
            j.control.awaitCancelled()
            TransferResult.Cancelled // does not publish a state itself
        })
        val a = job("a")
        queue.enqueue(a)
        a.await(TransferState.TRANSFERRING)
        queue.cancel("a")
        a.await(TransferState.CANCELLED)
        assertNotNull(a.tracker.current.finishedAt)
    }

    @Test
    fun pausedWaitingJobIsSkippedUntilResumed() = blocking {
        val gate = CompletableDeferred<Unit>()
        val ran = CopyOnWriteArrayList<String>()
        val queue = TransferQueue<String>(scope, { j ->
            ran.add(j.id)
            j.tracker.set(TransferState.TRANSFERRING)
            if (j.id == "a") gate.await()
            j.tracker.set(TransferState.COMPLETED)
            TransferResult.Completed(1, 1)
        })
        val a = job("a")
        val b = job("b")
        val c = job("c")
        queue.enqueue(a)
        a.await(TransferState.TRANSFERRING)
        queue.enqueue(b)
        queue.enqueue(c)
        queue.pause("b")
        b.await(TransferState.PAUSED)
        gate.complete(Unit)
        c.await(TransferState.COMPLETED)
        assertEquals(listOf("a", "c"), ran.toList())
        assertEquals(TransferState.PAUSED, b.tracker.current.state)
        queue.resume("b")
        b.await(TransferState.COMPLETED)
        assertEquals(listOf("a", "c", "b"), ran.toList())
    }

    @Test
    fun failedJobCanBeRetriedAndMovesToTheEnd() = blocking {
        val calls = AtomicInteger(0)
        val queue = TransferQueue<String>(scope, { j ->
            if (j.id == "x" && calls.incrementAndGet() == 1) {
                j.tracker.update { it.copy(state = TransferState.FAILED, failure = TransferFailure.UNREACHABLE) }
                TransferResult.Failed(TransferFailure.UNREACHABLE, null, false)
            } else {
                j.tracker.set(TransferState.COMPLETED)
                TransferResult.Completed(1, 1)
            }
        })
        val x = job("x")
        val y = job("y")
        queue.enqueue(x)
        queue.enqueue(y)
        x.await(TransferState.FAILED)
        y.await(TransferState.COMPLETED)
        assertEquals(TransferFailure.UNREACHABLE, x.tracker.current.failure)
        queue.retry("x")
        x.await(TransferState.COMPLETED)
        assertEquals(2, calls.get())
        assertNull(x.tracker.current.failure)
        assertEquals(listOf("y", "x"), queue.jobs.value.map { it.id })
        queue.retry("y") // completed jobs cannot be retried
        assertEquals(TransferState.COMPLETED, y.tracker.current.state)
    }

    @Test
    fun runnerExceptionBecomesInternalFailureAndQueueContinues() = blocking {
        val queue = TransferQueue<String>(scope, { j ->
            if (j.id == "boom") throw IllegalStateException("secret detail")
            j.tracker.set(TransferState.COMPLETED)
            TransferResult.Completed(1, 1)
        })
        val boom = job("boom")
        val ok = job("ok")
        queue.enqueue(boom)
        queue.enqueue(ok)
        boom.await(TransferState.FAILED)
        ok.await(TransferState.COMPLETED)
        assertEquals(TransferFailure.INTERNAL, boom.tracker.current.failure)
        assertFalse(boom.tracker.current.failureDetail.orEmpty().contains("secret"))
    }

    @Test
    fun resumableFailureBecomesInterruptedWhenRunnerDoesNotPublish() = blocking {
        val queue = TransferQueue<String>(scope, { _ ->
            TransferResult.Failed(TransferFailure.INTERRUPTED, "link lost", true)
        })
        val a = job("a")
        queue.enqueue(a)
        a.await(TransferState.INTERRUPTED)
        assertTrue(a.tracker.current.resumable)
        assertEquals(TransferFailure.INTERRUPTED, a.tracker.current.failure)
    }

    @Test
    fun snapshotsFollowTrackersAndRemoveWorksOnlyForFinishedJobs() = blocking {
        val gate = CompletableDeferred<Unit>()
        val queue = TransferQueue<String>(scope, { j ->
            j.tracker.update { it.copy(state = TransferState.TRANSFERRING, totalBytes = 100, transferredBytes = 40) }
            gate.await()
            j.tracker.set(TransferState.COMPLETED)
            TransferResult.Completed(1, 100)
        })
        val a = job("a")
        queue.enqueue(a)
        a.await(TransferState.TRANSFERRING)
        withTimeout(5_000) { queue.snapshots.first { s -> s.size == 1 && s[0].transferredBytes == 40L } }
        queue.remove("a") // still running: ignored
        assertEquals(1, queue.jobs.value.size)
        gate.complete(Unit)
        a.await(TransferState.COMPLETED)
        withTimeout(5_000) { queue.snapshots.first { s -> s.size == 1 && s[0].state == TransferState.COMPLETED } }
        queue.remove("a")
        assertTrue(queue.jobs.value.isEmpty())
        assertTrue(queue.snapshots.value.isEmpty())
        assertNull(queue.get("a"))
    }

    @Test
    fun scopeCancellationMarksRunningJobInterrupted() = blocking {
        val own = CoroutineScope(SupervisorJob() + Dispatchers.Default)
        val queue = TransferQueue<String>(own, { j ->
            j.tracker.set(TransferState.TRANSFERRING)
            awaitCancellation()
        })
        val a = job("a")
        queue.enqueue(a)
        a.await(TransferState.TRANSFERRING)
        own.cancel()
        a.await(TransferState.INTERRUPTED)
        assertTrue(a.tracker.current.resumable)
    }

    @Test
    fun duplicateIdIsIgnored() = blocking {
        val queue = TransferQueue<String>(scope, { j ->
            j.tracker.set(TransferState.COMPLETED)
            TransferResult.Completed(1, 1)
        })
        val a = job("a")
        queue.enqueue(a)
        queue.enqueue(job("a"))
        a.await(TransferState.COMPLETED)
        assertEquals(1, queue.jobs.value.size)
    }
}
