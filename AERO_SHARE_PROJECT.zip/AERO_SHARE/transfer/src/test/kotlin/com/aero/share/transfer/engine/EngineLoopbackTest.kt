package com.aero.share.transfer.engine

import com.aero.share.transfer.model.FileCategory
import com.aero.share.transfer.model.PeerTrust
import com.aero.share.transfer.model.TransferControl
import com.aero.share.transfer.model.TransferState
import java.io.File
import kotlin.random.Random
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.After
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

class EngineLoopbackTest {
    @get:Rule
    val tmp = TemporaryFolder()

    private var harness: Harness? = null

    private fun harness(): Harness = Harness(tmp.newFolder("h${System.nanoTime()}")).start().also { harness = it }

    @After
    fun tearDown() {
        harness?.stop()
    }

    @Test
    fun sendsFilesAndFolderTreeIntact() = runBlocking {
        val h = harness()
        val rnd = Random(1)
        val files = listOf(
            MemoryFile(1, "report.pdf", rnd.nextBytes(300_000)),
            MemoryFile(2, "Photos/2024/img1.jpg", rnd.nextBytes(1_000_000)),
            MemoryFile(3, "Photos/2024/notes.txt", "hello мир ".repeat(1000).toByteArray()),
            MemoryFile(4, "Photos/empty.bin", ByteArray(0)),
            MemoryFile(5, "deep/a/b/c/d.dat", rnd.nextBytes(70_000)),
        )
        val total = files.sumOf { it.size }
        val tracker = h.tracker("t1")
        val result = withTimeout(30_000) { h.sender().send(h.target(), h.request(files, "t1", title = "Test"), TransferControl(), tracker) }
        assertEquals(TransferResult.Completed(5, total), result)
        for (f in files) assertArrayEquals(f.relativePath, f.data, h.received(f.relativePath))

        val s = tracker.current
        assertEquals(TransferState.COMPLETED, s.state)
        assertEquals(total, s.transferredBytes)
        assertEquals(5, s.completedFiles)
        assertEquals(1f, s.fraction, 0f)
        assertNotNull(s.finishedAt)
        assertEquals("Receiver Phone", s.peerName)
        assertEquals(h.serverId.fingerprint, s.peer?.fingerprint)

        val offer = h.offers.single()
        assertEquals(5, offer.fileCount)
        assertEquals(total, offer.totalBytes)
        assertEquals("Test", offer.title)
        assertEquals(h.clientId.fingerprint, offer.peer.fingerprint)
        assertEquals(PeerTrust.UNKNOWN, offer.trust)
        assertFalse(offer.authenticatedByQr)
        assertTrue(offer.categories.containsAll(listOf(FileCategory.DOCUMENT, FileCategory.IMAGE, FileCategory.OTHER)))
        // first contact: both devices show the same verification code
        assertNotNull(offer.verificationCode)
        assertEquals(offer.verificationCode, s.verificationCode)

        val session = h.awaitSession()
        val received = withTimeout(10_000) { session.completion.await() }
        assertEquals(TransferResult.Completed(5, total), received)
        val rs = session.tracker.current
        assertEquals(TransferState.COMPLETED, rs.state)
        assertEquals(5, rs.savedFiles.size)
        assertEquals(total, rs.transferredBytes)
        assertTrue(h.parts.walkTopDown().none { it.isFile })
    }
}
