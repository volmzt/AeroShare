package com.aero.share.transfer.engine

import com.aero.share.transfer.model.ConflictPolicy
import com.aero.share.transfer.model.DeviceKind
import com.aero.share.transfer.model.FileCategory
import com.aero.share.transfer.model.LocalPeer
import com.aero.share.transfer.model.ManifestEntry
import com.aero.share.transfer.model.PeerInfo
import com.aero.share.transfer.model.PeerTrust
import com.aero.share.transfer.model.SavedFile
import com.aero.share.transfer.model.TransferDirection
import com.aero.share.transfer.model.TransferFailure
import com.aero.share.transfer.model.TransferSnapshot
import com.aero.share.transfer.model.TransferState
import com.aero.share.transfer.model.TransferTracker
import com.aero.share.transfer.model.TransportKind
import com.aero.share.transfer.pairing.PairTokenRegistry
import com.aero.share.transfer.security.DeviceIdentity
import com.aero.share.transfer.storage.FileIncomingStorage
import com.aero.share.transfer.storage.IncomingStorage
import com.aero.share.transfer.storage.IncomingTransferStore
import com.aero.share.transfer.storage.PartWriter
import com.aero.share.transfer.storage.PartialInfo
import java.io.ByteArrayInputStream
import java.io.File
import java.io.InputStream
import java.security.MessageDigest
import java.util.UUID
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout

/** In-memory source file. */
class MemoryFile(
    override val id: Int,
    override val relativePath: String,
    val data: ByteArray,
    override val lastModified: Long = 1_700_000_000_000L,
    override val mimeType: String? = null,
) : SendableFile {
    override val size: Long get() = data.size.toLong()
    override val category: FileCategory get() = FileCategory.classify(relativePath, mimeType)
    @Volatile var reportedVersion: SourceVersion? = null
    @Volatile var onOpen: (() -> Unit)? = null

    override fun open(offset: Long): InputStream {
        onOpen?.invoke()
        return ByteArrayInputStream(data, offset.toInt(), data.size - offset.toInt())
    }

    override fun currentVersion(): SourceVersion? = reportedVersion ?: SourceVersion(size, lastModified)
}

/** Deterministic pseudo-random content of any size without storing it. */
class GeneratedStream(private val size: Long, private val seed: Long, start: Long) : InputStream() {
    private var pos = start

    override fun read(): Int {
        if (pos >= size) return -1
        val b = byteAt(pos)
        pos++
        return b.toInt() and 0xFF
    }

    override fun read(b: ByteArray, off: Int, len: Int): Int {
        if (pos >= size) return -1
        val n = minOf(len.toLong(), size - pos).toInt()
        var i = 0
        while (i < n && (pos + i) and 7L != 0L) {
            b[off + i] = byteAt(pos + i)
            i++
        }
        while (i + 8 <= n) {
            val x = mix(seed + ((pos + i) shr 3))
            for (k in 0 until 8) b[off + i + k] = (x ushr (8 * k)).toByte()
            i += 8
        }
        while (i < n) {
            b[off + i] = byteAt(pos + i)
            i++
        }
        pos += n
        return n
    }

    private fun byteAt(p: Long): Byte = (mix(seed + (p shr 3)) ushr (8 * (p and 7).toInt())).toByte()

    private fun mix(z0: Long): Long {
        var z = z0 + -7046029254386353131L
        z = (z xor (z ushr 30)) * -4658895280553007687L
        z = (z xor (z ushr 27)) * -7723592293110705685L
        return z xor (z ushr 31)
    }

    companion object {
        fun sha256(size: Long, seed: Long): String {
            val md = MessageDigest.getInstance("SHA-256")
            val buf = ByteArray(1 shl 20)
            val s = GeneratedStream(size, seed, 0)
            while (true) {
                val n = s.read(buf, 0, buf.size)
                if (n < 0) break
                md.update(buf, 0, n)
            }
            return com.aero.share.transfer.security.Fingerprints.toHex(md.digest())
        }
    }
}

class VirtualFile(
    override val id: Int,
    override val relativePath: String,
    override val size: Long,
    private val seed: Long = 11,
    override val lastModified: Long = 1_700_000_000_000L,
) : SendableFile {
    override val category: FileCategory get() = FileCategory.OTHER
    override val mimeType: String? get() = null
    override fun open(offset: Long): InputStream = GeneratedStream(size, seed, offset)
    override fun currentVersion(): SourceVersion = SourceVersion(size, lastModified)
}

/** Storage that discards the data but counts it (proves bounded memory for huge files). */
class CountingStorage : IncomingStorage {
    val bytesWritten = AtomicLong(0)
    val published = CopyOnWriteArrayList<SavedFile>()

    override fun availableBytes(): Long? = null
    override fun destinationLabel(): String = "counting"

    override fun open(transferId: String, title: String?, peerKey: String): IncomingTransferStore = object : IncomingTransferStore {
        override fun partial(entry: ManifestEntry): PartialInfo? = null
        override fun completed(entry: ManifestEntry): SavedFile? = null
        override fun createPart(entry: ManifestEntry): PartWriter = object : PartWriter {
            override var size: Long = 0
            override fun write(buf: ByteArray, off: Int, len: Int) {
                size += len
                bytesWritten.addAndGet(len.toLong())
            }
            override fun openPrefix(length: Long): InputStream = ByteArrayInputStream(ByteArray(0))
            override fun truncate(length: Long) {}
            override fun sync() {}
            override fun close() {}
        }
        override fun reopenPart(entry: ManifestEntry): PartWriter? = null
        override fun commit(entry: ManifestEntry, part: PartWriter, sha256: String): SavedFile {
            val f = SavedFile("count://${entry.id}", entry.relativePath, entry.relativePath, part.size, entry.mimeType, entry.category, sha256)
            published.add(f)
            return f
        }
        override fun discard(entry: ManifestEntry) {}
        override fun discardAll() {}
        override fun finish() {}
    }
}

/** Counts what the receiver writes into parts (to prove a resumed transfer sends only the missing bytes). */
class MeteredStorage(private val inner: IncomingStorage) : IncomingStorage by inner {
    val partBytesWritten = AtomicLong(0)
    val createdParts = CopyOnWriteArrayList<String>()

    override fun open(transferId: String, title: String?, peerKey: String): IncomingTransferStore {
        val s = inner.open(transferId, title, peerKey)
        return object : IncomingTransferStore by s {
            override fun createPart(entry: ManifestEntry): PartWriter {
                createdParts.add(entry.relativePath)
                return Counting(s.createPart(entry))
            }

            override fun reopenPart(entry: ManifestEntry): PartWriter? = s.reopenPart(entry)?.let { Counting(it) }

            override fun commit(entry: ManifestEntry, part: PartWriter, sha256: String): SavedFile =
                s.commit(entry, (part as? Counting)?.inner ?: part, sha256)
        }
    }

    private inner class Counting(val inner: PartWriter) : PartWriter by inner {
        override fun write(buf: ByteArray, off: Int, len: Int) {
            partBytesWritten.addAndGet(len.toLong())
            inner.write(buf, off, len)
        }
    }
}

/** Two devices on loopback: one receiver server plus factory methods for senders. */
class Harness(
    private val root: File,
    val config: EngineConfig = EngineConfig(
        chunkSize = 64 * 1024,
        connectTimeoutMs = 3_000,
        idleTimeoutMs = 6_000,
        pingIntervalMs = 300,
        acceptTimeoutMs = 4_000,
        pauseTimeoutMs = 20_000,
        progressIntervalMs = 20,
    ),
    var clock: () -> Long = { System.currentTimeMillis() },
) {
    val serverId: DeviceIdentity = DeviceIdentity.generate("receiver")
    val clientId: DeviceIdentity = DeviceIdentity.generate("sender")
    val receiverLocal = LocalPeer(serverId.deviceId, "Receiver Phone", DeviceKind.PHONE, "1.0.0")
    val senderLocal = LocalPeer(clientId.deviceId, "Sender Tablet", DeviceKind.TABLET, "1.0.0")
    val tokens = PairTokenRegistry { clock() }
    val dest = File(root, "dest").also { it.mkdirs() }
    val parts = File(root, "parts").also { it.mkdirs() }

    @Volatile var storage: IncomingStorage = FileIncomingStorage(dest, parts, ConflictPolicy.KEEP_BOTH)

    @Volatile var trust = PeerTrust.UNKNOWN

    @Volatile var decide: suspend (IncomingOffer) -> OfferDecision = { OfferDecision.Accept }
    val offers = CopyOnWriteArrayList<IncomingOffer>()
    val rejected = CopyOnWriteArrayList<TransferFailure>()
    val sessions = LinkedBlockingQueue<ReceiveSession>()
    val logs = CopyOnWriteArrayList<String>()

    private val listener = object : IncomingListener {
        override suspend fun onOffer(offer: IncomingOffer): OfferDecision {
            offers.add(offer)
            return decide(offer)
        }

        override fun onSession(session: ReceiveSession) {
            sessions.add(session)
        }

        override fun onRejected(peer: PeerInfo?, remoteAddress: String, failure: TransferFailure) {
            rejected.add(failure)
        }
    }

    val server = ReceiverServer(
        serverId, { receiverLocal }, { config }, { trust }, tokens, { storage }, listener,
        EngineLogger { logs.add(it) },
    )
    var port = 0

    fun start(): Harness {
        port = runBlocking { server.start(0) }
        return this
    }

    fun stop() = server.stop()

    fun sender(cfg: EngineConfig = config) = TransferSender(clientId, senderLocal, cfg, EngineLogger { logs.add("S: $it") })

    fun target(
        pin: String? = serverId.fingerprint,
        token: ByteArray? = null,
        connector: SocketConnector = SocketConnector.DEFAULT,
        port: Int = this.port,
    ) = SendTarget("127.0.0.1", port, pin, token, TransportKind.LAN, connector)

    fun request(
        files: List<SendableFile>,
        id: String = UUID.randomUUID().toString(),
        compression: com.aero.share.transfer.model.CompressionMode = com.aero.share.transfer.model.CompressionMode.OFF,
        title: String? = null,
    ) = SendRequest(id, files, title, compression)

    fun tracker(id: String) = TransferTracker(TransferSnapshot(id, TransferDirection.SEND, TransferState.WAITING))

    fun awaitSession(timeoutMs: Long = 10_000): ReceiveSession =
        sessions.poll(timeoutMs, TimeUnit.MILLISECONDS) ?: error("no incoming session")

    fun received(path: String): ByteArray = File(dest, path).readBytes()
}

fun TransferTracker.awaitState(timeoutMs: Long = 15_000, predicate: (TransferSnapshot) -> Boolean): TransferSnapshot =
    try {
        runBlocking { withTimeout(timeoutMs) { state.first(predicate) } }
    } catch (e: kotlinx.coroutines.TimeoutCancellationException) {
        val here = Throwable().stackTrace.firstOrNull { it.className.contains("Test") && !it.className.contains("TestSupport") }
        throw AssertionError("timed out at $here; tracker=$current")
    }

/** Source whose reads block once [gateAt] bytes were delivered, until [release] is counted down. */
class GatedFile(
    override val id: Int,
    override val relativePath: String,
    val data: ByteArray,
    private val gateAt: Long,
    override val lastModified: Long = 1_700_000_000_000L,
) : SendableFile {
    val reached = java.util.concurrent.CountDownLatch(1)
    val release = java.util.concurrent.CountDownLatch(1)
    override val size: Long get() = data.size.toLong()
    override val category: FileCategory get() = FileCategory.classify(relativePath, null)
    override val mimeType: String? get() = null
    override fun currentVersion(): SourceVersion = SourceVersion(size, lastModified)

    override fun open(offset: Long): InputStream {
        val base = ByteArrayInputStream(data, offset.toInt(), data.size - offset.toInt())
        var pos = offset
        return object : InputStream() {
            override fun read(): Int {
                val one = ByteArray(1)
                return if (read(one, 0, 1) < 0) -1 else one[0].toInt() and 0xFF
            }

            override fun read(b: ByteArray, off: Int, len: Int): Int {
                if (pos >= gateAt && release.count > 0) {
                    reached.countDown()
                    release.await(30, TimeUnit.SECONDS)
                }
                val allowed = if (pos < gateAt && release.count > 0) minOf(len.toLong(), gateAt - pos).toInt() else len
                val n = base.read(b, off, allowed)
                if (n > 0) pos += n
                return n
            }
        }
    }
}

/** Remembers the plain TCP socket of the last connection so a test can cut the link. */
class CapturingConnector : SocketConnector {
    @Volatile var socket: java.net.Socket? = null
    override fun connect(host: String, port: Int, timeoutMs: Int): java.net.Socket =
        SocketConnector.DEFAULT.connect(host, port, timeoutMs).also { socket = it }
}

/** Minimal protocol client for tests that need to violate the protocol. */
class RawClient(
    h: Harness,
    val identity: DeviceIdentity = h.clientId,
    pin: String? = h.serverId.fingerprint,
) : AutoCloseable {
    val ssl: javax.net.ssl.SSLSocket
    val reader: com.aero.share.transfer.proto.FrameReader
    val writer: com.aero.share.transfer.proto.FrameWriter

    init {
        val plain = java.net.Socket()
        plain.connect(java.net.InetSocketAddress("127.0.0.1", h.port), 3_000)
        ssl = com.aero.share.transfer.security.TlsContexts.wrapClient(
            com.aero.share.transfer.security.TlsContexts.client(identity, pin), plain, "127.0.0.1", h.port,
        )
        ssl.soTimeout = 5_000
        ssl.startHandshake()
        reader = com.aero.share.transfer.proto.FrameReader(java.io.BufferedInputStream(ssl.inputStream))
        writer = com.aero.share.transfer.proto.FrameWriter(ssl.outputStream)
    }

    /** Next frame, skipping keep-alive PINGs. */
    fun next(): com.aero.share.transfer.proto.Frame {
        while (true) {
            val f = reader.read()
            if (f.type != com.aero.share.transfer.proto.FrameType.PING) return f
        }
    }

    fun expect(type: Int): com.aero.share.transfer.proto.Frame {
        val f = next()
        org.junit.Assert.assertEquals("frame type", type, f.type)
        return f
    }

    fun hello(token: ByteArray? = null, deviceId: String = identity.deviceId, version: Int = 1): com.aero.share.transfer.proto.HelloAck {
        writer.write(
            com.aero.share.transfer.proto.FrameType.HELLO,
            com.aero.share.transfer.proto.Hello(version, deviceId, "Raw client", 0, "1.0", com.aero.share.transfer.model.Capabilities.ALL, token).encode(),
        )
        return com.aero.share.transfer.proto.HelloAck.decode(expect(com.aero.share.transfer.proto.FrameType.HELLO_ACK))
    }

    fun offer(
        transferId: String,
        entries: List<com.aero.share.transfer.proto.WireEntry>,
        total: Long = entries.sumOf { it.size },
        count: Long = entries.size.toLong(),
    ) {
        writer.write(
            com.aero.share.transfer.proto.FrameType.OFFER,
            com.aero.share.transfer.proto.OfferHeader(transferId, count, total, false, false, 0, null).encode(),
        )
        for (b in com.aero.share.transfer.proto.OfferEntriesCodec.encodeBatches(entries)) {
            writer.write(com.aero.share.transfer.proto.FrameType.OFFER_ENTRIES, b)
        }
        writer.write(com.aero.share.transfer.proto.FrameType.OFFER_END)
    }

    fun readReply(): com.aero.share.transfer.proto.OfferReply =
        com.aero.share.transfer.proto.OfferReply.decode(expect(com.aero.share.transfer.proto.FrameType.OFFER_REPLY), 100_000)

    override fun close() {
        try {
            ssl.close()
        } catch (e: Exception) {
            // ignore
        }
    }
}

fun wireEntry(id: Long, path: String, size: Long, mtime: Long = 1_700_000_000_000L) =
    com.aero.share.transfer.proto.WireEntry(id, path, size, mtime, FileCategory.OTHER.code, null)

fun sha256Bytes(b: ByteArray): ByteArray = MessageDigest.getInstance("SHA-256").digest(b)

/** A scripted fake receiver (own identity) for tests of the sender against misbehaving peers. */
class FakeReceiver(
    val identity: DeviceIdentity = DeviceIdentity.generate("fake receiver"),
    private val script: (com.aero.share.transfer.proto.FrameReader, com.aero.share.transfer.proto.FrameWriter) -> Unit,
) : AutoCloseable {
    private val ss = com.aero.share.transfer.security.TlsContexts.createServerSocket(
        com.aero.share.transfer.security.TlsContexts.server(identity),
    ).also { it.bind(java.net.InetSocketAddress(java.net.InetAddress.getLoopbackAddress(), 0)) }
    val port: Int get() = ss.localPort

    init {
        Thread {
            try {
                val s = ss.accept() as javax.net.ssl.SSLSocket
                s.soTimeout = 5_000
                s.startHandshake()
                script(
                    com.aero.share.transfer.proto.FrameReader(java.io.BufferedInputStream(s.inputStream)),
                    com.aero.share.transfer.proto.FrameWriter(s.outputStream),
                )
                s.close()
            } catch (t: Throwable) {
                // the test asserts on the sender side
            }
        }.also { it.isDaemon = true }.start()
    }

    fun ack(w: com.aero.share.transfer.proto.FrameWriter, status: Int = 0) = w.write(
        com.aero.share.transfer.proto.FrameType.HELLO_ACK,
        com.aero.share.transfer.proto.HelloAck(1, status, identity.deviceId, "Fake", 0, "1.0", com.aero.share.transfer.model.Capabilities.ALL, false, false).encode(),
    )

    override fun close() {
        try {
            ss.close()
        } catch (e: Exception) {
            // ignore
        }
    }
}
