package com.aero.share.transfer.pairing

import com.aero.share.transfer.model.DeviceKind
import com.aero.share.transfer.security.DeviceIdentity
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PairingTest {
    @Test
    fun tokenIsSingleUseByDefault() {
        val reg = PairTokenRegistry()
        val t = reg.issue(60_000)
        assertEquals(16, t.bytes.size)
        assertEquals(1, reg.activeCount())
        assertTrue(reg.consume(t.bytes))
        assertFalse(reg.consume(t.bytes))
        assertEquals(0, reg.activeCount())
    }

    @Test
    fun tokenWithSeveralUsesAndWrongToken() {
        val reg = PairTokenRegistry()
        val t = reg.issue(60_000, maxUses = 2)
        assertFalse(reg.consume(ByteArray(16)))
        assertTrue(reg.consume(t.bytes))
        assertTrue(reg.consume(t.bytes))
        assertFalse(reg.consume(t.bytes))
    }

    @Test
    fun tokenExpires() {
        var now = 1_000L
        val reg = PairTokenRegistry { now }
        val t = reg.issue(5_000)
        now = 5_999
        assertEquals(1, reg.activeCount())
        now = 6_000
        assertEquals(0, reg.activeCount())
        assertFalse(reg.consume(t.bytes))
    }

    @Test
    fun invalidateAllDropsEverything() {
        val reg = PairTokenRegistry()
        val a = reg.issue(60_000)
        val b = reg.issue(60_000)
        reg.invalidateAll()
        assertFalse(reg.consume(a.bytes))
        assertFalse(reg.consume(b.bytes))
    }

    @Test
    fun tokensAreRandom() {
        val reg = PairTokenRegistry()
        assertFalse(reg.issue(1000).bytes.contentEquals(reg.issue(1000).bytes))
    }

    private fun payload(hotspot: HotspotCredentials? = null): QrPayload {
        val id = DeviceIdentity.generate()
        val token = PairTokenRegistry().issue(60_000)
        return QrPayload(
            version = 1,
            deviceId = id.deviceId,
            name = "Олексій & Pixel 8",
            kind = DeviceKind.PHONE,
            hosts = listOf("192.168.1.23", "fe80::1c2d:3eff:fe4f:5a6b"),
            port = 48_555,
            fingerprint = id.fingerprint,
            token = token.encoded,
            expiresAt = 1_700_000_123_456L,
            hotspot = hotspot,
        )
    }

    @Test
    fun qrRoundTrip() {
        val p = payload()
        val parsed = QrPayload.parse(p.encode())
        assertNotNull(parsed)
        assertEquals(p, parsed)
        assertArrayEquals(p.tokenBytes(), parsed!!.tokenBytes())
    }

    @Test
    fun qrRoundTripWithHotspot() {
        val p = payload(HotspotCredentials("DIRECT-ab-AERO", "pass word 123"))
        assertEquals(p, QrPayload.parse(p.encode()))
    }

    @Test
    fun qrParserRejectsMalformedInput() {
        val sample = payload()
        val good = sample.encode()
        val fp = sample.fingerprint
        assertNull(QrPayload.parse(""))
        assertNull(QrPayload.parse("https://example.com/?v=1"))
        assertNull(QrPayload.parse(good.replace("v=1", "v=2")))
        assertNull(QrPayload.parse(good.replace("&p=48555", "&p=0")))
        assertNull(QrPayload.parse(good.replace("&p=48555", "&p=70000")))
        assertNull(QrPayload.parse(good + "&p=1"))                       // duplicate key
        assertNull(QrPayload.parse(good.replace("&k=0", "&k=9")))
        assertNull(QrPayload.parse(good.replace(Regex("&id=[0-9a-f]{32}"), "&id=" + "0".repeat(32))))
        assertNull(QrPayload.parse(good.replace(fp, "xyz")))
        assertNull(QrPayload.parse(good.replace(Regex("&h=[^&]*"), "&h=evil.example.com")))
        assertNull(QrPayload.parse(good.replace(Regex("&h=[^&]*"), "&h=1.2.3.4,1.2.3.5,1.2.3.6,1.2.3.7,1.2.3.8")))
        assertNull(QrPayload.parse(good.replace(Regex("&h=[^&]*"), "&h=999.1.1.1")))
        assertNull(QrPayload.parse(good.replace(Regex("&t=[^&]*"), "&t=AAAA")))
        assertNull(QrPayload.parse(good + "&ssid=onlyssid"))
        assertNull(QrPayload.parse(good + "&ssid=net&pw=short"))
        assertNull(QrPayload.parse(good + "x".repeat(1200)))
        assertNull(QrPayload.parse(good.replace(Regex("&e=\\d+"), "&e=0")))
    }
}
