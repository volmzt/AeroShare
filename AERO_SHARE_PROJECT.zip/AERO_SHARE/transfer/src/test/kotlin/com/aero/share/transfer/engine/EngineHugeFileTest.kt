package com.aero.share.transfer.engine

import com.aero.share.transfer.model.ManifestEntry
import com.aero.share.transfer.model.SavedFile
import com.aero.share.transfer.model.TransferControl
import com.aero.share.transfer.model.TransferState
import com.aero.share.transfer.storage.IncomingStorage
import com.aero.share.transfer.storage.IncomingTransferStore
import com.aero.share.transfer.storage.PartWriter
import com.aero.share.transfer.storage.PartialInfo
import java.io.InputStream
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicLong
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

/**
 * Files beyond 2 GiB (Int range) streamed through the real TLS engine without ever being held in memory or on disk:
 * the source is generated on the fly and the destination only counts the bytes.
 */
class EngineHugeFileTest {
    @get:Rule
    val tmp = TemporaryFolder()

    private val created = ArrayList<Harness>()

    private val config = EngineConfig(
        chunkSize = 1 shl 20,
        connectTimeoutMs = 3_000,
        idleTimeoutMs = 4_000,
        pingIntervalMs = 300,
        acceptTimeoutMs = 4_000,
        pauseTimeoutMs = 20_000,
        progressIntervalMs = 100,
    )

    private fun harness(): Harness = Harness(tmp.newFolder("h${System.nanoTime()}"), config).start().also { created.add(it) }

    @After
    fun tearDown() {
        created.forEach { it.stop() }
    }

    @Test
    fun fileLargerThanTwoGibStreamsWithBoundedMemory() {
        val size = (1L shl 31) + 300L * 1024 * 1024 + 12_345 // ~2.3 GiB with an odd tail
        val seed = 4242L
        val h = harness()
        val counting = CountingStorage()
        h.storage = counting
        val tracker = h.tracker("huge")
        val result = runBlocking {
            withTimeout(600_000) { h.sender().send(h.target(), h.request(listOf(VirtualFile(1, "huge.bin", size, seed))), TransferControl(), tracker) }
        }
        assertTrue("sender result: $result (logs: ${h.logs.takeLast(5)})", result is TransferResult.Completed)
        assertEquals(size, counting.bytesWritten.get())
        val saved = counting.published.single()
        assertEquals(size, saved.size)
        assertEquals(GeneratedStream.sha256(size, seed), saved.sha256) // independent computation of the expected digest
        val snap = tracker.current
        assertEquals(TransferState.COMPLETED, snap.state)
        assertEquals(size, snap.transferredBytes)
        assertEquals(size, snap.totalBytes)
        assertEquals(1f, snap.fraction, 0f)
    }

    /** Pretends the first [have] bytes of a generated file were received earlier; nothing is stored. */
    private class VirtualResumeStorage(private val seed: Long, private val have: Long) : IncomingStorage {
        val written = AtomicLong(0)
        val published = CopyOnWriteArrayList<SavedFile>()
        @Volatile var restarted = false

        override fun availableBytes(): Long? = null
        override fun destinationLabel(): String = "virtual"

        private fun writer(): PartWriter = object : PartWriter {
            override var size: Long = have
            override fun write(buf: ByteArray, off: Int, len: Int) {
                size += len
                written.addAndGet(len.toLong())
            }
            override fun openPrefix(length: Long): InputStream = GeneratedStream(length, seed, 0)
            override fun truncate(length: Long) {
                restarted = true
            }
            override fun sync() {}
            override fun close() {}
        }

        override fun open(transferId: String, title: String?, peerKey: String): IncomingTransferStore = object : IncomingTransferStore {
            override fun partial(entry: ManifestEntry): PartialInfo = PartialInfo(have)
            override fun completed(entry: ManifestEntry): SavedFile? = null
            override fun createPart(entry: ManifestEntry): PartWriter {
                restarted = true
                return writer()
            }
            override fun reopenPart(entry: ManifestEntry): PartWriter = writer()
            override fun commit(entry: ManifestEntry, part: PartWriter, sha256: String): SavedFile {
                val f = SavedFile("virtual://${entry.id}", entry.relativePath, entry.relativePath, part.size, entry.mimeType, entry.category, sha256)
                published.add(f)
                return f
            }
            override fun discard(entry: ManifestEntry) {}
            override fun discardAll() {}
            override fun finish() {}
        }
    }

    @Test
    fun resumeFromAnOffsetBeyondTwoGibSendsOnlyTheRest() {
        val have = (1L shl 31) + 123_457 // already on the receiver, beyond Int range
        val size = have + 3L * 1024 * 1024 + 99
        val seed = 777L
        val h = harness()
        val storage = VirtualResumeStorage(seed, have)
        h.storage = storage
        val tracker = h.tracker("resume-huge")
        val result = runBlocking {
            withTimeout(600_000) { h.sender().send(h.target(), h.request(listOf(VirtualFile(1, "huge.bin", size, seed))), TransferControl(), tracker) }
        }
        assertTrue("sender result: $result (logs: ${h.logs.takeLast(5)})", result is TransferResult.Completed)
        assertTrue("the receiver must keep the partial data instead of restarting", !storage.restarted)
        assertEquals(size - have, storage.written.get())
        val saved = storage.published.single()
        assertEquals(size, saved.size)
        assertEquals(GeneratedStream.sha256(size, seed), saved.sha256)
        assertTrue(h.offers.single().isResume)
        assertEquals(have, h.offers.single().resumeBytes)
    }
}
