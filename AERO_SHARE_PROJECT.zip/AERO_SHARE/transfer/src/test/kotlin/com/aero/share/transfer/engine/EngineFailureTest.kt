package com.aero.share.transfer.engine

import com.aero.share.transfer.model.DeviceKind
import com.aero.share.transfer.model.LocalPeer
import com.aero.share.transfer.model.PeerTrust
import com.aero.share.transfer.model.TransferControl
import com.aero.share.transfer.model.TransferFailure
import com.aero.share.transfer.model.TransferState
import com.aero.share.transfer.security.DeviceIdentity
import com.aero.share.transfer.storage.IncomingStorage
import java.net.ServerSocket
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.random.Random
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.async
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

class EngineFailureTest {
    @get:Rule
    val tmp = TemporaryFolder()

    private val created = ArrayList<Harness>()

    private fun harness(config: EngineConfig? = null): Harness {
        val dir = tmp.newFolder("h${System.nanoTime()}")
        val h = if (config == null) Harness(dir) else Harness(dir, config)
        return h.start().also { created.add(it) }
    }

    @After
    fun tearDown() {
        created.forEach { it.stop() }
    }

    private fun small(id: Int = 1, path: String = "a.txt", size: Int = 5_000) = MemoryFile(id, path, Random(id).nextBytes(size))

    private fun send(h: Harness, files: List<SendableFile>, target: SendTarget = h.target(), control: TransferControl = TransferControl()) =
        runBlocking { withTimeout(30_000) { h.sender().send(target, h.request(files), control, h.tracker("x")) } }

    @Test
    fun declineIsReportedAndNothingIsWritten() {
        val h = harness()
        h.decide = { OfferDecision.Decline(DeclineReason.USER) }
        val result = send(h, listOf(small()))
        assertEquals(TransferResult.Failed(TransferFailure.DECLINED, null, false), result)
        assertTrue(h.dest.walkTopDown().none { it.isFile })
        assertTrue(h.sessions.isEmpty())
    }

    @Test
    fun secondDeviceGetsBusyWhileAnotherTransferIsWaitingForApproval() = runBlocking {
        val h = harness()
        val gate = CompletableDeferred<OfferDecision>()
        h.decide = { gate.await() }
        val first = async { h.sender().send(h.target(), h.request(listOf(small())), TransferControl(), h.tracker("first")) }
        withTimeout(10_000) { while (h.offers.isEmpty()) kotlinx.coroutines.delay(10) }

        val other = DeviceIdentity.generate("other sender")
        val otherSender = TransferSender(other, LocalPeer(other.deviceId, "Other", DeviceKind.PHONE, "1.0"), h.config)
        val tracker = h.tracker("second")
        val r = withTimeout(10_000) { otherSender.send(h.target(), h.request(listOf(small(2, "b.txt"))), TransferControl(), tracker) }
        assertEquals(TransferFailure.BUSY, (r as TransferResult.Failed).failure)
        assertEquals(TransferState.FAILED, tracker.current.state)
        assertTrue(h.rejected.contains(TransferFailure.BUSY))

        gate.complete(OfferDecision.Accept)
        assertTrue(withTimeout(20_000) { first.await() } is TransferResult.Completed)
    }

    @Test
    fun blockedDeviceIsRefused() {
        val h = harness()
        h.trust = PeerTrust.BLOCKED
        val r = send(h, listOf(small()))
        assertEquals(TransferFailure.BLOCKED, (r as TransferResult.Failed).failure)
        assertTrue(h.rejected.contains(TransferFailure.BLOCKED))
        assertTrue(h.offers.isEmpty())
    }

    @Test
    fun wrongPinnedFingerprintFailsAuthentication() {
        val h = harness()
        val r = send(h, listOf(small()), h.target(pin = DeviceIdentity.generate("impostor").fingerprint))
        assertEquals(TransferFailure.AUTH_FAILED, (r as TransferResult.Failed).failure)
        assertTrue(h.offers.isEmpty())
    }

    @Test
    fun qrTokenAuthenticatesOnceAndSkipsVerificationCode() {
        val h = harness()
        val token = h.tokens.issue(60_000)
        val files = listOf(small())
        val tracker = h.tracker("qr")
        val r = runBlocking {
            withTimeout(20_000) { h.sender().send(h.target(token = token.bytes), h.request(files), TransferControl(), tracker) }
        }
        assertTrue(r is TransferResult.Completed)
        val offer = h.offers.single()
        assertTrue(offer.authenticatedByQr)
        assertNull(offer.verificationCode)
        assertNull(tracker.current.verificationCode)

        // the same token cannot be used twice
        val again = send(h, listOf(small(3, "c.txt")), h.target(token = token.bytes))
        assertEquals(TransferFailure.AUTH_FAILED, (again as TransferResult.Failed).failure)
        assertTrue(h.rejected.contains(TransferFailure.AUTH_FAILED))
        assertEquals(1, h.offers.size)
    }

    @Test
    fun expiredQrTokenIsRefused() {
        var now = 1_000_000L
        val h = harness()
        h.clock = { now }
        val token = h.tokens.issue(5_000)
        now += 5_001
        val r = send(h, listOf(small()), h.target(token = token.bytes))
        assertEquals(TransferFailure.AUTH_FAILED, (r as TransferResult.Failed).failure)
        assertTrue(h.offers.isEmpty())
    }

    @Test
    fun closedPortIsReportedAsUnreachable() {
        val h = harness()
        val port = ServerSocket(0).use { it.localPort }
        val r = send(h, listOf(small()), h.target(port = port))
        assertEquals(TransferFailure.UNREACHABLE, (r as TransferResult.Failed).failure)
    }

    @Test
    fun silentPeerTimesOut() {
        val h = harness()
        ServerSocket(0).use { silent ->
            val acceptor = Thread { runCatching { silent.accept().use { Thread.sleep(3_000) } } }.also { it.isDaemon = true; it.start() }
            val cfg = h.config.copy(connectTimeoutMs = 500)
            val started = System.nanoTime()
            val r = runBlocking {
                withTimeout(20_000) {
                    h.sender(cfg).send(h.target(port = silent.localPort), h.request(listOf(small())), TransferControl(), h.tracker("t"))
                }
            }
            assertEquals(TransferFailure.TIMEOUT, (r as TransferResult.Failed).failure)
            assertTrue("gave up quickly", TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - started) < 5_000)
            acceptor.interrupt()
        }
    }

    @Test
    fun unansweredOfferTimesOutOnBothSides() {
        val h = harness(EngineConfig(chunkSize = 64 * 1024, connectTimeoutMs = 3_000, idleTimeoutMs = 6_000, pingIntervalMs = 300, acceptTimeoutMs = 600))
        val cancelled = AtomicBoolean(false)
        h.decide = {
            try {
                CompletableDeferred<OfferDecision>().await()
            } finally {
                cancelled.set(true)
            }
        }
        val r = send(h, listOf(small()))
        assertEquals(TransferFailure.TIMEOUT, (r as TransferResult.Failed).failure)
        assertTrue("the approval prompt was dismissed", cancelled.get())
    }

    @Test
    fun notEnoughSpaceIsReportedBeforeAskingTheUser() {
        val h = harness()
        val inner = h.storage
        h.storage = object : IncomingStorage by inner {
            override fun availableBytes(): Long = 10
        }
        val r = send(h, listOf(small(size = 5_000)))
        assertEquals(TransferFailure.NO_SPACE, (r as TransferResult.Failed).failure)
        assertTrue(h.offers.isEmpty())
        assertTrue(h.rejected.contains(TransferFailure.NO_SPACE))
    }

    @Test
    fun changedSourceFailsAndNothingIsPublished() {
        val h = harness()
        val f = small(size = 200_000)
        f.reportedVersion = SourceVersion(f.size + 1, f.lastModified)
        val r = send(h, listOf(f))
        assertEquals(TransferFailure.SOURCE_CHANGED, (r as TransferResult.Failed).failure)
        val session = h.awaitSession()
        val rr = runBlocking { withTimeout(10_000) { session.completion.await() } }
        assertEquals(TransferFailure.PEER_CANCELLED, (rr as TransferResult.Failed).failure)
        assertTrue(h.dest.walkTopDown().none { it.isFile })
        assertTrue(h.parts.walkTopDown().none { it.isFile })
    }

    @Test
    fun senderCancelStopsBothSidesAndDiscardsPartialData() {
        val h = harness()
        val gf = GatedFile(1, "big.bin", Random(5).nextBytes(1_048_576), gateAt = 262_144)
        val control = TransferControl()
        val tracker = h.tracker("c")
        val job = Thread {
            runBlocking { h.sender().send(h.target(), h.request(listOf(gf)), control, tracker) }
        }.also { it.start() }
        assertTrue(gf.reached.await(10, TimeUnit.SECONDS))
        val session = h.awaitSession()
        session.tracker.awaitState { it.transferredBytes >= 262_144 }
        control.cancel()
        gf.release.countDown()
        job.join(15_000)
        assertEquals(TransferState.CANCELLED, tracker.awaitState { it.state.isTerminal }.state)
        val rr = runBlocking { withTimeout(10_000) { session.completion.await() } }
        assertEquals(TransferFailure.PEER_CANCELLED, (rr as TransferResult.Failed).failure)
        assertTrue(h.dest.walkTopDown().none { it.isFile })
        assertTrue(h.parts.walkTopDown().none { it.isFile })
    }

    @Test
    fun receiverCancelStopsBothSidesAndDiscardsPartialData() {
        val h = harness()
        val gf = GatedFile(1, "big.bin", Random(6).nextBytes(1_048_576), gateAt = 262_144)
        val tracker = h.tracker("rc")
        val job = Thread {
            runBlocking { h.sender().send(h.target(), h.request(listOf(gf)), TransferControl(), tracker) }
        }.also { it.start() }
        assertTrue(gf.reached.await(10, TimeUnit.SECONDS))
        val session = h.awaitSession()
        session.tracker.awaitState { it.transferredBytes >= 262_144 }
        session.control.cancel()
        gf.release.countDown()
        job.join(15_000)
        val rr = runBlocking { withTimeout(10_000) { session.completion.await() } }
        assertEquals(TransferResult.Cancelled, rr)
        assertEquals(TransferState.CANCELLED, session.tracker.current.state)
        val s = tracker.awaitState { it.state.isTerminal }
        assertEquals(TransferFailure.PEER_CANCELLED, s.failure)
        assertTrue(h.dest.walkTopDown().none { it.isFile })
        assertTrue(h.parts.walkTopDown().none { it.isFile })
    }

    @Test
    fun cancelWhileTheUserIsStillDecidingDismissesThePrompt() {
        val h = harness()
        val promptCancelled = AtomicBoolean(false)
        h.decide = {
            try {
                CompletableDeferred<OfferDecision>().await()
            } finally {
                promptCancelled.set(true)
            }
        }
        val control = TransferControl()
        val tracker = h.tracker("w")
        val job = Thread { runBlocking { h.sender().send(h.target(), h.request(listOf(small())), control, tracker) } }.also { it.start() }
        runBlocking { withTimeout(10_000) { while (h.offers.isEmpty()) kotlinx.coroutines.delay(10) } }
        control.cancel()
        job.join(15_000)
        assertEquals(TransferState.CANCELLED, tracker.awaitState { it.state.isTerminal }.state)
        val deadline = System.currentTimeMillis() + 5_000
        while (!promptCancelled.get() && System.currentTimeMillis() < deadline) Thread.sleep(20)
        assertTrue("prompt must be dismissed when the sender cancels", promptCancelled.get())
        assertFalse(h.dest.walkTopDown().any { it.isFile })
    }

    @Test
    fun twoTransfersInARowWork() {
        val h = harness()
        assertTrue(send(h, listOf(small(1, "one.txt"))) is TransferResult.Completed)
        assertTrue(send(h, listOf(small(2, "two.txt"))) is TransferResult.Completed)
        assertEquals(2, h.dest.listFiles()!!.size)
    }
}
