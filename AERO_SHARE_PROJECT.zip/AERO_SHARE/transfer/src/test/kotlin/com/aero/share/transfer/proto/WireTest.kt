package com.aero.share.transfer.proto

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.EOFException
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test

class WireTest {
    private fun frameBytes(type: Int, payload: ByteArray): ByteArray {
        val out = ByteArrayOutputStream()
        FrameWriter(out).write(type, payload)
        return out.toByteArray()
    }

    private fun reader(vararg chunks: ByteArray): FrameReader {
        val all = ByteArrayOutputStream()
        chunks.forEach { all.write(it) }
        return FrameReader(ByteArrayInputStream(all.toByteArray()))
    }

    private fun header(type: Int, len: Long): ByteArray =
        byteArrayOf(type.toByte(), (len ushr 24).toByte(), (len ushr 16).toByte(), (len ushr 8).toByte(), len.toByte())

    private fun frameOf(bytes: ByteArray, type: Int = 0) = Frame(type, bytes, bytes.size)

    // ------------------------------------------------------------------ frames

    @Test
    fun framesRoundTripForAllSizes() {
        for (size in listOf(0, 1, 100, 65_535, 65_536, 65_537, 200_000, 2 * 1024 * 1024)) {
            val payload = ByteArray(size) { (it * 31 + size).toByte() }
            val f = reader(frameBytes(FrameType.FILE_DATA, payload)).read()
            assertEquals(FrameType.FILE_DATA, f.type)
            assertEquals(size, f.length)
            assertArrayEquals("size $size", payload, f.copyPayload())
        }
    }

    @Test
    fun backToBackFramesKeepTheirBoundaries() {
        val a = ByteArray(10) { 1 }
        val b = ByteArray(300_000) { 2 }
        val c = ByteArray(0)
        val r = reader(
            frameBytes(FrameType.OFFER, a), frameBytes(FrameType.FILE_DATA, b), frameBytes(FrameType.TRANSFER_END, c),
        )
        val f1 = r.read()
        assertEquals(FrameType.OFFER, f1.type)
        assertArrayEquals(a, f1.copyPayload())
        val f2 = r.read()
        assertEquals(FrameType.FILE_DATA, f2.type)
        assertArrayEquals(b, f2.copyPayload())
        val f3 = r.read()
        assertEquals(FrameType.TRANSFER_END, f3.type)
        assertEquals(0, f3.length)
        assertThrows(EOFException::class.java) { r.read() }
    }

    @Test
    fun headerIsBigEndian() {
        val bytes = frameBytes(FrameType.FILE_DATA, ByteArray(0x010203))
        assertEquals(0x31, bytes[0].toInt())
        assertEquals(0x00, bytes[1].toInt())
        assertEquals(0x01, bytes[2].toInt())
        assertEquals(0x02, bytes[3].toInt())
        assertEquals(0x03, bytes[4].toInt())
        assertEquals(5 + 0x010203, bytes.size)
    }

    @Test
    fun writeWithRoomProducesTheSameBytesAsWrite() {
        val payload = ByteArray(1234) { (it % 251).toByte() }
        val buf = ByteArray(WireLimits.HEADER_SIZE + payload.size + 7)
        System.arraycopy(payload, 0, buf, WireLimits.HEADER_SIZE, payload.size)
        val out = ByteArrayOutputStream()
        FrameWriter(out).writeWithRoom(FrameType.FILE_DATA, buf, payload.size)
        assertArrayEquals(frameBytes(FrameType.FILE_DATA, payload), out.toByteArray())
        assertThrows(IllegalArgumentException::class.java) {
            FrameWriter(ByteArrayOutputStream()).writeWithRoom(FrameType.FILE_DATA, ByteArray(10), 10)
        }
    }

    @Test
    fun writeAcceptsASliceOfABuffer() {
        val src = ByteArray(100) { it.toByte() }
        val out = ByteArrayOutputStream()
        FrameWriter(out).write(FrameType.FILE_DATA, src, 10, 20)
        val f = FrameReader(ByteArrayInputStream(out.toByteArray())).read()
        assertArrayEquals(src.copyOfRange(10, 30), f.copyPayload())
    }

    @Test
    fun unknownFrameTypesAreRejected() {
        for (type in listOf(0x00, 0x03, 0x13, 0x34, 0x7F, 0xFF)) {
            assertThrows("type $type", ProtocolException::class.java) { reader(header(type, 0)).read() }
        }
        for (type in listOf(
            FrameType.HELLO, FrameType.HELLO_ACK, FrameType.OFFER, FrameType.OFFER_ENTRIES, FrameType.OFFER_END,
            FrameType.OFFER_REPLY, FrameType.FILE_BEGIN, FrameType.FILE_DATA, FrameType.FILE_END, FrameType.FILE_RESULT,
            FrameType.PAUSE, FrameType.RESUME, FrameType.CANCEL, FrameType.PING, FrameType.TRANSFER_END, FrameType.TRANSFER_DONE,
        )) {
            assertTrue(FrameType.isKnown(type))
            assertEquals(type, reader(header(type, 0)).read().type)
        }
    }

    @Test
    fun oversizedFramesAreRejectedOnReadAndWrite() {
        val maxControl = WireLimits.MAX_CONTROL_PAYLOAD
        val maxData = WireLimits.MAX_DATA_PAYLOAD
        assertThrows(ProtocolException::class.java) { reader(header(FrameType.OFFER_ENTRIES, maxControl + 1L)).read() }
        assertThrows(ProtocolException::class.java) { reader(header(FrameType.FILE_DATA, maxData + 1L)).read() }
        assertThrows(ProtocolException::class.java) { reader(header(FrameType.OFFER, 0xFFFFFFFFL)).read() }
        assertThrows(ProtocolException::class.java) { reader(header(FrameType.FILE_DATA, 0x80000000L)).read() }
        // exactly at the limit is fine
        assertEquals(maxControl, reader(frameBytes(FrameType.OFFER_ENTRIES, ByteArray(maxControl))).read().length)
        assertThrows(IllegalArgumentException::class.java) { frameBytes(FrameType.OFFER_ENTRIES, ByteArray(maxControl + 1)) }
        assertThrows(IllegalArgumentException::class.java) { frameBytes(FrameType.FILE_DATA, ByteArray(maxData + 1)) }
        assertEquals(maxData, WireLimits.maxPayload(FrameType.FILE_DATA))
        assertEquals(maxControl, WireLimits.maxPayload(FrameType.OFFER))
    }

    @Test
    fun truncatedStreamsEndWithEof() {
        assertThrows(EOFException::class.java) { reader().read() }
        assertThrows(EOFException::class.java) { reader(byteArrayOf(FrameType.OFFER.toByte(), 0, 0)).read() }
        assertThrows(EOFException::class.java) { reader(header(FrameType.OFFER, 10), ByteArray(4)).read() }
        // a huge declared length must not allocate more than the protocol allows and ends in EOF
        assertThrows(EOFException::class.java) { reader(header(FrameType.FILE_DATA, WireLimits.MAX_DATA_PAYLOAD.toLong()), ByteArray(10)).read() }
    }

    @Test
    fun readerBufferIsReusedButCopyPayloadIsStable() {
        val r = reader(frameBytes(FrameType.OFFER, byteArrayOf(1, 2, 3)), frameBytes(FrameType.OFFER, byteArrayOf(9, 8)))
        val first = r.read()
        val copy = first.copyPayload()
        r.read()
        assertArrayEquals(byteArrayOf(1, 2, 3), copy)
        assertEquals(3, first.length)
    }

    // ------------------------------------------------------------------ primitives

    @Test
    fun primitivesRoundTrip() {
        val b = MsgWriter(1).u8(0).u8(255).u16(0).u16(65_535).u32(0).u32(0xFFFFFFFFL).i64(Long.MIN_VALUE).i64(Long.MAX_VALUE).i64(-1)
            .bytes(byteArrayOf(7, 8, 9)).toByteArray()
        val r = MsgReader(frameOf(b))
        assertEquals(0, r.u8())
        assertEquals(255, r.u8())
        assertEquals(0, r.u16())
        assertEquals(65_535, r.u16())
        assertEquals(0L, r.u32())
        assertEquals(0xFFFFFFFFL, r.u32())
        assertEquals(Long.MIN_VALUE, r.i64())
        assertEquals(Long.MAX_VALUE, r.i64())
        assertEquals(-1L, r.i64())
        assertArrayEquals(byteArrayOf(7, 8, 9), r.bytes(3))
        assertEquals(0, r.remaining)
        r.requireEnd()
    }

    @Test
    fun writerEnforcesIntegerRanges() {
        assertThrows(IllegalArgumentException::class.java) { MsgWriter().u8(256) }
        assertThrows(IllegalArgumentException::class.java) { MsgWriter().u8(-1) }
        assertThrows(IllegalArgumentException::class.java) { MsgWriter().u16(65_536) }
        assertThrows(IllegalArgumentException::class.java) { MsgWriter().u16(-1) }
        assertThrows(IllegalArgumentException::class.java) { MsgWriter().u32(-1) }
        assertThrows(IllegalArgumentException::class.java) { MsgWriter().u32(0x1_0000_0000L) }
    }

    @Test
    fun readerFailsCleanlyOnUnderflow() {
        val empty = MsgReader(frameOf(ByteArray(0)))
        assertThrows(ProtocolException::class.java) { empty.u8() }
        assertThrows(ProtocolException::class.java) { MsgReader(frameOf(ByteArray(1))).u16() }
        assertThrows(ProtocolException::class.java) { MsgReader(frameOf(ByteArray(3))).u32() }
        assertThrows(ProtocolException::class.java) { MsgReader(frameOf(ByteArray(7))).i64() }
        assertThrows(ProtocolException::class.java) { MsgReader(frameOf(ByteArray(3))).bytes(4) }
        assertThrows(ProtocolException::class.java) { MsgReader(frameOf(ByteArray(3))).bytes(-1) }
        assertThrows(ProtocolException::class.java) { MsgReader(frameOf(ByteArray(2))).requireEnd() }
    }

    @Test
    fun readerHonoursTheFrameLengthNotTheBufferSize() {
        val payload = byteArrayOf(1, 2, 3, 4, 5, 6, 7, 8)
        val r = MsgReader(Frame(FrameType.OFFER, payload, 3))
        assertEquals(3, r.remaining)
        r.u16()
        assertThrows(ProtocolException::class.java) { r.u16() }
    }

    @Test
    fun stringsAreUtf8WithLengthPrefix() {
        val s = "Привіт, світе 🌍 — 日本語"
        val bytes = MsgWriter().str(s, 200).toByteArray()
        assertEquals(s.toByteArray(Charsets.UTF_8).size + 2, bytes.size)
        val r = MsgReader(frameOf(bytes))
        assertEquals(s, r.str(200))
        r.requireEnd()
        assertEquals("", MsgReader(frameOf(MsgWriter().str("", 10).toByteArray())).str(10))
    }

    @Test
    fun stringLimitsAndInvalidStringsAreRejected() {
        assertThrows(IllegalArgumentException::class.java) { MsgWriter().str("abcdef", 5) }
        val bytes = MsgWriter().str("abcdef", 10).toByteArray()
        assertThrows(ProtocolException::class.java) { MsgReader(frameOf(bytes)).str(5) }
        // declared length longer than the data
        assertThrows(ProtocolException::class.java) { MsgReader(frameOf(byteArrayOf(0, 9, 65, 66))).str(100) }
        // NUL characters never travel
        assertThrows(ProtocolException::class.java) { MsgReader(frameOf(byteArrayOf(0, 3, 65, 0, 66))).str(100) }
    }

    @Test
    fun clipKeepsCodePointBoundaries() {
        assertEquals("abc", MsgWriter.clip("abc", 10))
        assertEquals("a", MsgWriter.clip("a🌍b", 4)) // the globe needs 4 bytes: 1 + 4 > 4
        assertEquals("a🌍", MsgWriter.clip("a🌍b", 5))
        assertEquals("а", MsgWriter.clip("абв", 3))
        assertEquals("", MsgWriter.clip("абв", 1))
        val long = "я".repeat(500)
        val clipped = MsgWriter.clip(long, 128)
        assertEquals(128, clipped.toByteArray(Charsets.UTF_8).size)
        assertTrue(long.startsWith(clipped))
    }

    // ------------------------------------------------------------------ messages

    @Test
    fun helloRoundTripsWithAndWithoutToken() {
        val token = ByteArray(16) { (it + 1).toByte() }
        val withToken = Hello.decode(frameOf(Hello(1, "abcd", "Pixel 9", 2, "1.2.3", 0x1F, token).encode()))
        assertEquals(1, withToken.version)
        assertEquals("abcd", withToken.deviceId)
        assertEquals("Pixel 9", withToken.name)
        assertEquals(2, withToken.kind)
        assertEquals("1.2.3", withToken.appVersion)
        assertEquals(0x1F, withToken.capabilities)
        assertArrayEquals(token, withToken.token)

        val without = Hello.decode(frameOf(Hello(1, "abcd", "Pixel 9", 2, "1.2.3", -1, null).encode()))
        assertNull(without.token)
        assertEquals(-1, without.capabilities) // all 32 bits survive the unsigned wire format
    }

    @Test
    fun helloClipsLongNamesAndValidatesTheToken() {
        val h = Hello.decode(frameOf(Hello(1, "id", "я".repeat(300), 0, "v", 0, null).encode()))
        assertTrue(h.name.toByteArray(Charsets.UTF_8).size <= Protocol.MAX_NAME)
        assertThrows(IllegalArgumentException::class.java) { Hello(1, "id", "n", 0, "v", 0, ByteArray(8)).encode() }

        val good = Hello(1, "id", "n", 0, "v", 0, null).encode()
        // wrong magic
        val badMagic = good.copyOf().also { it[0] = 'X'.code.toByte() }
        assertThrows(ProtocolException::class.java) { Hello.decode(frameOf(badMagic)) }
        // trailing bytes
        assertThrows(ProtocolException::class.java) { Hello.decode(frameOf(good + byteArrayOf(1))) }
        // truncated
        assertThrows(ProtocolException::class.java) { Hello.decode(frameOf(good.copyOf(good.size - 3))) }
        // token length that is neither 0 nor 16..32
        val badToken = good.copyOf().also { it[it.size - 1] = 5 } + ByteArray(5)
        assertThrows(ProtocolException::class.java) { Hello.decode(frameOf(badToken)) }
    }

    @Test
    fun helloOfAnotherVersionIsReportedWithoutParsingTheRest() {
        val bytes = Protocol.MAGIC + byteArrayOf(2, 9, 9, 9, 9, 9, 9)
        val h = Hello.decode(frameOf(bytes))
        assertEquals(2, h.version)
        assertEquals("", h.deviceId)
    }

    @Test
    fun helloAckRoundTrips() {
        for (qr in listOf(true, false)) for (code in listOf(true, false)) {
            val a = HelloAck.decode(frameOf(HelloAck(1, HelloStatus.BUSY, "dev", "Name", 3, "9.9", 77, qr, code).encode()))
            assertEquals(1, a.version)
            assertEquals(HelloStatus.BUSY, a.status)
            assertEquals("dev", a.deviceId)
            assertEquals("Name", a.name)
            assertEquals(3, a.kind)
            assertEquals("9.9", a.appVersion)
            assertEquals(77, a.capabilities)
            assertEquals(qr, a.authenticatedByQr)
            assertEquals(code, a.showsCode)
        }
        val bytes = HelloAck(1, 0, "d", "n", 0, "v", 0, false, false).encode()
        assertThrows(ProtocolException::class.java) { HelloAck.decode(frameOf(bytes + byteArrayOf(0))) }
        assertThrows(ProtocolException::class.java) { HelloAck.decode(frameOf(bytes.copyOf(bytes.size - 1))) }
    }

    @Test
    fun offerHeaderRoundTripsAndRejectsInvalidValues() {
        for (folder in listOf(true, false)) for (compression in listOf(true, false)) {
            val h = OfferHeader.decode(frameOf(OfferHeader("t-1", 4_000_000_000L, 12_345_678_901_234L, folder, compression, 0x0F, "Holiday ✈").encode()))
            assertEquals("t-1", h.transferId)
            assertEquals(4_000_000_000L, h.fileCount)
            assertEquals(12_345_678_901_234L, h.totalBytes)
            assertEquals(folder, h.folder)
            assertEquals(compression, h.compressionRequested)
            assertEquals(0x0F, h.categoriesMask)
            assertEquals("Holiday ✈", h.title)
        }
        assertNull(OfferHeader.decode(frameOf(OfferHeader("t", 1, 1, false, false, 0, null).encode())).title)
        assertThrows(ProtocolException::class.java) { OfferHeader.decode(frameOf(OfferHeader("", 1, 1, false, false, 0, null).encode())) }
        assertThrows(ProtocolException::class.java) { OfferHeader.decode(frameOf(OfferHeader("t", 1, -1, false, false, 0, null).encode())) }
        val ok = OfferHeader("t", 1, 1, false, false, 0, null).encode()
        assertThrows(ProtocolException::class.java) { OfferHeader.decode(frameOf(ok + byteArrayOf(0))) }
        val longTitle = OfferHeader.decode(frameOf(OfferHeader("t", 1, 1, false, false, 0, "ж".repeat(400)).encode()))
        assertTrue(longTitle.title!!.toByteArray(Charsets.UTF_8).size <= Protocol.MAX_TITLE)
    }

    private fun entry(i: Int, path: String = "dir/file$i.txt", mime: String? = if (i % 2 == 0) "text/plain" else null) =
        WireEntry(i.toLong(), path, i * 1000L, 1_700_000_000_000L + i, i % 7, mime)

    @Test
    fun offerEntriesAreBatchedAndDecodeInOrder() {
        val entries = (0 until 1000).map { entry(it) }
        val batches = OfferEntriesCodec.encodeBatches(entries)
        assertEquals(5, batches.size) // 200 entries per frame
        assertTrue(batches.all { it.size <= WireLimits.MAX_CONTROL_PAYLOAD })
        val decoded = batches.flatMap { OfferEntriesCodec.decode(frameOf(it)) }
        assertEquals(entries.size, decoded.size)
        for (i in entries.indices) {
            val a = entries[i]
            val b = decoded[i]
            assertEquals(a.id, b.id)
            assertEquals(a.path, b.path)
            assertEquals(a.size, b.size)
            assertEquals(a.lastModified, b.lastModified)
            assertEquals(a.category, b.category)
            assertEquals(a.mimeType, b.mimeType)
        }
    }

    @Test
    fun longPathsSplitBatchesBySize() {
        val path = "d/" + "я".repeat(500) // ~1 KB per entry
        val entries = (0 until 150).map { entry(it, path = path + it) }
        val batches = OfferEntriesCodec.encodeBatches(entries)
        assertTrue("expected several batches, got ${batches.size}", batches.size >= 2)
        assertTrue(batches.all { it.size <= Protocol.MAX_BATCH_BYTES + 2 * Protocol.MAX_PATH })
        assertEquals(entries.size, batches.sumOf { OfferEntriesCodec.decode(frameOf(it)).size })
    }

    @Test
    fun emptyManifestEncodesToNothingAndBadEntriesAreRejected() {
        assertTrue(OfferEntriesCodec.encodeBatches(emptyList()).isEmpty())
        assertThrows(IllegalArgumentException::class.java) {
            OfferEntriesCodec.encodeBatches(listOf(entry(1, path = "x".repeat(Protocol.MAX_PATH + 1))))
        }
        // too many entries announced in one frame
        val tooMany = MsgWriter().u16(Protocol.MAX_ENTRIES_PER_BATCH * 4 + 1).toByteArray()
        assertThrows(ProtocolException::class.java) { OfferEntriesCodec.decode(frameOf(tooMany)) }
        // announced entries missing
        val missing = MsgWriter().u16(3).toByteArray()
        assertThrows(ProtocolException::class.java) { OfferEntriesCodec.decode(frameOf(missing)) }
        // trailing bytes after the last entry
        val ok = OfferEntriesCodec.encodeBatches(listOf(entry(1))).single()
        assertThrows(ProtocolException::class.java) { OfferEntriesCodec.decode(frameOf(ok + byteArrayOf(0))) }
    }

    @Test
    fun offerReplyRoundTrips() {
        val sha = ByteArray(32) { it.toByte() }
        val reply = OfferReply(ReplyCode.ACCEPT, listOf(ReplyEntry(1, 0, ByteArray(32)), ReplyEntry(0xFFFFFFFFL, 123_456_789_012L, sha)))
        val d = OfferReply.decode(frameOf(reply.encode()), 10)
        assertEquals(ReplyCode.ACCEPT, d.decision)
        assertEquals(2, d.entries.size)
        assertEquals(1L, d.entries[0].id)
        assertEquals(0L, d.entries[0].offset)
        assertEquals(0xFFFFFFFFL, d.entries[1].id)
        assertEquals(123_456_789_012L, d.entries[1].offset)
        assertArrayEquals(sha, d.entries[1].prefixSha256)

        val accept0 = OfferReply.decode(frameOf(OfferReply(ReplyCode.ACCEPT, emptyList()).encode()), 0)
        assertTrue(accept0.entries.isEmpty())

        for (code in listOf(ReplyCode.DECLINE_USER, ReplyCode.BUSY, ReplyCode.NO_SPACE, ReplyCode.NOT_ALLOWED, ReplyCode.TIMEOUT, ReplyCode.STORAGE_ERROR)) {
            val r = OfferReply.decode(frameOf(OfferReply(code, emptyList()).encode()), 10)
            assertEquals(code, r.decision)
            assertTrue(r.entries.isEmpty())
        }
    }

    @Test
    fun offerReplyRejectsInvalidShapes() {
        val sha = ByteArray(32)
        val good = OfferReply(ReplyCode.ACCEPT, listOf(ReplyEntry(1, 0, sha), ReplyEntry(2, 0, sha))).encode()
        // more entries than the manifest has
        assertThrows(ProtocolException::class.java) { OfferReply.decode(frameOf(good), 1) }
        // count does not match the data
        assertThrows(ProtocolException::class.java) { OfferReply.decode(frameOf(good.copyOf(good.size - 1)), 10) }
        assertThrows(ProtocolException::class.java) { OfferReply.decode(frameOf(good + byteArrayOf(0)), 10) }
        // a decline carries no entries
        assertThrows(ProtocolException::class.java) { OfferReply.decode(frameOf(byteArrayOf(ReplyCode.BUSY.toByte(), 0)), 10) }
        // negative offsets
        val negative = OfferReply(ReplyCode.ACCEPT, listOf(ReplyEntry(1, -5, sha))).encode()
        assertThrows(ProtocolException::class.java) { OfferReply.decode(frameOf(negative), 10) }
        // wrong digest size on encode
        assertThrows(IllegalArgumentException::class.java) { OfferReply(ReplyCode.ACCEPT, listOf(ReplyEntry(1, 0, ByteArray(5)))).encode() }
    }

    @Test
    fun fileMessagesRoundTrip() {
        val begin = FileBegin.decode(frameOf(FileBegin(0xFFFFFFFFL, 9_000_000_000L, Encoding.DEFLATE).encode()))
        assertEquals(0xFFFFFFFFL, begin.id)
        assertEquals(9_000_000_000L, begin.startOffset)
        assertEquals(Encoding.DEFLATE, begin.encoding)

        val sha = ByteArray(32) { (it * 3).toByte() }
        val end = FileEnd.decode(frameOf(FileEnd(5, sha).encode()))
        assertEquals(5L, end.id)
        assertArrayEquals(sha, end.sha256)

        val result = FileResult.decode(frameOf(FileResult(7, FileStatus.NO_SPACE, "диск повний").encode()))
        assertEquals(7L, result.id)
        assertEquals(FileStatus.NO_SPACE, result.status)
        assertEquals("диск повний", result.detail)
        val clipped = FileResult.decode(frameOf(FileResult(7, FileStatus.IO_ERROR, "x".repeat(1000)).encode()))
        assertEquals(Protocol.MAX_DETAIL, clipped.detail.length)

        assertEquals(CancelReason.SOURCE_CHANGED, CancelMsg.decode(frameOf(CancelMsg(CancelReason.SOURCE_CHANGED).encode())).reason)

        val done = TransferDone.decode(frameOf(TransferDone(TransferDone.FAILED, 4_000_000_000L, 3).encode()))
        assertEquals(TransferDone.FAILED, done.status)
        assertEquals(4_000_000_000L, done.okCount)
        assertEquals(3L, done.failedCount)
    }

    @Test
    fun fileMessagesRejectInvalidValues() {
        assertThrows(ProtocolException::class.java) { FileBegin.decode(frameOf(FileBegin(1, -1, Encoding.RAW).encode())) }
        assertThrows(ProtocolException::class.java) { FileBegin.decode(frameOf(FileBegin(1, 0, 2).encode())) }
        assertThrows(ProtocolException::class.java) { FileBegin.decode(frameOf(FileBegin(1, 0, 0).encode() + byteArrayOf(0))) }
        assertThrows(IllegalArgumentException::class.java) { FileEnd(1, ByteArray(31)).encode() }
        assertThrows(ProtocolException::class.java) { FileEnd.decode(frameOf(ByteArray(10))) }
        assertThrows(ProtocolException::class.java) { FileResult.decode(frameOf(FileResult(1, 0, "").encode() + byteArrayOf(1))) }
        assertThrows(ProtocolException::class.java) { CancelMsg.decode(frameOf(ByteArray(0))) }
        assertThrows(ProtocolException::class.java) { TransferDone.decode(frameOf(ByteArray(8))) }
    }

    @Test
    fun codecsIgnoreBytesBeyondTheFrameLength() {
        val encoded = FileBegin(3, 4, Encoding.RAW).encode()
        val padded = encoded + ByteArray(50) { 0x55 }
        val f = FileBegin.decode(Frame(FrameType.FILE_BEGIN, padded, encoded.size))
        assertEquals(3L, f.id)
        assertEquals(4L, f.startOffset)
        assertNotNull(f)
        assertFalse(FrameType.isKnown(0x99))
    }
}
