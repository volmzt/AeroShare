package com.aero.share.transfer.engine

import com.aero.share.transfer.model.TransferControl
import com.aero.share.transfer.model.TransferState
import com.aero.share.transfer.model.TransferTracker
import java.util.concurrent.TimeUnit
import kotlin.random.Random
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.After
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

class EngineResumeTest {
    @get:Rule
    val tmp = TemporaryFolder()

    private val created = ArrayList<Harness>()

    private fun harness(config: EngineConfig? = null): Harness {
        val dir = tmp.newFolder("h${System.nanoTime()}")
        val h = if (config == null) Harness(dir) else Harness(dir, config)
        return h.start().also { created.add(it) }
    }

    @After
    fun tearDown() {
        created.forEach { it.stop() }
    }

    private fun bytes(seed: Int, size: Int) = Random(seed).nextBytes(size)

    private fun startSend(h: Harness, files: List<SendableFile>, id: String, connector: SocketConnector = SocketConnector.DEFAULT, control: TransferControl = TransferControl()): Pair<Thread, TransferTracker> {
        val tracker = h.tracker(id)
        val t = Thread { runBlocking { h.sender().send(h.target(connector = connector), h.request(files, id), control, tracker) } }
        t.isDaemon = true
        t.start()
        return t to tracker
    }

    private fun sendNow(h: Harness, files: List<SendableFile>, id: String, tracker: TransferTracker = h.tracker(id)): TransferResult =
        runBlocking { withTimeout(30_000) { h.sender().send(h.target(), h.request(files, id), TransferControl(), tracker) } }

    private fun assertCompleted(h: Harness, r: TransferResult) {
        assertTrue("result=$r logs=${h.logs}", r is TransferResult.Completed)
    }

    @Test
    fun interruptedTransferResumesFromTheConfirmedOffset() {
        val h = harness()
        val metered = MeteredStorage(h.storage)
        h.storage = metered
        val data = bytes(1, 1_572_864)
        val gate = 786_432L
        val gated = GatedFile(1, "movie.bin", data, gate)
        val link = CapturingConnector()
        val (thread, t1) = startSend(h, listOf(gated), "resume-1", link)
        assertTrue(gated.reached.await(10, TimeUnit.SECONDS))
        val s1 = h.awaitSession()
        s1.tracker.awaitState { it.transferredBytes >= gate }

        link.socket!!.close() // the link drops
        gated.release.countDown()
        thread.join(15_000)
        val first = t1.awaitState { it.state == TransferState.INTERRUPTED }
        assertTrue(first.resumable)
        val r1 = runBlocking { withTimeout(10_000) { s1.completion.await() } }
        assertTrue(r1 is TransferResult.Failed && r1.resumable)
        assertEquals(TransferState.INTERRUPTED, s1.tracker.current.state)
        assertTrue("nothing is published before the file is complete", h.dest.walkTopDown().none { it.isFile })

        val before = metered.partBytesWritten.get()
        val t2 = h.tracker("resume-1")
        assertCompleted(h, sendNow(h, listOf(MemoryFile(1, "movie.bin", data)), "resume-1", t2))
        val offer = h.offers.last()
        assertTrue(offer.isResume)
        assertEquals(gate, offer.resumeBytes)
        assertEquals("only the missing bytes were transferred", data.size - gate, metered.partBytesWritten.get() - before)
        assertArrayEquals(data, h.received("movie.bin"))
        assertEquals(data.size.toLong(), t2.current.transferredBytes)
    }

    @Test
    fun changedSourceRestartsThatFileFromZero() {
        val h = harness()
        val metered = MeteredStorage(h.storage)
        h.storage = metered
        val data = bytes(2, 1_048_576)
        val gated = GatedFile(1, "doc.bin", data, 524_288)
        val link = CapturingConnector()
        val (thread, t1) = startSend(h, listOf(gated), "chg", link)
        assertTrue(gated.reached.await(10, TimeUnit.SECONDS))
        h.awaitSession().tracker.awaitState { it.transferredBytes >= 524_288 }
        link.socket!!.close()
        gated.release.countDown()
        thread.join(15_000)
        t1.awaitState { it.state == TransferState.INTERRUPTED }

        // same size and timestamp, but the content of the already transferred part differs
        val changed = data.copyOf().also { it[100] = (it[100] + 1).toByte() }
        val before = metered.partBytesWritten.get()
        assertCompleted(h, sendNow(h, listOf(MemoryFile(1, "doc.bin", changed)), "chg"))
        assertTrue(h.offers.last().isResume)
        assertEquals("the whole file was sent again", data.size.toLong(), metered.partBytesWritten.get() - before)
        assertArrayEquals(changed, h.received("doc.bin"))
    }

    @Test
    fun alreadyCompletedFilesAreSkippedOnRetry() {
        val h = harness()
        val metered = MeteredStorage(h.storage)
        h.storage = metered
        val a = MemoryFile(1, "a.bin", bytes(3, 200_000))
        val b = MemoryFile(2, "dir/b.bin", bytes(4, 200_000))
        val cData = bytes(5, 600_000)
        val cGated = GatedFile(3, "c.bin", cData, 262_144) // a multiple of the 64 KiB chunk size
        val link = CapturingConnector()
        val (thread, t1) = startSend(h, listOf(a, b, cGated), "ledger", link)
        assertTrue(cGated.reached.await(10, TimeUnit.SECONDS))
        val s1 = h.awaitSession()
        s1.tracker.awaitState { it.completedFiles == 2 && it.transferredBytes >= 662_144 }
        link.socket!!.close()
        cGated.release.countDown()
        thread.join(15_000)
        t1.awaitState { it.state == TransferState.INTERRUPTED }
        assertEquals(2, h.dest.walkTopDown().count { it.isFile })

        val partsBefore = metered.createdParts.size
        val written = metered.partBytesWritten.get()
        val t2 = h.tracker("ledger")
        assertCompleted(h, sendNow(h, listOf(a, b, MemoryFile(3, "c.bin", cData)), "ledger", t2))
        val offer = h.offers.last()
        assertTrue(offer.isResume)
        assertEquals(200_000L + 200_000L + 262_144L, offer.resumeBytes)
        assertEquals("no new part was created", partsBefore, metered.createdParts.size)
        assertEquals("only the rest of the last file was transferred", 600_000L - 262_144L, metered.partBytesWritten.get() - written)
        assertEquals(3, t2.current.completedFiles)
        assertArrayEquals(a.data, h.received("a.bin"))
        assertArrayEquals(b.data, h.received("dir/b.bin"))
        assertArrayEquals(cData, h.received("c.bin"))
        assertEquals(3, h.dest.walkTopDown().count { it.isFile })
    }

    @Test
    fun retryFromTheSameDeviceReplacesAStaleConnection() {
        val h = harness()
        val data = bytes(6, 900_000)
        val gated = GatedFile(1, "x.bin", data, 262_144)
        val (thread, t1) = startSend(h, listOf(gated), "stale")
        assertTrue(gated.reached.await(10, TimeUnit.SECONDS))
        val s1 = h.awaitSession()
        s1.tracker.awaitState { it.transferredBytes >= 262_144 }

        // the first connection is still open (as after a silent network drop) when the retry arrives
        assertCompleted(h, sendNow(h, listOf(MemoryFile(1, "x.bin", data)), "stale"))
        assertArrayEquals(data, h.received("x.bin"))
        val r1 = runBlocking { withTimeout(10_000) { s1.completion.await() } }
        assertTrue(r1 is TransferResult.Failed && r1.resumable)
        assertEquals(TransferState.INTERRUPTED, s1.tracker.current.state)

        gated.release.countDown()
        thread.join(15_000)
        assertEquals(TransferState.INTERRUPTED, t1.awaitState { it.state.isTerminal || it.state == TransferState.INTERRUPTED }.state)
    }

    @Test
    fun senderPauseStopsTheDataAndResumeFinishesTheTransfer() {
        val h = harness()
        val data = bytes(7, 1_048_576)
        val gated = GatedFile(1, "p.bin", data, 262_144)
        val control = TransferControl()
        val (thread, t) = startSend(h, listOf(gated), "pause", control = control)
        assertTrue(gated.reached.await(10, TimeUnit.SECONDS))
        val session = h.awaitSession()
        session.tracker.awaitState { it.transferredBytes >= 262_144 }

        control.pause()
        gated.release.countDown()
        val paused = t.awaitState { it.state == TransferState.PAUSED }
        assertFalse(paused.pausedByPeer)
        assertEquals(0L, paused.bytesPerSecond)
        val rp = session.tracker.awaitState { it.state == TransferState.PAUSED }
        assertTrue("the receiver shows that the other side paused", rp.pausedByPeer)

        val sent = t.current.transferredBytes
        Thread.sleep(500)
        assertEquals("no data while paused", sent, t.current.transferredBytes)
        val received = session.tracker.current.transferredBytes
        Thread.sleep(300)
        assertEquals(received, session.tracker.current.transferredBytes)

        control.resume()
        t.awaitState { it.state == TransferState.COMPLETED }
        thread.join(10_000)
        assertArrayEquals(data, h.received("p.bin"))
    }

    @Test
    fun receiverPauseHoldsTheTransferUntilResumed() {
        val h = harness()
        val data = bytes(8, 1_048_576)
        val gated = GatedFile(1, "q.bin", data, 262_144)
        val (thread, t) = startSend(h, listOf(gated), "rpause")
        assertTrue(gated.reached.await(10, TimeUnit.SECONDS))
        val session = h.awaitSession()
        session.tracker.awaitState { it.transferredBytes >= 262_144 }

        session.control.pause()
        val paused = session.tracker.awaitState { it.state == TransferState.PAUSED }
        assertFalse(paused.pausedByPeer)
        gated.release.countDown()
        val held = session.tracker.current.transferredBytes
        Thread.sleep(500)
        assertEquals("the receiver does not consume data while paused", held, session.tracker.current.transferredBytes)
        assertFalse(t.current.state.isTerminal)

        session.control.resume()
        t.awaitState { it.state == TransferState.COMPLETED }
        thread.join(10_000)
        assertEquals(TransferState.COMPLETED, session.tracker.awaitState { it.state.isTerminal }.state)
        assertArrayEquals(data, h.received("q.bin"))
    }

    @Test
    fun aPauseThatLastsTooLongInterruptsTheTransferAndItCanBeResumed() {
        val cfg = EngineConfig(
            chunkSize = 64 * 1024, connectTimeoutMs = 3_000, idleTimeoutMs = 6_000, pingIntervalMs = 300,
            acceptTimeoutMs = 4_000, pauseTimeoutMs = 700, progressIntervalMs = 20,
        )
        val h = harness(cfg)
        val data = bytes(9, 1_048_576)
        val gated = GatedFile(1, "slow.bin", data, 262_144)
        val control = TransferControl()
        val (thread, t) = startSend(h, listOf(gated), "longpause", control = control)
        assertTrue(gated.reached.await(10, TimeUnit.SECONDS))
        val session = h.awaitSession()
        session.tracker.awaitState { it.transferredBytes >= 262_144 }
        control.pause()
        gated.release.countDown()
        val s = t.awaitState(10_000) { it.state == TransferState.INTERRUPTED }
        assertTrue(s.resumable)
        thread.join(10_000)
        assertEquals(TransferState.INTERRUPTED, session.tracker.awaitState { it.state == TransferState.INTERRUPTED }.state)

        assertCompleted(h, sendNow(h, listOf(MemoryFile(1, "slow.bin", data)), "longpause"))
        assertTrue(h.offers.last().isResume)
        assertArrayEquals(data, h.received("slow.bin"))
    }
}
