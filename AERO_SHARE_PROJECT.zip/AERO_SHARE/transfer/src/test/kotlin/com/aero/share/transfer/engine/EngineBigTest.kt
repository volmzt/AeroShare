package com.aero.share.transfer.engine

import com.aero.share.transfer.model.CompressionMode
import com.aero.share.transfer.model.TransferControl
import com.aero.share.transfer.model.TransferState
import com.aero.share.transfer.path.PathSafety
import java.io.File
import kotlin.random.Random
import kotlinx.coroutines.flow.takeWhile
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.After
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

/** Realistic shapes of transfers: many files, odd names, compression, empty files. */
class EngineBigTest {
    @get:Rule
    val tmp = TemporaryFolder()

    private val created = ArrayList<Harness>()

    private fun harness(): Harness = Harness(tmp.newFolder("h${System.nanoTime()}")).start().also { created.add(it) }

    @After
    fun tearDown() {
        created.forEach { it.stop() }
    }

    private fun send(h: Harness, files: List<SendableFile>, mode: CompressionMode = CompressionMode.OFF, title: String? = null) =
        h.tracker("t-${System.nanoTime()}").let { tracker ->
            val result = runBlocking {
                withTimeout(120_000) { h.sender().send(h.target(), h.request(files, compression = mode, title = title), TransferControl(), tracker) }
            }
            result to tracker
        }

    @Test
    fun manifestWithThousandsOfFilesIsSplitIntoBatchesAndDelivered() {
        val h = harness()
        val files = (0 until 1500).map { i ->
            MemoryFile(i + 1, "tree/d${i % 31}/s${i % 7}/file_$i.dat", ByteArray(i % 97) { (it * 7 + i).toByte() })
        }
        val (result, tracker) = send(h, files, title = "Many small files")
        assertTrue("sender result: $result", result is TransferResult.Completed)
        assertEquals(TransferState.COMPLETED, tracker.current.state)
        assertEquals(1500, tracker.current.completedFiles)

        val session = h.awaitSession()
        val done = session.tracker.awaitState { it.state == TransferState.COMPLETED }
        assertEquals(1500, done.completedFiles)
        assertEquals(1500, done.savedFiles.size)
        assertEquals(1500, h.offers.single().fileCount)
        assertEquals(files.sumOf { it.size }, h.offers.single().totalBytes)
        assertEquals("Many small files", h.offers.single().title)

        for (f in files) assertArrayEquals(f.relativePath, (f as MemoryFile).data, h.received(f.relativePath))
        assertEquals(1500, h.dest.walkTopDown().count { it.isFile })
        assertTrue("no staging leftovers", h.parts.walkTopDown().none { it.isFile })
    }

    @Test
    fun unicodeAndAwkwardNamesArriveSafely() {
        val h = harness()
        val raw = listOf(
            "Звіт за 2026 — фінал (1).pdf",
            "日本語/ファイル.txt",
            "emoji 🌍 trip.txt",
            "with space/ and #hash %20 & plus+.txt",
            "ünïcödé/Ñandú.txt",
            "a:b*c?.txt",
            "dir\\back\\slash.txt",
            "CON.txt",
            "я".repeat(120) + ".txt",
            "я".repeat(200) + ".txt",
            "very/deep/" + (1..20).joinToString("/") { "level$it" } + "/leaf.txt",
        )
        val files = raw.mapIndexed { i, name -> MemoryFile(i + 1, name, "content of $i / $name".toByteArray()) }
        val (result, _) = send(h, files)
        assertTrue("sender result: $result", result is TransferResult.Completed)

        for (f in files) {
            val safe = PathSafety.sanitizeRelativePath(f.relativePath)!!
            assertTrue("${f.relativePath} -> $safe", File(h.dest, safe).isFile)
            assertArrayEquals(safe, f.data, h.received(safe))
            assertTrue(safe.split('/').all { it.toByteArray(Charsets.UTF_8).size <= 255 })
        }
        assertEquals("a_b_c_.txt", PathSafety.sanitizeRelativePath("a:b*c?.txt"))
        assertTrue(File(h.dest, "a_b_c_.txt").isFile)
        assertTrue(File(h.dest, "dir/back/slash.txt").isFile)
        assertTrue(File(h.dest, "_CON.txt").isFile)
        // nothing escaped the destination
        assertEquals(files.size, h.dest.walkTopDown().count { it.isFile })
        assertFalse(File(h.dest.parentFile, "slash.txt").exists())
    }

    @Test
    fun namesThatCollideAfterSanitizingAreBothKept() {
        val h = harness()
        val a = MemoryFile(1, "x:y.txt", "content A".toByteArray())
        val b = MemoryFile(2, "x_y.txt", "content B".toByteArray())
        val c = MemoryFile(3, "sub/p?q.txt", "content C".toByteArray())
        val d = MemoryFile(4, "sub/p*q.txt", "content D".toByteArray())
        val (result, _) = send(h, listOf(a, b, c, d))
        assertTrue("sender result: $result", result is TransferResult.Completed)

        val all = h.dest.walkTopDown().filter { it.isFile }.associate { it.relativeTo(h.dest).path to it.readText() }
        assertEquals(4, all.size)
        assertEquals(setOf("content A", "content B", "content C", "content D"), all.values.toSet())
        assertEquals("content A", all["x_y.txt"]) // the first one in manifest order keeps the plain name
        assertEquals("content C", all["sub/p_q.txt"])
    }

    @Test
    fun aSingleEmptyFileIsDelivered() {
        val h = harness()
        val (result, tracker) = send(h, listOf(MemoryFile(1, "empty.txt", ByteArray(0))))
        assertTrue("sender result: $result", result is TransferResult.Completed)
        assertEquals(TransferState.COMPLETED, tracker.current.state)
        assertTrue(File(h.dest, "empty.txt").isFile)
        assertEquals(0L, File(h.dest, "empty.txt").length())
        val offer = h.offers.single()
        assertEquals(1, offer.fileCount)
        assertEquals(0L, offer.totalBytes)
        assertEquals(0f, tracker.current.fraction, 0f) // nothing to measure; never NaN
    }

    @Test
    fun compressionKeepsEveryFileIntact() {
        val h = harness()
        val text = "The quick brown fox jumps over the lazy dog.\n".repeat(20_000).toByteArray()
        val files = listOf(
            MemoryFile(1, "docs/notes.txt", text),
            MemoryFile(2, "photos/IMG_0001.jpg", Random(1).nextBytes(300_000)),
            MemoryFile(3, "archive.zip", Random(2).nextBytes(150_000)),
            MemoryFile(4, "tiny.txt", "hi".toByteArray()),
            MemoryFile(5, "data/table.csv", ("id,name,value\n" + (1..30_000).joinToString("\n") { "$it,item$it,${it * 3}" }).toByteArray()),
        )
        val (result, tracker) = send(h, files, CompressionMode.SMART)
        assertTrue("sender result: $result", result is TransferResult.Completed)
        assertTrue("sender reports that compression was used", tracker.current.compressed)
        for (f in files) assertArrayEquals(f.relativePath, (f as MemoryFile).data, h.received(f.relativePath))
        val session = h.awaitSession()
        assertTrue(session.tracker.awaitState { it.state == TransferState.COMPLETED }.compressed)

        // the same files without compression are still byte-identical and the flag stays off
        val h2 = harness()
        val (result2, tracker2) = send(h2, files, CompressionMode.OFF)
        assertTrue(result2 is TransferResult.Completed)
        assertFalse(tracker2.current.compressed)
        for (f in files) assertArrayEquals(f.relativePath, (f as MemoryFile).data, h2.received(f.relativePath))
    }

    @Test
    fun mediumFilesWithProgressThatNeverGoesBackwards() {
        val h = harness()
        val files = (1..4).map { MemoryFile(it, "m/file$it.bin", Random(it).nextBytes(3_000_000)) }
        val tracker = h.tracker("progress")
        val seen = java.util.concurrent.CopyOnWriteArrayList<Long>()
        val watcher = Thread {
            runBlocking {
                tracker.state.takeWhile { s ->
                    seen.add(s.transferredBytes)
                    !s.state.isTerminal
                }.collect { }
            }
        }.also { it.isDaemon = true; it.start() }
        val result = runBlocking {
            withTimeout(60_000) { h.sender().send(h.target(), h.request(files), TransferControl(), tracker) }
        }
        watcher.join(5_000)
        assertTrue(result is TransferResult.Completed)
        assertTrue("progress went backwards: $seen", seen.zipWithNext().all { (a, b) -> b >= a })
        assertEquals(12_000_000L, tracker.current.transferredBytes)
        assertEquals(1f, tracker.current.fraction, 0f)
        for (f in files) assertArrayEquals(f.data, h.received(f.relativePath))
    }
}
