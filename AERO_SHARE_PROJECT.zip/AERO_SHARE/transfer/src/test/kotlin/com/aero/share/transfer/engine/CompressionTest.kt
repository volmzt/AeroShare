package com.aero.share.transfer.engine

import com.aero.share.transfer.proto.ProtocolException
import java.io.ByteArrayOutputStream
import kotlin.random.Random
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test

class CompressionTest {
    private fun deflate(chunks: List<ByteArray>, maxChunk: Int = 65_536): List<ByteArray> {
        val d = ChunkDeflater(maxChunk)
        try {
            return chunks.map { c ->
                val n = d.compress(c, 0, c.size)
                d.buffer.copyOfRange(5, 5 + n)
            }
        } finally {
            d.close()
        }
    }

    private fun inflate(frames: List<ByteArray>, cap: Int = 4 * 1024 * 1024): ByteArray {
        val inflater = ChunkInflater(cap)
        val out = ByteArrayOutputStream()
        try {
            for (f in frames) inflater.inflate(f, 0, f.size) { b, n -> out.write(b, 0, n) }
        } finally {
            inflater.close()
        }
        return out.toByteArray()
    }

    private fun split(data: ByteArray, size: Int): List<ByteArray> =
        (0 until data.size step size).map { data.copyOfRange(it, minOf(it + size, data.size)) }

    @Test
    fun textShrinksAndRoundTripsAcrossChunks() {
        val text = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. ".repeat(6_000).toByteArray()
        val frames = deflate(split(text, 65_536))
        assertTrue("compressed ${frames.sumOf { it.size }} of ${text.size}", frames.sumOf { it.size } < text.size / 10)
        assertArrayEquals(text, inflate(frames))
    }

    @Test
    fun incompressibleDataStillRoundTrips() {
        val noise = Random(5).nextBytes(300_000)
        val frames = deflate(split(noise, 65_536))
        assertArrayEquals(noise, inflate(frames))
    }

    @Test
    fun everyFrameIsSelfContainedUpToItsFlushPoint() {
        // the receiver must be able to turn each frame into plain bytes as soon as it arrives
        val parts = listOf("first chunk ".repeat(100), "second chunk ".repeat(100), "third ".repeat(100)).map { it.toByteArray() }
        val frames = deflate(parts)
        val inflater = ChunkInflater(1 shl 20)
        try {
            for (i in parts.indices) {
                val out = ByteArrayOutputStream()
                inflater.inflate(frames[i], 0, frames[i].size) { b, n -> out.write(b, 0, n) }
                assertArrayEquals("frame $i", parts[i], out.toByteArray())
            }
        } finally {
            inflater.close()
        }
    }

    @Test
    fun tinyAndEmptyChunksWork() {
        val chunks = listOf(byteArrayOf(42), ByteArray(0), byteArrayOf(1, 2, 3), ByteArray(0))
        val frames = deflate(chunks)
        assertArrayEquals(byteArrayOf(42, 1, 2, 3), inflate(frames))
    }

    @Test
    fun offsetsInTheSourceBufferAreHonoured() {
        val src = ByteArray(1000) { (it % 10).toByte() }
        val d = ChunkDeflater(1000)
        val n = d.compress(src, 100, 500)
        val frame = d.buffer.copyOfRange(5, 5 + n)
        d.close()
        assertArrayEquals(src.copyOfRange(100, 600), inflate(listOf(frame)))
    }

    @Test
    fun decompressionBombsAreStopped() {
        val zeros = ByteArray(8 * 1024 * 1024)
        val d = ChunkDeflater(zeros.size)
        val n = d.compress(zeros, 0, zeros.size)
        val frame = d.buffer.copyOfRange(5, 5 + n)
        d.close()
        assertTrue("tiny on the wire: $n", n < 100_000)
        assertThrows(ProtocolException::class.java) { inflate(listOf(frame), cap = 4 * 1024 * 1024) }
        // the same data is fine when the cap allows it
        assertEquals(zeros.size, inflate(listOf(frame), cap = 9 * 1024 * 1024).size)
    }

    @Test
    fun corruptCompressedDataIsAProtocolError() {
        // valid zlib header followed by a reserved block type
        val bad = byteArrayOf(0x78, 0x9C.toByte(), 0xFF.toByte(), 0xFF.toByte(), 0xFF.toByte(), 0xFF.toByte())
        assertThrows(ProtocolException::class.java) { inflate(listOf(bad)) }
        // not even a zlib header
        assertThrows(ProtocolException::class.java) { inflate(listOf(byteArrayOf(1, 2, 3, 4, 5, 6, 7, 8))) }
    }

    @Test
    fun policySkipsFormatsThatAreAlreadyCompressed() {
        for (name in listOf("IMG_0001.JPG", "a/b/photo.jpeg", "clip.mp4", "song.mp3", "archive.zip", "backup.tar.gz",
            "app.apk", "bundle.aeroapks", "doc.pdf", "report.docx", "x.7z", "pic.heic", "music.flac")) {
            assertFalse(name, CompressionPolicy.shouldCompress(name, 10_000_000))
        }
        for (name in listOf("notes.txt", "data.csv", "dump.json", "code.kt", "movie.srt", "image.bmp", "README", "dir.jpg/readme", "log.txt.1")) {
            assertTrue(name, CompressionPolicy.shouldCompress(name, 10_000_000))
        }
    }

    @Test
    fun policySkipsTinyFiles() {
        assertFalse(CompressionPolicy.shouldCompress("notes.txt", 0))
        assertFalse(CompressionPolicy.shouldCompress("notes.txt", 511))
        assertTrue(CompressionPolicy.shouldCompress("notes.txt", 512))
    }
}
